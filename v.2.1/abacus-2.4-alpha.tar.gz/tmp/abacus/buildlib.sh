#!/bin/bash

cd abacus-2.4-alpha/lib/linux20-gcc29/
./make-lib cplex80
./make-lib cplex65
./make-lib soplex

