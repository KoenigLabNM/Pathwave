#!/usr/bin/perl -i

while (<>) {
  if (s#/\*[0-9:]+\*/##g) {
    next if /^\s*$/;
  }
  next if /^#line \d+/;
  print;
}
