# Thomas lange 8/1993
while (<>) {
$ver = 1  if /begin{verbatim/;
$ver = 0  if /end{verbatim/;
$tab = 1  if /begin{tabbing/;
$tab = 0  if /end{tabbing/;

   s/&/\\&/g  if $tab;
   s/_/\\_/g if $tab;
   s/#/\\#/g if $tab;

   s/_\|/\\_\|/g;
   s/ABA_/ABA\\_/g unless $ver;
   s/CPLUSPLUS\//CPLUSPLUS/g;
   s/GPLUSPLUS\//GPLUSPLUS/g;

   s/\|([^|]*)\|/{\\tt $1}/g;
   s/@\*1//g;
   s/@\*\*//g;
   s/@,\ //g;
   s/@[\[\]]\ //g;
   s/@[\ \*,\/\[#\]]//g;
   print;
}
