#!/usr/bin/perl -i

while (<>) {
   s/:\s*:/::/g;
   print;
}
