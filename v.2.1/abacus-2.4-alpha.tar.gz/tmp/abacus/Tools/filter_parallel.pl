#!/usr/bin/perl
#
# This filter removes all text of a *.w file which is specific to the
# parallel version of ABACUS, when the ABACUS_PARALLEL is defined.
#
# - boehm

# state
$abapar=0;     # inside #ifdef ABACUS_PARALLEL ... #endif block?
$echo=1;       # output the input lines?
$level=0;      # number of nested #ifdef directives

while (<>) {
  if ($abapar==0) {
    if (/^#ifdef ABACUS_PARALLEL/) { $abapar=1; $echo=0; next; }
    if (/^#ifndef ABACUS_PARALLEL/) { $abapar=1; $echo=1; next; }
  }
  else {
    if ($level==0) {
      if (/^#else/) { $echo=1-$echo; next; }
      if (/^#endif/) { $abapar=0; $echo=1; next; }
    }
    # $level>=0
    if (/^#if/) { $level++; }
    if (/^#endif/) { $level--; }
    #
    if (/^#ifn?def ABACUS_PARALLEL/) {
      print stderr "error: nested #ifdef ABACUS_PARALLEL\n";
    }
  }
  if ($echo==1) {
    print $_;
  }
}
