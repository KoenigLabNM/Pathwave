/*@ ----------------------------------------------------------------------------

   Class #SPxAggregateSM#

   Identification:
   $Id: spxaggregatesm.hh,v 1.1 1998/07/16 12:11:32 boehm Exp $

   Program history:
   $Log: spxaggregatesm.hh,v $
   Revision 1.1  1998/07/16 12:11:32  boehm
   *** empty log message ***


    ----------------------------------------------------------------------------
*/

#ifndef DEF_SPxAggregateSM_H		// prevent multiple includes
#define DEF_SPxAggregateSM_H

//@ ----------------------------------------------------------------------------
/*  \Section{Imports}
    Import required system include files ...
 */
#include <assert.h>


/*  ... and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxsimplifier.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxsimplifier/spxsimplifier.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** Remove redundant row and columns. 
    This \Ref{SPxSimplifier} thries to eliminat redundant rows or columns from
    its loaded \Ref{SPxLP}.
 */
class SPxAggregateSM : public SPxSimplifier
{
private:
    double	delta ;
    SPxLP*	lp ;

protected:
    int		eliminate( const SVector& row, double b ) ;

public:
	/// 
    double	maxFill ;
	/// 
    double	stability ;
	/// 
    void	load( SPxLP* ) ;
	/// 
    void	unload( ) ;
	/// 
    SPxLP*	loadedLP() const 		{ return lp ; }
	/// 
    int		simplify( ) ;
	/// 
    void	unsimplify( ) ;
	/// 
    double	value( double x )	{ return x + lp->spxSense()*delta ; }
} ;

#endif // #DEF_SPxAggregateSM_H#
