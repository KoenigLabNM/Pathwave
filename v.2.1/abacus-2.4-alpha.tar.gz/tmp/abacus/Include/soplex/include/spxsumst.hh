/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #spxsumst#

   Identification:
   $Id: spxsumst.hh,v 1.1 1998/07/16 12:11:40 boehm Exp $

   Program history:
   $Log: spxsumst.hh,v $
   Revision 1.1  1998/07/16 12:11:40  boehm
   *** empty log message ***


    ----------------------------------------------------------------------------
*/

#ifndef DEF_spxsumst_H		// prevent multiple includes
#define DEF_spxsumst_H

//@ ----------------------------------------------------------------------------
/*  \Section{Imports}
    Import required system include files ...
 */
#include <assert.h>


/*  ... and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxvectorst.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxvectorst/spxvectorst.hh"

#endif	// #SUBDIR_INCLUDE#


//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** Simple heuristic #SPxStarter#.
    Testing version of an #SPxVectorST# using a very simplistic heuristic to
    build up an approximated solution vector.
 */
class SPxSumST : public SPxVectorST
{
private:
protected:
    void	setupWeights( SoPlex& base ) ;
public:
	/// 
    SPxSumST()	{}
} ;

#endif // #DEF_spxsumst_H#
