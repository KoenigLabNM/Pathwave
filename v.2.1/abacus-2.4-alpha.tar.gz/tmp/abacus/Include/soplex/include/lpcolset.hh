/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #LPColSet#

   Identification:
   $Id: lpcolset.hh,v 1.1 1998/07/16 12:11:29 boehm Exp $

   Program history:
   $Log: lpcolset.hh,v $
   Revision 1.1  1998/07/16 12:11:29  boehm
   *** empty log message ***

// Revision 2.5  1996/01/08  12:22:42  bzfwunde
// Moved to new non-GNU generic Makefile environment
//
// Revision 2.4  1995/11/21  16:20:30  bzfwunde
// introduced SUBDIR_INCLUDE
//
// Revision 2.3  1995/10/13  15:28:12  bzfwunde
// minor improvements
//
// Revision 2.2  1995/06/15  13:14:14  bzfwunde
// minor changes (friend declaration)
//
// Revision 2.1  1995/03/31  15:00:15  bzfwunde
// tested Version running with set packing
//
// Revision 1.1.1.1  1995/03/03  19:09:20  bzfwunde
// initial version
//
// Revision 1.1.1.1  1995/01/14  19:55:42  pus
// initial, tested version
//
// Revision 1.1.1.1  1995/01/12  17:34:26  bzfwunde
// initial tested version
//

    ----------------------------------------------------------------------------
*/
#ifndef DEFlpcolset		// prevent multiple includes
#define DEFlpcolset


//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "lpcol.hh"
#include "dvector.hh"
#include "svset.hh"

#else 	// #SUBDIR_INCLUDE#

#include "lpcol/lpcol.hh"
#include "dvector/dvector.hh"
#include "svset/svset.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** Set of LP columns. 
    Class #LPColSet# implements a set of #LPCol#s. Unless for memory
    limitations, any number of #LPCol#s may be #add#ed to an #LPColSet#. Single
    or multiple #LPCol#s may be #add#ed to an #LPColSet#, where each method
    #add()# comes with two different signatures. One with an one without a
    parameter, used for returning the #Key#s assigned to the new #LPCol#s
    by the set. See \Ref{DataSet::Key} for a more detailed description of the
    concept of #Key#s. For the concept of renumbering #LPCol#s within an
    #LPColSet# after removal of some #LPCol#s see \Ref{DataSet}.

    @see	DataSet, DataSet::Key
 */
class LPColSet : protected SVSet
{
private:
    friend class	GlobalPointer ;
    friend class	DoPlex ;
    DVector	low, up, object ;

public:
	/// 
    typedef SVSet::Key	Key ;

    /**@name Inquiry */
    //@{
	/// Return maximum number of #LPCol#s currently in #LPColSet#. 
    int			num() const			{ return SVSet::num() ; }
	/// Return maximum number of #LPCol#s currently fitting into #LPColSet#. 
    int			max() const			{ return SVSet::max() ; }

	/// 
    const Vector&	obj() const			{ return object ; }
	/// return vector of #obj# values. 
    Vector&		obj()				{ return object ; }

	/// 
    double		obj( int i ) const		{ return object[i] ; }
	/// return #obj# of #i#-th #LPCol# in #LPColSet#. 
    double&		obj( int i )			{ return object[i] ; }

	/// 
    double		obj( Key k ) const		{ return object[number(k)] ; }
	/// return #obj# of #k#-th #LPCol# in #LPColSet#. 
    double&		obj( Key k )			{ return object[number(k)] ; }

	/// 
    const Vector&	lower() const			{ return low ; }
	/// return vector of #lower# values. 
    Vector&		lower()				{ return low ; }

	/// 
    double		lower( int i ) const		{ return low[i] ; }
	/// return #lower# of #i#-th #LPCol# in #LPColSet#. 
    double&		lower( int i )			{ return low[i] ; }

	/// 
    double		lower( Key k ) const		{ return low[number(k)] ; }
	/// return #lower# of #k#-th #LPCol# in #LPColSet#. 
    double&		lower( Key k )			{ return low[number(k)] ; }

	/// 
    const Vector&	upper() const			{ return up ; }
	/// return vector of #upper# values. 
    Vector&		upper()				{ return up ; }

	/// 
    double		upper( int i ) const		{ return up[i] ; }
	/// return #upper# of #i#-th #LPCol# in #LPColSet#. 
    double&		upper( int i )			{ return up[i] ; }

	/// 
    double		upper( Key k ) const		{ return up[number(k)] ; }
	/// return #upper# of #k#-th #LPCol# in #LPColSet#. 
    double&		upper( Key k )			{ return up[number(k)] ; }

	/// 
    SVector&		colVector( int i )		{ return operator[](i) ; }
	/// return #colVector# of #i#-th #LPCol# in #LPColSet#. 
    const SVector&	colVector( int i ) const	{ return operator[](i) ; }

	/// 
    const SVector&	colVector( Key k ) const	{ return operator[](k) ; }
	/// return #colVector# of #k#-th #LPCol# in #LPColSet#. 
    SVector&		colVector( Key k )		{ return operator[](k) ; }

	/// return #Key# of #i#-th #LPCol# in #LPColSet#. 
    Key		key( int i ) const			{ return SVSet::key(i) ; }
	/// return number of #k#-th #LPCol# in #LPColSet#. 
    int		number( Key k ) const			{ return SVSet::number(k) ; }
	/// does #Key k# belong to #LPColSet#?. 
    int		has( Key k ) const			{ return SVSet::has(k) ; }
    //@}


    /**@name Extension
	All extension methods come with two signatures, one of which providing a
	parameter to return the assigned #Key#(s). See \Ref{DataSet} for a more
	detailed description. All extension methods are designed to
	automatically realloc memory if required.
     */
    //@{
	/// 
    void	add(const LPCol& col)
    		{
		    Key	k ;
		    add(k, col) ;
		}
	/// add #col# to #LPColSet#. 
    void	add(Key& key, const LPCol& col)
    		{   add( key, col.obj(), col.lower(),
			      col.colVector(), col.upper() ) ;  
		}

	/// 
    void	add(double obj, double lower, const SVector& colVector, double upper)
    		{
		    Key	k ;
		    add(k, obj, lower, colVector, upper) ;
		}
	/** add #LPCol# consisting of #lower#, #colVector# and #upper# to
	    #LPColSet#
	 */
    void	add    (Key&		key,
    			double		obj,
			double		lower,
			const SVector&	colVector,
			double		upper ) ;

	/// 
    void	add( const LPColSet& set ) ;
	/// add all #LPCol#s of #set# to #LPColSet#. 
    void	add(Key key[], const LPColSet& set ) ;

	/// 
    void	add2(Key k, int n, int idx[], double val[])
    		{   SVSet::add2(colVector(k), n, idx, val) ; }
	/// add #n# nonzero (#idx#, #val#) to #i#-th #colVector#.. 
    void	add2(int i, int n, int idx[], double val[])
    		{   SVSet::add2(colVector(i), n, idx, val) ; }

	/// 
    SVector&	create(int nonzeros=0, double obj=1, double lw=0, double upp=1)
    		{
		    Key k ;
		    return create( k, nonzeros, obj, lw, upp ) ;
		}
	/** Create new #LPCol# with specified arguments and return a reference
	    to its column vector.
	 */
    SVector&	create(Key& nkey, int nonzeros=0, double obj=1, double low=0, double up=1) ;
    //@}


    /**@name Shrinking
	See \Ref{DataSet} for a description of the renumbering of the remaining
	#LPCol#s in a #LPColSet# after the call of a removal method.
     */
    //@{
	/// remove #i#-th #LPCol#. 
    void	remove(int i) ;
	/// remove #k#-th #LPCol#. 
    void	remove(Key k)
    		{   remove( number(k) ) ;   }


	/// remove multiple elements. 
    void	remove(int perm[]) ;

	/// 
    void	remove(Key keys[], int n)
    		{
		    DataArray<int>	perm(num()) ;
		    remove( keys, n, perm ) ;
		}

	/// 
    void	remove(int nums[], int n)
    		{
		    DataArray<int>	perm(num()) ;
		    remove( nums, n, perm ) ;
		}

	/// 
    void	remove(Key keys[], int n, int* perm) ;

	/// remove #n# #LPCol#s from set. 
    void	remove(int nums[], int n, int* perm) ;

	/// remove all #LPCol#s. 
    void	clear() ;
    //@}


    /**@name Memory Management
     *  See \Ref{SVSet} for a description of the memory management methods.
     */
    //@{
	/// 
    void	reMax(int newmax = 0)
    		{
		    SVSet::reMax ( newmax ) ;
		    up.reSize    ( max() ) ;
		    low.reSize   ( max() ) ;
		    object.reSize( max() ) ;
		}
	/// used nonzero memory. 
    int		memSize() const			{ return SVSet::memSize() ; }

	/// length of nonzero memory. 
    int		memMax() const			{ return SVSet::memMax() ; }

	/// reset length of nonzero memory. 
    void	memRemax(int newmax)	 	{ SVSet::memRemax(newmax) ; }

	/// garbage collection in nonzero memory. 
    void	memPack() 			{ SVSet::memPack() ; }


	    /// 
	LPColSet&	operator=( const LPColSet& rs )
	{
	    SVSet::operator=(rs) ;
	    low    = rs.low ;
	    up     = rs.up ;
	    object = rs.object ;
	    return *this ;
	}

	/// 
    		LPColSet( int max = -1, int memmax = -1 )
		    : SVSet(max, memmax), low(0), up(0), object(0)		{ }
    //@}

	/// 
    int		isConsistent() const ;
} ;


#endif // #DEFlpcolset#
