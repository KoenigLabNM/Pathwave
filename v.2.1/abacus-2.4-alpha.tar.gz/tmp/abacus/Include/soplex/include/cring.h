/*@ ----------------------------------------------------------------------------
 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 

   Identification:
   $Id: cring.h,v 1.1 1998/07/16 12:11:25 boehm Exp $

   Program history:
   $Log: cring.h,v $
   Revision 1.1  1998/07/16 12:11:25  boehm
   *** empty log message ***


    ----------------------------------------------------------------------------
 */


/***************************************************************
		    Double linked ring
 ***************************************************************/

#define isZero(val, eps)	((val)<(eps) && -(val)<(eps))
#define isNonZero(val, eps)	((val)>(eps) || -(val)>(eps))

#define initDR(ring)	((ring).prev = (ring).next = &(ring))

#define init2DR(elem, ring)					\
{								\
    (elem).next = (ring).next ;					\
    (elem).next->prev = &(elem) ;				\
    (elem).prev = &(ring) ;					\
    (ring).next = &(elem) ;					\
}

#define	removeDR(ring)						\
{								\
    (ring).next->prev = (ring).prev ;				\
    (ring).prev->next = (ring).next ;				\
}

#define mergeDR(ring1, ring2)					\
{								\
    Dring	*tmp ;						\
    tmp = (ring1).next ;					\
    (ring1).next = (ring2).next ;				\
    (ring2).next = tmp ;					\
    (ring1).next->prev = &(ring1) ;				\
    (ring2).next->prev = &(ring2) ;				\
}
