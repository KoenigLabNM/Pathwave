/*@ -----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


    DIdxSet

    Identification:
    $Id: didxset.hh,v 1.1 1998/07/16 12:11:26 boehm Exp $

    Program history:
    $Log: didxset.hh,v $
    Revision 1.1  1998/07/16 12:11:26  boehm
    *** empty log message ***

// Revision 2.5  1996/01/08  12:20:27  bzfwunde
// Moved to new non-GNU generic Makefile environment
//
// Revision 2.4  1995/11/21  16:17:09  bzfwunde
// introduced SUBDIR_INCLUDE
//
// Revision 2.3  1995/10/13  15:23:46  bzfwunde
// minor improvements
//
// Revision 2.2  1995/07/21  16:59:39  bzfwunde
// fixed copy constructor bug ...
//
// Revision 2.1  1995/03/31  14:56:43  bzfwunde
// tested Version running with set packing
//
// Revision 1.2  1995/03/03  18:54:01  bzfwunde
// minor bug fixes and
// changes to the interface
//
// Revision 1.1.1.1  1995/01/14  19:59:54  pus
// Total checkin of a stably running version of DoPlex
//

   -----------------------------------------------------------------------------
*/

/*	\Section{DIdxSet}
*/

#ifndef DEFdidxset	// Verhindern mehrfacher #include "didxset.hh"#.
#define DEFdidxset

//	Ben\"otigte Include-Dateien:
#include <assert.h>
#include <stdlib.h>

//	Ben\"otigte Klassen:
#ifndef	SUBDIR_INCLUDE
#include "idxset.hh"
#else	// #SUBDIR_INCLUDE#
#include "idxset/idxset.hh"
#endif	// #SUBDIR_INCLUDE#


/** dynamic index set. 
    Class #DIdxSet# provids dynamic \Ref{IdxSet} in the sense, that no
    restrictions are posed on the use of methods #add()#. However, method
    #indexMem()# has been moved to the #private# members. This is because
    #DIdxSet# adds it own memory managment to class #IdxSet# and the user must
    not interfer with it.

    Upon construction of an #DIdxSet#, memory is allocated automatically. The
    memory consumption can be controlled with methods #max()# and #setMax()#.
    Finally, the destructor will release all allocated memory.
*/
class DIdxSet : public IdxSet
{
private:
    int*&	indexMem() ;

public:
/*
    Die Implementierung st\"utzt sich voll auf die Datenstrukturen der
    Basisklasse #IdxSet#. Lediglich die Methoden, bei denen Dynamizit\"at
    hinzugef\"ugt wird, m\"ussen \"uberlagert werden.
*/
	/// assignment operator. 
    DIdxSet&	operator=(const IdxSet& sv)
		{
		    int n = sv.size() ;
		    if(max() - size() < n)
			setMax(size() + n) ;
		    IdxSet::operator=(sv) ;
		    return *this ;
		}

	/// assignment operator. 
    DIdxSet&	operator=(const DIdxSet& sv)
		{ return operator=(IdxSet(sv)) ; }

	/// add #n# uninitialized indices. 
    void	add(int n)
		{
		    if(max() - size() < n)
			setMax(size() + n) ;
		    IdxSet::add(n) ;
		}

	/// add all indices from #sv#. 
    void	add(const IdxSet& sv)
		{
		    int n = sv.size() ;
		    if(max() - size() < n)
			setMax(size() + n) ;
		    IdxSet::add(sv) ;
		}

	/// add #n# indices from #i#. 
    void	add(int n, const int *i)
		{
		    if(max() - size() < n)
			setMax(size() + n) ;
		    IdxSet::add(n, i) ;
		}

    	/** set maximum number of indices. 
	    This methods resets the memory consumption of the #DIdxSet# to
	    #newmax#. However, if #newmax < size()#, it is reset to #size()#
	    only.
	 */
    void	setMax(int newmax=1) ;

    	/// 
    DIdxSet(const IdxSet& old) ;
    	/// 
    DIdxSet(const DIdxSet& old) ;
    	/// 
    DIdxSet(int n = 8) ;
    	/// 
    ~DIdxSet() ;
} ;

#endif	// #DEFdidxset#

