/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #SPxDefaultPR#

   Identification:
   $Id: spxdefaultpr.hh,v 1.1 1998/07/16 12:11:33 boehm Exp $

   Program history:
   $Log: spxdefaultpr.hh,v $
   Revision 1.1  1998/07/16 12:11:33  boehm
   *** empty log message ***

// Revision 1.5  1996/01/08  12:32:03  bzfwunde
// Moved to new non-GNU generic Makefile environment
//
// Revision 1.4  1995/11/21  16:27:37  bzfwunde
// introduced SUBDIR_INCLUDE
//
// Revision 1.3  1995/10/13  15:36:47  bzfwunde
// minor improvements
//
// Revision 1.2  1995/05/17  11:44:39  bzfwunde
// introduced SSVector
//
// Revision 1.1.1.1  1995/03/31  15:04:43  bzfwunde
// tested Version running with set packing
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFspxdefaultpr		// prevent multiple includes
#define DEFspxdefaultpr

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxpricer.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxpricer/spxpricer.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** default pricer. 
    Class #SPxDefaultPR# is an implementation class for #SPxPricer# implementing
    Dantzig's the default pricing strategy, i.e. maximal/minimal reduced cost or
    maximal violated constraint.
 */
class SPxDefaultPR : public SPxPricer
{
protected:
    SoPlex*	thesolver ;
    double	theeps ;

public:
	/// 
    SoPlex*	solver() const				{ return thesolver ; }

	/// 
    double	epsilon() const				{ return theeps ; }
	/// 
    void	setEpsilon( double eps )		{ theeps = eps ; }

	/// 
    void	load( SoPlex* solver )			{ thesolver = solver ; }

	/// 
    void	clear()					{ thesolver = 0 ; }

	/// 
    void	setType( SoPlex::Type tp )
		{ (void)tp ; }
	/// 
    void	setRep( SoPlex::Representation rep )
		{ (void)rep ; }

	/// 
    int 	selectLeave(double& bst, int start, int incr) ;
	/// 
    int		selectLeave() ;
	/// 
    void	left4(int n, SoPlex::Id id)
		{ (void)n ; (void)id ; }

	/// 
    SoPlex::Id	selectEnter(double& bst, int start1, int incr1, int start2, int incr2) ;
	/// 
    SoPlex::Id	selectEnter() ;
	/// 
    void	entered4(SoPlex::Id id, int n)
		{ (void)n ; (void)id ; }


	/// 
    void	addedVecs  ( int n )
		{ (void)n ; }
	/// 
    void	addedCoVecs( int n )
		{ (void)n ; }


	/// 
    void	removedVec(int i)
		{ (void)i ; }
	/// 
    void	removedVecs(const int perm[])
		{ (void)perm ; }
	/// 
    void	removedCoVec(int i)
		{ (void)i ; }
	/// 
    void	removedCoVecs(const int perm[])
		{ (void)perm ; }


	/// 
    void	changeObj( const Vector& newObj )
		{ (void)newObj ; }
	/// 
    void	changeObj( int i, double newVal )
		{ (void)newVal ; (void)i ; }
	/// 
    void	changeLower( const Vector& newLower )
		{ (void)newLower ; }
	/// 
    void	changeLower( int i, double newLower )
		{ (void)i ; (void)newLower ; }
	/// 
    void	changeUpper( const Vector& newUpper )
		{ (void)newUpper ; }
	/// 
    void	changeUpper( int i, double newUpper )
		{ (void)i ; (void)newUpper ; }
	/// 
    void	changeLhs( const Vector& newLhs )
		{ (void)newLhs ; }
	/// 
    void	changeLhs( int i, double newLhs )
		{ (void)i ; (void)newLhs ; }
	/// 
    void	changeRhs( const Vector& newRhs )
		{ (void)newRhs ; }
	/// 
    void	changeRhs( int i, double newRhs )
		{ (void)i ; (void)newRhs ; }
	/// 
    void	changeRow( int i, const LPRow& newRow )
		{ (void)i ; (void)newRow ; }
	/// 
    void	changeCol( int i, const LPCol& newCol )
		{ (void)i ; (void)newCol ; }
	/// 
    void	changeElement( int i, int j, double val )
		{ (void)i ; (void)j ; (void)val ; }
	/// 
    void	changeSense( SoPlex::Sense sns )
		{ (void)sns ; }
} ;


#endif // #DEFspxdefaultprr#
