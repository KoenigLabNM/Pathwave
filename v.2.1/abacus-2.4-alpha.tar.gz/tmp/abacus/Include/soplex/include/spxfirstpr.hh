/*@ ----------------------------------------------------------------------------

   Class #SPxFirstPR#

   Identification:
   $Id: spxfirstpr.hh,v 1.1 1998/07/16 12:11:35 boehm Exp $

   Program history:
   $Log: spxfirstpr.hh,v $
   Revision 1.1  1998/07/16 12:11:35  boehm
   *** empty log message ***

// Revision 1.1.1.1  1996/01/08  12:29:47  bzfwunde
// Initial version of a pricer that selects the first violated bound
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFSPxFirstPR		// prevent multiple includes
#define DEFSPxFirstPR

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	   SUBDIR_INCLUDE

#include "spxpricer.hh"

#else 	//@ SUBDIR_INCLUDE

#include "spxpricer/spxpricer.hh"

#endif	//@ SUBDIR_INCLUDE



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/**
    #SPxPricer# implementation class that selects the first violated bound it
    finds as pivot. For the #ENTER#ing Simplex this is the ``most partial''
    pricing possible.
 */
class SPxFirstPR : public SPxPricer
{
private:
    int		lastIdx ;
    SoPlex::Id	lastId ;
    int		first( const double* test, int start, int end ) ;

    int		firstP( int start, int end ) ;

protected:
    SoPlex*	thesolver ;
    double	theeps ;

public:
	///
    SoPlex*	solver() const				{ return thesolver ; }

	///
    double	epsilon() const				{ return theeps ; }
	///
    void	setEpsilon( double eps )		{ theeps = eps ; }

	///
    void	load( SoPlex* solver )			{ thesolver = solver ; }

	///
    void	clear()					{ thesolver = 0 ; }

	///
    void	setType( SoPlex::Type tp ) ;
	///
    void	setRep( SoPlex::Representation rep )
		{ (void)rep ; }

	///
    int		selectLeave() ;
	///
    void	left4(int n, SoPlex::Id id)
		{ (void)n ; (void)id ; }

	///
    SPxLP::Id	selectEnter() ;
	///
    void	entered4(SoPlex::Id id, int n)
		{ (void)n ; (void)id ; }


	///
    void	addedVecs  ( int n )
		{ (void)n ; }
	///
    void	addedCoVecs( int n )
		{ (void)n ; }


	///
    void	removedVec(int i)
		{ (void)i ; }
	///
    void	removedVecs(const int perm[])
		{ (void)perm ; }
	///
    void	removedCoVec(int i)
		{ (void)i ; }
	///
    void	removedCoVecs(const int perm[])
		{ (void)perm ; }


	///
    void	changeObj( const Vector& newObj )
		{ (void)newObj ; }
	///
    void	changeObj( int i, double newVal )
		{ (void)newVal ; (void)i ; }
	///
    void	changeLower( const Vector& newLower )
		{ (void)newLower ; }
	///
    void	changeLower( int i, double newLower )
		{ (void)i ; (void)newLower ; }
	///
    void	changeUpper( const Vector& newUpper )
		{ (void)newUpper ; }
	///
    void	changeUpper( int i, double newUpper )
		{ (void)i ; (void)newUpper ; }
	///
    void	changeLhs( const Vector& newLhs )
		{ (void)newLhs ; }
	///
    void	changeLhs( int i, double newLhs )
		{ (void)i ; (void)newLhs ; }
	///
    void	changeRhs( const Vector& newRhs )
		{ (void)newRhs ; }
	///
    void	changeRhs( int i, double newRhs )
		{ (void)i ; (void)newRhs ; }
	///
    void	changeRow( int i, const LPRow& newRow )
		{ (void)i ; (void)newRow ; }
	///
    void	changeCol( int i, const LPCol& newCol )
		{ (void)i ; (void)newCol ; }
	///
    void	changeElement( int i, int j, double val )
		{ (void)i ; (void)j ; (void)val ; }
	///
    void	changeSense( SoPlex::Sense sns )
		{ (void)sns ; }
} ;


#endif // |DEFSPxFirstPR|
