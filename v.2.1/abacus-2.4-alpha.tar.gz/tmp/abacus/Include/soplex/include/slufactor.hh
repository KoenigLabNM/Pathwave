/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #SLUFactor#

   Identification:
   $Id: slufactor.hh,v 1.1 1998/07/16 12:11:31 boehm Exp $

   Program history:
   $Log: slufactor.hh,v $
   Revision 1.1  1998/07/16 12:11:31  boehm
   *** empty log message ***

// Revision 1.5  1996/03/21  11:07:10  bzfwunde
// New Makefile
// Many preformance improvents
// Very Sparse Right Hand-side support
//
// Revision 1.4  1996/01/08  12:28:16  bzfwunde
// Moved to new non-GNU generic Makefile environment
// changed some stupid file names
//
// Revision 1.3  1995/11/21  16:25:20  bzfwunde
// - changed interface for solve2 methods
// - introduced SUBDIR_INCLUDE
//
// Revision 1.2  1995/10/13  15:34:27  bzfwunde
// minor improvements for better performance
//
// Revision 1.1.1.1  1995/05/23  07:52:36  bzfwunde
// Reinitialized CVS module of C++ embedded C sparse LU factorization
// and related functions
//
// Revision 2.2  1995/05/17  11:40:45  bzfwunde
// - improved factorization
// - solve methods implemented using pointers
//
// Revision 2.1  1995/03/31  15:01:44  bzfwunde
// tested Version running with set packing
//
// Revision 1.4  1995/03/09  15:58:54  bzfwunde
// Tested version: Running even on CRAY :-)
//
// Revision 1.3  1995/03/03  18:55:40  bzfwunde
// bug fixes
// improved performance
//
// Revision 1.3  1995/01/14  20:00:21  pus
// Total checkin of a stably running version of DoPlex
//
// Revision 1.2  1994/12/15  15:45:55  pus
// - Interface documented in c++doc
// - removed garbage files
//

    ----------------------------------------------------------------------------
*/
#ifndef DEFslufactor
#define DEFslufactor


//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "dvector.hh"
#include "slinsolver.hh"

#else

#include "dvector/dvector.hh"
#include "slinsolver/slinsolver.hh"

#endif

extern "C"
{
#include "clutypes.h"
#include "clumembers.h"
}


#define MAXUPDATES	1000		// maximum nr. of factorization updates
					// allowed before refactorization .


//@ ----------------------------------------------------------------------------
/*	\Section{Class Declaration}
 */
/** Sparse LU factorization.
 *  This is an implementation class for \Ref{SLinSolver} using sparse LU
 *  factorization.
 */
class SLUFactor : public SLinSolver, private CLUFactor
{
public:
    	/// how to perform #change# method. 
    enum UpdateType
    {	    /// 
	ETA	= 0,
	    /// 
	FOREST_TOMLIN
    } ;

protected:
    void	assign(const SLUFactor& old) ;
    void	freeAll() ;
    void	changeEta( int idx, SSVector& eta ) ;

    DVector	vec ;
    SSVector	ssvec ;

    int		usetup ;	// 1 if update vector has been setup
    UpdateType	uptype ;
    SSVector	eta ;
    SSVector	forest ;
    double	lastThreshold ;

public:
	/// 
    typedef SLinSolver::Status	Status ;

    /**@name Control Parameters */
    //@{
	    /// minimum threshold to use. 
	double	minThreshold ;

	    /// #|x| < epsililon# is considered to be 0. 
	double	epsilon ;

	    /// sets the number of pivot candidates for block pivoting. 
	int	candidates ;

	    /// minimum stability to acchieve by setting threshold. 
	double	minStability ;

	    /// 
	UpdateType	utype()				{ return uptype ; }

	    /** Set UpdateType. 
	     *  The new #UpdateType# becomes valid only after the next call to
	     *  method #load()#.
	     */
	void		setUtype( UpdateType tp )	{ uptype = tp ; }
    //@}

    /**@name derived from \Ref{SLinSolver}
     *  See documentation of \Ref{SLinSolver} for a documentation of these
     *  methods.
     */
    //@{
	    /// 
	void	clear() ;
	    /// 
	int	dim() const		{ return thedim ; }
	    /// 
	int	memory() const		{ return nzCnt + l.start[l.firstUnused]; }
	    /// 
	Status	status() const		{ return (Status)stat ; }
	    /// 
	double	stability() const ;

	    /// 
	Status	load( const SVector* vec[], int dim ) ;

	    /// 
	void	solve2right( Vector& x, Vector& b ) const ;
	    /// 
	void	solve2right( Vector& x, SSVector& b ) const ;
	    /// 
	void	solve2right( SSVector& x, Vector& b ) const ;
	    /// 
	void	solve2right( SSVector& x, SSVector& b ) const ;

	    /// 
	void	solveRight ( Vector&	    x,
			     const Vector&  b 	) const ;
	    /// 
	void	solveRight ( Vector&	    x,
			     const SVector& b 	) const ;
	    /// 
	void	solveRight ( SSVector&	    x,
			     const Vector&  b 	) const ;
	    /// 
	void	solveRight ( SSVector&	    x,
			     const SVector& b 	) const ;

	    /// 
	void	solveRight4update( SSVector&      x,
				   const SVector& b ) ;
	    /// 
	void	solve2right4update( SSVector&      x,
				    Vector&        two,
				    const SVector& b,
				    SSVector&      rhs ) ;

	    /// 
	void	solve2left( Vector& x, Vector& b ) const ;
	    /// 
	void	solve2left( Vector& x, SSVector& b ) const ;
	    /// 
	void	solve2left( SSVector& x, Vector& b ) const ;
	    /// 
	void	solve2left( SSVector& x, SSVector& b ) const ;

	    /// 
	void	solveLeft ( Vector&        x,
			    const Vector& b 	) const ;
	    /// 
	void	solveLeft ( Vector&        x,
			    const SVector& b 	) const ;
	    /// 
	void	solveLeft ( SSVector&      x,
			    const Vector&  b 	) const ;
	    /// 
	void	solveLeft ( SSVector&      x,
			    const SVector& b 	) const ;

	    /// 
	void	solveLeft ( SSVector&      x,
			    Vector&        two,
			    const SVector& b,
			    SSVector&      rhs2 ) const ;

	    /// 
	Status	change( int idx, const SVector& subst, const SSVector* eta=0 ) ;
    //@}

	/** A zero vector.
	 *  Return a zero #Vector# of the factorizations dimension. This may
	 *  {\em temporarily} be used by other the caller in order to save
	 *  memory (management overhead), but {\em must be reset to 0} when a
	 *  method of #SLUFactor# is called.
	 */
    Vector&	zeroVec() const		{ return ((SLUFactor*)this)->vec ; }

    	/// 
    void	SLUFactor::dump() const ;
	/// 
    int		isConsistent() const ;
	/// 
    SLUFactor&	operator=(const SLUFactor& old) ;
	/// 
    SLUFactor(const SLUFactor& old)
	: vec   ( old.vec )
	, ssvec ( old.ssvec )
	, eta   ( old.eta )
	, forest( old.forest )
    { assign(old) ; }
	/// 
    SLUFactor() ;
	/// 
    virtual ~SLUFactor() ;
} ;

#endif
