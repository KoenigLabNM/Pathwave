/*@ ----------------------------------------------------------------------------

   Class #SPxPenalty#

   Identification:
   $Id: spxpenalty.hh,v 1.1 1998/07/16 12:11:37 boehm Exp $

   Program history:
   $Log: spxpenalty.hh,v $
   Revision 1.1  1998/07/16 12:11:37  boehm
   *** empty log message ***

// Revision 1.6  1996/03/21  11:08:20  bzfwunde
// New Makefile
//
// Revision 1.5  1996/01/08  12:32:17  bzfwunde
// Moved to new non-GNU generic Makefile environment
//
// Revision 1.4  1995/11/21  16:27:55  bzfwunde
// introduced SUBDIR_INCLUDE
//
// Revision 1.3  1995/10/13  15:37:03  bzfwunde
// minor improvements
//
// Revision 1.2  1995/05/17  11:44:56  bzfwunde
// introduced SSVector
//
// Revision 1.1.1.1  1995/03/31  15:08:16  bzfwunde
// tested Version running with set packing
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFspxpenalty		// prevent multiple includes
#define DEFspxpenalty

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required classes
 */
#ifndef	SUBDIR_INCLUDE

#include "spxpricer.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxpricer/spxpricer.hh"

#endif	// #SUBDIR_INCLUDE#


//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** penalty pricer. 
    This implementation class for #SPxPricer# initially sets up penalty values
    for all vector to be in the basis. When pricing, the pivot vectors are
    selected according to these penalties.
 */
class SPxPenalty : public SPxPricer
{
private:
    DVector		cPenalty ;		// column penalties
    DVector		rPenalty ;		// row    penalties

    double		objlength ;		// length of objective vector.
    void		computeCP( int start, int end ) ;
    void		computeRP( int start, int end ) ;

protected:
    SoPlex*	thesolver ;
    double	theeps ;

public:
	/**@name \  */
	/**@name return loaded solver */
    SoPlex*	solver() const				{ return thesolver ; }

	/// bound violations up to #epsilon# are tollerated. 
    double	epsilon() const				{ return theeps ; }
	///
    void	setEpsilon( double eps )		{ theeps = eps ; }

	///
    void	load( SoPlex* base ) ;

	///
    void	clear()					{ thesolver = 0 ; }

	///
    int		selectLeave() ;

	///
    SPxLP::Id	selectEnter() ;


	///
    virtual void	addedVecs  ( int n ) ;
	///
    virtual void	addedCoVecs( int n ) ;


	///
    virtual void	removedVec(int i) ;
	///
    virtual void	removedCoVecs(const int perm[]) ;
	///
    virtual void	removedVecs(const int perm[]) ;
	///
    virtual void	removedCoVec(int i) ;


	///
    void	setType( SoPlex::Type tp )
		{ (void)tp ; }
	///
    void	setRep( SoPlex::Representation rep )
		{ (void)rep ; }
	///
    void	left4(int n, SoPlex::Id id)
		{ (void)n ; (void)id ; }
	///
    void	entered4(SoPlex::Id id, int n)
		{ (void)n ; (void)id ; }

	///
    void	changeObj( const Vector& newObj )
		{ (void)newObj ; }
	///
    void	changeObj( int i, double newVal )
		{ (void)newVal ; (void)i ; }
	///
    void	changeLower( const Vector& newLower )
		{ (void)newLower ; }
	///
    void	changeLower( int i, double newLower )
		{ (void)i ; (void)newLower ; }
	///
    void	changeUpper( const Vector& newUpper )
		{ (void)newUpper ; }
	///
    void	changeUpper( int i, double newUpper )
		{ (void)i ; (void)newUpper ; }
	///
    void	changeLhs( const Vector& newLhs )
		{ (void)newLhs ; }
	///
    void	changeLhs( int i, double newLhs )
		{ (void)i ; (void)newLhs ; }
	///
    void	changeRhs( const Vector& newRhs )
		{ (void)newRhs ; }
	///
    void	changeRhs( int i, double newRhs )
		{ (void)i ; (void)newRhs ; }
	///
    void	changeRow( int i, const LPRow& newRow )
		{ (void)i ; (void)newRow ; }
	///
    void	changeCol( int i, const LPCol& newCol )
		{ (void)i ; (void)newCol ; }
	///
    void	changeElement( int i, int j, double val )
		{ (void)i ; (void)j ; (void)val ; }
	///
    void	changeSense( SPxLP::SPxSense sns )
		{ (void)sns ; }

	///
    int	isConsistent() const ;
} ;


#endif // #DEFspxpenalty#
