/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #cachelpsolver#

   Identification:
   $Id: cachelpsolver.hh,v 1.1 1998/07/16 12:11:23 boehm Exp $

   Program history:
   $Log: cachelpsolver.hh,v $
   Revision 1.1  1998/07/16 12:11:23  boehm
   *** empty log message ***

// Revision 1.2  1995/11/21  16:14:33  bzfwunde
// simple minded implementations
//
// Revision 1.1.1.1  1995/10/24  11:03:38  bzfwunde
// initial version, that compiles but does not do anything usefull.
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFcachelpsolver		// prevent multiple includes
#define DEFcachelpsolver

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	   SUBDIR_INCLUDE

#include "lpsolver.hh"
#include "dvector.hh"
#include "dataarray.hh"

#else

#include "lpsolver/lpsolver.hh"
#include "dvector/dvector.hh"
#include "dataarray/dataarray.hh"

#endif



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** LP solver with result caching.
    Class #CacheLPSolver# provides some caching for some of the data access
    methods of #LPSolver#. E.g. when multiple successive calls to method
    #primal()# occur, only the first call the primal solution vector is really
    constructed. The following calls will return the previously constructed
    vector.
 */
class CacheLPSolver : public LPSolver
{
private:
    DVector			theObj ;
    DVector			thePrimal ;
    DVector			theRdCost ;
    DataArray<signed char>	colBase ;

    DVector			theDual ;
    DVector			theSlack ;
    DataArray<signed char>	rowBase ;

public:
	/// #i#-th value of objective vector. 
    virtual double	obj( int i ) const				= 0 ;

	/// #id#-th value of objective vector. 
    virtual double	obj( ColId id ) const				= 0 ;

	/// return const objective vector. 
    virtual const Vector&	obj() const ;

	/// return const solution vector for primal variables if available. 
    virtual const Vector&	primal() const ;

	/// return const vector of slack variables if available. 
    virtual const Vector&	slacks() const ;

	/// return const solution vector for dual variables if available. 
    virtual const Vector&	dual() const ;

	/// return const vector of reduced costs if available. 
    virtual const Vector&	rdCost() const ;

	/// return row ids if available. 
    virtual void	getRowIds( RowId ids[] ) const ;

	/// return column ids if available. 
    virtual void	getColIds( ColId ids[] ) const ;

	/// return status for primal vars if available. 
    virtual const signed char*	rowBasis() const ;

	/// return status for dual vars if available. 
    virtual const signed char*	colBasis() const ;
} ;

#endif // |DEFcachelpsolver|
