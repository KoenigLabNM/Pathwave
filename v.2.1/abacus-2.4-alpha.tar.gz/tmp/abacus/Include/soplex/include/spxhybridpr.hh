/*@ ----------------------------------------------------------------------------

   Class #SPxHybridPR#

   Identification:
   $Id: spxhybridpr.hh,v 1.1 1998/07/16 12:11:36 boehm Exp $

   Program history:
   $Log: spxhybridpr.hh,v $
   Revision 1.1  1998/07/16 12:11:36  boehm
   *** empty log message ***


    ----------------------------------------------------------------------------
*/

#ifndef DEF_SPxHybridPR_H		// prevent multiple includes
#define DEF_SPxHybridPR_H

//@ ----------------------------------------------------------------------------
/*  \Section{Imports}
    Import required system include files ...
 */
#include <assert.h>


/*  ... and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxpricer.hh"
#include "spxdevexpr.hh"
#include "spxparmultpr.hh"
#include "spxsteeppr.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxpricer/spxpricer.hh"
#include "spxdevexpr/spxdevexpr.hh"
#include "spxparmultpr/spxparmultpr.hh"
#include "spxsteeppr/spxsteeppr.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** Hybrid Pricer for SoPlex. 
    The hybrid pricer for SoPlex tries to guess the best pricing strategy to
    use for pricing the loaded LP with the loaded algorithm type and basis
    representation. Currently it does so by switching between \Ref{SPxSteepPR},
    \Ref{SPxDevexPR} and \Ref{SPxParMultPR}.
 */
class SPxHybridPR : public SPxPricer
{
    SPxSteepPR		steep ;
    SPxParMultPR	parmult ;
    SPxDevexPR		devex ;

    SPxPricer*		thepricer ;
    SoPlex*		thesolver ;
    double		theeps ;

public:
	/// 
    SoPlex*	solver() const				{ return thesolver ; }

	/// 
    double	epsilon() const				{ return theeps ; }
	/// 
    void	setEpsilon( double eps ) ;

	/// 
    void	load( SoPlex* solver ) ;

	/// 
    void	clear()	;

	/// 
    void	setType( SoPlex::Type tp ) ;
	/// 
    void	setRep( SoPlex::Representation rep ) ;

	/// 
    int		selectLeave() ;
	/// 
    void	left4(int n, SoPlex::Id id) ;

	/// 
    SoPlex::Id	selectEnter() ;
	/// 
    void	entered4(SoPlex::Id id, int n) ;

	/// 
    void	addedVecs  ( int n ) ;
	/// 
    void	addedCoVecs( int n ) ;

	/// 
    void	removedVec(int i) ;
	/// 
    void	removedVecs(const int perm[]) ;
	/// 
    void	removedCoVec(int i) ;
	/// 
    void	removedCoVecs(const int perm[]) ;


	/// 
    void	changeObj( const Vector& newObj ) ;
	/// 
    void	changeObj( int i, double newVal ) ;
	/// 
    void	changeLower( const Vector& newLower ) ;
	/// 
    void	changeLower( int i, double newLower ) ;
	/// 
    void	changeUpper( const Vector& newUpper ) ;
	/// 
    void	changeUpper( int i, double newUpper ) ;
	/// 
    void	changeLhs( const Vector& newLhs ) ;
	/// 
    void	changeLhs( int i, double newLhs ) ;
	/// 
    void	changeRhs( const Vector& newRhs ) ;
	/// 
    void	changeRhs( int i, double newRhs ) ;
	/// 
    void	changeRow( int i, const LPRow& newRow ) ;
	/// 
    void	changeCol( int i, const LPCol& newCol ) ;
	/// 
    void	changeElement( int i, int j, double val ) ;
	/// 
    void	changeSense( SoPlex::Sense sns ) ;
	/// 
    int	isConsistent() const ;

	/// 
    SPxHybridPR() ;
} ;

#endif // #DEF_SPxHybridPR_H#
