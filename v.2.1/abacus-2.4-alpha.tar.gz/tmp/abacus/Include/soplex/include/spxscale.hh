/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #SPxScale#

   Identification:
   $Id: spxscale.hh,v 1.1 1998/07/16 12:11:38 boehm Exp $

   Program history:
   $Log: spxscale.hh,v $
   Revision 1.1  1998/07/16 12:11:38  boehm
   *** empty log message ***

// Revision 1.2  1996/03/21  11:11:54  bzfwunde
// New Makefile
// Bug fix for empty columns/rows
//
// Revision 1.1.1.1  1995/11/21  16:34:09  bzfwunde
// initial version: scale LP rows and columns to maximum absolute value
//

    ----------------------------------------------------------------------------
*/
#ifndef DEFspxscale		// prevent multiple includes
#define DEFspxscale


//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxsimplifier.hh"
#include "dataarray.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxsimplifier/spxsimplifier.hh"
#include "dataarray/dataarray.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** LP scaling. 
    This #SPxSimplifier# implementation performs simple scaling of the LPs rows
    and columns.
 */
class SPxScale : public SPxSimplifier
{
    SPxLP*		lp ;
    DataArray<double>	colscale ;
    DataArray<double>	rowscale ;

public:
	/// 
    virtual void	load( SPxLP* ) ;
	/// 
    virtual void	unload( ) ;
	/// 
    virtual SPxLP*	loadedLP() const 		{ return lp ; }
	/// 
    virtual int		simplify( ) ;
	/// 
    virtual void	unsimplify( ) ;

	/// 
    int			isConsistent() const
			{
			    return colscale.isConsistent()
				&& rowscale.isConsistent() ;
			}
	/// 
    SPxScale()		{}
} ;


#endif // |DEFspxscale|
