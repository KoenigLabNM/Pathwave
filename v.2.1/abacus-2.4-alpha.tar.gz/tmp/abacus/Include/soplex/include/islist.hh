/*@ -----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


    islist

    Identification:
    $Id: islist.hh,v 1.1 1998/07/16 12:11:28 boehm Exp $

    Program history:
    $Log: islist.hh,v $
    Revision 1.1  1998/07/16 12:11:28  boehm
    *** empty log message ***

# Revision 2.3  1995/11/21  16:19:01  bzfwunde
# introduced SUBDIR_INCLUDE
#
# Revision 2.2  1995/10/13  15:27:22  bzfwunde
# minor improvements
#
# Revision 2.1  1995/03/31  14:58:53  bzfwunde
# tested Version running with set packing
#
# Revision 1.1  1994/12/22  15:31:05  bzfwunde
# moved to c++doc and
# modified for cfront compliance :-(
#

# Revision 1.13  1994/08/10  07:48:41  bzfwunde
# Ported to SparcWorks CC and g++ 2.6.0
#
# Revision 1.12  1994/06/20  10:42:36  bzfwunde
# debuged and improved version imported from rolands home.
#
# Revision 1.2  1994/06/16  17:46:02  pus
# Added FLAT_FILES macro dependencies for include files.
# Reformatted source files.
#
# Revision 1.1.1.1  1994/05/17  16:57:09  pus
# homeInstallation
#
# Revision 1.11  1994/03/30  16:00:16  bzfwunde
# declared some methodes const.
#
# Revision 1.10  1994/03/25  10:53:16  bzfwunde
# bug fix: move() with empty lists.
#
# Revision 1.9  1994/03/25  09:56:15  bzfwunde
# Added method move()
#
# Revision 1.8  1994/03/22  18:29:19  bzfwunde
# change long -> int
#
# Revision 1.7  1994/02/23  15:30:06  bzfwunde
# method clear() added.
#
# Revision 1.6  1994/02/10  15:13:18  bzfwunde
# Changes commited by GNUmakefile
#
# Revision 1.5  1994/02/02  15:01:50  bzfwunde
# Changes commited by GNUmakefile
#
# Revision 1.4  1994/01/31  14:05:28  bzfwunde
# Changes commited by GNUmakefile
#
# Revision 1.3  1994/01/10  16:12:44  bzfwunde
# Changes commited by GNUmakefile
#
   -----------------------------------------------------------------------------
 */

#ifndef DEFislist
#define DEFislist

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>
#include <iostream.h>


//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

#ifndef	_CRAYMPP
/** Elements for \Ref{IsList}s.
    Class #IsElement# allows to easily construct list elements for an intrusive
    single linked list #IsList# out of a template class #T#. It adds a #next#
    pointer to each element. An instance of #IdElement<T># a can be used just
    like an instance of #T# itself, except for that method #next()# has been
    added (thereby overriding any method #next()# defined in #T#).

    WARNING: This does not compile with AT\&T cfront compiler!
 */
template < class T >
class IsElement : public T
{
protected:		
    IsElement<T>*	the_next ;	// link to next element

public:
	/// 
    IsElement<T>*&	next()			{ return the_next ; }		
	/// 
    IsElement<T>*	next() const		{ return the_next ; }	

	/// 
    IsElement(const T& old)
	: T(old)
    	, the_next(0)		{}

	/// 
    IsElement(const IsElement<T>& old)
	: T(old)
    	, the_next(0)		{}

	/// 
    IsElement()					{}
} ;
#endif	// _CRAYMPP


/** Intrusive single linked list. 
    Class #IsList# implements an intrusive single linked list of elements of a
    template class #T#. As an {\em instrusive} list, the objects of type #T#
    must provide methods #next()# for setting and inquiring a pointer to the
    next element in a list. The user is responsible for not modifying the
    #next()# pointer of elements currently residing in a list, which may destroy
    the lists integrity. For this, class #IsList# provides enough methods for
    modifying a list in a save way. See the method list for a description.
 */
template < class T >
class IsList
{
protected:		
    T*	the_first ;
    T*	the_last ;

public:
#ifndef	_CRAYMPP
	/** IsElement
	    Class #Element# provides an easy way of constructing list elements
	    out of an arbritrary class #T#. See #IsElement# for more
	    information.
	 */
    typedef	IsElement<T>	Element ;
#endif

    /**@name Extension */
    //@{
	/// append #elem# to #IsList#. 
    void	append(T* elem)
		{
		    if(the_last)
			the_last->next() = elem ;
		    else
			the_first = elem ;
		    the_last = elem ;
		}

	/// prepend #elem# to #IsList#. 
    void	prepend(T* elem)
		{
		    if(the_first)
			elem->next() = the_first ;
		    else
			the_last = elem ;
		    the_first = elem ;
		}

	/// insert #elem# to #IsList# after its element #after#. 
    void	insert(T* elem, T* after)
		{
		    assert(find(after)) ;
		    if(after == the_last)
			append(elem) ;
		    else
		    {
			elem->next() = after->next() ;
			after->next() = elem ;
		    }
		}

	/** append all elements of #list# to #IsList#. 
	    Appending one list to another keeps the appended #list#.  Instead,
	    #list# remains an own #IsList# which is then part of the
	    concatenated list. This means that modifying #list# will modify the
	    concateneted list as well and vice versa. The programmer is
	    responsible for such changes not to yield inconsistent lists.
	 */
    void	append(IsList<T>& list)
		{
		    if(list.the_first)				
		    {
			append(list.the_first) ;
			the_last = list.the_last ;
		    }
		}

	/** prepend all elements of #list# to #IsList#. 
	    Appending one list to another keeps the appended #list#.  Instead,
	    #list# remains an own #IsList# which is then part of the
	    concatenated list. This means that modifying #list# will modify the
	    concateneted list as well and vice versa. The programmer is
	    responsible for such changes not to yield inconsistent lists.
	 */
    void	prepend(IsList<T>& list)
		{
		    if(list.the_first)				
		    {
			prepend(list.the_last) ;
			the_first = list.the_first ;
		    }
		}

	/** insert all elements of #list# after element #after# of an #IsList#. 
	    Inserting one list into another keeps the appended #list#. Instead,
	    #list# remains an own #IsList# which is then part of the
	    concatenated list. This means that modifying #list# will modify the
	    concateneted list as well and vice versa. The programmer is
	    responsible for such changes not to yield inconsistent lists.
	 */
    void	insert(IsList<T>& list, T*after)
		{
		    assert(find(after)) ;
		    if(list.the_first)				
		    {
			list.the_last->next() = after->next() ;
			after->next() = list.first() ;
			if(after == last())
			    the_last = list.last() ;
		    }
		}
    //@}

    /**@name Removal */
    //@{
	/// remove the successor of #after# from an #IsList#. 
    void	remove_next(T *after)
		{
		    assert(find(after)) ;
		    if(after->next())
		    {
			if(after->next() == last())
			    the_last = after ;
			after->next() = after->next()->next() ;
		    }
		}

	/// remove element #elem# from an #IsList#. 
    void	remove(const T *elem)
		{
		    if(the_first)
		    {
			if(elem == the_first)
			{
			    the_first = next(elem) ;
			    if(the_first == 0)
				the_last = 0 ;
			}
			else
			{
			    T	*after = the_first ;
			    for( ; after != the_last; after = after->next())
				if(after->next() == elem)
				{
				    remove_next(after) ;
				    return ;
				}
			}
		    }
		}

	/** remove all elements of #list# from an #IsList#. 
	    Removing #list# form an #IsList# requires #list# to be part of the
	    #IsList#. Such a situation can be acchieved by previously adding
	    (i.e.  #append#ing, #insert#ing or #prepend#ing a list) a list or
	    explicitely constructing a sublist with method #sublist()#.
	 */
    void	remove(const IsList<T>& list)
		{
		    if(the_first != 0  &&  list.the_first != 0)
		    {
			assert(find(list.first())) ;
			assert(find(list.last())) ;
			if(the_first == list.the_first)
			{
			    if(the_last == list.the_last)
				the_first = the_last = 0 ;
			    else
				the_first = list.the_last->next() ;
			}
			else
			{
			    T	*after = the_first ;
			    for( ; after->next() != list.the_first; after = after->next())
				;
			    if(the_last == list.the_last)
				the_last = after ;
			    else
				after->next() = list.the_last->next() ;
			}
		    }
		}

	/// remove all elements from an #IsList#. 
    void	clear()			{ the_first = the_last = 0 ; }
    //@}

    /**@name Access */
    //@{
	/// return the #IsList#'s first element. 
    T*		first() const		{ return the_first ; }

	/// return the #IsList#'s last element. 
    T*		last() const		{ return the_last ; }

	/** return successor of #elem# in an #IsList#. 
	    The successor of #elem# in a list generally corresponds to the
	    element returned by #elem->next()#. However, if #elem# is the last
	    element in an #IsList#, this method will return 0, whereas
	    #elem->next()# may yield an arbitrary value. For example, if the
	    current list is actually a sublist of another, larger #IsList#,
	    #elem->next()# returns the successor of #elem# in this larger
	    #IsList#.
	 */
    T*		next(const T *elem) const 
		{ return (elem == the_last) ? 0 : (T*)(elem->next()) ; }

	/// return nr. of elements in #IsList#. 
    int		length() const
		{
		    int	num ;
		    if(the_first)
		    {
			T	*test = the_first ;
			for(num = 1; test != the_last; test = test->next())
			    ++num ;
			return num ;
		    }
		    return 0 ;
		}

	/// return position of element #elem# within #IsList#. 
    int		find(const T* elem) const
		{
		    T	*test = the_first ;
		    do
		    {
			if(test == elem)
			    return 1 ;
		    }
		    while( (test = next(test)) ) ;
		    return 0 ;
		}

	/** construct sublist of an #IsList#. 
	    Retruns a new #IsList# containing a sublist of an #IsList# starting
	    with element #start# and reaching up to element #end#. Both must be
	    members of the #IsList# or 0, in which case the first and last
	    element are used, respectively.
	 */
    IsList<T>	sublist(const T* start = 0, const T* end = 0) const
		{
		    IsList<T>	part = *this ;
		    if(start)
		    {
			assert(find(start)) ;
			part.the_first = (T *)start ;
		    }
		    if(end)
		    {
			assert(part.find(end)) ;
			part.the_last = (T *)end ;
		    }
		    return part ;
		}
    //@}

    /**@name Miscellaneous */
    //@{
	/**
	    This method is of a rather technical nature. If all list elements
	    are taken form one array of elements, in certain circumstances the
	    user may be forced to realloc this array. As a consequence all
	    #next()# pointers of the list elements would become invalid.
	    However, all addresses will be changed by a constant offset #delta#.
	    Then #move(delta)# may be called, which adjusts the #next()#
	    pointers of all elements in the list.
	 */
    void	move(long delta)
		{
		    if(the_first)
		    {
			T*	elem ;
			the_last  = (T*)(delta + long(the_last)) ;
			the_first = (T*)(delta + long(the_first)) ;
			for(elem = first() ; elem ; elem = next(elem))
			    if(elem != last())
				elem->next() = (T*)(delta + long(elem->next())) ;
		    }
		}

	/** Default constructor.
	    The default constructor may be used to setup a (sub-)list, by
	    specifying a #first# and #last# element. Then #last# must be a
	    successor of #first#.
	 */
    IsList(T* first = 0, T* last = 0)
	: the_first(first), the_last(last)
    {
	if(first)
	{
	    assert(last) ;
	    assert(find(last)) ;
	}
    }

	/// consistency check. 
    int	isConsistent() const
	{
	    if(first() != 0   &&  last() == 0)
	    {
		cerr << "Inconsistency detected in class IsList\n" ;
		return 0 ;
	    }
	    if(first() == 0   &&  last() != 0)
	    {
		cerr << "Inconsistency detected in class IsList\n" ;
		return 0 ;
	    }
	    if(first()  &&  find(last()) == 0)
	    {
		cerr << "Inconsistency detected in class IsList\n" ;
		return 0 ;
	    }
	    return 1 ;
	}
    //@}
} ;

#endif	
