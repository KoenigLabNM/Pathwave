/*@ ----------------------------------------------------------------------------
 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 

   Identification:
   $Id: cluprotos.h,v 1.1 1998/07/16 12:11:24 boehm Exp $

   Program history:
   $Log: cluprotos.h,v $
   Revision 1.1  1998/07/16 12:11:24  boehm
   *** empty log message ***


    ----------------------------------------------------------------------------
 */


#ifndef PROTOS
#define PROTOS

/*
*/
#define WITH_L_ROWS

#define CLU_OK			0
#define CLU_INSTABLE		1
#define CLU_SINGULAR		2
#define CLU_OUT_OF_MEMORY	8

#include "clutypes.h"

int	factor( CLUFactor*,
		SVector**,	/* Array of column vector pointers   */
		double,		/* pivoting threshold                */
		double,		/* epsilon for zero detection        */
		int		/* # of pivot candidates             */
	      ) ;

void	solveRight        ( CLUFactor*, double*, double* ) ;
int	solveRight4update ( CLUFactor*, double*, int*, double,
			    double*, double*, int*, int* ) ;

void	solveRight2( CLUFactor*	fac,
		     double*	vec1,
		     double*	vec2,
		     double*	rhs1,
		     double*	rhs2 ) ;

int	solveRight2update( CLUFactor*	fac,
			   double*	vec1,
			   double*	vec2,
			   double*	rhs1,
			   double*	rhs2,
			   int*		nonz,
			   double	eps,
			   double*	tmp,
			   int*		forestNum,
			   int*		forestIdx ) ;

void	solveLeft    ( double*, CLUFactor*, double* ) ;
int	solveLeftEps ( double*, CLUFactor*, double*, int*, double ) ;

int	solveLeft2( CLUFactor*	fac,
		    double*	vec1,
		    int*	nonz,
		    double*	vec2,
		    double	eps,
		    double*	rhs1,
		    double*	rhs2 ) ;

int	updateCLUFactor       ( CLUFactor*, int, double*, const int*, int ) ;
int	updateCLUFactorNoClear( CLUFactor*, int, const double*, const int*, int ) ;
int	forestUpdateCLUFactor ( CLUFactor* fac, int col, double* work, int n, int *nonz ) ;
int	CLUFactorIsConsistent ( CLUFactor* ) ;

void	solveLright( CLUFactor* fac, double* vec ) ;

/********************************************************************************
	very sparse solution methods
*/
int	vSolveRight4update( CLUFactor* fac, double eps,
			    double* vec, int* idx,		/* result       */
			    double* rhs, int* ridx, int rn,	/* rhs & Forest */
			    double* forest, int* forestNum, int* forestIdx ) ;
int	vSolveRight4update2( CLUFactor* fac, double eps,
			     double* vec, int* idx,			/* result1 */
			     double* rhs, int* ridx, int rn,		/* rhs1    */
			     double* vec2, double eps2,			/* result2 */
			     double* rhs2, int* ridx2, int rn2,		/* rhs2    */
			     double* forest, int* forestNum, int* forestIdx ) ;
void	vSolveRightNoNZ( CLUFactor* fac,
			 double* vec2, double eps2,		/* result2 */
			 double* rhs2, int* ridx2, int rn2 ) ;	/* rhs2    */

int	vSolveLeft( CLUFactor* fac, double eps,
		    double* vec, int* idx,				/* result */
		    double* rhs, int* ridx, int rn ) ;			/* rhs    */

void	vSolveLeftNoNZ( CLUFactor* fac, double eps,
			double* vec,				/* result */
			double* rhs, int* ridx, int rn ) ;	/* rhs    */

int	vSolveLeft2( CLUFactor* fac, double eps,
		     double* vec, int* idx,				/* result */
		     double* rhs, int* ridx, int rn,			/* rhs    */
		     double* vec2,					/* result2 */
		     double* rhs2, int* ridx2, int rn2 ) ;		/* rhs2    */

/********************************************************************************/
void	remaxRow( CLUFactor*, int, int ) ;
void	remaxCol( CLUFactor*, int, int ) ;
int	makeLvec( CLUFactor*, int, int ) ;
void	packRows( CLUFactor* fac ) ;

void	dumpCLUFactor( CLUFactor* fac ) ;

void*	Malloc	( int ) ;
void*	Realloc	( void*, int ) ;
void	Free	( void* ) ;

#endif /* PROTOS */
