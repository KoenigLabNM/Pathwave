/*@ ----------------------------------------------------------------------------

   Class #SPxGeneralSM#

   Identification:
   $Id: spxgeneralsm.hh,v 1.1 1998/07/16 12:11:35 boehm Exp $

   Program history:
   $Log: spxgeneralsm.hh,v $
   Revision 1.1  1998/07/16 12:11:35  boehm
   *** empty log message ***


    ----------------------------------------------------------------------------
*/

#ifndef DEF_SPxGeneralSM_H		// prevent multiple includes
#define DEF_SPxGeneralSM_H

//@ ----------------------------------------------------------------------------
/*  \Section{Imports}
    Import required system include files ...
 */
#include <assert.h>


/*  ... and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxredundantsm.hh"
#include "spxaggregatesm.hh"
#include "spxrem1sm.hh"
#include "spxscale.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxredundantsm/spxredundantsm.hh"
#include "spxaggregatesm/spxaggregatesm.hh"
#include "spxrem1sm/spxrem1sm.hh"
#include "spxscale/spxscale.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** General LP preprocessing. 
    This \Ref{SPxSimplifier} iterativly applies a number of preprocessors to its
    loaded \Ref{SPxLP}.
 */
class SPxGeneralSM : public SPxSimplifier
{
private:
    SPxRem1SM		rem1 ;
    SPxRedundantSM	redu ;
    SPxAggregateSM	aggr ;
    SPxScale		scale ;

    SPxLP*		lp ;

public:
	/// 
    void	load( SPxLP* ) ;
	/// 
    void	unload( ) ;
	/// 
    SPxLP*	loadedLP() const ;
	/// 
    int		simplify( ) ;
	/// 
    void	unsimplify( ) ;
	/// 
    double	value( double x ) ;
	/// 
    SPxGeneralSM()		{}
} ;

#endif // #DEF_SPxGeneralSM_H#
