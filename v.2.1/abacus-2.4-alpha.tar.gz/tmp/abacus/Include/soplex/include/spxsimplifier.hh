/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #SPxSimplifier#

   Identification:
   $Id: spxsimplifier.hh,v 1.1 1998/07/16 12:11:39 boehm Exp $

   Program history:
   $Log: spxsimplifier.hh,v $
   Revision 1.1  1998/07/16 12:11:39  boehm
   *** empty log message ***

// Revision 1.4  1996/03/21  11:05:56  bzfwunde
// New Makefile
// Many preformance improvents
//
// Revision 1.3  1995/11/21  16:25:52  bzfwunde
// introduced SUBDIR_INCLUDE
//
// Revision 1.2  1995/10/13  15:35:35  bzfwunde
// minor improvements
//
// Revision 1.1.1.1  1995/03/31  15:04:12  bzfwunde
// tested Version running with set packing
//

    ----------------------------------------------------------------------------
*/
#ifndef DEFspxsimplifier		// prevent multiple includes
#define DEFspxsimplifier


//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxlp.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxlp/spxlp.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** LP simplification base class. 
    Instances of classes derived from #SPxSimplifier# may be loaded to #SoPlex# in
    order to simplify LPs before solving them. #SoPlex# will #load()# itself to
    the #SPxSimplifier# and then call #simplify()#. Generally any #SPxLP# can be
    loaded to a #SPxSimplifier# for #simplify()#ing it. The simplification can
    be undone by calling #unsimplify()#.
 */
class SPxSimplifier
{
private:
protected:
public:
	/// 
    virtual void	load( SPxLP* )					= 0;
	/// 
    virtual void	unload( )					= 0;
	/// 
    virtual SPxLP*	loadedLP() const				= 0;

	/** Simplify loaded #SPxLP#. It returns
	    \begin{description}
	    \item[0]	 if this could be done,
	    \item[1]	 if the LP was detected to be unbounded or
	    \item[-1]	 if the LP was detected to be infeasible.
	    \end{description}
	 */
    virtual int		simplify( )					= 0;
	/// 
    virtual void	unsimplify( )					= 0;

	/** objective value for unsimplified LP. 
	    The simplifyed LP may show other objective values than the
	    original, if a constant part has been removed from the LP.
	    This method returns the value for the original LP, for a
	    value #x# of the simplified LP.
	 */
    virtual double	value( double x )		{ return x ; }

	/// 
    int			isConsistent() const		{ return 1 ; }
} ;


#endif // #DEFspxsimplifier#
