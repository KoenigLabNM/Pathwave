/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #SPxHarrisRT#

   Identification:
   $Id: spxharrisrt.hh,v 1.1 1998/07/16 12:11:35 boehm Exp $

   Program history:
   $Log: spxharrisrt.hh,v $
   Revision 1.1  1998/07/16 12:11:35  boehm
   *** empty log message ***


// Revision 1.4  1996/01/08  12:34:04  bzfwunde
// Moved to new non-GNU generic Makefile environment
// Changes for better readability
// Removed C implementations
//
// Revision 1.3  1995/11/21  16:27:03  bzfwunde
// introduced SUBDIR_INCLUDE
//
// Revision 1.2  1995/10/13  15:36:22  bzfwunde
// minor improvements
//
// Revision 1.1.1.1  1995/03/31  14:54:03  bzfwunde
// tested Version running with set packing
//

    ----------------------------------------------------------------------------
*/
#ifndef DEFspxharrisrt		// prevent multiple includes
#define DEFspxharrisrt


//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxratiotester.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxratiotester/spxratiotester.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** Harris pricing with shifting. 
    Class #SPxHarrisRT# is a stable implementation of a #SPxRatioTester# class
    along the lines of Harris' two phase algorithm. Additionally it uses
    shifting of bounds in order to avoid cycling.
 */
class SPxHarrisRT : public SPxRatioTester
{
protected:
    SoPlex*	thesolver ;

    int	maxDelta
    (
	double*		max,		/* max abs value in upd */
	double*		val,		/* initial and chosen value */
	int		num,		/* # of indices in idx */
	const int*	idx,		/* nonzero indices in upd */
	const double*	upd,		/* update vector for vec */
	const double*	vec,		/* current vector */
	const double*	low,		/* lower bounds for vec */
	const double*	up,		/* upper bounds for vec */
	double		delta,		/* allowed bound violation */
	double		epsilon,	/* what is 0? */
	double		infinity	/* what is $\infty$? */
    ) ;

    int	minDelta
    (
	double*		max,		/* max abs value in upd */
	double*		val,		/* initial and chosen value */
	int 		num,		/* # of indices in idx */
	const int*	idx,		/* nonzero indices in upd */
	const double*	upd,		/* update vector for vec */
	const double*	vec,		/* current vector */
	const double*	low,		/* lower bounds for vec */
	const double*	up,		/* upper bounds for vec */
	double		delta,		/* allowed bound violation */
	double		epsilon,	/* what is 0? */
	double		infinity	/* what is $\infty$? */
    ) ;

public:
	/// 
    SoPlex*	solver() const				{ return thesolver ; }

	/// 
    void	load( SoPlex* solver )			{ thesolver = solver ; }

	/// 
    void	clear( )				{ thesolver = 0 ; }

	/// 
    int		selectLeave(double& val) ;

	/// 
    SoPlex::Id	selectEnter(double& val) ;

	/// 
    void	setType( SoPlex::Type )					{}
} ;

#endif // #DEFspxharrisrt#
