/*@ -----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


    Vector

    Identification:
    $Id: vector.hh,v 1.1 1998/07/16 12:11:44 boehm Exp $

    Program history:
    $Log: vector.hh,v $
    Revision 1.1  1998/07/16 12:11:44  boehm
    *** empty log message ***

# Revision 2.8  1996/03/21  10:59:11  bzfwunde
# New Makefile
# Many preformance improvents
#
# Revision 2.7  1996/01/08  12:21:44  bzfwunde
# Moved to new non-GNU generic Makefile environment
#
# Revision 2.6  1995/11/21  16:15:32  bzfwunde
# optimized hardcoded loop unrolling
#
# Revision 2.5  1995/10/13  15:21:27  bzfwunde
# improved performance by register usage
#
# Revision 2.4  1995/06/15  13:10:28  bzfwunde
# minor changes
#
# Revision 2.3  1995/05/22  15:24:14  bzfwunde
# changed PSVector -> SVector
#
# Revision 2.2  1995/05/17  11:27:46  bzfwunde
# - pointer based implementation of C functions
# - added svector
#
# Revision 2.1  1995/03/31  14:55:54  bzfwunde
# tested Version running with set packing
#
# Revision 1.3  1995/03/09  15:51:56  bzfwunde
# Tested version: Running even on CRAY :-)
#
# Revision 1.2  1995/03/03  19:04:12  bzfwunde
# improved interface
#
# Revision 1.1  1994/11/04  10:36:50  bzfwunde
# documented with c++doc
#

# Revision 1.9  1994/08/10  08:04:54  bzfwunde
# Ported to SparcWorks CC and g++ 2.6.0
#
# Revision 1.4  1994/06/19  10:13:47  pus
# minor bug fixes --- I hope ...
#
# Revision 1.3  1994/06/16  17:48:43  pus
# Added FLAT_FILES macro dependencies for include files.
# Reformatted source files.
#
# Revision 1.2  1994/06/16  13:33:12  pus
# changed source line lenghts.
#
# Revision 1.1.1.1  1994/05/17  16:57:24  pus
# homeInstallation
#
# Revision 1.6  1994/03/30  16:02:24  bzfwunde
# declared some methodes const.
#
# Revision 1.5  1994/03/08  15:11:54  bzfwunde
# *** empty log message ***
#
# Revision 1.4  1994/03/02  19:51:46  bzfwunde
# bug fix in operator*()
#
# Revision 1.3  1994/02/28  18:15:53  bzfwunde
# bug fixes ?  I, hope !
#
# Revision 1.2  1994/02/10  15:11:49  bzfwunde
# Changes commited by GNUmakefile
#
# Revision 1.1.1.1  1994/02/07  16:18:31  bzfwunde
# Initial installation by GNUmakefile
#

   -----------------------------------------------------------------------------
 */

#ifndef DEFvector
#define DEFvector


/*	\Section{Imports}
    In addition to some standard includes, we declare friend classes and a set
    of C functions, used as optimized C implementations of member functions of
    #Vector#.
 */
#include <assert.h>
#include <string.h>
#include <iostream.h>
#include <math.h>

class SLUFactor ;
class SVector ;
class SSVector ;
class SubSVector ;
class IdxSet ;

extern "C"
{
#include "vectorC.h"
}


/** dense vector. 
    Class #Vector# provides dense linear algebra vectors. It does not provide
    memory management for the array of values. Instead, the constructor requires
    a pointer to a memory block large enough to fit the desired dimension of
    #double# values.

    After construction, the values of a #Vector# can be accessed with the
    subscript operator.  A #Vector# ensures that no access to values bejond the
    specified dimension is done. However, this feature can be turned off, if
    compiled with #-DNDEBUG#.

    A #Vector# is distinguished from a simple array of #double#s, by providing a
    set of mathematical operations. Since #Vector# does not provide any memory
    management features, no operations are available that would require
    allocation of temporary memory space. Here is a list of provided operations,
    where the examples asume that #Vector a, b# and #double x# have been
    declared.

    \begin{center}
    \begin{tabular}{lll}
	Operation	& Description	        & 	\\
	\hline
	#-=#		& subtraction           & #a -= b#	\\
	#+=#		& addition              & #a += b#	\\
	#*#		& scalar product        & #x = a * b#	\\
	#*=#		& scaling               & #a *= x#	\\
	#maxAbs()#	& infinity norm		& #a.maxAbs()# == $\|a\|_{\infty}$	\\
	#length()#	& norm		        & #a.length()  == sqrt(a*a)#	\\
	#length2()#	& squared norm	        & #a.length2() == a*a# \\
	#multAdd()#	& add scaled vector	& #a.multAdd(b, x)# \\
    \end{tabular}
    \end{center}

    When using any of these operations, the vector involved must be of the same
    dimension. For #b# also #SVector b# are allowed, if it does not contain
    nonzeros with index greater than the dimension of #x#.
 */
/*	\Section{Class declaration}
    A vector consists of its dimension #dimen# and a pointer to its values
    #val#. Both are public, since derived classes may want to do some
    automatic memory management.
 */
//@Memo:	a linear algebra vector
class Vector
{
    friend class	LP ;
    friend class	GlobalPointer ;
    friend		Vector& Usolve(Vector&, const SLUFactor&) ;
    friend		Vector& Usolve2(Vector&, Vector&, const SLUFactor&) ;

protected:
	/// dimension of vector. 
    int		dimen ;

	/** Pointer to values of a vector. 
	 *  The memory block pointed to by #val# must at least have size
	 *  #dimen * sizeof(double)#.
	 */

    double	*val ;
public:
	/// dimension of vector. 
    int			dim() const
    			{   return dimen ; }


	/// return #n#-th value. 
    double&		operator[](int n)
			{
			    assert(n >= 0 && n < dim()) ;
			    return val[n] ;
			}

	/// return #n#-th value. 
    double		operator[](int n) const
			{
			    assert(n >= 0 && n < dim()) ;
			    return val[n] ;
			}

	/// 
    Vector&		operator+=(const Vector& vec) ;
	/// 
    Vector&		operator+=(const SVector& vec) ;
	/// 
    Vector&		operator+=(const SubSVector& vec) ;
	/// 
    Vector&		operator+=(const SSVector& vec) ;

	/// 
    Vector&		operator-=(const Vector& vec) ;
	/// 
    Vector&		operator-=(const SVector& vec) ;
	/// 
    Vector&		operator-=(const SubSVector& vec) ;
	/// 
    Vector&		operator-=(const SSVector& vec) ;

	/// scaling. 
    Vector&		operator*=(double x) ;


	/// 
    double		operator*(const SSVector& v) const ;
	/// 
    double		operator*(const SVector& v) const ;
	/// 
    double		operator*(const SubSVector& v) const ;
	/// inner product. 
    double		operator*(const Vector& v) const
			{
			    assert(v.dim() == dim()) ;
			    return MultiplyVectorVector( val, dimen, v.val ) ;
			}

	/// infinity norm of a Vector. 
    double		maxAbs() const ;
	/// euclidian norm of a Vector. 
    double		length() const ;
	/// squared norm of a Vector. 
    double		length2() const ;

	/// 
    Vector&		multAdd(double x, const SVector& vec) ;
	/// 
    Vector&		multAdd(double x, const SubSVector& vec) ;
	/// 
    Vector&		multAdd(double x, const SSVector& svec) ;
	/// add scaled vector (#+= x*vec#). 
    Vector&		multAdd(double x, const Vector& vec)
			{
			    assert( vec.dim() == dim() ) ;
			    Vector_MultAddVector( x, dim(), *this, vec ) ;
			    return *this ;
			}


	/// 
			operator double*()			{   return val ; }
	/** Conversion to C-style pointer. 
	    This cast operator serves for using a #Vector# in an old C
	    function. It returns a pointer to the first value of the array.
	 */
			operator const double*() const		{   return val ; }


	/// output operator. 
    friend ostream&	operator<<(ostream& s, const Vector& vec) ;

	/// consistency check. 
    int			isConsistent() const ;


	/// set vector to 0. 
    void		clear()	
			{   if( dimen) memset( val, 0, dimen*sizeof(double) ) ; }

	/// zero values given by #idx#. 
    Vector&		clear(const IdxSet& idx) ;


	/// 
    Vector&		operator=(const Vector& vec) ;
	/// 
    Vector&		operator=(const SVector& vec) ;
	/** Assignment operator.
	    Assigning a #SVector# or #SSVector# to a #Vector# using the operator
	    will set all values to 0 except the nonzeros of the right handside
	    #SVector#.  This is in constrast to method #assign()#.
	 */
    Vector&		operator=(const SSVector& vec) ;

	/// assign values of #sv# only. 
    Vector&		assign(const SVector& psv) ;
	/** Assign values of #sv#.
	    Assigns all nonzeros of #sv# to a vector. All other values remain
	    unchanged.
	 */
    Vector&		assign(const SSVector& sv) ;

	/** Constructor. 
	 *  #Vector#s do not provide their own memory for storing values.
	 *  Instead, it must be passed a memory block #val# at construction. It
	 *  must be large enough to fit at least #dim# double values.
    	 */
    Vector(int dim, double *vl)
    {
	assert(dim >= 0) ;
	Vector::dimen = dim ;
	Vector::val = vl ;
    }
} ;

#endif	// #DEFvector#
