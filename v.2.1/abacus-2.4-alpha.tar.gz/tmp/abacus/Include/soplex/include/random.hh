/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #Random#

   Identification:
   $Id: random.hh,v 1.1 1998/07/16 12:11:30 boehm Exp $

   Program history:
   $Log: random.hh,v $
   Revision 1.1  1998/07/16 12:11:30  boehm
   *** empty log message ***

// Revision 2.4  1996/01/08  12:24:39  bzfwunde
// Moved to new non-GNU generic Makefile environment
//
// Revision 2.3  1995/11/21  16:22:27  bzfwunde
// implemention no longer uses drand48
//
// Revision 2.2  1995/10/13  15:31:32  bzfwunde
// minor improvements
//
// Revision 2.1  1995/03/31  14:54:55  bzfwunde
// tested Version running with set packing
//
// Revision 1.2  1995/03/09  16:02:21  bzfwunde
// Tested version: Running even on CRAY :-)
//
// Revision 1.1.1.1  1994/12/21  17:05:27  bzfwunde
// initial version
//
    ----------------------------------------------------------------------------
*/
#ifndef DEFrandom		// prevent multiple includes
#define DEFrandom

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>
#include <stdlib.h>

//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

#define  RSTEP    1103515245
#define  RDIVIDE  65536
#define  RADD     12345
#define  RMULT    32768


/** random numbers. 
    Class random provides random double variables, i.e. a value variable that
    gives another value each time it is accessed. It may be used just like an
    ordinary double by means of an overloaded cast #operator double ()#.
 */
class Random
{
private:
    double	themin ;	// minimum random number to be returned
    double	themax ;	// maximum random number to be returned

    unsigned long	next ;
    double	next_random ()
    {
	next = next * RSTEP + RADD;
	return last_random() ;
    }
    double	last_random() const
    {
	int i = ( int ) ( next / RDIVIDE ) % RMULT;
	return ( ( double ) i / RMULT );
    }

public:
	/// return lower bound of random numbers. 
    double	min() const		{ return themin ; }
	/// return upper bound of random numbers. 
    double	max() const		{ return themax ; }

	/** Get next random number. 
	    When a #Random# variable is used where a #double# value is
	    expected, a new random number within the range specified in the
	    constructor is retured.
	 */
		operator double()
		{ return (themin + (themax-themin) * next_random() ) ; }

	/// return last random number or seed for next one. 
    double	last() const
		{ return (themin + (themax-themin) * last_random() ) ; }

	/// reset lower bound for random numbers. 
    void	setMin(double min)		{ themin = min ; }
	
	/// reset lower bound for random numbers. 
    void	setMax(double max)		{ themax = max ; }

	/// reset seed for next random number. 
    void	setSeed(double seed)
    		{
		    seed = (seed-themin) / (themax-themin) ;
		    next = (unsigned long)(seed * RMULT * RDIVIDE) ;
		}

	/** Default constructor.
	    Construct a new (pseudo) #Random# variable returning values between
	    #min# and #max# and using #seed# as seed for the random variable's
	    sequence. However, in the current implementation seeds are not
	    handled.
	 */
    Random(double min=0, double max=1, double seed=0.5)
	: themin(min), themax(max)
    {
	if( seed < min || seed > max )
	    seed = (min + max) / 2 ;
	setSeed(seed) ; 
    }

	/// consistency check. 
    int	isConsistent() const
    	{ return themin <= themax ; }
} ;

#endif // #DEFrandom#
