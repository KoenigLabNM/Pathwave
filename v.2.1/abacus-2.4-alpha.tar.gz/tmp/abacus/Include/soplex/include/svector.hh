/*@ -----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


    SVector

    Identification:
    $Id: svector.hh,v 1.1 1998/07/16 12:11:42 boehm Exp $

    Program history:
    $Log: svector.hh,v $
    Revision 1.1  1998/07/16 12:11:42  boehm
    *** empty log message ***

# Revision 2.8  1996/03/21  10:56:19  bzfwunde
# Many preformance improvents
# New Makefile
#
# Revision 2.7  1996/01/08  12:12:51  bzfwunde
# moved to new non-GNU Makefile environment
#
# Revision 2.6  1995/11/21  16:16:10  bzfwunde
# some optimizations
#
# Revision 2.5  1995/10/13  15:21:54  bzfwunde
# improved performance and reduced redundance
#
# Revision 2.4  1995/06/15  13:04:40  bzfwunde
# bug fixes ?
#
# Revision 2.3  1995/05/22  15:22:37  bzfwunde
# changed PSVector -> SVector
#

    -----------------------------------------------------------------------------
 */

/*	\Section{Imports}
 */
#ifndef DEFsvector	// Verhindern mehrfacher #include "svector.hh"#.
#define DEFsvector

#include <iostream.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#ifndef	SUBDIR_INCLUDE

#include "vector.hh"

#else 	// #SUBDIR_INCLUDE#

#include "vector/vector.hh"

#endif	// #SUBDIR_INCLUDE#


//@ -----------------------------------------------------------------------------
/*	\Section{Class Declaration}
    Class #SVector_Element# should be a subclass of #SVector#: I hate cfront :-(
 */
struct SVector_Element
{
    double	val ;
    int	idx ;
} ;

/** Sparse vectors.
 *  Class #SVector# provides packed sparse vectors. Such are a sparse vectors,
 *  with a storage scheme that keeps all data in one contiguous block of memory.
 *  This is best suited for using them for parallel computing on a distributed
 *  memory multiprocessor.
 *
 * #SVector# does not provide any memory management (this will be done by class
 * #DSVector#). This means, that the constructor of #SVector# expects memory
 * where to save the nonzeros. Further, adding nonzeros to an #SVector# may fail
 * if no more memory is available for saving them (see also #DSVector#).
 *
 * When nonzeros are added to an #SVector#, they are appended to the set of
 * nonzeros, i.e. they recieve numbers #size()#, #size()+1# ... . An #SVector#
 * can hold atmost #max()# nonzeros, where #max()# is given in the constructor.
 * When removing nonzeros, the remaining nonzeros are renumbered. However, only
 * the numbers greater than the number of the first removed nonzero are
 * affected.
 *
 * The following mathematical operations are provided by class #SVector#
 * (#SVector a, b, c; double x#):\\ 
 * \begin{center}
 * \begin{tabular}{lll}
 *     Operation	& Description		& \\
 * 	 \hline
 *     #-=#		& subtraction		& #a -= b#	\\
 *     #+=#		& addition		& #a += b#	\\
 *     #*#		& skalar product	& #x = a * b#	\\
 *     #*=#		& scaling		& #a *= x#	\\
 *     #maxAbs()#	& infinity norm		& #a.maxAbs()# == $\|a\|_{\infty}$ \\
 *     #length()#	& eucledian norm	& #a.length()# == $\sqrt{a^2}$	\\
 *     #length2()#	& square norm 		& #a.length2()# == $a^2$	\\
 * \end{tabular}
 * \end{center}
 * 
 * Operators #+=# and #-=# should be used with caution, since no efficient
 * implementation is available. One should think of assigning the left handside
 * vector to a dense #Vector# first and perform the addition on it. The same
 * applies to the scalar product #*#.
 *
 * There are two numberings of the nonzeros of an #SVector#. First, an #SVector#
 * is supposed to act like a linear algebra #Vector#. An {\em index} reffers to
 * this view of an #SVector#: #operator[]# is provided which return the value of
 * the vector to the given index, i.e. 0 for all indeces not in the set of
 * nonzeros.  The other view of #SVector#s is that of a set of nonzeros. The
 * nonzeros are numbered from 0 to #size()-1#. Methods #index(n)# and #value(n)#
 * allow to access the index and value of the #n#-th nonzero. #n# is reffered to
 * as the {\em number} of a nonzero.
 */
class SVector
{
    friend class GlobalPointer ;
    friend class Vector ;
    friend class SSVector ;
public:
    typedef SVector_Element	Element ;

#ifdef	FOR_DOCXX
	/** Sparse vector nonzero element.
	 *  #SVector# keep their nonzeros in an array of #Element#s providing
	 *  members for saving the nonzero's index and value.
	 */
    struct Element
    {
	    /// Value of nonzero element
	double	val ;
	    /// Index of nonzero element
	int	idx ;
    } ;
#endif


protected:
/*	\Section{Datastructures}
    An #SVector# keeps its data in an array of #Element#s. The size and maximum
    number of elements allowed is stored in the -1st #Element# in its members
    #idx# and #val# respectively.
 */
    Element	*elem ;

public:
    /**@name Modification */
    //@{
	/// switch n'th with 0'th nonzero. 
    void	toFront(int n) ;

	/// append one nonzero #(i,v)#. 
    void	add(int i, double v)
		{
		    int	n = size() ;
		    elem[n].idx = i ;
		    elem[n].val = v ;
		    size() = n+1 ;
		    assert( size() <= max() ) ;
		}

	/// append nonzeros of #sv#. 
    void	add(const SVector& sv)
		{ add(sv.size(), sv.elem) ; }

	/// append #n# nonzeros. 
    void	add(int n, const int i[], const double v[]) ;

	/// append #n# nonzeros. 
    void	add(int n, const Element e[]) ;

	/// remove nonzeros n thru m. 
    void	remove(int n, int m) ;

	/// remove n-th nonzero. 
    void	remove(int n)
		{
		    assert(n < size()  &&  n >= 0) ;
		    elem[n] = elem[--size()] ;
		}
	/// remove all indices. 
    void	clear()				{ size() = 0 ; }

	/// sort nonzero to increasing indices. 
    void	sort() ;
    //@}


    /**@name Inquiery*/
    //@{
	/// number of used indeces. 
    int		size() const			{ return elem[-1].idx ; }

	/// maximal number indeces. 
    int		max() const			{ return *(int*)&(elem[-1].val) ; }

	/// maximal index. 
    int		dim() const ;

	/** Number of index #i#. 
	    Return the number of the first index #i#. If no index #i# is available
	    in the #IdxSet#, -1 is returned. Otherwise, #index(number(i)) == i#
	    hods.
	 */
    int		number(int i) const
		{
		    int		n = size() ;
		    Element*	e = &(elem[n]) ;
		    while(n--)
		    {
			--e ;
			if( e->idx == i )
			    return n ;
		    }
		    return -1 ;
		}

	/// get value to index #i#. 
    double	operator[](int i) const
		{
		    int	n = number(i) ;
		    if(n >= 0)
			return elem[n].val ;
		    return 0 ;
		}

	/// 
    Element&	element(int n)
		{
		    assert(n >= 0  && n < max()) ;
		    return elem[n] ;
		}

	/// get #n#-th nonzero element. 
    Element	element(int n) const
		{
		    assert(n >= 0  && n < size()) ;
		    return elem[n] ;
		}

	/// 
    int&	index(int n)
		{
		    assert(n >= 0  && n < size()) ;
		    return elem[n].idx ;
		}

	/// get index of #n#-th nonzero. 
    int		index(int n) const
		{
		    assert(n >= 0  && n < size()) ;
		    return elem[n].idx ;
		}

	/// 
    double&	value(int n)
		{
		    assert(n >= 0  && n < size()) ;
		    return elem[n].val ;
		}

	/// get value of #n#-th nonzero. 
    double	value(int n) const
		{
		    assert(n >= 0  && n < size()) ;
		    return elem[n].val ;
		}
    //@}


    /**@name Mathematical Operations */
    //@{
	/// infinity norm. 
    double	maxAbs() const ;

	/// eucledian norm. 
    double	length() const
		{ return sqrt(length2()) ; }

	/// squared eucledian norm. 
    double	length2() const ;

	/// scale with #x#. 
    SVector&	operator*=(double x) ;

	/// inner product. 
    double	operator*(const Vector& w) const ;
    //@}


    /**@name Miscellaneous*/
    //@{
	/// 
    friend ostream&	operator<<(ostream& os, const SVector& v) ;

	/// 
    SVector&	operator=(const SSVector& sv) ;
	/// assignment operator. 
    SVector&	operator=(const SVector& sv) ;
	/// 
    SVector&	operator=(const Vector& sv) ;
	/// 
    SVector&	assign(const Vector& vec, double eps = 1e-12) ;

	/// consistency check. 
    int		isConsistent() const ;

	/** default constructor. 
	    The constructor expects one memory block where to store the nonzero
	    elements. This must passed to the constructor, where the {\em number
	    of #Element#s} needs that fit into the memory must be given and a
	    pointer to the begining of the memory block. Once this memory has
	    been passed, it shall not be modified until the #SVector# is no
	    longer used. Note, that when a memory block for $n$, say, #Element#s
	    has been passed, only $n-1$ are available for actually storing
	    nonzeros. The remaining one is used for bookkeeping purposes.
	 */
		SVector(int n=0, Element* mem=0)
		{ setMem(n, mem) ; }

	// Internals.
    Element*	mem() const		{ return elem-1 ; }
    int&	size()			{ assert(elem) ; return elem[-1].idx ; }
    int&	max()			{ assert(elem) ; return *(int*)(&elem[-1].val) ; }
    void	setMem( int n, Element* elmem )
		{
		    if( n )
		    {
			assert( n > 0 ) ;
			assert( elmem ) ;
			elmem->val = 0 ;	// for purify to shut up
			elem   = &(elmem[1]) ;
			size() = 0 ;
			max()  = n-1 ;
		    }
		    else
			elem   = 0 ;
		}
    //@}

} ;

inline Vector&	Vector::multAdd(double x, const SVector& vec)
{
    assert( vec.dim() <= dim() ) ;
    Vector_MultAddSVector( val, x, vec.size(), vec.elem ) ;
    return *this ;
}

#endif	// #DEFsvector#
