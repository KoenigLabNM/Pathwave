/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #SPxStarter#

   Identification:
   $Id: spxstarter.hh,v 1.1 1998/07/16 12:11:39 boehm Exp $

   Program history:
   $Log: spxstarter.hh,v $
   Revision 1.1  1998/07/16 12:11:39  boehm
   *** empty log message ***

// Revision 1.4  1996/03/21  11:05:40  bzfwunde
// New Makefile
// Many preformance improvents
//
// Revision 1.3  1995/11/21  16:25:38  bzfwunde
// introduced SUBDIR_INCLUDE
//
// Revision 1.2  1995/10/13  15:35:19  bzfwunde
// minor improvements
//
// Revision 1.1.1.1  1995/03/31  15:04:02  bzfwunde
// tested Version running with set packing
//
// Revision 1.1.1.1  1995/03/03  19:06:19  bzfwunde
// initial version
//
// Revision 1.1.1.1  1994/11/25  10:13:51  bzfwunde
// initial version of starting base generator base class
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFspxdstarter		// prevent multiple includes
#define DEFspxdstarter

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "soplex.hh"

#else 	// #SUBDIR_INCLUDE#

#include "soplex/soplex.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** #SoPlex# start basis generation base class. 
    #SPxStarter# is the virtual base class for classes generating a starter basis
    for the Simplex solver #SoPlex#. When a #SPxStarter# object has been loaded
    to a #SoPlex# solver, the latter will call method #generate()# in order to
    have a start basis generated. Implementations of method #generate()# must
    terminate by #SoPlex::load()#ing the generated basis to #SoPlex#. Loaded
    basises must be nonsingular.
 */
class SPxStarter
{
public:
	/// generate start basis for loaded basis. 
    virtual void	generate( SoPlex& base ) = 0 ;

	/// destructor. 
    virtual		~SPxStarter()			{ }

	/// check consistency. 
    virtual int		isConsistent() const ;
};


#endif // #DEFspxdstarter#
