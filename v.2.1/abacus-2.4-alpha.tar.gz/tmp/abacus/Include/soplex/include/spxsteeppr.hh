/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #SPxSteepPR#

   Identification:
   $Id: spxsteeppr.hh,v 1.1 1998/07/16 12:11:40 boehm Exp $

   Program history:
   $Log: spxsteeppr.hh,v $
   Revision 1.1  1998/07/16 12:11:40  boehm
   *** empty log message ***

// Revision 1.2  1996/03/21  11:08:44  bzfwunde
// New Makefile
// Many preformance improvents
// Tie breaking
//
// Revision 1.1.1.1  1996/01/08  12:32:48  bzfwunde
// Moved from SPxSteep to SPxSteepPR
// Moved to new non-GNU generic Makefile environment
//
// Revision 1.4  1995/11/21  16:28:58  bzfwunde
// - introduced SUBDIR_INCLUDE
// - improvement: prefered use of fixed/free variables.
//
// Revision 1.3  1995/10/13  15:37:30  bzfwunde
// minor improvements
//
// Revision 1.2  1995/05/17  11:45:31  bzfwunde
// ntroduced SSVector
//
// Revision 1.1.1.1  1995/03/31  15:08:49  bzfwunde
// tested Version running with set packing
//
// Revision 1.2  1995/03/03  19:03:04  bzfwunde
// Implemented and somewhat tested all kinds of manipulation methods on the LP
//
// Revision 1.1.1.1  1994/12/19  09:52:47  bzfwunde
// initial version from home
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFspxsteeppr		// prevent multiple includes
#define DEFspxsteeppr

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxpricer.hh"
#include "random.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxpricer/spxpricer.hh"
#include "random/random.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** steepest edge pricer. 
    Class #SPxSteepPR# implements a steepest edge pricer to be used with #SoPlex#.
 */
class SPxSteepPR : public SPxPricer
{
protected:
    DVector	penalty ;		// vector of pricing penalties
    DVector	coPenalty ;		// vector of pricing penalties

    DVector	workVec ;		// working vector
    SSVector	workRhs ;		// working vector

    int		lastIdx ;
    SoPlex::Id	lastId ;
    double	pi_p ;
    double	theeps ;

    SoPlex*	thesolver ;

    int			prefSetup ;
    DataArray<double>	coPref ;	// preference multiplier for selecting as pivot
    DataArray<double>	pref ;		// preference multiplier for selecting as pivot
    DataArray<double>	leavePref ;

    void		setupPrefs( double mult,
				    double tie,   double cotie,
				    double shift, double coshift,
				    int rstart=0, int cstart=0,
				    int rend=-1,  int cend=-1 ) ;
    virtual void	setupPrefs( SoPlex::Type ) ;

public:
    /**@name constrol parameters */
    //@{
	/** How to setup the direction multipliers. 
	    Possible settings are #EXACT# for starting with exactly computed
	    values, or #DEFAULT# for starting with multipliers set to 1. The
	    latter is the default.
	 */
    enum Setup {
    		/// 
	EXACT,	
		/// 
	DEFAULT
    } ;

	/// Setup type. 
    Setup	setup ;

	/// accuracy for computing steepest directions. 
    double	accuracy ;
    //@}

	/// return loaded solver. 
    SoPlex*	solver() const				{ return thesolver ; }
	/// bound violations up to #epsilon# are tollerated. 
    double	epsilon() const				{ return theeps ; }
	/// 
    void	setEpsilon( double eps )		{ theeps = eps ; }

	/// 
    void	load( SoPlex* base ) ;
	/// 
    void	clear() ;
	/// 
    void	setType( SoPlex::Type ) ;
	/// 
    void	setRep( SoPlex::Representation rep ) ;

	/// 
    int		selectLeave() ;
protected:
    int		selectLeave(double& best, int start=0, int incr=1) ;
public:

	/// 
    void	left4(int n, SoPlex::Id id) ;
    void	left4(int n, SoPlex::Id id, int start, int incr) ;

	/// 
    SoPlex::Id	selectEnter() ;
protected:
    SoPlex::Id	selectEnter(double& best, int start1=0, int incr1=1,
    					  int start2=0, int incr2=1) ;
    SoPlex::Id	otherSelectEnter(double& best, int start1=0, int incr1=1,
    					  int start2=0, int incr2=1) ;
public:

	/// 
    void	entered4(SoPlex::Id id, int n) ;
    void	entered4(SoPlex::Id id, int n, int start1, int incr1, int start2, int incr2) ;


    /**@name	Extension
       @memo	Methods for implemementing the public add methods
     */
    //@{
	/// #n# vectors have been added to loaded LP. 
    virtual void	addedVecs  ( int n ) ;
	/// #n# covectors have been added to loaded LP. 
    virtual void	addedCoVecs( int n ) ;
    //@}


    /**@name 	Shrinking
       @memo	Methods for implemementing the public remove methods
     */
    //@{
	/// 
    virtual void	removedVec(int i) ;
	/// 
    virtual void	removedCoVecs(const int perm[]) ;
	/// 
    virtual void	removedVecs(const int perm[]) ;
	/// 
    virtual void	removedCoVec(int i) ;
    //@}


    /**@name Manipulation */
    //@{
	/// 
    void	changeObj( const Vector& newObj )
		{ (void)newObj ; }
	/// 
    void	changeObj( int i, double newVal )
		{ (void)newVal ; (void)i ; }
	/// 
    void	changeLower( const Vector& newLower )
		{ (void)newLower ; }
	/// 
    void	changeLower( int i, double newLower )
		{ (void)i ; (void)newLower ; }
	/// 
    void	changeUpper( const Vector& newUpper )
		{ (void)newUpper ; }
	/// 
    void	changeUpper( int i, double newUpper )
		{ (void)i ; (void)newUpper ; }
	/// 
    void	changeLhs( const Vector& newLhs )
		{ (void)newLhs ; }
	/// 
    void	changeLhs( int i, double newLhs )
		{ (void)i ; (void)newLhs ; }
	/// 
    void	changeRhs( const Vector& newRhs )
		{ (void)newRhs ; }
	/// 
    void	changeRhs( int i, double newRhs )
		{ (void)i ; (void)newRhs ; }
	/// 
    void	changeRow( int i, const LPRow& newRow )
		{ (void)i ; (void)newRow ; }
	/// 
    void	changeCol( int i, const LPCol& newCol )
		{ (void)i ; (void)newCol ; }
	/// 
    void	changeElement( int i, int j, double val )
		{ (void)i ; (void)j ; (void)val ; }
	/// 
    void	changeSense( SoPlex::Sense sns )
		{ (void)sns ; }
    //@}

	/// check consistency. 
    int	isConsistent() const ;


    SPxSteepPR()
	: workRhs ( 0, 1e-16 )
	, setup   ( DEFAULT )
	, accuracy( 1e-4 )
    {}
} ;

#endif // #DEFspxsteeppr#
