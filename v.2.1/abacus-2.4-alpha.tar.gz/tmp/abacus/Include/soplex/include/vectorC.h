/*@ -----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


    VectorC

    Identification:
    $Id: vectorC.h,v 1.1 1998/07/16 12:11:44 boehm Exp $

    Program history:
    $Log: vectorC.h,v $
    Revision 1.1  1998/07/16 12:11:44  boehm
    *** empty log message ***

 * Revision 2.1  1995/10/13  15:21:30  bzfwunde
 * improved performance by register usage
 *
 * Revision 2.3  1995/05/22  15:24:17  bzfwunde
 * changed PSVector -> SVector
 *
 * Revision 2.2  1995/05/17  11:27:48  bzfwunde
 * - pointer based implementation of C functions
 * - added psvector
 *
 * Revision 2.1  1995/03/31  14:55:56  bzfwunde
 * tested Version running with set packing
 *
 * Revision 1.2  1995/03/09  15:51:57  bzfwunde
 * Tested version: Running even on CRAY :-)
 *
 * Revision 1.1  1994/11/04  10:36:53  bzfwunde
 * documented with c++doc
 *

   -----------------------------------------------------------------------------
*/
#ifndef	VECTOR_C_H
#define	VECTOR_C_H

void	Vector_MultAddSSVector( register double* vec, register double x,
				register int n, register const int *idx,
				register const double *val ) ;
void	Vector_MultAddSVector(  register double* vec, register double x,
				int n, void *elem ) ;
void    Vector_MultAddVector(   register double x, register int n,
				register double* v, register const double* w ) ;
void	Vector_Set0toSSVector(  register double*zero, register int n,
				register const int* idx, register const double* val ) ;
double	MultiplyVectorSSVector( register const double* dense, register int n,
				register const int* idx, register const double* val ) ;
double	MultiplyVectorVector(   register const double* v1, register int dim,
				register const double* v2 ) ;

#endif
