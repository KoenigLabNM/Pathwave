/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #Timer#

   Copyright (C) 1994 Martin Grammel
   Permission to use, copy, and distribute this software is granted.
   This software is provided as is without expressed or implied warranty.
   Send bugs, comments or suggestions to <grammel@zib-berlin.de>.

   Identification:
   $Id: timer.hh,v 1.1 1998/07/16 12:11:43 boehm Exp $
   
   Program history:
   $Log: timer.hh,v $
   Revision 1.1  1998/07/16 12:11:43  boehm
   *** empty log message ***

# Revision 2.3  1996/03/21  11:03:58  bzfwunde
# New Makefile
#
# Revision 2.2  1995/08/18  14:14:27  bzfgramm
# support function inlining
#

   ----------------------------------------------------------------------------
   */

#ifndef _CLASS_TIMER_HH
#define _CLASS_TIMER_HH

/* import system include files */

/* import user include files */
#ifdef SUBDIR_INCLUDE
#include "timer/timer.h"
#else
#include "timer.h"
#endif

/*
 ******************************************************************************
 *
 *	Definition of Class #Timer#
 *
 ******************************************************************************
 */

/** Stopwatch. 
    In C or C++ programs, the usual way to measure time intervalls, e.g.\
    running times of some complex computations, is to call one of the provided
    system functions like {\tt clock()}, {\tt time()}, {\tt times()}, {\tt
    gettimeofday()}, {\tt getrusage()} etc.  By these functions one can gather
    information about the process' user and system time and the system clock
    (real time).

    Unfortunately, these functions are rather clumsy.  The programmer determines
    computation times by querying a (virtual) clock value at the beginning and
    another one at the end of some computation and converting the difference of
    these values into seconds.  Some functions impose some restrictions, for
    instance, the values of the ANSI C function {\tt clock()} are of high
    resolution but will wrap around after about 36 minutes (cpu time).  Most
    timing functions take some data structure as argument that has to be
    allocated before the call and from which the user has to pick up the
    information of interest after the call.  Problems can arise, when porting
    programs to other operating systems that do not support standards like POSIX
    etc.

    In order to simplify measuring computation times and to hide the
    system-dependencies involved, a concept of {\em timers} accounting the
    process' user, system and real time is implemented.  C and C++ interfaces
    are provided as a set of functions operating on timers and a timer class
    respectively.

    The idea is to provide a type #Timer# for objects that act like a stopwatch.
    Operations on such an objects include: start accounting time, stop
    accounting, read the actual time account and reset the objects time account
    to zero.

    After initialization, accounting for user, system and real time can be
    started by calling a function #start()#. Accounting is suspended by calling
    a function #stop()# and can be resumed at any time by calling #start()#
    again.

    The user, system or real time actually accounted by a timer can be accessed
    at any time by the methods shown in this code section:

    \begin{verbatim}
       double utime, stime, rtime;
         
       utime = timer.userTime();
       stime = timer.systemTime();
       rtime = timer.realTime();
         
       timer.getTimes(utime, stime rtime);
    \end{verbatim}

    For convenience, the actually accounted user time is returned by #stop()#
    too.  Function #reset()# re-initializes a timer clearing all time>
    accounts.

    Function #resolution()# returns the smallest (non-zero) time intervall which
    is resolved by the underlying system function: #res = 1/Timer_resolution()#.
 */
class Timer
{
/*
    \section{Implementation}
    Implementation consist of files {\tt timer.h} (C interface), {\tt timer.hh}
    (C++ interface) and {\tt timer.c} (implementation).

    The process' user and system times are accessed by calling function {\tt
    times()} which is declared in \verb!<sys/times.h>!.  If OS supports POSIX
    compatibility through providing \verb!<sys/unistd.h>!, set
    \verb!-DHAVE_UNISTD_H! when compiling {\tt timer.c}.  Ignore compiler
    warnings about missing prototypes of functions (e.g.\ \verb!_sysconf()!).
 */
public:

// Stop-Watch Methods:

    /// initialize timer, set timing accounts to zero. 
    void reset();

    /// start timer, resume accounting user, system and real time. 
    void start();

    /// stop timer, return accounted user time. 
    double stop();

    /// return accounted user time. 
    double userTime() const;

    /// return accounted system time. 
    double systemTime() const;

    /// return accounted real time. 
    double realTime() const;

    /// get accounted user, system or real time. 
    void getTimes(double 	*userTime = 0,
		  double	*systemTime = 0,
		  double 	*realTime = 0) const;

    /// return resolution of timer as 1/seconds. 
    static long resolution();

// Constructors and Destructor:

    ///
    Timer();

protected:
    // relay on C implementation of timer
    Timer_t timer;
} ;



/*@******************************************************************************
 *
 *	Implementation of Class #Timer#  (inline functions)
 *
 ******************************************************************************
 */


// initialize timer, set time accounts to zero
inline void Timer::reset()
{
    Timer_reset(&timer);
}


// start timer, resume accounting user, system and real time
inline void Timer::start()
{
    Timer_start(&timer);
}


// stop timer, return accounted user time
inline double Timer::stop()
{
    return Timer_stop(&timer);
}


// return accounted user time
inline double Timer::userTime() const
{
    return Timer_userTime(&timer);
}


// return accounted system time
inline double Timer::systemTime() const
{
    return Timer_systemTime(&timer);
}


// return accounted real time
inline double Timer::realTime() const
{
    return Timer_realTime(&timer);
}


// get accounted user, system or real time
inline void Timer::getTimes(double 	*userTime,
			    double	*systemTime,
			    double 	*realTime) const
{
    Timer_getTimes(&timer, userTime, systemTime, realTime);
}


// return resolution of timer as 1/seconds
inline long Timer::resolution()
{
    return Timer_resolution();
}


// default constructor (initializing timer)
inline Timer::Timer()
{
    Timer_reset(&timer);
}


/*
 ******************************************************************************
 *
 *	End of Class #Timer#
 *
 ******************************************************************************
 */


#endif /* ! _CLASS_TIMER_HH */
