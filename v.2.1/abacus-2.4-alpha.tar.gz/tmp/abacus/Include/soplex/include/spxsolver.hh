/*@ ----------------------------------------------------------------------------

   Class #SPxSolver#

   Identification:
   $Id: spxsolver.hh,v 1.1 1998/07/16 12:11:39 boehm Exp $

   Program history:
   $Log: spxsolver.hh,v $
   Revision 1.1  1998/07/16 12:11:39  boehm
   *** empty log message ***


    ----------------------------------------------------------------------------
*/

#ifndef DEF_spxsolver_H		// prevent multiple includes
#define DEF_spxsolver_H

//@ ----------------------------------------------------------------------------
/*  \Section{Imports}
    Import required system include files ...
 */
#include <assert.h>


/*  ... and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxsteeppr.hh"
#include "spxfastrt.hh"
#include "spxweightst.hh"
#include "slufactor.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxsteeppr/spxsteeppr.hh"
#include "spxfastrt/spxfastrt.hh"
#include "spxweightst/spxweightst.hh"
#include "slufactor/slufactor.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/// preconfigured \Ref{SoPlex} LP-solver. 
class SPxSolver : public SoPlex
{
private:
    SPxFastRT	rt ;
    SPxSteepPR	pr ;
    SPxWeightST	st ;
    SLUFactor	slu ;

public:
    SPxSolver ( Type type=LEAVE, SoPlex::Representation rep=SoPlex::ROW ) ;
} ;

#endif // #DEF_spxsolver_H#
