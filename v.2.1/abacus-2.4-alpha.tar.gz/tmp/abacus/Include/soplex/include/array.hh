/*@ -----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


    Array

    Identification:
    $Id: array.hh,v 1.1 1998/07/16 12:11:23 boehm Exp $

    Program history:
    $Log: array.hh,v $
    Revision 1.1  1998/07/16 12:11:23  boehm
    *** empty log message ***

# Revision 1.4  1996/01/08  12:24:23  bzfwunde
# Moved to new non-GNU generic Makefile environment
#
# Revision 1.3  1995/10/13  15:31:20  bzfwunde
# minor improvements
#
# Revision 1.2  1995/03/31  14:54:41  bzfwunde
# tested Version running with set packing
#
# Revision 1.1  1994/12/22  15:26:50  bzfwunde
# moved to c++doc
#
# Revision 1.9  1994/08/10  07:49:52  bzfwunde
# Ported to SparcWorks CC and g++ 2.6.0
#
# Revision 1.8  1994/06/20  10:43:25  bzfwunde
# debuged and improved version imported from rolands home.
#
# Revision 1.2  1994/06/16  13:30:49  pus
# modified line lengths.
#
# Revision 1.1.1.1  1994/05/17  16:57:03  pus
# homeInstallation
#
# Revision 1.6  1994/03/30  15:57:43  bzfwunde
# declared some methodes const.
#
# Revision 1.5  1994/03/22  18:27:58  bzfwunde
# change long -> int
#
# Revision 1.4  1994/02/28  18:12:06  bzfwunde
# some interface improvements.
#
# Revision 1.3  1994/02/10  16:13:10  bzfwunde
# Changes commited by GNUmakefile
#

 -----------------------------------------------------------------------------
 */
#ifndef DEFarray	
#define DEFarray

//@ ----------------------------------------------------------------------------
/*      \Section{Imports}
    Import required system include files
 */
#include <stdlib.h>
#include <assert.h>

//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/**
    Class #Array# provides safe arrays of arbitrary type. #Array# elements are
    accessed just like ordinary C++ array elements by means of the index
    #operator[]#. Safety is provided by
    \begin{itemize}
    \item	automatic memory management in constructor and destructure
		preventing memory leaks
    \item	checking of array bound when accessing elements with the
		indexing #operator[]# (only when compiled without #-DNDEBUG#).
    \end{itemize}

    Moreover, #Array#s may easily be extended by #insert#ing or #append#ing elements
    to the #Array# or shrunken by #remov#ing elements. Method #reSize(int n)# resets
    the #Array#s length to #n# thereby appending elements or truncating the
    #Array# to the required size.

    Finally, #Array#s may be used as arguments of standard C functions requiring
    pointers thru a cast operator.

    An #Array# is implemented in a C++ complient way with respect to how memory
    is managemed: Only operators #new# and #delete# are used for allocating
    memory. This involves some overhead for all methods effecting the length of
    an #Array#, i.e. all methods #insert#, #append#, #remove# and #reSize#. This
    involves allocating a new C++ array of the new size and copying all elements
    with the template parameters #operator=#.

    For this reason, it is not convenient to use class #Array#, if its elements
    are \Ref{Data Objects}. In this case use class \Ref{DataArray} instead.

    @see	DataArray, Data Objects
 */
template<class T>
class Array
{
protected:
    /*  For the implementation we simply store:
     */
    int	num ;			// the length of array #data# and
    T	*data ;			// the array of elements

public:
    	/// reference #n#'th element. 
    T&		operator[](int n)
		{
		    assert(n >= 0  &&  n < size()) ;
		    return data[n] ;
		}
    	/// reference #n#'th element. 
    const T&	operator[](int n) const
		{
		    assert(n >= 0  &&  n < size()) ;
		    return data[n] ;
		}

    	/// Cast to C arrey. 
    		operator T* ()				{ return data ; }
    	/** Cast to constant C array. 
	    This method allows it to use an #Array<T># as argument for all
	    functions expecting #T*# or #const T*#. However, when used, bound
	    checking can no longer be performed in the function using #T*#.
	 */
    		operator const T* () const		{ return data ; }

    	/// append #n# uninitialized elements. 
    void	append(int n)				{ insert(size(), n) ; }
    	/// append #n# elements from #tarray#. 
    void	append(int n, const T* tarray)		{ insert(size(), n, tarray) ; }
    	/// append all elements from #tarray#. 
    void	append(const Array<T>& tarray)		{ insert(size(), tarray) ; }

    	/// insert #n# uninitialized elements before #i#-th element. 
    void	insert(int i, int n)			
		{
		    assert(i <= size()) ;
		    if(n > 0)
		    {
			int	k ;
			T	*olddata = data ;
			data = new T[size()+n] ;
			assert(data) ;
			if(size() > 0)
			{
			    for(k = 0; k < i; ++k)
				data[k] = olddata[k] ;
			    for(; k < size(); ++k)
				data[k+n] = olddata[k] ;
			    delete[] olddata ;
			}
			num += n ;
		    }
		}

    	/// insert #n# elements from #tarray# before #i#-th element. 
    void	insert(int i, int n, const T* tarray)	
		{
		    insert(i, n) ;
		    for(n--; n >= 0; --n)
			data[n+i] = tarray[n] ;
		}

    	/// insert all elements from #tarray# before #i#-th element. 
    void	insert(int i, const Array<T>& tarray)	
		{
		    int n = tarray.size() ;
		    insert(i, n) ;
		    for(n--; n >= 0; --n)
			data[n+i] = tarray.data[n] ;
		}

    	/// remove #m# elements starting at #n#. 
    void	remove(int n=0, int m=1)			
		{
		    assert(n >= 0  &&  m >= 0) ;
		    if(m > 0  &&  n < size())
		    {
			T	*olddata = data ;
			m   -= (n+m <= size()) ? 0 : n+m-size() ;	
			num -= m ;
			if(num > 0)					
			{
			    int 	i ;
			    data = new T[num] ;
			    for(i = 0; i < n; ++i)
				data[i] = olddata[i] ;
			    for(; i < num; ++i)
				data[i] = olddata[i+m] ;
			}
			delete[] olddata ;
		    }
		}

    	/// remove all elements. 
    void	clear()					
		{
		    if(num > 0)
		    {
			num = 0 ;
			delete[] data ;
		    }
		}


    	/// return nr. of elements. 
    int		size() const				{ return num ; }

    	/// reset nr. of elements. 
    void	reSize(int newsize)	
		{
		    if(newsize < size())
			remove(newsize, size()-newsize) ;
		    else if(newsize > size())
			append(newsize - size()) ;
		}

    	/** Assignment operator.
	    Assigning an rvalue #Array# to an lvalue #Array# involves resizing
	    the lvalue to the rvalues #size()# and copying all elements via
	    the #Array# element's assignment #operator=#.
	 */
    Array<T>&	operator=(const Array<T>& rhs)		
		{
		    reSize(rhs.size()) ;
		    for(int i = 0 ; i < size() ; ++i)
			data[i] = rhs.data[i] ;
		    return *this ;
		}

    	/** Default Constructor.
	    The constructor allocates an #Array# of #n# uninitialized elements.
	 */
		Array(int n = 0)
		    : data( 0 )
		{
		    assert(n >= 0) ;
		    num = n ;
		    if(num > 0)
		    {
			data = new T[num] ;
			assert(data) ;
		    }
		}

    	/// 
		Array(const Array<T>& old)		
		    : num(old.num)
		{
		    if(num > 0)
		    {
			data = new T[num] ;
			assert(data) ;
			*this = old ;
		    }
		}

    	/// 
		~Array()				
		{
		    if(num > 0)
			delete[] data ;
		}

    	/// 
    int		isConsistent() const			
		{
		    if(num < 0  ||  (num > 0  &&  data == 0) )
		    {
			cerr << "Inconsistency detected in class array\n" ;
			return 0 ;
		    }
		    return 1 ;
		}
} ;

#endif
