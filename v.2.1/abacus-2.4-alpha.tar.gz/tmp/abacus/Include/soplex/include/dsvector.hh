/*@ -----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 

 *
 *	Author:	Roland Wunderling
 *	Copyright by Author, All rights reserved
 *

    DSVector

    Identification:
    $Id: dsvector.hh,v 1.1 1998/07/16 12:11:27 boehm Exp $

    Program history:
    $Log: dsvector.hh,v $
    Revision 1.1  1998/07/16 12:11:27  boehm
    *** empty log message ***

# Revision 2.7  1996/03/21  11:00:55  bzfwunde
# New Makefile
# Many preformance improvents
#
# Revision 2.6  1996/01/08  12:22:26  bzfwunde
# Moved to new non-GNU generic Makefile environment
#
# Revision 2.5  1995/11/21  16:20:15  bzfwunde
# introduced SUBDIR_INCLUDE
#
# Revision 2.4  1995/10/13  15:27:37  bzfwunde
# minor improvements
#
# Revision 2.3  1995/06/15  13:11:26  bzfwunde
# minor changes
#
# Revision 2.2  1995/05/22  16:02:38  bzfwunde
# changed PSVector -> SVector
#

    -----------------------------------------------------------------------------
 */

/*	\Section{Imports}
 */
#ifndef DEFdsvector
#define DEFdsvector

#include <assert.h>

#ifndef	SUBDIR_INCLUDE

#include "svector.hh"
#include "ssvector.hh"

#else	// #SUBDIR_INCLUDE#

#include "svector/svector.hh"
#include "ssvector/ssvector.hh"

#endif	// #SUBDIR_INCLUDE#


/*	\Section{Class Declaration}
 */
/** Dynamic sparse vectors.
    Class #DSVector# implements dynamic sparse vectors, i.e. #SVector#s
    with an automatic memory management. This allows the user to freely #add()#
    as many nonzeros to a #DSVector# as desired, without any precautions.
    For saving memory method #setMax()# allows to reduce memory consumption to
    the amount really required.
 */
class DSVector : public SVector
{
    friend class GlobalPointer ;
    friend class SLinSolver ;

    Element*	theelem ;		// here is where the memory is
    int*	mem() ;

    void	allocMem( int ) ;
    void	makeMem(int n)
		{
		    if(max() - size() < ++n)
			setMax(size() + n) ;
		}

public:
	/// 
    DSVector&	operator=(const SSVector& sv)
		{
		    int n = sv.size() ;
		    clear() ;
		    makeMem(n) ;
		    SVector::operator=(sv) ;
		    return *this ;
		}
	/// 
    DSVector&	operator=(const SVector& sv)
		{
		    int n = sv.size() ;
		    clear() ;
		    makeMem(n) ;
		    SVector::operator=(sv) ;
		    return *this ;
		}
	/// 
    DSVector&	operator=(const DSVector& sv)
		{
		    int n = sv.size() ;
		    clear() ;
		    makeMem(n) ;
		    SVector::operator=(sv) ;
		    return *this ;
		}
	/// 
    DSVector&	operator=(const Vector& vec) ;
	/// 
    DSVector&	assign(const Vector& vec, double eps = 1e-16) ;

	/// 
    void	add(const SVector& sv)
		{
		    int n = sv.size() ;
		    clear() ;
		    makeMem(n) ;
		    SVector::add(sv) ;
		}

	/// 
    void	add(int i, double v)
		{
		    makeMem(1) ;
		    SVector::add(i, v) ;
		}

	/// 
    void	add(int n, const int *i, const double *v)
		{
		    makeMem(n) ;
		    SVector::add(n, i, v) ;
		}

    	/** reset nonzero memory to #>= newmax#. 
	    This methods resets the memory consumption of the #DIdxSet# to
	    #newmax#. However, if #newmax < size()#, it is reset to #size()#
	    only.
	 */
    void	setMax(int newmax = 1) ;

    	/// 
    DSVector(const Vector& vec) ;

    	/// 
    DSVector(const SVector& old) ;
    	/// 
    DSVector(const DSVector& old) ;

	/** Default constructor.
	    Creates a #DSVector# ready to hold #n# nonzeros. However, the memory is
	    automatically enlarged, if more nonzeros are added to the #DSVector#.
	 */
    DSVector(int n = 8) ;

	/// 
    ~DSVector() ;

	/// 
    int	isConsistent() const ;
} ;

#endif	// #DEFdsvector#
