/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #SPxRatioTester#

   Identification:
   $Id: spxratiotester.hh,v 1.1 1998/07/16 12:11:37 boehm Exp $

   Program history:
   $Log: spxratiotester.hh,v $
   Revision 1.1  1998/07/16 12:11:37  boehm
   *** empty log message ***

// Revision 1.4  1996/03/21  11:06:12  bzfwunde
// New Makefile
// Many preformance improvents
//
// Revision 1.3  1995/11/21  16:26:05  bzfwunde
// introduced SUBDIR_INCLUDE
//
// Revision 1.2  1995/10/13  15:35:47  bzfwunde
// minor improvements
//
// Revision 1.1.1.1  1995/03/31  14:54:13  bzfwunde
// tested Version running with set packing
//

    ----------------------------------------------------------------------------
*/
#ifndef DEFspxratiotester		// prevent multiple includes
#define DEFspxratiotester


//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "soplex.hh"

#else 	// #SUBDIR_INCLUDE#

#include "soplex/soplex.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** #SoPlex# ratio test base class. 
    Class #SPxRatioTester# is the virtual base class for computing the ratio
    test within the Simplex algorithm driven by #SoPlex#. After a #SoPlex#
    solver has been #load()#ed to an #SPxRatioTester#, the solver calls
    #selectLeave()# for computing the ratio test for the entering simplex and
    #selectEnter()# for computing the ratio test in leaving simplex.
 */
class SPxRatioTester
{
public:
	/** Load LP.
	    Load the solver and LP for which pricing steps are to be performed.
	 */
    virtual void	load( SoPlex* lp )				= 0 ;

	/// 
    virtual void	clear( )					= 0 ;

	/// 
    virtual SoPlex*	solver() const					= 0 ;

	/** Select index to leave the basis.
	    Method #selectLeave()# is called by the loaded #SoPlex# solver, when
	    computing the entering simplex algorithm. It's task is to select and
	    return the index of the basis variable that is to leave the basis.
	    When beeing called, #fVec()# fullfills the basic bounds #lbBound()#
	    and #ubBound()# within #delta#. #fVec().delta()# is the vector by
	    which #fVec()# will be updated in this simplex step. Its nonzero
	    indeces are stored in sorted order in #fVec().idx()#.
	    
	    If #val>0#, #val# is the maximum allowed update value for #fVec()#,
	    otherwise the minimum. Method #selectLeave()# must chose #val# of the
	    same sign as passed, such that updating #fVec()# by #val# yields a
	    new vector that satisfies all basic bounds (within #delta#). The
	    returned index, must be the index of an element of #fVec()#, that
	    reaches one of its bounds with this update.
	 */
    virtual int		selectLeave(double& val)			= 0 ;

	/** Select Id to enter the basis.
	    Method #selectEnter# is called by the loaded #SoPlex# solver, when
	    computing the leaving simplex algorithm. It's task is to select and
	    return the #Id# of the basis variable that is to enter the basis.
	    When beeing called, #pVec()# fullfills the bounds #lpBound()# and
	    #upBound()# and #coPvec()# bounds #lcBound()# and #ucBound()# within
	    #delta#, respectively. #pVec().delta()# and #coPvec().delta()# are
	    the vectors by which #pVec()# and #coPvec()# will be updated in this
	    simplex step. Their nonzero indeces are stored in sorted order in
	    #pVec().idx()# and #coPvec().idx()#.
	    
	    If #val>0#, #val# is the maximum allowed update value for #pVec()#
	    and #coPvec()#, otherwise the minimum. Method #selectEnter()# must
	    chose #val# of the same sign as passed, such that updating #pVec()#
	    and #coPvec()# by #val# yields a new vector that satisfies all basic
	    bounds (within #delta#). The returned #Id#, must be the #Id# of an
	    element of #pVec()# or #coPvec()#, that reaches one of its bounds
	    with this update.
	 */
    virtual SoPlex::Id	selectEnter(double& val)			= 0 ;

	/** Set Simplex type.
	    Inform pricer about (a change of) the loaded #SoPlex#'s #Type#. In
	    the sequel, only the corresponding select methods may be called.
	 */
    virtual void	setType( SoPlex::Type )				= 0 ;

	/// 
    virtual 		~SPxRatioTester()				{}
} ;


#endif // #DEFspxratiotester#
