#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	_BINARY	258
#define	_STRING	259
#define	_BOUNDS	260
#define	_VALUE	261
#define	_LO	262
#define	_UP	263
#define	_FX	264
#define	_FR	265
#define	_MI	266
#define	_PL	267
#define	_MAXIMIZE	268
#define	_MINIMIZE	269
#define	_ST	270
#define	_END	271
#define	_MINUS	272
#define	_PLUS	273
#define	_LESS_EQUAL	274
#define	_GREATER_EQUAL	275
#define	_EQUAL_TO	276
#define	_INFINITY	277
#define	_FREE	278


extern YYSTYPE yylval;
