/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #SPxVectorST#

   Identification:
   $Id: spxvectorst.hh,v 1.1 1998/07/16 12:11:41 boehm Exp $

   Program history:
   $Log: spxvectorst.hh,v $
   Revision 1.1  1998/07/16 12:11:41  boehm
   *** empty log message ***

// Revision 1.2  1996/03/21  11:10:35  bzfwunde
// New Makefile
//
// Revision 1.1.1.1  1995/11/21  16:31:46  bzfwunde
// initial release: construct basis from offered vector
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFspxvectorst		// prevent multiple includes
#define DEFspxvectorst

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxweightst.hh"
#include "vector.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxweightst/spxweightst.hh"
#include "vector/vector.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** solution vector based start basis. 
    This version of #SPxWeightST# can be used to construct a starting basis for
    an LP to be solved with #SoPlex#, if an approximate solution vector or dual
    vector (possibly optained by a heuristic) is available. This is done by
    setting up weights for the #SPxWeightST# it is derived from.

    The primal vector to be used is loaded by calling method #primal()# while
    #dual()# setups for the dual vector. Methods #primal()# or #dual()# must be
    called {\em before} #generate()# is called by \Ref{SoPlex} to set up a
    starting basis. If more than one call of method #primal()# or #dual()#
    occurred only the most recent one is valid for generating the starting base.
 */
class SPxVectorST : public SPxWeightST
{
    const Vector*	prim ;
    const Vector*	dvec ;
protected:
	/// 
    void	setupWeights( SoPlex& base ) ;
public:
	/// setup primal solution vector. 
    void	primal( const Vector& v )
    		{
		    prim = &v ;
		    dvec = 0 ;
		}
	/// setup primal solution vector. 
    void	dual( const Vector& v )
		{
		    prim = 0 ;
		    dvec = &v ;
		}
	/// 
    SPxVectorST()	{}
} ;

#endif // #DEFspxvectorst#
