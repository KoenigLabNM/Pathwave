/*@ -----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


    IdxSet

    Identification:
    $Id: idxset.hh,v 1.1 1998/07/16 12:11:28 boehm Exp $

    Program history:
    $Log: idxset.hh,v $
    Revision 1.1  1998/07/16 12:11:28  boehm
    *** empty log message ***

# Revision 2.4  1995/10/13  15:23:58  bzfwunde
# minor improvements
#
# Revision 2.3  1995/06/15  13:05:55  bzfwunde
# minor changes
#
# Revision 2.2  1995/05/22  15:24:58  bzfwunde
# ichanged PSVector -> SVector
#
# Revision 2.1  1995/03/31  14:55:40  bzfwunde
# tested Version running with set packing
#
# Revision 1.4  1995/03/09  15:52:41  bzfwunde
# Tested version: Running even on CRAY :-)
#
# Revision 1.3  1995/03/03  18:38:28  bzfwunde
# minor bug fixes
#
# Revision 1.2  1994/11/25  10:16:26  bzfwunde
# removed g++2.6.2 warnings
#
# Revision 1.1  1994/11/12  20:39:28  pus
# moved to c++doc
#
# Revision 1.10  1994/06/20  10:45:56  bzfwunde
# debuged and improved version imported from rolands home.
#
# Revision 1.3  1994/06/16  17:48:01  pus
# Added FLAT_FILES macro dependencies for include files.
# Reformatted source files.
#
# Revision 1.2  1994/06/16  13:31:29  pus
# change source line lengths.
#
# Revision 1.1.1.1  1994/05/17  16:57:11  pus
# homeInstallation
#
# Revision 1.9  1994/04/07  10:40:08  bzfwunde
# removed stupid friend declaration.
#
# Revision 1.8  1994/03/30  15:59:40  bzfwunde
# declared some methodes const.
#
# Revision 1.7  1994/03/22  14:21:35  bzfwunde
# * changed interface
# * long -> int
#
# Revision 1.6  1994/03/09  22:40:20  bzfwunde
# added method: toFront().
#
# Revision 1.5  1994/02/28  18:13:13  bzfwunde
# Extended interface to allow manipulation of array idx.
#
# Revision 1.4  1994/02/14  11:52:23  bzfwunde
# Changes commited by GNUmakefile
#
 */

/*	\Section{Imports}
 */
#ifndef DEFidxset
#define DEFidxset

#include <assert.h>


/*	\Section{Class Declaration}
 */
/** index set. 
    Class #IdxSet# provides a set of indices. At construction it must be given
    an array of #int# where to store the indice and its length. The array will
    from then on be managed by the #IdxSet#.

    Indices are implicitely numbered from 0 thru #size()-1#. They can be
    accessed (and altered) via method #index()# with the desired index number as
    argument.  Range checking is performed in the debug version.

    Indices may be added or removed from the set, by calling #add()# or
    #remove()# methods, respectively. However, no #IdxSet# can hold more then
    #max()# indices, i.e. the number given at the constructor.

    When removing indices, the remaining ones are renumbered. However, all
    indices before the first removed index keep their number unchanged.
*/
class IdxSet
{
/*	\SubSection{Datastructures}
    Die intern Darstellung eines #IdxSet#s besteht i.w.~aus einem Feld f\"ur
    die Indizes (#idx#).  In #len# wird dessen L\"ange gehalten, wovon die
    ersten #num# tats\"achlich benutzt werden. Der Feld wird von der Klasse
    nicht selbst alloziiert, sondern mu\ss\ Instanzen bei der Initialisierung
    \"ubergeben werden.
 */
protected:
    friend class	Vector ;

    int			num ;		// nr. of used indices
    int			len ;		// length of array #idx#
    int			*idx ;		// array of indices

public:
    /**@name Access */
    //@{
	/// 
    int&	index(int n)
		{
		    assert(n >= 0  &&  n < size()) ;
		    return idx[n] ;
		}

	/// access #n#-th index. 
    int		index(int n) const
		{
		    assert(n >= 0  &&  n < size()) ;
		    return idx[n] ;
		}
    //@}

    /**@name Inquiery */
    //@{
	/// Number of used indices. 
    int		size() const
		{ return num ; }

	/// Maximal number indices. 
    int		max() const
		{ return len ; }

	/// Maximal index. 
    int		dim() const ;

	/** Number of index #i#. 
	    Return the number of the first index #i#. If no index #i# is
	    available in the #IdxSet#, -1 is returned. Otherwise,
	    #index(number(i)) == i# hods.
	 */
    int		number(int i) const ;
    //@}

    /**@name Extension
	An #IdxSet# cannot be extended to fit more than #max()# elements. If
	neccessary, the user must explicitely provide the #IdxSet# with a
	suitable memory. Alternatively, one can use \Ref{DIdxSet}s which provide
	the required memory managemant.
     */
    //@{
	/// append #n# uninitialized indices. 
    void	add(int n)
		{
		    assert(n >= 0  &&  n + size() <= max()) ;
		    num += n ;
		}

	/// append all indices of #set#. 
    void	add(const IdxSet& set)
		{ add(set.size(), set.idx) ; }

	/// Append #n# indices in #i#. 
    void	add(int n, const int i[]) ;

	/// Append index #i#. 
    void	addIdx( int i )
    		{
		    assert( size() < max() ) ;
		    idx[num++] = i ;
		}
    //@}

    /**@name Removal */
    //@{
	/// remove indices #n# through #m#. 
    void	remove(int n, int m) ;

	/// remove #n#-th index. 
    void	remove(int n)
		{
		    if(n < size()  &&  n >= 0)
			idx[n] = idx[--num] ;
		}

	/// remove all indices. 
    void	clear()
		{ num = 0 ; }
    //@}

    /**@name Internals
	The use of the following functions is not encouraged since they
	interfere with the internal representation of #IdxSet#. Such consists of
	a pointer to the array of indices that has been passed to the
	constructor, along with an #int# for the maximal length of this array
	and the number of elements currently in use. These members may be
	changed with the following methods.
     */
    //@{
	/** reset the size of the index array. 
	    Handle with care to prevent memory leakages. It is not safe to
	    enlarge #max()# without providing an extended index array.
	 */
    void	setMax(int mx)
		{ len = mx ; }

	/// reset the number of indices. 
    void	setSize(int sz)
		{
		    num = sz ;
		    assert(size() <= max()) ;
		    assert(size() >= 0) ;
		}

	/// 
    int*&	indexMem()			{ return idx ; }
	/// pointer to the index array. 
    const int*	indexMem() const		{ return idx ; }

#ifndef	_CRAYMPP
	/// 
           	operator int* ()		{ return idx ; }
	/// pointer to the index array. 
           	operator const int* () const	{ return idx ; }
#endif	//@ _CRAYMPP
    //@}

    /**@name Miscellaneous */
    //@{
	/// switch n'th and 0'th index. 
    void	toFront(int n) ;

	/** Assignment operator.
	    The assignment operator copies all nonzeros of the right handside
	    #IdxSet# to the left one. This implies, that the latter must have
	    enough index memory.
	 */
    IdxSet&	operator=(const IdxSet& set) ;

	/// consistency check. 
    int		isConsistent() const ;

	/** Constructor. 
	    The constructur receives the index memory #imem# to use for saving
	    its indices. This must be large enough to fit #n# indices. #l# can
	    be given to construct an #IdxSet# initialized to the #l# first
	    indices in #imem#.
	 */
		IdxSet(int n=0, int imem[]=0, int l=0)
		    : num(l), len(n), idx(imem)
		    { assert( isConsistent() ) ; }

	/**@name Copy constructor
	    The copy constructor creates an #IdxSet# that {\em shares} the same
	    index array. This is fine for argument passing in function calls,
	    but may be dangerous if one keeps a copy constructed #IdxSet# on
	    data, that has been released.
	 */
    //@}
} ;

#endif	// #DEFidxset#
