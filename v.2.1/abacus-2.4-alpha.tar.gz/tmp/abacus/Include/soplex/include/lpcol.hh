/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #LPCol#

   Identification:
   $Id: lpcol.hh,v 1.1 1998/07/16 12:11:28 boehm Exp $

   Program history:
   $Log: lpcol.hh,v $
   Revision 1.1  1998/07/16 12:11:28  boehm
   *** empty log message ***

// Revision 2.4  1996/01/08  12:23:00  bzfwunde
// Moved to new non-GNU generic Makefile environment
//
// Revision 2.3  1995/11/21  16:20:43  bzfwunde
// introduced SUBDIR_INCLUDE
//
// Revision 2.2  1995/10/13  15:29:06  bzfwunde
// minor improvements
//
// Revision 2.1  1995/03/31  14:59:40  bzfwunde
// tested Version running with set packing
//
// Revision 1.1.1.1  1995/03/03  18:49:05  bzfwunde
// minor bug fixes
// changes to the interface
//
// Revision 1.1.1.1  1995/01/12  17:35:35  bzfwunde
// initial, tested version
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFlpcol		// prevent multiple includes
#define DEFlpcol

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "dsvector.hh"

#else 	// #SUBDIR_INCLUDE#

#include "dsvector/dsvector.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */
/** LP column. 
    Class #LPCol# provides a datatype for storing the column of an LP a the
    form similar to
	\[
	\begin{array}{rl}
	    \hbox{max}	& c^T x		\\
	    \hbox{s.t.}	& Ax \le b	\\
			& l \le x \le u
	\end{array}
	\]
    Hence, an #LPCol# consists of an objective value, a column #DSVector# and
    an upper and lower bound to the corresponding variable, which may include
    $\pm\infty$. However, it depends on the LP code to use, what values are
    actually treated as $\infty$.
 */
class LPCol
{
private:
    double	up, low, object ;
    DSVector	vec ;
public:
	/// 
    double		obj() const			{ return object ; }
	/// access objective value. 
    double&		obj()				{ return object ; }

	/// 
    double		upper() const			{ return up ; }
	/// access upper bound. 
    double&		upper()				{ return up ; }

	/// 
    double		lower() const			{ return low ; }
	/// access lower bound. 
    double&		lower()				{ return low ; }

	/// 
    const SVector&	colVector() const		{ return vec ; }
	/// access constraint column vector. 
    DSVector&		colVector()			{ return vec ; }

	/// 
    LPCol(const LPCol& old)
	: up(old.up), low(old.low), object(old.object), vec(old.vec)	{ }

	/** Default Constructor.
	    Construct #LPCol# with a column vector ready for taking #defDim#
	    nonzeros.
	 */
    LPCol( int defDim = 0 )
	: up(1e+300), low(0), object(0), vec( defDim )	{ }

	/** Initializing Constructor.
	    Construct #LPCol# with the given objective value #obj#, a column
	    vector #vec#, upper bound #upper# and lower bound #lower#.
	 */
    LPCol(double obj, const SVector& vector, double upper, double lower)
	: up(upper), low(lower), object(obj), vec(vector)	{ }

	/// 
    int	isConsistent() const			{ return vec.isConsistent() ; }
} ;


#endif // #DEFlpcol#
