/*@ ----------------------------------------------------------------------------

   Class #SPxRedundantSM#

   Identification:
   $Id: spxredundantsm.hh,v 1.1 1998/07/16 12:11:38 boehm Exp $

   Program history:
   $Log: spxredundantsm.hh,v $
   Revision 1.1  1998/07/16 12:11:38  boehm
   *** empty log message ***


    ----------------------------------------------------------------------------
*/

#ifndef DEF_SPxRedundantSM_H		// prevent multiple includes
#define DEF_SPxRedundantSM_H

//@ ----------------------------------------------------------------------------
/*  \Section{Imports}
    Import required system include files ...
 */
#include <assert.h>


/*  ... and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxsimplifier.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxsimplifier/spxsimplifier.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** Remove redundant row and columns. 
    This \Ref{SPxSimplifier} thries to eliminat redundant rows or columns from
    its loaded \Ref{SPxLP}.
 */
class SPxRedundantSM : public SPxSimplifier
{
private:
    double	delta ;
    SPxLP*	lp ;

#ifndef	GNU_IS_OK_AGAIN
    void	dummy( const SVector&, double&, double&, int&, int& ) const ;
#endif

protected:
public:
	/// 
    void	load( SPxLP* ) ;
	/// 
    void	unload( ) ;
	/// 
    SPxLP*	loadedLP() const 		{ return lp ; }
	/// 
    int		simplify( ) ;
	/// 
    void	unsimplify( ) ;
	/// 
    double	value( double x )	{ return x + lp->spxSense()*delta ; }
} ;

#endif // #DEF_SPxRedundantSM_H#
