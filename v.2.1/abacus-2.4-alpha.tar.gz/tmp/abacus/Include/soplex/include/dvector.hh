/*@ -----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


    Vector

    Identification:
    $Id: dvector.hh,v 1.1 1998/07/16 12:11:27 boehm Exp $

    Program history:
    $Log: dvector.hh,v $
    Revision 1.1  1998/07/16 12:11:27  boehm
    *** empty log message ***

# Revision 1.9  1996/01/08  12:19:57  bzfwunde
# Moved to new non-GNU generic Makefile environment
#
# Revision 1.8  1995/11/21  16:17:51  bzfwunde
# - introduced SUBDIR_INCLUDE
# - changed initialization: no zeroing of vector in constructor!!
#
# Revision 1.7  1995/10/13  15:24:30  bzfwunde
# added io methods
#
# Revision 1.6  1995/03/31  14:56:27  bzfwunde
# tested Version running with set packing
#
# Revision 1.5  1995/03/09  15:51:25  bzfwunde
# Tested version: Running even on CRAY :-)
#
# Revision 1.4  1995/03/03  18:42:52  bzfwunde
# minor bug fixes
#
# Revision 1.3  1994/12/27  13:51:57  bzfwunde
# moved to c++doc
#

# Revision 1.7  1994/11/04  10:38:05  bzfwunde
# documented with c++doc
#
# Revision 1.6  1994/08/10  07:57:05  bzfwunde
# Ported to SparcWorks CC and g++ 2.6.0
#
# Revision 1.5  1994/06/20  10:53:56  bzfwunde
# debuged and improved version imported from rolands home.
#
# Revision 1.3  1994/06/19  10:19:39  pus
# minor bug fix --- I hope ...
#
# Revision 1.2  1994/06/16  17:50:05  pus
# Added FLAT_FILES macro dependencies for include files.
# Reformatted source files.
#
# Revision 1.1.1.1  1994/05/17  16:57:22  pus
# homeInstallation
#
# Revision 1.4  1994/03/30  16:06:21  bzfwunde
# declared some methodes const.
#
# Revision 1.3  1994/02/28  18:15:27  bzfwunde
# Added some functionality.
#
# Revision 1.2  1994/02/14  12:22:08  bzfwunde
# Changes commited by GNUmakefile
#
# Revision 1.1.1.1  1994/02/07  16:17:53  bzfwunde
# Initial installation by GNUmakefile
#
   -----------------------------------------------------------------------------
 */

#ifndef DEFdvector
#define DEFdvector


/*	\Section{Imports}
    Import required system include files
 */
#include <iostream.h>
#include <stdlib.h>
#include <assert.h>


/*  and class header files
 */
#ifndef	   SUBDIR_INCLUDE

#include "vector.hh"
#include "svector.hh"

#else	// #SUBDIR_INCLUDE#

#include "vector/vector.hh"
#include "svector/svector.hh"

#endif	// #SUBDIR_INCLUDE#


//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */
/** Dynamic vectors.
    Class #DVector# is a derived class of #Vector# adding automatic memory
    management to such objects. This allows to implement maths operations
    #operator+# and #operator-#. Further, it is possible to reset the dimension
    of a #DVector#s via method #reDim()#. However, this may render all
    references to values of a #reDim()#ed #DVector# invalid.

    For vectors that are often subject to #reDim()# it may be unconvenient to
    reallocate the required memory every time. Instead, an array of values of
    length #memSize()# is kept, where only the first #dim()# elements are used.
    Initially, #memSize() == dim()#. However, if the dimension is increased,
    #memSize()# will be increased at least by a factor of 1.2 to be prepared for
    futur (small) #reDim()#s. Finally, one can explisitely set #memSize()# with
    method #reSize()#, but not lower than #dim()#.
 */
class DVector : public Vector
{
    int		memsize ;	// length of array of values #mem#
    double*	mem ;		// value array to be used

public:
    /**@name Maths */
    //@{
	/// 
    friend DVector	operator+(const Vector& v, const Vector& w) ;
	/// 
    friend DVector	operator+(const SVector& v, const Vector& w) ;
	/// adding vectors. 
    friend DVector	operator+(const Vector& v, const SVector& w) ;

	/// 
    friend DVector	operator-(const Vector& v, const Vector& w) ;
	/// 
    friend DVector	operator-(const SVector& v, const Vector& w) ;
	/// subtracting vectors. 
    friend DVector	operator-(const Vector& v, const SVector& w) ;

	/// 
    friend DVector	operator-(const Vector& vec) ;
	/// negative vectors. 
    friend DVector	operator-(const SVector& vec) ;

	/// 
    friend DVector	operator*(const Vector& v, double x) ;
	/// scaled vectors. 
    friend DVector	operator*(double x, const Vector& v) ;
    //@}


    /**@name Assignments */
    //@{
	/// 
    DVector&		operator+=(const Vector& vec)
			{
			    Vector::operator+=(vec) ;
			    return *this ;
			}

	/// 
    DVector&		operator+=(const SVector& vec)
			{
			    Vector::operator+=(vec) ;
			    return *this ;
			}

	/// 
    DVector&		operator-=(const Vector& vec)
			{
			    Vector::operator-=(vec) ;
			    return *this ;
			}

	/// 
    DVector&		operator-=(const SVector& vec)
			{
			    Vector::operator-=(vec) ;
			    return *this ;
			}

	/// 
    DVector&		operator*=(double x)
			{
			    Vector::operator*=(x) ;
			    return *this ;
			}

	/// 
    DVector&		operator=(const Vector& vec)
			{
			    if( vec.dim() != dim() )
				reDim( vec.dim() ) ;
			    Vector::operator=(vec) ;
			    return *this ;
			}

	/// 
    DVector&		operator=(const DVector& vec)
			{
			    if( vec.dim() != dim() )
				reDim( vec.dim() ) ;
			    Vector::operator=(vec) ;
			    return *this ;
			}

	/// 
    DVector&		operator=(const SVector& vec)
			{
			    Vector::operator=(vec) ;
			    return *this ;
			}
    //@}

    /**@name Miscellaneous */
    //@{
	/// reset #DVector#s dimension to #newdim#. 
    void		reDim(int newdim) ;
	/// reset #DVector#s memory size to #newsize#. 
    void		reSize(int newsize) ;
	///	reset #DVector#s memory size to #newsize# and dimension to #newdim#
    void		reSize(int newsize, int newdim) ;
	/// get #DVector#s memory size. 
    int			memSize() const		{ return memsize ; }

	/// 
    friend istream&	operator>>(istream& s, DVector& vec) ;
	/// 
			DVector(const Vector& old) ;
	/// 
			DVector(const DVector& old) ;
	/// 
			DVector(int dim = 0) ;
	/// 
			~DVector() ;
	/// 
    int		isConsistent() const ;
    //@}
} ;

#endif
