/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #SPxDefaultRT#

   Identification:
   $Id: spxdefaultrt.hh,v 1.1 1998/07/16 12:11:34 boehm Exp $

   Program history:
   $Log: spxdefaultrt.hh,v $
   Revision 1.1  1998/07/16 12:11:34  boehm
   *** empty log message ***

// Revision 1.5  1996/03/21  11:09:32  bzfwunde
// New Makefile
// Many preformance improvents
// Better numerical stability
//
// Revision 1.4  1996/01/08  12:33:25  bzfwunde
// Moved to new non-GNU generic Makefile environment
//
// Revision 1.3  1995/11/21  16:26:20  bzfwunde
// introduced SUBDIR_INCLUDE
//
// Revision 1.2  1995/10/13  15:35:59  bzfwunde
// minor improvements
//
// Revision 1.1.1.1  1995/03/31  15:04:23  bzfwunde
// tested Version running with set packing
//

    ----------------------------------------------------------------------------
*/
#ifndef DEFspxdefaultrt		// prevent multiple includes
#define DEFspxdefaultrt


//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxratiotester.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxratiotester/spxratiotester.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** textbook ratio test for #SoPlex#. 
    Class #SPxDefaultRT# provides an implementation of the textbook ratio test
    as a derived class of #SPxRatioTester#. This class is not intended for
    reliably solving LPs (even though it does the job for ``numerically simple''
    LPs). Instead, it should serve as a demonstration of how to write ratio
    tester classes.
 */
class SPxDefaultRT : public SPxRatioTester
{
protected:
    SoPlex*	thesolver ;

	/// 
    int		selectLeave(double& val, int start, int incr) ;

	/// 
    SoPlex::Id	selectEnter(double& val, int start1, int incr1, int start2, int incr2) ;

public:
	/// 
    SoPlex*	solver() const				{ return thesolver ; }

	/// 
    void	load( SoPlex* solver )			{ thesolver = solver ; }

	/// 
    void	clear( )				{ thesolver = 0 ; }

	/// 
    int		selectLeave(double& val) ;

	/// 
    SoPlex::Id	selectEnter(double& val) ;

	/// 
    void	setType( SoPlex::Type )					{}
} ;

#endif // #DEFspxdefaultrt#
