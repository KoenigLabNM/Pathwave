/*@ ----------------------------------------------------------------------------
 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 

   Identification:
   $Id: clumembers.h,v 1.1 1998/07/16 12:11:23 boehm Exp $

   Program history:
   $Log: clumembers.h,v $
   Revision 1.1  1998/07/16 12:11:23  boehm
   *** empty log message ***


    ----------------------------------------------------------------------------
 */
#ifndef DATA_STUCTURES
#define DATA_STUCTURES

#include "clutypes.h"

typedef struct	CLUFactor
{
    int	thedim ;		/* dimension of factorized matrix   */
    int	stat ;			/* Status indicator. */
    int	nzCnt ;			/* number of nonzeros in U	*/
    double	initMaxabs ;	/* maximum abs number in initail Matrix	*/
    double	maxabs ;	/* maximum abs number in L and U	*/

    double	rowMemMult ;	/* factor of minimum Memory * #of nonzeros */
    double	colMemMult ;	/* factor of minimum Memory * #of nonzeros */
    double	lMemMult ;	/* factor of minimum Memory * #of nonzeros */

    Perm 	row ;		/* row permutation matrices */
    Perm 	col ;		/* column permutation matrices */

    L		l ;		/* L matrix */
    double	*diag ;		/* Array of pivot elements          */
    U		u ;		/* U matrix */

    double	*work ;		/* Working array: must always be left as 0! */
    double	*work2 ;	/* Working array: must always be left as 0! */
} CLUFactor ;

#endif /* DATA_STUCTURES */
