/*@ ----------------------------------------------------------------------------

			This file is part of the class library

	    SoPlex  --- the Sequential object-oriented simPlex

	    (c) by	Roland Wunderling
			Konarad Zuse Zentrum fuer Informationstechnik Berlin
			Heilbronner Str. 10,
			D-10711 Berlin, Germany

	There is absolutely no right to redistribute this file without the
	explicite permission by the authour.


    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


   Class #LPRow#

   Identification:
   $Id: lprow.hh,v 1.1 1998/07/16 12:11:29 boehm Exp $

   Program history:
   $Log: lprow.hh,v $
   Revision 1.1  1998/07/16 12:11:29  boehm
   *** empty log message ***

// Revision 2.4  1996/01/08  12:23:34  bzfwunde
// Moved to new non-GNU generic Makefile environment
//
// Revision 2.3  1995/11/21  16:21:10  bzfwunde
// introduced SUBDIR_INCLUDE
//
// Revision 2.2  1995/10/13  15:29:38  bzfwunde
// minor improvements
//
// Revision 2.1  1995/03/31  14:59:09  bzfwunde
// tested Version running with set packing
//
// Revision 1.2  1995/03/03  18:47:55  bzfwunde
// changed interface names
// minor bug fixes
//
// Revision 1.1.1.1  1995/01/12  17:36:20  bzfwunde
// initial, tested version
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFlprow		// prevent multiple includes
#define DEFlprow

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "dsvector.hh"

#else 	// #SUBDIR_INCLUDE#

#include "dsvector/dsvector.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** (In)equality for LPs.
    Class #LPRow# provides constraints for linear programs in the form
    \[
			l \le a^Tx \le r,
    \]
    where $a$ is a \Ref{DSVector}. $l$ is referred to as {\em left hand side},
    $r$ as {\rm right hand side} and $a$ as {\em row vector} or the constraint
    vector. $l$ and $r$ may also take values $\pm$#infinity#. This static member
    is predefined, but may be overridden to meet the needs of the LP solver to
    be used.

    #LPRow#s allow to specify regular inequalities of the form 
    \[
			    a^Tx \sim \alpha,
    \]
    where $\sim$ can take any value of $\{\le, =, \ge\}$, by setting #rhs# and
    #lhs# to the same value or setting one of them to $\infty$.

    Since constraints in the regular form occur often, #LPRow#s offers methods
    #type()# and #value()# for retreiving $\sim$ and $\alpha$ of an #LPRow# in
    this form, respectively. Also, a constructor for #LPRow#s given in regular
    form is provided.
 */
class LPRow
{
private:
    double	left, right ;
    DSVector	vec ;

public:
	/// values #>= infinity# are treated as $\infty$. 
    static double	infinity ;

	/** (In)Equality of an LP row.
	    #LPRow#s may be of one of the above #Type#s. This datatype may be
	    used for constructing new #LPRow#s in the regular form.
	 */
    enum Type
    {				/// $a^Tx \le \alpha$. 
	LESS_EQUAL,		/// $a^Tx = \alpha$. 
	EQUAL,			/// $a^Tx \ge \alpha$. 
	GREATER_EQUAL,		/// $\lambda \le a^Tx \le \rho$. 
	RANGE
    } ;

    /**@name Inquiry */
    //@{
	/// 
    Type		type() const ;
	/** Right-hand side value of (in)equality.
	    This method returns $\alpha$ for a #LPRow# in regular form.
	    However, #value()# may only be called for #LPRow#s with
	    #type() != RANGE#.
	 */
    double		value() const ;

	/// 
    double		lhs() const		{ return left ; }
	/// access left hand side value. 
    double&		lhs()			{ return left ; }

	/// 
    double		rhs() const		{ return right ; }
	/// access right hand side value. 
    double&		rhs()			{ return right ; }

	/// 
    const SVector&	rowVector() const	{ return vec ; }
	/// access constraint rowVector. 
    DSVector&		rowVector()		{ return vec ; }
    //@}

    /**@name Miscellaneous */
    //@{
	/** Construct #LPRow# with a vector ready to hold #defDim# nonzeros
	 */
    LPRow( int defDim = 0 )
   	: left(0), right( infinity ), vec( defDim )		{}

	/// 
    LPRow(const LPRow& row)
    	: left(row.left), right(row.right), vec(row.vec)	{}

	/** Construct #LPRow# with the given left-hand side, right-hand side
	    and rowVector.
	 */
    LPRow(double lhs, const SVector& rowVector, double rhs)
    	: left(lhs), right(rhs), vec(rowVector)	{}

	/** Construct #LPRow# from passed #rowVector#, #type# and #value#
	 */
    LPRow(const SVector& rowVector, Type type, double value) ;

	/// check consistency. 
    int	isConsistent() const			{ return vec.isConsistent() ; }
    //@}
} ;

#endif // #DEFlprow#
