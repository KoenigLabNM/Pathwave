/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #SPxWeightst#

   Identification:
   $Id: spxweightst.hh,v 1.1 1998/07/16 12:11:41 boehm Exp $

   Program history:
   $Log: spxweightst.hh,v $
   Revision 1.1  1998/07/16 12:11:41  boehm
   *** empty log message ***

// Revision 1.3  1996/03/21  11:11:11  bzfwunde
// New Makefile
// Various improvents
//
// Revision 1.2  1995/11/21  16:32:26  bzfwunde
// - introduced SUBDIR_INCLUDE
// - improvements: made more CPLEX-like, but not quite :-(
//
// Revision 1.1.1.1  1995/05/22  15:41:17  bzfwunde
// starter with simple-minded heuristic
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFspxweightst		// prevent multiple includes
#define DEFspxweightst

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxstarter.hh"
#include "dataarray.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxstarter/spxstarter.hh"
#include "dataarray/dataarray.hh"

#endif	// #SUBDIR_INCLUDE#


//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** weighted start basis. 
    Class #SPxWeightST# is an implementation of a #SPxStarter# for generating a
    Simplex starting basis. Using method #setupWeights()# it sets up arrays
    #weight# and #coWeight#, or equivalently #rowWeight# and #colWeight#.
    (#rowWeight# and #colWeight# are just pointers initialized to #weight# and
    #coWeight# according to the representation of \Ref{SoPlex} #base# passed to
    method #generate#.) 

    The weight values are then used to setup a starting basis for the LP:
    vectors with low values are likely to become dual (i.e. basic for a column
    basis) and such with high values are likely to become primal (i.e. nonbasic
    for a column basis).
    
    However, if a varialbe having an upper and lower bound is to become primal,
    there is still a choice for setting it either to its upper or lower bound.
    Members #rowRight# and #colUp# are used to determine where to set a primal
    variable. If #rowRight[i]# is set to a nonzero value, the right-hand side
    inequality is set tightly for the #i#-th to become primal. Analogously, If
    #colUp[j]# is nonzero, the #j#-th variable will be set to its upper bound
    if it becomes primal.
 */
class SPxWeightST : public SPxStarter
{
    DataArray<int>	forbidden ;

    DataArray<double>*	weight ;
    DataArray<double>*	coWeight ;
    void    SPxWeightST::setPrimalStatus(SPxBasis::Desc&, const SoPlex&, const SoPlex::Id&) ;

protected:
	/// weight value for LP rows. 
    DataArray<double>	rowWeight ;
	/// weight value for LP columns. 
    DataArray<double>	colWeight ;

	/// set variable to rhs?. 
    DataArray<int>	rowRight ;
	/// set primal variable to upper bound. 
    DataArray<int>	colUp ;

	/**
	    This method is called in order to setup the weights for all
	    variables. It has been declared #virtual# in order to allow for
	    derived classes to compute other weight values.
	 */
    virtual void	setupWeights( SoPlex& base ) ;

public:
	/// 
    void	generate( SoPlex& base ) ;

	/// 
    SPxWeightST()	{}
	/// 
    int		isConsistent() const ;
} ;

#endif // #DEFspxweightst#
