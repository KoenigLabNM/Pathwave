/*@ ----------------------------------------------------------------------------

   Class #SPxRem1SM#

   Identification:
   $Id: spxrem1sm.hh,v 1.1 1998/07/16 12:11:38 boehm Exp $

   Program history:
   $Log: spxrem1sm.hh,v $
   Revision 1.1  1998/07/16 12:11:38  boehm
   *** empty log message ***


    ----------------------------------------------------------------------------
*/

#ifndef DEF_SPxRem1SM_H		// prevent multiple includes
#define DEF_SPxRem1SM_H

//@ ----------------------------------------------------------------------------
/*  \Section{Imports}
    Import required system include files ...
 */
#include <assert.h>


/*  ... and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxsimplifier.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxsimplifier/spxsimplifier.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** LP simplifier for removing singletons. 
    This \Ref{SPxSimplifier} removes rows and possibly columns containing one
    nonzero value only.
 */
class SPxRem1SM : public SPxSimplifier
{
private:
    SPxLP*	lp ;
    double	delta ;

protected:
public:
	/// 
    void	load( SPxLP* ) ;
	/// 
    void	unload( ) ;
	/// 
    SPxLP*	loadedLP() const 		{ return lp ; }
	/// 
    int		simplify( ) ;
	/// 
    void	unsimplify( ) ;
	/// 
    double	value( double x )	{ return x - lp->spxSense()*delta ; }
} ;

#endif // #DEF_SPxRem1SM_H#
