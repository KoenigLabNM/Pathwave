/*@ ----------------------------------------------------------------------------

   Class #SPxDevexPR#

   Identification:
   $Id: spxdevexpr.hh,v 1.1 1998/07/16 12:11:34 boehm Exp $

   Program history:
   $Log: spxdevexpr.hh,v $
   Revision 1.1  1998/07/16 12:11:34  boehm
   *** empty log message ***


    ----------------------------------------------------------------------------
*/

#ifndef DEF_SPxDevexPR_H		// prevent multiple includes
#define DEF_SPxDevexPR_H

//@ ----------------------------------------------------------------------------
/*  \Section{Imports}
    Import required system include files ...
 */
#include <assert.h>


/*  ... and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxpricer.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxpricer/spxpricer.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/// Devex Pricer for SoPlex. 
/** The Devex Pricer for SoPlex implements an approximate steepest edge pricing,
    that does without solving an extra linear system and computing the scalar
    products.
 */
class SPxDevexPR : public SPxPricer
{
private:
protected:
    double	last ;		// penalty, selected at last iteration
    DVector	penalty ;	// vector of pricing penalties
    DVector	coPenalty ;	// vector of pricing penalties

    SoPlex*	thesolver ;
    double	theeps ;

public:
	/// return loaded solver. 
    SoPlex*	solver() const				{ return thesolver ; }
	/// bound violations up to #epsilon# are tollerated. 
    double	epsilon() const				{ return theeps ; }
	/// 
    void	setEpsilon( double eps )		{ theeps = eps ; }

	/// 
    void	load( SoPlex* base ) ;
	/// 
    void	clear()					{ thesolver = 0 ; }
	/// 
    void	setType( SoPlex::Type ) ;
	/// 
    void	setRep( SoPlex::Representation rep ) ;

	/// 
    int		selectLeave() ;
protected:
    int		selectLeave(double& best, int start=0, int incr=1) ;
public:

	/// 
    void	left4(int n, SoPlex::Id id) ;
protected:
    void	left4(int n, SoPlex::Id id, int start, int incr) ;
public:

	/// 
    SoPlex::Id	selectEnter() ;
protected:
    SoPlex::Id	selectEnter(double& best, int start1=0, int incr1=1,
    					  int start2=0, int incr2=1) ;
public:

	/// 
    void	entered4(SoPlex::Id id, int n) ;
protected:
    void	entered4(SoPlex::Id id, int n, int start1, int incr1, int start2, int incr2) ;
public:


	/// #n# vectors have been added to loaded LP. 
    virtual void	addedVecs  ( int n ) ;
	/// #n# covectors have been added to loaded LP. 
    virtual void	addedCoVecs( int n ) ;


	/// These  methods are use for implemementing the public remove methods. 
    virtual void	removedVec(int i) ;
	/// 
    virtual void	removedCoVecs(const int perm[]) ;
	/// 
    virtual void	removedVecs(const int perm[]) ;
	/// 
    virtual void	removedCoVec(int i) ;


	/// 
    void	changeObj( const Vector& newObj )
		{ (void)newObj ; }
	/// 
    void	changeObj( int i, double newVal )
		{ (void)newVal ; (void)i ; }
	/// 
    void	changeLower( const Vector& newLower )
		{ (void)newLower ; }
	/// 
    void	changeLower( int i, double newLower )
		{ (void)i ; (void)newLower ; }
	/// 
    void	changeUpper( const Vector& newUpper )
		{ (void)newUpper ; }
	/// 
    void	changeUpper( int i, double newUpper )
		{ (void)i ; (void)newUpper ; }
	/// 
    void	changeLhs( const Vector& newLhs )
		{ (void)newLhs ; }
	/// 
    void	changeLhs( int i, double newLhs )
		{ (void)i ; (void)newLhs ; }
	/// 
    void	changeRhs( const Vector& newRhs )
		{ (void)newRhs ; }
	/// 
    void	changeRhs( int i, double newRhs )
		{ (void)i ; (void)newRhs ; }
	/// 
    void	changeRow( int i, const LPRow& newRow )
		{ (void)i ; (void)newRow ; }
	/// 
    void	changeCol( int i, const LPCol& newCol )
		{ (void)i ; (void)newCol ; }
	/// 
    void	changeElement( int i, int j, double val )
		{ (void)i ; (void)j ; (void)val ; }
	/// 
    void	changeSense( SoPlex::Sense sns )
		{ (void)sns ; }

	/// 
    int	isConsistent() const ;
} ;

#endif // #DEF_SPxDevexPR_H#
