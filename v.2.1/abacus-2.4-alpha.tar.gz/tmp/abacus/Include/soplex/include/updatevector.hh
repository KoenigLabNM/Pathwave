/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 

   
   Class #UpdateVector#
   
   Identification:
   $Id: updatevector.hh,v 1.1 1998/07/16 12:11:44 boehm Exp $
   
   Program history:
   $Log: updatevector.hh,v $
   Revision 1.1  1998/07/16 12:11:44  boehm
   *** empty log message ***

// Revision 2.6  1996/03/21  11:03:35  bzfwunde
// New Makefile
// Many preformance improvents
//
// Revision 2.5  1995/11/21  16:22:55  bzfwunde
// introduced SUBDIR_INCLUDE
//
// Revision 2.4  1995/10/13  15:31:58  bzfwunde
// minor improvements
//
// Revision 2.3  1995/05/22  15:25:46  bzfwunde
// changed PSVector -> SVector
// provide sparse updates only
//
// Revision 2.2  1995/05/17  11:29:12  bzfwunde
// based on SSVectors
//
// Revision 2.1  1995/03/31  14:56:13  bzfwunde
// tested Version running with set packing
//
// Revision 1.3  1995/03/03  19:02:17  bzfwunde
// minor bug fixes
// improvements
//
// Revision 1.2  1994/11/25  10:40:51  bzfwunde
// switched to c++doc
// bugfixes
//
   
   ----------------------------------------------------------------------------
*/

#ifndef DEFupdatevector
#define DEFupdatevector

#include <assert.h>

#ifndef	SUBDIR_INCLUDE

#include "dvector.hh"
#include "ssvector.hh"

#else 	// #SUBDIR_INCLUDE#

#include "dvector/dvector.hh"
#include "ssvector/ssvector.hh"

#endif	// #SUBDIR_INCLUDE#

extern "C"
{
void UpdateUpdateVector( double*, double, int, const int*, const double* ) ;
}

//@ ----------------------------------------------------------------------------

/*  \Section{Class Declaration}
    The datastructur of #UpdateVector# is straightforward. It adds to the
    baseclass #DVector# another #SSVector thedelta# for the update vector
    $\delta$ and a #double theval# for the update value $\alpha$.
 */

/** vector with updates. 
    In many algorithms vectors are updated in every iteration, by adding a
    multiple of another vector to it, i.e., given a vector $x$, a scalar
    $\alpha$ and another vector $\delta$, the update to $x$ constists of
    substituting it by $x \leftarrow x + \alpha\cdot\delta$.

    While the update itself can easily be expressed with methods of #Vector#,
    it is often desirable to save the last update vector $\delta$ and value
    $\alpha$. This is provided by class #UpdateVector#.

    #UpdateVector#s are derived from #DVector# and provide additional methods
    for saving and setting the multiplicator $\alpha$ and the update vector
    $\delta$. Further, it allows for efficient sparse updates, by providing an
    #IdxSet# idx containing the nonzero indeces of $\delta$.
 */
class UpdateVector : public DVector
{
    double		theval ;
    SSVector		thedelta ;

public:
	/// 
    double&		value()			{ return theval ; }
	/// update multiplicator $\alpha$. 
    double		value() const		{ return theval ; }

	/// 
    SSVector&		delta()			{ return thedelta ; }
	/// update vector $\delta$. 
    const SSVector&	delta() const		{ return thedelta ; }

	/// nonzero indeces of $\delta$. 
    const IdxSet&	idx() const		{ return thedelta.indices() ; }

	/** Update vector with $\alpha \cdot \delta$. 
	 *  Add #value() * delta()# to the #UpdateVector#. Only the indeces set
	 *  in #idx()# are affected. For all other indeces, #delta()# is asumed
	 *  to be 0.
	 */
    void		update()		{ multAdd( theval, thedelta ) ; }

	/// clear vector and update vector. 
    void	clear()
    		{
		    DVector::clear() ;
		    clearUpdate() ;
		}

	/// clear $\delta$, $\alpha$ and #idx()# using #idx()#. 
    void	clearUpdate()
    		{
		    thedelta.clear() ;
		    theval = 0 ;
		}


	/// reset dimension. 
    void	reDim( int newdim )
    		{
		    DVector::reDim(newdim) ;
		    thedelta.reDim(newdim) ;
		}

	/// 
    UpdateVector&	operator=(const DVector& rhs)
    {
	DVector::operator=(rhs) ;
	return *this ;
    }

	/// 
    UpdateVector&	operator=(const UpdateVector& rhs) ;

	/// default constructor. 
		UpdateVector( int dim /*=0*/, double eps /*=1e-16*/ )
		    : DVector ( dim ),
		      theval  ( 0 ),
		      thedelta( dim, eps )
		{ }

	/// 
    int		isConsistent() const ;
} ;


#endif // DEFupdatevector
