/*@ ----------------------------------------------------------------------------
 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 

   Identification:
   $Id: clutypes.h,v 1.1 1998/07/16 12:11:24 boehm Exp $

   Program history:
   $Log: clutypes.h,v $
   Revision 1.1  1998/07/16 12:11:24  boehm
   *** empty log message ***


    ----------------------------------------------------------------------------
 */

#ifndef CLU_TYPES
#define CLU_TYPES

/*
 * 	This file defines all C data structures involved in the high-speed
 *	C sparse LU factorization routine.
 */

/*	Data structures for saving the row and column permutations.
 */
typedef struct
{
    int	*orig ;		/* orig[p] original index from p */
    int	*perm ;		/* perm[i] permuted index from i */
} Perm ;


/*	Double linked ring structure for garbage collection of column or
 *	row file in working matrix.
 */
typedef struct _dr_
{
    struct _dr_	*next ;
    struct _dr_	*prev ;
    int		idx ;
} Dring ;

/*	Data structures for saving the working matrix and U factor.
 */
typedef struct
{
    struct Row
    {
	Dring	list ;		/* Double linked ringlist of vector
				   indices in the order they appear
				   in the row file */
	Dring	*elem ;		/* Array of ring elements.            */
	int	size ;		/* size of arrays val and idx         */
	int	used ;		/* used entries of arrays idx and val */
	double	*val ;		/* hold nonzero values                */
	int	*idx ;		/* hold nonzero indices               */
	int	*start ;	/* starting positions in val and idx  */
	int	*len ;		/* used nonzeros per row vectors      */
	int	*max ;		/* maximum available nonzeros per row:
				   start[i] + max[i] == start[elem[i].next->idx] 
				   len[i] <= max[i].
				 */
    }	row ;
    struct Col
    {
	Dring	list ;		/* Double linked ringlist of vector
				   indices in the order they appear
				   in the column file */
	Dring	*elem ;		/* Array of ring elements.            */
	int	size ;		/* size of array idx                  */
	int	used ;		/* used entries of array idx          */
	int	*idx ;		/* hold nonzero indices               */
	double	*val ;		/* hold nonzero values: this is only initialized
				   in the end of the factorization with DEFAULT
				   updates.
				 */
	int	*start ;	/* starting positions in val and idx  */
	int	*len ;		/* used nonzeros per column vector    */
	int	*max ;		/* maximum available nonzeros per colunn:
				   start[i] + max[i] == start[elem[i].next->idx] 
				   len[i] <= max[i].
				 */
    }	col ;
    int	lastColSing ;		/* stage of last eliminated column singleton */
    int	lastRowSing ;		/* stage of last eliminated row singleton */
} U ;


/*	Data structures for saving the working matrix and U factor.
 */
typedef struct
{
    int		size ;		/* size of arrays val and idx        */
    double	*val ;		/* values of L vectors               */
    int		*idx ;		/* indices of L vectors	             */
    int		startSize ;	/* size of array start               */
    int		firstUpdate ;	/* number of first update L vector   */
    int		firstUnused ;	/* number of first unused L vector   */
    int		*start ;	/* starting positions in val and idx */
    int		*row ;		/* column indices of L vectors       */
    int		updateType ;	/* type of updates to be used.       */

    /*  The following arrays have length |firstUpdate|, since they keep
	rows of the L-vectors occuring during the factorization (without
	updates), only:
     */
    double	*rval ;		/* values of rows of L               */
    int		*ridx ;		/* indices of rows of L              */
    int		*rbeg ;		/* start of rows in rval and ridx    */
    int		*rorig ;	/* original row permutation          */
    int		*rperm ;	/* original row permutation          */
} L ;


#ifndef __cplusplus
typedef struct
{
    double	val ;
    int		idx ;
} PSVector_Element ;

typedef struct
{
    PSVector_Element* elem ;
} SVector ;

#define	PSV_MAX(sv)	( (*(int*)&(sv)->elem[-1].val) )
#define	PSV_SIZ(sv)	( (sv)->elem[-1].idx )

#endif

#endif /* CLU_TYPES */
