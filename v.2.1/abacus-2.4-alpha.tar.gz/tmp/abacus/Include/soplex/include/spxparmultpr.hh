/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #SPxParMultPr#

   Identification:
   $Id: spxparmultpr.hh,v 1.1 1998/07/16 12:11:36 boehm Exp $

   Program history:
   $Log: spxparmultpr.hh,v $
   Revision 1.1  1998/07/16 12:11:36  boehm
   *** empty log message ***

// Revision 1.2  1996/03/21  11:07:48  bzfwunde
// New Makefile
// Many preformance improvents
//
// Revision 1.1.1.1  1996/01/08  12:31:34  bzfwunde
// initial version of partial multiple pricing
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFspxparmultpr		// prevent multiple includes
#define DEFspxparmultpr

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "spxpricer.hh"
#include "dataarray.hh"
#include "array.hh"
#include "ssvector.hh"

#else 	// #SUBDIR_INCLUDE#

#include "spxpricer/spxpricer.hh"
#include "dataarray/dataarray.hh"
#include "array/array.hh"
#include "ssvector/ssvector.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */
struct SPxParMultPr_Tmp
{
    SoPlex::Id	id ;
    double	test ;
} ;

/** partial multiple pricing. 
    Class #SPxParMultPr# is an implementation class for #SPxPricer# implementing
    Dantzig's the default pricing strategy with partial multiple pricing.
    Partial multiple pricing applies to the #ENTER#ing Simplex only. A set of
    #partialSize# eligible pivot indices is selected (partial pricing). In the
    following Simplex iterations pricing is are restricted to these indices
    (multiple pricing) until no more eligable pivots are available. Partial
    multiple pricing significantly reduces the computation time for computing
    the matrix-vector-product in the Simplex algorithm.
 */
class SPxParMultPR : public SPxPricer
{
protected:
    SoPlex*			thesolver ;
    double			theeps ;
    DataArray<SPxParMultPr_Tmp>	pricSet ;
    int				multiParts ;
    int				used ;
    int				min ;
    int				last ;
    int				count ;

public:
	/// Set size for partial pricing. 
    static int	partialSize ;

	/// 
    SoPlex*	solver() const				{ return thesolver ; }

	/// 
    double	epsilon() const				{ return theeps ; }
	/// 
    void	setEpsilon( double eps )		{ theeps = eps ; }

	/// 
    void	load( SoPlex* solver ) ;

	/// 
    void	clear()					{ thesolver = 0 ; }

	/// 
    void	setType( SoPlex::Type tp ) ;
	/// 
    void	setRep( SoPlex::Representation rep )	{ (void)rep ; }

	/// 
    int		selectLeave() ;
	/// 
    void	left4(int n, SoPlex::Id id)		{ (void)n ; (void)id ; }

	/// 
    SPxLP::Id	selectEnter() ;
	/// 
    void	entered4(SoPlex::Id id, int n) ;


	/// 
    void	addedVecs  ( int n )
		{ (void)n ; }
	/// 
    void	addedCoVecs( int n )
		{ (void)n ; }


	/// 
    void	removedVec(int i)
		{ (void)i ; }
	/// 
    void	removedVecs(const int perm[])
		{ (void)perm ; }
	/// 
    void	removedCoVec(int i)
		{ (void)i ; }
	/// 
    void	removedCoVecs(const int perm[])
		{ (void)perm ; }


	/// 
    void	changeObj( const Vector& newObj )
		{ (void)newObj ; }
	/// 
    void	changeObj( int i, double newVal )
		{ (void)newVal ; (void)i ; }
	/// 
    void	changeLower( const Vector& newLower )
		{ (void)newLower ; }
	/// 
    void	changeLower( int i, double newLower )
		{ (void)i ; (void)newLower ; }
	/// 
    void	changeUpper( const Vector& newUpper )
		{ (void)newUpper ; }
	/// 
    void	changeUpper( int i, double newUpper )
		{ (void)i ; (void)newUpper ; }
	/// 
    void	changeLhs( const Vector& newLhs )
		{ (void)newLhs ; }
	/// 
    void	changeLhs( int i, double newLhs )
		{ (void)i ; (void)newLhs ; }
	/// 
    void	changeRhs( const Vector& newRhs )
		{ (void)newRhs ; }
	/// 
    void	changeRhs( int i, double newRhs )
		{ (void)i ; (void)newRhs ; }
	/// 
    void	changeRow( int i, const LPRow& newRow )
		{ (void)i ; (void)newRow ; }
	/// 
    void	changeCol( int i, const LPCol& newCol )
		{ (void)i ; (void)newCol ; }
	/// 
    void	changeElement( int i, int j, double val )
		{ (void)i ; (void)j ; (void)val ; }
	/// 
    void	changeSense( SoPlex::Sense sns )
		{ (void)sns ; }

	/// 
    int		isConsistent() const ;
} ;


#endif // #DEFspxparmultprr#
