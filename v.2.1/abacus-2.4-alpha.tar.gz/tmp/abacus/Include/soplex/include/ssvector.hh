/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #SSVector#

   Identification:
   $Id: ssvector.hh,v 1.1 1998/07/16 12:11:42 boehm Exp $

   Program history:
   $Log: ssvector.hh,v $
   Revision 1.1  1998/07/16 12:11:42  boehm
   *** empty log message ***

// Revision 1.6  1996/03/21  10:56:46  bzfwunde
// Many preformance improvents
// New Makefile
//
// Revision 1.5  1996/01/08  12:20:15  bzfwunde
// Moved to new non-GNU generic Makefile environment
//
// Revision 1.4  1995/11/21  16:16:54  bzfwunde
// - some optimizations
// - introduced SUBDIR_INCLUDE
//
// Revision 1.3  1995/10/13  15:23:12  bzfwunde
// minor improvements
//
// Revision 1.2  1995/05/22  15:23:13  bzfwunde
// changed PSVector -> SVector
//
// Revision 1.1.1.1  1995/05/17  11:28:15  bzfwunde
// Semi Sparse Vectors
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFssvector		// prevent multiple includes
#define DEFssvector

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>



/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "dvector.hh"
#include "subsvector.hh"
#include "svector.hh"
#include "didxset.hh"

#else 	// #SUBDIR_INCLUDE#

#include "dvector/dvector.hh"
#include "subsvector/subsvector.hh"
#include "svector/svector.hh"
#include "didxset/didxset.hh"

#endif	// #SUBDIR_INCLUDE#

class	SVSet ;



//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/** semi sparse vector. 
    This class implements {\bf S}emi {\bf S}parse {\bf Vector}s. Such are
    #DVector#s where the indices of its nonzero elements can be stored in an
    extra #IdxSet#. Only elements with absolute value #> epsilon# are considered
    to be nonzero. Since really storing the nonzeros is not allways convenient,
    an #SSVector# provides two different statuses: setup and not setup.
    An #SSVector# being setup means that the nonzero indices are available,
    otherwise an #SSVector# is just an ordinary #Vector# with an empty #IdxSet#.
 */
class SSVector : protected DVector, protected DIdxSet
{
    SSVector&	assign2product1(const SVSet& A, const SSVector& x ) ;
    SSVector&	assign2productShort(const SVSet& A, const SSVector& x ) ;
    SSVector&	assign2productFull(const SVSet& A, const SSVector& x ) ;

    int		setupStatus ;

    friend class	DVector ;
    friend class	Vector ;
    friend class	DSVector ;
    friend class	SMoPlex ;

public:
    /// 
    double	epsilon ;

    /**@name Status of an #SSVector#
        An #SSVector# can be setup or not. In case it is setup, its #IdxSet#
	correctly contains all indices of nonzero elements of the #SSVector#.
	Otherwise, it does not contain any usefull data. Wheter or not an
	#SSVector# is setup can be determined with method #isSetup()#.

	There are three method for directly affecting the setup status of an
	#SSVector#
	\begin{description}
	\item[unSetup]		This method sets the status to ``not setup''.
	\item[setup]		This method initializes the #IdxSet# to the
				#SSVector#s nonzero indices and sets the status
				to ``setup''.
	\item[forceSetup]	This method sets the status to ``setup'' without
				verifying, that the #IdxSet# correctly contains
				all nonzero indices. It may be used when the
				nonzero indices have been computed externally.
	\end{description}
     */
    //@{
	/// return setup status. 
    int		isSetup() const			{ return setupStatus ; }

	/// make #SSVector# not setup. 
    void	unSetup()			{ setupStatus = 0 ; }

	/*/ initialize nonzero indices for all elements with absolute values
	    #> eps# and set all other elements to 0.
	 */
    void	setup( ) ;

	/// force setup status. 
    void	forceSetup( )			{ setupStatus = 1 ; }
    //@}

    /**@name Methods for a setup #SSVectors# */
    //@{
	/// return #n#-th index. 
    int		index(int n) const
    		{
		    assert( isSetup() ) ;
		    return IdxSet::index(n) ;
		}

	/// return value to #n#-th index. 
    double	value(int n) const
    		{
		    assert( isSetup() ) ;
		    assert( n >= 0 && n < size() ) ; 
		    return val[idx[n]] ;
		}

	/// find number of index #i# (or -1). 
    int		number(int i) const
    		{
		    assert( isSetup() ) ;
		    return IdxSet::number(i) ;
		}

	/// number of nonzeros. 
    int		size() const
    		{
		    assert( isSetup() ) ;
		    return IdxSet::size() ;
		}

	/*/ add nonzero #(i,x)# to #SSVector#
	    (no nonzero with index #i# must exist!)
	 */
    void	add( int i, double x )
    		{
		    assert( val[i] == 0 ) ;
		    assert( number(i) < 0 ) ;
		    addIdx(i) ;
		    val[i] = x ;
		}

	/// set #i#-t element to x. 
    void	setValue( int i, double x ) ;

	/// clear element #i#. 
    void	clearIdx( int i )
    		{
		    if( isSetup() )
		    {
			int	n = number(i) ;
			if( n >= 0 )
			    remove( n ) ;
		    }
		    val[i] = 0 ;
		}

	/// set #n#-th nonzero element to 0 (must exist!). 
    void	clearNum( int n )
    		{
		    assert( isSetup() ) ;
		    assert( index(n) >= 0 ) ;
		    val[index(n)] = 0 ;
		    remove( n ) ;
		}
    //@}


    /**@name Methods independend on the Status */
    //@{
	/// return #i#-th value. 
    double	operator[](int i) const		{ return val[i] ; }

	/// return array indices. 
    const int*	indexMem() const		{ return IdxSet::indexMem() ; }

	/// return array values. 
    const double*	values() const		{ return val ; }

	/// return indices. 
    const IdxSet&	indices() const		{ return *this ; }

	/// return array indices. 
    int*	altIndexMem()
    		{
		    unSetup() ;
		    return IdxSet::indexMem() ;
		}

	/// return array values. 
    double*	altValues()
    		{
		    unSetup() ;
		    return val ;
		}

	/// return indices. 
    IdxSet&	altIndices()
    		{
		    unSetup() ;
		    return *this ;
		}
    //@}


    /**@name Mathematical opeations */
    //@{
	/// 
    SSVector&	operator+=(const Vector& vec) ;
	/// 
    SSVector&	operator+=(const SVector& vec) ;
	/// 
    SSVector&	operator+=(const SubSVector& vec) ;
	/// 
    SSVector&	operator+=(const SSVector& vec) ;

	/// 
    SSVector&	operator-=(const Vector& vec) ;
	/// 
    SSVector&	operator-=(const SVector& vec) ;
	/// 
    SSVector&	operator-=(const SubSVector& vec) ;
	/// 
    SSVector&	operator-=(const SSVector& vec) ;

	/// 
    SSVector&	operator*=(double x) ;

	/// add scaled vector (#+= x*vec#). 
    SSVector&	multAdd(double x, const SSVector& vec ) ;
	/// 
    SSVector&	multAdd(double x, const SVector& vec ) ;
	/// 
    SSVector&	multAdd(double x, const SubSVector& vec ) ;
	/// 
    SSVector&	multAdd(double x, const Vector& vec ) ;

	/// assign #SSVector# to $x^T \cdot A$. 
    SSVector&	assign2product(const SSVector& x, const SVSet& A ) ;
	/// assign #SSVector# to $A \cdot x$. 
    SSVector&	assign2product(const SVSet& A, const SSVector& x ) ;
	/// assign #SSVector# to $A \cdot x$ for a setup #x#. 
    SSVector&	assign2product4setup(const SVSet& A, const SSVector& x ) ;
	/// assign #SSVector# to $A \cdot x$ thereby setting up #x#. 
    SSVector&	assign2productAndSetup(const SVSet& A, SSVector& x ) ;

	/// infinity norm of a Vector. 
    double	maxAbs() const ;
	/// euclidian norm of a Vector. 
    double	length() const ;
	/// squared norm of a Vector. 
    double	length2() const ;
    //@}

    /**@name Miscellaneous */
    //@{
	/// 
    int		dim() const		{ return dimen ; }
	/// reset dimension. 
    void	reDim ( int newdim ) ;
	/// set number of nonzeros (thereby unSetup SSVector). 
    void	setSize( int n )
    		{
		    unSetup() ;
		    IdxSet::setSize( n ) ;
		}
	/// reset memory consumption. 
    void	reMem( int newsize ) ;
	/// set to 0. 
    void	clear () ;

	/// 
    SSVector&	operator=(const SSVector& rhs) ;
	/// setup #rhs# vector, if it is not allready. 
    SSVector&	operator=(SSVector& rhs) ;
	/// 
    SSVector&	operator=(const SVector& rhs) ;
	/// 
    SSVector&	operator=(const Vector& rhs)
    		{
		    unSetup() ;
		    Vector::operator=(rhs) ;
		    return *this ;
		}
	/// assign only the elements of #rhs#. 
    SSVector&	assign(const SVector& rhs ) ;

	/// construct nonsetup copy of #vec#. 
    SSVector( const Vector& vec, double eps=1e-16 )
	: DVector    ( vec )
	, DIdxSet    ( vec.dim()+1 )
	, setupStatus( 0 )
	, epsilon    ( eps )
    { }

	/// 
    SSVector( int dim=0, double eps=1e-16 )
	: DVector    ( dim )
	, DIdxSet    ( dim+1 )
	, setupStatus( 1 )
	, epsilon    ( eps )
    {
	Vector::clear() ;
    }

	/// 
    SSVector( const SSVector& vec )
	: DVector    ( vec )
	, DIdxSet    ( vec.dim()+1 )
	, setupStatus( vec.setupStatus )
	, epsilon    ( vec.epsilon )
    {
	*((DIdxSet*)this) = vec ;
    }

	/// 
    int	isConsistent() const ;
    //@}
} ;


//@ ----------------------------------------------------------------------------

inline Vector&	Vector::multAdd(double x, const SSVector& svec)
{
    assert( svec.dim() <= dim() ) ;
    if( svec.isSetup() )
	Vector_MultAddSSVector( val, x,
				svec.size(),
				svec.indexMem(),
				svec.val ) ;
    else
	multAdd( x, *(const Vector*)&svec ) ;
    return *this ;
}

inline Vector&	Vector::assign(const SSVector& svec)
{
    assert( svec.dim() <= dim() ) ;
    if( svec.isSetup() )
	Vector_Set0toSSVector( val, svec.size(), svec.indexMem(), svec.val ) ;
    else
	operator=( *(const Vector*)&svec ) ;
    return *this ;
}

inline Vector&	Vector::operator=(const SSVector& vec)
{
    if( vec.isSetup() )
    {
	clear ( ) ;
	assign( vec ) ;
    }
    else
	operator=( *(const Vector*)&vec ) ;
    return *this ;
}

inline double	Vector::operator*(const SSVector& v) const
{
    assert( dim() == v.dim() ) ;
    if( v.isSetup() )
	return MultiplyVectorSSVector( val, v.size(), v.indexMem(), v.val ) ;
    else
	return operator*( *(const Vector*)&v ) ;
}

#endif // #DEFssvector#
