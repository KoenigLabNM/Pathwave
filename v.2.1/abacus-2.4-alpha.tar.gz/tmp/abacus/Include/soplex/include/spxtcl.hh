/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Module #SPxTCL#

   Identification:
   $Id: spxtcl.hh,v 1.1 1998/07/16 12:11:40 boehm Exp $

   Program history:
   $Log: spxtcl.hh,v $
   Revision 1.1  1998/07/16 12:11:40  boehm
   *** empty log message ***

// Revision 1.4  1996/03/21  10:54:17  bzfwunde
// Many preformance improvents
//
// Revision 1.3  1996/01/08  12:18:17  bzfwunde
// Moved to new non-GNU generic Makefile environment
//
// Revision 1.2  1995/11/21  16:12:47  bzfwunde
// - added some commands
// - adapted for more tcl versions
//
// Revision 1.1.1.1  1995/05/17  11:24:58  bzfwunde
// TCL shell for SoPlex
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFspxtcl		// prevent multiple includes
#define DEFspxtcl


//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
extern "C" {
#include <assert.h>
#include <stdio.h>
#include <signal.h>
}


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "soplex.hh"
#include "slufactor.hh"
#include "timer.hh"
#include "spxdefaultpr.hh"
#include "spxparmultpr.hh"
#include "spxhybridpr.hh"
#include "spxsteeppr.hh"
#include "spxdevexpr.hh"
#include "spxweightpr.hh"
#include "spxdefaultrt.hh"
#include "spxharrisrt.hh"
#include "spxfastrt.hh"
#include "spxweightst.hh"
#include "spxsumst.hh"
#include "spxvectorst.hh"
#include "spxscale.hh"
#include "spxrem1sm.hh"
#include "spxredundantsm.hh"
#include "spxaggregatesm.hh"
#include "spxgeneralsm.hh"

#else 	// #SUBDIR_INCLUDE#

#include "soplex/soplex.hh"
#include "slufactor/slufactor.hh"
#include "timer/timer.hh"
#include "spxdefaultpr/spxdefaultpr.hh"
#include "spxhybridpr/spxhybridpr.hh"
#include "spxparmultpr/spxparmultpr.hh"
#include "spxsteeppr/spxsteeppr.hh"
#include "spxdevexpr/spxdevexpr.hh"
#include "spxweightpr/spxweightpr.hh"
#include "spxdefaultrt/spxdefaultrt.hh"
#include "spxharrisrt/spxharrisrt.hh"
#include "spxfastrt/spxfastrt.hh"
#include "spxweightst/spxweightst.hh"
#include "spxsumst/spxsumst.hh"
#include "spxvectorst/spxvectorst.hh"
#include "spxscale/spxscale.hh"
#include "spxrem1sm/spxrem1sm.hh"
#include "spxredundantsm/spxredundantsm.hh"
#include "spxaggregatesm/spxaggregatesm.hh"
#include "spxgeneralsm/spxgeneralsm.hh"

#endif	// #SUBDIR_INCLUDE#


extern "C" {
void	initSPxTCL( Tcl_Interp* interp ) ;
}

//@ ----------------------------------------------------------------------------
/* \Section{Class Declaration}
 */

/// TCL interpreter for SoPlex.
class SPxTCL : public SoPlex
{
public:
    SLUFactor	slu ;
    static int	cntrC ;
private:
    int		terminate()
    		{
		    if( cntrC )
			return 1 ;
		    if( maxTime > 0  &&  time() > maxTime )
			return 1 ;
		    return SoPlex::terminate() ;
		}

    void	factorize( )
		{
		    SoPlex::factorize( ) ;
		    if( verbose )
		    {
			cout.precision(16) ;
			cout << (type() == LEAVE ? "L " : "E ") ;
			cout << basis().iteration() << ":\t" ;
			cout << value() ;
			cout << "\t(" << shift() << ")\n" << flush;
		    }
		}
public:
	/* #Soplex# refinements
	 */
    int&		minDim ;
    double&		nzFac ;
    int&		mxUpd ;
    int			verbose ;
    double		maxTime ;
    Timer		timer ;

    SPxScale		scale ;
    SPxRem1SM		rem1 ;
    SPxAggregateSM	aggr ;
    SPxRedundantSM	redu ;
    SPxGeneralSM	general ;

#ifndef	NO_WEIGHT_ST
    SPxWeightST		wgtST ;
    SPxVectorST		vecST ;
#endif
    SPxSumST		sumST ;

    SPxDefaultPR	defPR ;
    SPxParMultPR	pmlPR ;
    SPxHybridPR		hbrPR ;
    SPxWeightPR		wgtPR ;
    SPxSteepPR		stpPR ;
    SPxDevexPR		dvxPR ;

    SPxDefaultRT	defRT ;
    SPxHarrisRT		stbRT ;
    SPxFastRT		fstRT ;

    NameSet		rowNames ;
    NameSet		colNames ;

    int		leaveCount()		{ return SoPlex::leaveCount ; }
    int		enterCount()		{ return SoPlex::enterCount ; }
    double	time()			{ return timer.userTime() ; }

    LPSolver::Status	solve()
			{
			    timer.reset() ;
			    timer.start() ;
			    LPSolver::Status stat = SoPlex::solve() ;
			    timer.stop() ;
			    return stat ;
			}

    SPxTCL() ;

#ifdef	FOR_DOCXX
    /**	TCL shell class for #SoPlex#.
	Initialize a #Tcl_Interp# for a #SoPlex# solver.
     */
    friend void initSPxTCL ( Tcl_Interp* interp ) ;
#endif	// FOR_DOCXX
} ;

#endif // #DEFspxtcl#
