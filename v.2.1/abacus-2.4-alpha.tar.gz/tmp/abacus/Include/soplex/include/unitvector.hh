/*@ ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Roland Wunderling
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 


   Class #UnitVector#

   Identification:
   $Id: unitvector.hh,v 1.1 1998/07/16 12:11:43 boehm Exp $

   Program history:
   $Log: unitvector.hh,v $
   Revision 1.1  1998/07/16 12:11:43  boehm
   *** empty log message ***

// Revision 1.7  1996/03/21  11:03:17  bzfwunde
// New Makefile
// Many preformance improvents
//
// Revision 1.6  1995/11/21  16:22:41  bzfwunde
// introduced SUBDIR_INCLUDE
//
// Revision 1.5  1995/10/13  15:31:47  bzfwunde
// minor improvements
//
// Revision 1.4  1995/05/22  15:21:43  bzfwunde
// changed PSVector -> SVector
//
// Revision 1.3  1995/03/31  14:55:11  bzfwunde
// tested Version running with set packing
//
// Revision 1.2  1995/03/03  18:37:24  bzfwunde
// minor bug fix
//
// Revision 1.1.1.1  1994/10/10  13:16:09  bzfwunde
// initial realease: sparse unit vector class
//

    ----------------------------------------------------------------------------
*/

#ifndef DEFunitvector		// prevent multiple includes
#define DEFunitvector

//@ ----------------------------------------------------------------------------
/*	\Section{Imports}
    Import required system include files
 */
#include <assert.h>


/*  and class header files
 */
#ifndef	SUBDIR_INCLUDE

#include "svector.hh"

#else 	// #SUBDIR_INCLUDE#

#include "svector/svector.hh"

#endif	// #SUBDIR_INCLUDE#



//@ ----------------------------------------------------------------------------
/*	\Section{Class Declaration}
 */

/** sparse unit vector. 
    A #UnitVector# is an #SVector# that can take only one nonzero value with
    value 1 but arbitrary index.
 */
class UnitVector : public SVector
{
private:
    Element	themem ;
    Element	themem1 ;

public:
	/// 
    double	value(int n) const	{ (void)n ; assert(n==0) ; return 1 ; }

	/// construct #i#-th unit vector. 
    UnitVector( int i = 0 )
	: SVector( 2, &themem )
	{
	    add(i, 1.0) ;
	}

	/// 
    UnitVector( const UnitVector& rhs )
	: SVector( 2, &themem )
	, themem ( rhs.themem )
	, themem1( rhs.themem1 )
	{}

	/// 
    UnitVector&	operator=( const UnitVector& rhs )
    {
	themem1 = rhs.themem1 ;
	return *this ;
    }

	/// 
    int	isConsistent() const ;
} ;


#endif // #DEFunitvector#
