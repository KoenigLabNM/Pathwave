/* ----------------------------------------------------------------------------

 
 
                        This file is part of the class library
 
            SoPlex  --- the Sequential object-oriented simPlex
 
            (c) by      Martin Grammel
                        Konarad Zuse Zentrum fuer Informationstechnik Berlin
                        Heilbronner Str. 10, 
                        D-10711 Berlin, Germany
 
        There is absolutely no right to redistribute this file without the
        explicite permission by the authour.
 
 
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 

   
   Module |Timer|

   Identification:
   $Id: timer.h,v 1.1 1998/07/16 12:11:43 boehm Exp $
   
   Program history:
   $Log: timer.h,v $
   Revision 1.1  1998/07/16 12:11:43  boehm
   *** empty log message ***

 * Revision 2.2  1995/08/18  14:14:24  bzfgramm
 * support function inlining
 *
   
   ----------------------------------------------------------------------------
   */

#ifndef _MODULE_TIMER_H
#define _MODULE_TIMER_H

/* import system include files */
#include <sys/types.h>
#include <time.h>

#ifdef	__cplusplus
extern "C" {
#endif

/* define `inline' as appropriate */
#if !defined (__cplusplus)
#if !defined (inline)
#if defined (__GNUC__)
#define	inline	__inline__
#else
#define	inline
#endif  /* !__GNUC__ */
#endif  /* !inline */
#endif	/* Not C++  */


/******************************************************************************
 *
 *	Definition of Module |Timer|
 *
 ******************************************************************************
 */


/*
 * Private Definitions of Timer:
 */


/* timer status */
enum _Timer_Status {Timer_RESET, Timer_STOPPED, Timer_RUNNING};


/* timer data structure */
struct _Timer_Struct
{
    enum _Timer_Status	status;
    clock_t		uAccount;
    clock_t		sAccount;
    clock_t		rAccount;
};


/* convert ticks to seconds */
extern double Timer_ticks2sec(clock_t ticks);


/* get actual user, system and real time from system */
extern void Timer_getTicks(clock_t* usrTicks,
			   clock_t* sysTicks,
			   clock_t* realTicks);


/*
 * Public Interface of Timer:
 */


/* abstract type of Timer */
typedef struct _Timer_Struct Timer_t;


/* initialize timer, set timing accounts to zero */
static inline void Timer_reset(Timer_t *timer)
{
    assert(timer);
    timer->status = Timer_RESET;
    timer->uAccount = timer->rAccount = timer->sAccount = 0;
}


/* start timer, resume accounting user, system and real time */
static inline void Timer_start(Timer_t *timer)
{
    assert(timer);
    assert(timer->status == Timer_RESET
	   || timer->status == Timer_STOPPED
	   || timer->status == Timer_RUNNING);

    /* ignore start request if timer is runnning */
    if (timer->status != Timer_RUNNING)
    {
	clock_t uTime, sTime, rTime;
	Timer_getTicks(&uTime, &sTime, &rTime);
	timer->uAccount -= uTime;
	timer->sAccount -= sTime;
	timer->rAccount -= rTime;
	timer->status = Timer_RUNNING;
    }
}
    

/* stop timer, return accounted user time */
static inline double Timer_stop(Timer_t *timer)
{
    assert(timer);
    assert(timer->status == Timer_RESET
	   || timer->status == Timer_STOPPED
	   || timer->status == Timer_RUNNING);

    /* status remains unchanged if timer is not running */
    if (timer->status == Timer_RUNNING)
    {
	clock_t uTime, sTime, rTime;
	Timer_getTicks(&uTime, &sTime, &rTime);
	timer->uAccount += uTime;
	timer->sAccount += sTime;
	timer->rAccount += rTime;
	timer->status = Timer_STOPPED;
    }

    return (Timer_ticks2sec(timer->uAccount));
}


/* get user, system or real time accounted by timer;
 * null pointers for times are allowed.
 */
static inline void Timer_getTimes(const Timer_t	*timer,
			   double 		*userTime,
			   double		*systemTime,
			   double 		*realTime)
{
    assert(timer);
    assert(timer->status == Timer_RESET
	   || timer->status == Timer_STOPPED
	   || timer->status == Timer_RUNNING);

    if (timer->status != Timer_RUNNING)
    {
	if (userTime)
	    *userTime = Timer_ticks2sec(timer->uAccount);
	if (systemTime)
	    *systemTime = Timer_ticks2sec(timer->sAccount);
	if (realTime)
	    *realTime = Timer_ticks2sec(timer->rAccount);
    }
    else
    {
	clock_t uTime, sTime, rTime;
	Timer_getTicks(&uTime, &sTime, &rTime);
	if (userTime)
	    *userTime = Timer_ticks2sec(uTime + timer->uAccount);
	if (systemTime)
	    *systemTime = Timer_ticks2sec(sTime + timer->sAccount);
	if (realTime)
	    *realTime = Timer_ticks2sec(rTime + timer->rAccount);
    }

    assert(userTime ? *userTime >= 0.0 : 1);
    assert(systemTime ? *systemTime >= 0.0 : 1);
    assert(realTime ? *realTime >= 0.0 : 1);
}


/* return user time accounted by timer */
static inline double Timer_userTime(const Timer_t *timer)
{
    double uTime;
    assert(timer);
    assert(timer->status == Timer_RESET
	   || timer->status == Timer_STOPPED
	   || timer->status == Timer_RUNNING);

    Timer_getTimes(timer, &uTime, 0, 0);
    return (uTime);
}


/* return system time accounted by timer */
static inline double Timer_systemTime(const Timer_t *timer)
{
    double sTime;
    assert(timer);
    assert(timer->status == Timer_RESET
	   || timer->status == Timer_STOPPED
	   || timer->status == Timer_RUNNING);

    Timer_getTimes(timer, 0, &sTime, 0);
    return (sTime);
}


/* return real time accounted by timer */
static inline double Timer_realTime(const Timer_t *timer)
{
    double rTime;
    assert(timer);
    assert(timer->status == Timer_RESET
	   || timer->status == Timer_STOPPED
	   || timer->status == Timer_RUNNING);

    Timer_getTimes(timer, 0, 0, &rTime);
    return (rTime);
}


/* return resolution of timer as 1/seconds */
extern long Timer_resolution(void);


/******************************************************************************
 *
 *	End of Definition of Module |Timer|
 *
 ******************************************************************************
 */


#ifdef	__cplusplus
}
#endif

#endif /* ! _MODULE_TIMER_H */
