/*******************************************************************/
/*  CPXDEFS.h                                                      */
/*  Version 6.0                                                    */
/*                                                                 */
/*  Copyright (c) 1997-1998                                        */
/*  ILOG                                                           */
/*  All Rights Reserved                                            */
/*                                                                 */
/*  Last modified  4 March 1998, IJL                               */
/*******************************************************************/

#ifndef __CPXDEFS_H
#define __CPXDEFS_H

#ifdef __cplusplus
extern "C" {
#endif

/* The version is an integer, to allow testing in user include files */

#define  CPX_VERSION  600


/* It seems necessary to have the include for <stdio.h> after the
   1167 pragma, when that pragma is active. <stdio.h> is include here
   so that the 'FILE' type is defined */

#include <stdio.h>

#ifdef   CPXWIN32
#define  CPXPUBLIC      __stdcall
#define  CPXPUBVARARGS  __cdecl
typedef  void *CPXFILEptr;
#else
#define  CPXPUBLIC
#define  CPXPUBVARARGS
typedef  FILE *CPXFILEptr; 
#endif

#ifdef  SYSGNUSPARC
#include <sys/stdtypes.h>
#endif

/* CPX_INFBOUND:  Any bound bigger than this is treated as infinity */

#define CPX_INFBOUND  1.0E+20

#ifndef  CPX_MODERN
#define INFBOUND    CPX_INFBOUND
#endif

#define  CPX_STR_PARAM_MAX    512
 
/* Values returned for 'stat' by solution () */

#define CPX_OPTIMAL                      1
#define CPX_INFEASIBLE                   2
#define CPX_UNBOUNDED                    3
#define CPX_OBJ_LIM                      4
#define CPX_IT_LIM_FEAS                  5
#define CPX_IT_LIM_INFEAS                6
#define CPX_TIME_LIM_FEAS                7
#define CPX_TIME_LIM_INFEAS              8
#define CPX_NUM_BEST_FEAS                9
#define CPX_NUM_BEST_INFEAS             10
#define CPX_OPTIMAL_INFEAS              11
#define CPX_ABORT_FEAS                  12
#define CPX_ABORT_INFEAS                13
#define CPX_ABORT_DUAL_INFEAS           14
#define CPX_ABORT_PRIM_INFEAS           15
#define CPX_ABORT_PRIM_DUAL_INFEAS      16
#define CPX_ABORT_PRIM_DUAL_FEAS        17
#define CPX_ABORT_CROSSOVER             18

/* Error codes */

#define CPXERR_NO_MEMORY              1001
#define CPXERR_NO_ENVIRONMENT         1002
#define CPXERR_BAD_ARGUMENT           1003
#define CPXERR_NULL_POINTER           1004
#define CPXERR_POINTER_MISMATCH       1005
#define CPXERR_CALLBACK               1006
#define CPXERR_POSITIVE_SPACE         1007
#define CPXERR_MEMORY_MODEL           1008
#define CPXERR_NO_PROBLEM             1009
#define CPXERR_LIMITS_TOO_BIG         1012
#define CPXERR_BAD_PARAM_NUM          1013
#define CPXERR_PARAM_TOO_SMALL        1014
#define CPXERR_PARAM_TOO_BIG          1015
#define CPXERR_PROMOTION_VERSION      1016
#define CPXERR_NOT_FOR_MIP            1017
#define CPXERR_NOT_FOR_QP             1018
#define CPXERR_CHILD_OF_CHILD         1019
#define CPXERR_TOO_MANY_THREADS       1020
#define CPXERR_CANT_CLOSE_CHILD       1021
#define CPXERR_BAD_PROB_TYPE          1022
#define CPXERR_NOT_ONE_PROBLEM        1023
#define CPXERR_NOT_MIPCLASS           1024
#define CPXERR_NOT_QPCLASS            1025
#define CPXERR_STR_PARAM_TOO_LONG     1026
       
#define CPXERR_MSG_NO_CHANNEL         1051
#define CPXERR_MSG_NO_FILEPTR         1052
#define CPXERR_MSG_NO_FUNCTION        1053
       
#define CPXERR_BOUNDS_INFEAS          1100
#define CPXERR_PRESLV_INForUNBD       1101
#define CPXERR_PRESLV_NO_PROB         1103
#define CPXERR_PRESLV_ABORT           1106
#define CPXERR_PRESLV_BASIS_MEM       1107
#define CPXERR_PRESLV_COPYSOS         1108
#define CPXERR_PRESLV_COPYORDER       1109
#define CPXERR_PRESLV_SOLN_MIP        1110
#define CPXERR_PRESLV_SOLN_QP         1111
#define CPXERR_PRESLV_START_LP        1112
#define CPXERR_PRESLV_FAIL_BASIS      1114
#define CPXERR_PRESLV_NO_BASIS        1115
#define CPXERR_PRESLV_COPYMIPSTART    1116

/* Callable library miscellaneous routines */

#define CPXERR_INDEX_RANGE            1200
#define CPXERR_COL_INDEX_RANGE        1201
#define CPXERR_COL_NEW_INDEX_RANGE    1202
#define CPXERR_ROW_INDEX_RANGE        1203
#define CPXERR_ROW_NEW_INDEX_RANGE    1204
#define CPXERR_INDEX_RANGE_LOW        1205
#define CPXERR_INDEX_RANGE_HIGH       1206
#define CPXERR_NEGATIVE_SURPLUS       1207
#define CPXERR_ARRAY_TOO_LONG         1208
#define CPXERR_NAME_CREATION          1209
#define CPXERR_NAME_NOT_FOUND         1210
#define CPXERR_NO_RHS_IN_OBJ          1211
#define CPXERR_CANT_REALLOC_RIMS      1214
#define CPXERR_BAD_SENSE              1215
#define CPXERR_NO_RNGVAL              1216
#define CPXERR_NO_SOLN                1217
#define CPXERR_NO_RIM                 1218
#define CPXERR_NO_NAMES               1219
#define CPXERR_NO_OBJ_NAME            1220
#define CPXERR_NOT_FIXED              1221
#define CPXERR_DUP_ENTRY              1222

/* Simplex related */

#define CPXERR_INDEX_NOT_BASIC        1251
#define CPXERR_NEED_OPT_SOLN          1252
#define CPXERR_BAD_STATUS             1253
#define CPXERR_NOT_UNBOUNDED          1254
#define CPXERR_SBASE_INCOMPAT         1255
#define CPXERR_SINGULAR               1256
#define CPXERR_PRIIND                 1257
#define CPXERR_NO_LU_FACTOR           1258
#define CPXERR_NO_SENSIT              1260
#define CPXERR_NO_BASIC_SOLN          1261
#define CPXERR_NO_BASIS               1262
#define CPXERR_ABORT_STRONGBRANCH     1263
#define CPXERR_NO_NORMS               1264
#define CPXERR_NOT_DUAL_UNBOUNDED     1265

/* Network related */

#define CPXERR_NET_SMALL              1290
#define CPXERR_NET_IMBALANCE          1291
#define CPXERR_BAD_METHOD             1292

/* Space related.  Only CPXERR_NO_SPACE should be returned */

#define CPXERR_NO_SPACE               1401
#define CPXERR_NO_SPACE_FREE          1402
#define CPXERR_NO_SPACE_FREE_NZ       1403
#define CPXERR_NO_SPACE_FREE_NAM      1404
#define CPXERR_NO_SPACE_NAMES         1406

/* For readers and writers */

#define CPXERR_NO_FILENAME            1421
#define CPXERR_FAIL_OPEN_WRITE        1422
#define CPXERR_FAIL_OPEN_READ         1423
#define CPXERR_BAD_FILETYPE           1424

/* Common to LP, MPS, and related readers */

#define CPXERR_TOO_MANY_ROWS          1431
#define CPXERR_TOO_MANY_COLS          1432
#define CPXERR_TOO_MANY_COEFFS        1433
#define CPXERR_BAD_NUMBER             1434
#define CPXERR_BAD_EXPO_RANGE         1435
#define CPXERR_NO_OBJ_SENSE           1436

/* Common to MPS and related readers */

#define CPXERR_NO_NAME_SECTION        1441
#define CPXERR_BAD_SOS_TYPE           1442
#define CPXERR_COL_ROW_REPEATS        1443
#define CPXERR_RIM_ROW_REPEATS        1444
#define CPXERR_ROW_REPEATS            1445
#define CPXERR_COL_REPEATS            1446
#define CPXERR_RIM_REPEATS            1447
#define CPXERR_ROW_UNKNOWN            1448
#define CPXERR_COL_UNKNOWN            1449
#define CPXERR_RHS_UNKNOWN            1450
#define CPXERR_BOUND_UNKNOWN          1451
#define CPXERR_RANGE_UNKNOWN          1452
#define CPXERR_NO_ROW_SENSE           1453
#define CPXERR_EXTRA_FX_BOUND         1454
#define CPXERR_EXTRA_FR_BOUND         1455
#define CPXERR_EXTRA_BV_BOUND         1456
#define CPXERR_BAD_BOUND_TYPE         1457
#define CPXERR_UP_BOUND_REPEATS       1458
#define CPXERR_LO_BOUND_REPEATS       1459
#define CPXERR_NO_BOUND_TYPE          1460
#define CPXERR_NO_QMATRIX_SECTION     1461
#define CPXERR_BAD_SECTION_ENDATA     1462
#define CPXERR_INT_TOO_BIG_INPUT      1463

/* Unique to MPS reader */

#define CPXERR_NO_ROWS_SECTION        1471
#define CPXERR_NO_COLUMNS_SECTION     1472
#define CPXERR_BAD_SECTION_BOUNDS     1473
#define CPXERR_RANGE_SECTION_ORDER    1474
#define CPXERR_BAD_SECTION_QMATRIX    1475
#define CPXERR_NO_OBJECTIVE           1476
#define CPXERR_ROW_REPEAT_PRINT       1477
#define CPXERR_COL_REPEAT_PRINT       1478
#define CPXERR_RIMNZ_REPEATS          1479
#define CPXERR_EXTRA_INTORG           1480
#define CPXERR_EXTRA_INTEND           1481
#define CPXERR_EXTRA_SOSORG           1482
#define CPXERR_EXTRA_SOSEND           1483
#define CPXERR_TOO_MANY_RIMS          1484
#define CPXERR_TOO_MANY_RIMNZ         1485
#define CPXERR_NO_ROW_NAME            1486
#define CPXERR_BAD_OBJ_SENSE          1487

/* For REVISE files */

#define CPXERR_REV_INDICATOR          1501
#define CPXERR_REV_REPEATS            1502
#define CPXERR_REV_OBJROW_ILLEG       1503
#define CPXERR_REV_SEN_N_ILLEG        1504
#define CPXERR_REV_EXTRA_RIM          1505
#define CPXERR_REV_RIM_NAMES          1506
#define CPXERR_REV_DELRHS_ILLEG       1507
#define CPXERR_REV_RHS_COEFF          1508
#define CPXERR_REV_DELRNG_ILLEG       1509
#define CPXERR_REV_RANGE_COEFF        1510
#define CPXERR_REV_NO_RANGES          1511
#define CPXERR_REV_DELBND_ILLEG       1512
#define CPXERR_REV_BIN_UB             1513
#define CPXERR_REV_BND_COEFF          1514
#define CPXERR_REV_RIM_COEFF          1515
#define CPXERR_REV_TOO_MANY_ROWS      1516
#define CPXERR_REV_TOO_MANY_COLS      1517
#define CPXERR_REV_TOO_MANY_NZS       1518
#define CPXERR_REV_TOO_MANY_RIMV      1519

/* PAR Files */

#define CPXERR_PAR_NO_HEADER          1525
#define CPXERR_PAR_BAD_HEADER         1526
#define CPXERR_PAR_SHORT              1527
#define CPXERR_PAR_DATA               1528

/* NET files */

#define CPXERR_NET_DATA               1530
#define CPXERR_NOT_MIN_COST_FLOW      1531
#define CPXERR_BAD_ROW_ID             1532
#define CPXERR_DEMAND_BALANCE         1533
#define CPXERR_NET_NO_PROBLEM         1535
#define CPXERR_NET_FIRST_CHAR         1536
#define CPXERR_BAD_CHAR               1537

/* BAS files */

#define CPXERR_BAS_FILE_SHORT         1550
#define CPXERR_BAD_INDICATOR          1551
#define CPXERR_NO_ENDATA              1552
#define CPXERR_FILE_ENTRIES           1553
#define CPXERR_SBASE_ILLEGAL          1554
#define CPXERR_BAS_FILE_SIZE          1555
#define CPXERR_NO_VECTOR_SOLN         1556

/* SAV files */

#define CPXERR_NOT_SAV_FILE           1560
#define CPXERR_SAV_FILE_DATA          1561
#define CPXERR_SAV_FILE_WRITE         1562
#define CPXERR_FILE_FORMAT            1563

/* LP reader errors */

#define CPXERR_ADJ_SIGNS              1602
#define CPXERR_RHS_IN_OBJ             1603
#define CPXERR_ADJ_SIGN_SENSE         1604
#define CPXERR_QUAD_IN_ROW            1605
#define CPXERR_ADJ_SIGN_QUAD          1606
#define CPXERR_NO_OPERATOR            1607
#define CPXERR_NO_OP_OR_SENSE         1608
#define CPXERR_NO_ID_FIRST            1609
#define CPXERR_NO_RHS_COEFF           1610
#define CPXERR_NO_NUMBER_FIRST        1611
#define CPXERR_NO_QUAD_EXP            1612
#define CPXERR_QUAD_EXP_NOT_2         1613
#define CPXERR_NO_QP_OPERATOR         1614
#define CPXERR_NO_NUMBER              1615
#define CPXERR_NO_ID                  1616
#define CPXERR_BAD_ID                 1617
#define CPXERR_BAD_EXPONENT           1618
#define CPXERR_NO_BOUND_SENSE         1621
#define CPXERR_BAD_BOUND_SENSE        1622
#define CPXERR_NO_NUMBER_BOUND        1623
#define CPXERR_LP_TOO_MANY_ROWS       1624
#define CPXERR_LP_TOO_MANY_COLS       1625
#define CPXERR_LP_TOO_MANY_COEFFS     1626
#define CPXERR_INVALID_NUMBER         1650
       
#define CPXERR_IIS_NO_INFO            1701
#define CPXERR_IIS_NO_SOLN            1702
#define CPXERR_IIS_FEAS               1703
#define CPXERR_IIS_NOT_INFEAS         1704
#define CPXERR_IIS_OPT_INFEAS         1705
#define CPXERR_IIS_DEFAULT            1706
#define CPXERR_IIS_NO_BASIC           1707
#define CPXERR_IIS_NO_PRIMAL          1708
#define CPXERR_IIS_NO_LOAD            1709
#define CPXERR_IIS_SUB_OBJ_LIM        1710
#define CPXERR_IIS_SUB_IT_LIM         1711
#define CPXERR_IIS_SUB_TIME_LIM       1712
#define CPXERR_IIS_NUM_BEST           1713

/* Private errors are 2000-2999 (cpxpriv.h)
   MIP errors are 3000-3999 (mipdefs.h)
   Barrier errors are 4000-4999 (bardefs.h)
   QP errors are 5000-5999 (qpdefs.h) */

#define CPXERR_LICENSE_MIN           32000
#define CPXERR_NO_MIP_LIC            32301
#define CPXERR_NO_BARRIER_LIC        32302
#define CPXERR_LICENSE_MAX           32999

/* Generic constants */

#define CPX_ON                           1
#define CPX_OFF                          0
#define CPX_MAX                         -1
#define CPX_MIN                          1

/* Pricing options */

#define CPX_PPRIIND_PARTIAL             -1
#define CPX_PPRIIND_AUTO                 0
#define CPX_PPRIIND_DEVEX                1
#define CPX_PPRIIND_STEEP                2
#define CPX_PPRIIND_STEEPQSTART          3
#define CPX_PPRIIND_FULL                 4
       
#define CPX_DPRIIND_AUTO                 0
#define CPX_DPRIIND_FULL                 1
#define CPX_DPRIIND_STEEP                2
#define CPX_DPRIIND_FULLSTEEP            3
#define CPX_DPRIIND_STEEPQSTART          4


/* Values returned by getmethod (). Also used by MIP algorithms */

#define CPXALG_NONE                      0
#define CPXALG_PRIMAL                    1
#define CPXALG_DUAL                      2
#define CPXALG_NETWORK                   3
#define CPXALG_BARRIER                   4
#define CPXALG_DUAL_BARRIER              5
#define CPXALG_BARRIER_NO_CROSSOVER      6
#define CPXALG_PIVOTIN                   7
#define CPXALG_PIVOTOUT                  8

/* Basis status values */

#define CPX_AT_LOWER                     0
#define CPX_BASIC                        1
#define CPX_AT_UPPER                     2
#define CPX_FREE_SUPER                   3

/* Infeasibility Finder return values */

#define CPXIIS_COMPLETE                  1
#define CPXIIS_PARTIAL                   2

/* Infeasibility Finder display values */

#define CPXIIS_TERSE                      1
#define CPXIIS_VERBOSE                    2

/* Infeasibility Finder row and column statuses */

#define CPXIIS_AT_LOWER                   0
#define CPXIIS_FIXED                      1
#define CPXIIS_AT_UPPER                   2

/* NETOPT optimization status values */

#define CPX_NETOPTIMAL                   -1
#define CPX_NETINFEASIBLE                -2
#define CPX_NETUNBOUNDED                 -3
#define CPX_NETUNBOUNDED_INF             -4

/* Extra rim vector types used in 'etype'/'rimtype' array */

#define EXTRANROW                         1
#define EXTRARHS                          2
#define EXTRARNG                          3
#define EXTRABDL                          4
#define EXTRABDU                          5

/* Variable types for ctype array */

#define CPX_CONTINUOUS                   'C'
#define CPX_BINARY                       'B'
#define CPX_INTEGER                      'I'

/* Old names for variable types */
#ifndef  CPX_MODERN
#define CONTINUOUS                       CPX_CONTINUOUS
#define BINARY                           CPX_BINARY
#define INTEGER                          CPX_INTEGER 
#endif

/* Problem Types
   Types 0 through 5 are user types, 6 through 8 are internal */

#define CPXPROB_LP                       0
#define CPXPROB_MIP                      1
#define CPXPROB_RELAXED                  2
#define CPXPROB_FIXED                    3
#define CPXPROB_NODELP                   4
#define CPXPROB_QP                       5
#define CPXPROB_ZEROEDQP                 6

/* Old names for problem types */
#ifndef  CPX_MODERN
#define CPXPROB_RELAX     CPXPROB_RELAXED
#define CPXPROB_FIX       CPXPROB_FIXED
#define CPXPROB_RELAXEDQP CPXPROB_ZEROEDQP
#endif

/* CPLEX Parameter numbers */
#define CPX_PARAM_ADVIND               1001
#define CPX_PARAM_AGGFILL              1002
#define CPX_PARAM_AGGIND               1003
#define CPX_PARAM_BASINTERVAL          1004
#define CPX_PARAM_CFILEMUL             1005
#define CPX_PARAM_CLOCKTYPE            1006
#define CPX_PARAM_CRAIND               1007
#define CPX_PARAM_DEPIND               1008
#define CPX_PARAM_DPRIIND              1009
#define CPX_PARAM_PRICELIM             1010
#define CPX_PARAM_RIMREADLIM           1011
#define CPX_PARAM_RIMNZREADLIM         1012
#define CPX_PARAM_EPMRK                1013
#define CPX_PARAM_EPOPT                1014
#define CPX_PARAM_EPPER                1015
#define CPX_PARAM_EPRHS                1016
#define CPX_PARAM_FASTMIP              1017
#define CPX_PARAM_IISIND               1018
#define CPX_PARAM_SIMDISPLAY           1019
#define CPX_PARAM_ITLIM                1020
#define CPX_PARAM_ROWREADLIM           1021
#define CPX_PARAM_NETFIND              1022
#define CPX_PARAM_COLREADLIM           1023
#define CPX_PARAM_NZREADLIM            1024
#define CPX_PARAM_OBJLLIM              1025
#define CPX_PARAM_OBJULIM              1026
#define CPX_PARAM_PERIND               1027
#define CPX_PARAM_PERLIM               1028
#define CPX_PARAM_PPRIIND              1029
#define CPX_PARAM_PREIND               1030
#define CPX_PARAM_REINV                1031
#define CPX_PARAM_REVERSEIND           1032
#define CPX_PARAM_RFILEMUL             1033
#define CPX_PARAM_SCAIND               1034
#define CPX_PARAM_SCRIND               1035
#define CPX_PARAM_SIMTHREADS           1036
#define CPX_PARAM_SINGLIM              1037
#define CPX_PARAM_SINGTOL              1038
#define CPX_PARAM_TILIM                1039
#define CPX_PARAM_PPPIND               1040
#define CPX_PARAM_XXXIND               1041
#define CPX_PARAM_EFFSLACKIND          1042
#define CPX_PARAM_PREDISP              1043
#define CPX_PARAM_PREDUAL              1044
#define CPX_PARAM_PREMEMFACT           1045
#define CPX_PARAM_ROWGROWTH            1046
#define CPX_PARAM_COLGROWTH            1047
#define CPX_PARAM_NZGROWTH             1048
#define CPX_PARAM_EPOPT_H              1049
#define CPX_PARAM_EPRHS_H              1050
#define CPX_PARAM_FLIPIND              1051

/* Barrier is in bardefs.h, MIP is in mipdefs.h, QP is in qpdefs.h */

#define CPX_PARAM_ALL_MIN              1000
#define CPX_PARAM_ALL_MAX              5000

/* Callback values for wherefrom   */

#define CPX_CALLBACK_PRIMAL              1
#define CPX_CALLBACK_DUAL                2
#define CPX_CALLBACK_NETWORK             3
#define CPX_CALLBACK_PRIMAL_CROSSOVER    4
#define CPX_CALLBACK_DUAL_CROSSOVER      5
#define CPX_CALLBACK_BARRIER             6
#define CPX_CALLBACK_PRESOLVE            7
/* Be sure to check the MIP values */

/* Values for getcallbackinfo function */

#define CPX_CALLBACK_INFO_PRIMAL_OBJ            1
#define CPX_CALLBACK_INFO_DUAL_OBJ              2
#define CPX_CALLBACK_INFO_PRIMAL_INFMEAS        3
#define CPX_CALLBACK_INFO_DUAL_INFMEAS          4
#define CPX_CALLBACK_INFO_PRIMAL_FEAS           5
#define CPX_CALLBACK_INFO_DUAL_FEAS             6
#define CPX_CALLBACK_INFO_ITCOUNT               7
#define CPX_CALLBACK_INFO_CROSSOVER_PPUSH       8
#define CPX_CALLBACK_INFO_CROSSOVER_PEXCH       9
#define CPX_CALLBACK_INFO_CROSSOVER_DPUSH      10
#define CPX_CALLBACK_INFO_CROSSOVER_DEXCH      11
#define CPX_CALLBACK_INFO_CROSSOVER_SBCNT      12
#define CPX_CALLBACK_INFO_PRESOLVE_ROWSGONE    13
#define CPX_CALLBACK_INFO_PRESOLVE_COLSGONE    14
#define CPX_CALLBACK_INFO_PRESOLVE_AGGSUBST    15
#define CPX_CALLBACK_INFO_PRESOLVE_COEFFS      16
/* Be sure to check the MIP values */

/* To support old CBINFO names */

#ifndef  CPX_MODERN

#define CPX_CBINFO_PRIMAL_OBJ        CPX_CALLBACK_INFO_PRIMAL_OBJ       
#define CPX_CBINFO_DUAL_OBJ          CPX_CALLBACK_INFO_DUAL_OBJ         
#define CPX_CBINFO_PRIMAL_INFMEAS    CPX_CALLBACK_INFO_PRIMAL_INFMEAS   
#define CPX_CBINFO_DUAL_INFMEAS      CPX_CALLBACK_INFO_DUAL_INFMEAS     
#define CPX_CBINFO_PRIMAL_FEAS       CPX_CALLBACK_INFO_PRIMAL_FEAS      
#define CPX_CBINFO_DUAL_FEAS         CPX_CALLBACK_INFO_DUAL_FEAS        
#define CPX_CBINFO_ITCOUNT           CPX_CALLBACK_INFO_ITCOUNT          
#define CPX_CBINFO_CROSSOVER_SBCNT   CPX_CALLBACK_INFO_CROSSOVER_SBCNT  
#define CPX_CBINFO_PRESOLVE_ROWSGONE CPX_CALLBACK_INFO_PRESOLVE_ROWSGONE
#define CPX_CBINFO_PRESOLVE_COLSGONE CPX_CALLBACK_INFO_PRESOLVE_COLSGONE
#define CPX_CBINFO_PRESOLVE_AGGSUBST CPX_CALLBACK_INFO_PRESOLVE_AGGSUBST
#define CPX_CBINFO_PRESOLVE_COEFFS   CPX_CALLBACK_INFO_PRESOLVE_COEFFS  

#endif

/* structure types */

struct cpxlp;
typedef struct cpxlp  *CPXLPptr;

struct cpxchannel;
typedef struct cpxchannel *CPXCHANNELptr;

struct cpxenv;
typedef struct cpxenv *CPXENVptr;

typedef char *CPXCHARptr; /* to simplify CPXPUBLIC syntax */
typedef void *CPXVOIDptr; /* to simplify CPXPUBLIC syntax */

#ifndef  CPX_MODERN

#define CPXoptimize     CPXprimopt
#define CPXtreeread     CPXreadcopytree
#define CPXvecread      CPXreadcopyvec
#define CPXreadloadbase CPXreadcopybase
#define CPXloadorder    CPXcopyorder
#define CPXloadsos      CPXcopysos
#define CPXloadbase     CPXcopybase
#define CPXloaddnorms   CPXcopydnorms
#define CPXloadpnorms   CPXcopypnorms
#define CPXloadstart    CPXcopystart
#define CPXopenCPLEX    CPXopenCPLEXdevelop
#define CPXgetitc       CPXgetitcnt
#define CPXgetitci      CPXgetphase1cnt

#endif

/* advance.c */

int CPXPUBLIC
   CPXgetbhead     (CPXENVptr env, CPXLPptr lp, int *head,
                    double *x);
int CPXPUBLIC
   CPXbinvcol      (CPXENVptr env, CPXLPptr lp, int j, double *x);
int CPXPUBLIC
   CPXbinvrow      (CPXENVptr env, CPXLPptr lp, int i, double *y);
int CPXPUBLIC
   CPXbinvacol     (CPXENVptr env, CPXLPptr lp, int j, double *x);
int CPXPUBLIC
   CPXbinvarow     (CPXENVptr env, CPXLPptr lp, int i, double *z);
int CPXPUBLIC
   CPXftran        (CPXENVptr env, CPXLPptr lp, double *x);
int CPXPUBLIC
   CPXbtran        (CPXENVptr env, CPXLPptr lp, double *y);
int CPXPUBLIC
   CPXgetijrow     (CPXENVptr env, CPXLPptr lp, int i, int j,
                    int *row_p);
int CPXPUBLIC
   CPXgetweight    (CPXENVptr env, CPXLPptr lp, int rcnt,
                    int *rmatbeg, int *rmatind, double *rmatval,
                    double *weight, int dpriind);
int CPXPUBLIC
   CPXstrongbranch (CPXENVptr env, CPXLPptr lp, int *goodlist,
                    int goodlen, double *downpen, double *uppen,
                    int itlim);
int CPXPUBLIC
   CPXdualfarkas   (CPXENVptr env, CPXLPptr lp, double *y, 
                    double *proof_p);
int CPXPUBLIC
   CPXgetobjoffset (CPXENVptr env, CPXLPptr lp, double *objoffset_p);

/* callback.c */

int CPXPUBLIC
   CPXsetlpcallbackfunc  (CPXENVptr env, 
                          int (CPXPUBLIC *callback)(CPXENVptr,
                          void *, int, void *), void *cbhandle);
int CPXPUBLIC
   CPXsetmipcallbackfunc (CPXENVptr env, 
                          int (CPXPUBLIC *callback)(CPXENVptr,
                          void *, int, void *), void *cbhandle);
int CPXPUBLIC
   CPXgetcallbackinfo    (CPXENVptr env, void *cbdata,
                          int wherefrom, int whichinfo,
                          void *result_p);

void CPXPUBLIC
   CPXgetlpcallbackfunc  (CPXENVptr env,
                          int (CPXPUBLIC **callback_p)(CPXENVptr,
                          void *, int, void *), void **cbhandle_p);
void CPXPUBLIC
   CPXgetmipcallbackfunc (CPXENVptr env,
                          int (CPXPUBLIC **callback_p)(CPXENVptr,
                          void *, int, void *), void **cbhandle_p);

/* check.c */

int CPXPUBLIC
   CPXcheckprob         (CPXENVptr env, char *probname,
                         int numcols, int numrows, int numrims,
                         int objsen, double *obj, double *rhs,
                         char *sense, int *matbeg, int *matcnt,
                         int *matind, double *matval,
                         double *lb, double *ub, double *rngval,
                         int *freerowind, int *rimtype, int *rimbeg,
                         int *rimcnt, int *rimind, double *rimval,
                         char *dataname, char *objname,
                         char *rhsname, char *rngname, char *bndname,
                         char **colname, char *colnamestore,
                         char **rowname, char *rownamestore,
                         char **rimname, char *rimnamestore,
                         int colspace, int rowspace, int nzspace,
                         int rimspace, int rimnzspace,
                         unsigned colnamespace, 
                         unsigned rownamespace,
                         unsigned rimnamespace, char *ctype);
int CPXPUBLIC
   CPXchecklp           (CPXENVptr env, char *probname,
                         int numcols, int numrows,
                         int objsen, double *obj, double *rhs,
                         char *sense, int *matbeg, int *matcnt,
                         int *matind, double *matval,
                         double *lb, double *ub, double *rngval,
                         int colspace, int rowspace, int nzspace);
int CPXPUBLIC
   CPXchecklpwnames     (CPXENVptr env, char *probname,
                         int numcols, int numrows,
                         int objsen, double *obj, double *rhs,
                         char *sense, int *matbeg, int *matcnt,
                         int *matind, double *matval,
                         double *lb, double *ub, double *rngval,
                         char **colname, char *colnamestore,
                         char **rowname, char *rownamestore,
                         int colspace, int rowspace, int nzspace,
                         unsigned colnamespace, 
                         unsigned rownamespace);
int CPXPUBLIC
   CPXcheckqpsep        (CPXENVptr env, CPXLPptr lp, 
                         double *qsepvec);
int CPXPUBLIC
   CPXcheckquad         (CPXENVptr env, CPXLPptr lp, int *qmatbeg,
                         int *qmatcnt, int *qmatind, double *qmatval,
                         int qnzspace);
int CPXPUBLIC
   CPXcheckcopylp       (CPXENVptr env, CPXLPptr lp, int numcols,
                         int numrows, int objsen, double *obj,
                         double *rhs, char *sense, int *matbeg,
                         int *matcnt, int *matind, double *matval,
                         double *lb, double *ub, double *rngval);
int CPXPUBLIC
   CPXcheckcopylpwnames (CPXENVptr env, CPXLPptr lp, int numcols,
                         int numrows, int objsen, double *obj,
                         double *rhs, char *sense, int *matbeg,
                         int *matcnt, int *matind, double *matval,
                         double *lb, double *ub, double *rngval,
                         char **colname, char **rowname);
int CPXPUBLIC
   CPXcheckaddcols      (CPXENVptr env, CPXLPptr lp, int ccnt, 
                         int nzcnt, double *obj, int *cmatbeg, 
                         int *cmatind, double *cmatval, double *lb,
                         double *ub, char **colname);
int CPXPUBLIC
   CPXcheckaddrows      (CPXENVptr env, CPXLPptr lp, int ccnt, 
                         int rcnt, int nzcnt, double *rhs, 
                         char *sense, int *rmatbeg, int *rmatind, 
                         double *rmatval, char **colname, 
                         char **rowname);
int CPXPUBLIC
   CPXcheckchgcoeflist  (CPXENVptr env, CPXLPptr lp, int numcoefs, 
                         int *rowlist, int *collist, 
                         double *vallist);
int CPXPUBLIC
   CPXcheckvals         (CPXENVptr env, CPXLPptr lp, int cnt, 
                         int *rowind, int *colind, double *values);
int CPXPUBLIC
   CPXcheckcopyqpsep    (CPXENVptr env, CPXLPptr lp, 
                         double *qsepvec);
int CPXPUBLIC
   CPXcheckcopyquad     (CPXENVptr env, CPXLPptr lp, int *qmatbeg, 
                         int *qmatcnt, int *qmatind, 
                         double *qmatval);

/* cpxuset.c */

int CPXPUBLIC
   CPXsetlogfile (CPXENVptr env, CPXFILEptr lfile);
int CPXPUBLIC
   CPXgetlogfile (CPXENVptr env, CPXFILEptr *logfile_p);

/* dleave.c */

int CPXPUBLIC
   CPXmdleave (CPXENVptr env, CPXLPptr lp, int *goodlist, 
               int goodlen, double *downratio, double *upratio);

/* dualopt.c */

int CPXPUBLIC
   CPXdualopt  (CPXENVptr env, CPXLPptr lp);

/* env.c */

CPXCHARptr CPXPUBLIC
   CPXversion         (CPXENVptr env);

CPXENVptr CPXPUBLIC
   CPXopenCPLEXdevelop (int *status_p);
CPXENVptr CPXPUBLIC
   CPXopenCPLEXruntime (int *status_p, int serialnum, 
                        char *licenvstring);
CPXENVptr CPXPUBLIC
   CPXparenv           (CPXENVptr env, int *status_p);

int CPXPUBLIC
   CPXfreeparenv       (CPXENVptr env, CPXENVptr *child_p);
int CPXPUBLIC
   CPXcloseCPLEX       (CPXENVptr *env_p);
int CPXPUBLIC
   CPXgetchannels      (CPXENVptr env, CPXCHANNELptr *cpxresults_p,
                        CPXCHANNELptr *cpxwarning_p,
                        CPXCHANNELptr *cpxerror_p,
                        CPXCHANNELptr *cpxlog_p);
int CPXPUBLIC
   CPXflushstdchannels (CPXENVptr env);
int CPXPUBLIC
   CPXsetuserhandle    (CPXENVptr env, void *userhandle);
int CPXPUBLIC
   CPXgetuserhandle    (CPXENVptr env, void **userhandle_p);

/* error.c */

CPXCHARptr CPXPUBLIC
   CPXgeterrorstring (CPXENVptr env, int errcode, char *buffer);

/* fchange.c */

int CPXPUBLIC
   CPXchgfromfreerow (CPXENVptr env, CPXLPptr lp, int cnt,
                      int *indices, char *sense, double *rhs,
                      int *rowmap);
int CPXPUBLIC
   CPXchgtofreerow   (CPXENVptr env, CPXLPptr lp, int cnt,
                      int *indices, int *rowmap);
int CPXPUBLIC
   CPXchgfreecoef    (CPXENVptr env, CPXLPptr lp, int i, int j,
                      double newvalue);

/* findiis.c */

int CPXPUBLIC
   CPXgetiis     (CPXENVptr env, CPXLPptr lp, int *iisstat_p,
                  int *rowind, int *rowbdstat, int *iisnumrows_p,
                  int *colind, int *colbdstat, int *iisnumcols_p);
int CPXPUBLIC
   CPXfindiis    (CPXENVptr env, CPXLPptr lp, int *iisnumrows_p,
                  int *iisnumcols_p);
int CPXPUBLIC
   CPXdisplayiis (CPXENVptr env, CPXLPptr lp, CPXCHANNELptr channel,
                  int display);
int CPXPUBLIC
   CPXiiswrite   (CPXENVptr env, CPXLPptr lp, char *filename);

/* load.c */

CPXLPptr CPXPUBLIC
   CPXloadprob     (CPXENVptr env, char *probname,
                    int numcols, int numrows, int numrims,
                    int objsen, double *obj, double *rhs,
                    char *sense, int *matbeg, int *matcnt,
                    int *matind, double *matval,
                    double *lb, double *ub, double *rngval,
                    int *freerowind, int *rimtype, int *rimbeg,
                    int *rimcnt, int *rimind, double *rimval,
                    char *dataname, char *objname,
                    char *rhsname, char *rngname, char *bndname,
                    char **colname, char *colnamestore,
                    char **rowname, char *rownamestore,
                    char **rimname, char *rimnamestore,
                    int colspace, int rowspace, int nzspace,
                    int rimspace, int rimnzspace,
                    unsigned colnamespace, unsigned rownamespace,
                    unsigned rimnamespace);
CPXLPptr CPXPUBLIC
   CPXloadlp       (CPXENVptr env, char *probname,
                    int numcols, int numrows,
                    int objsen, double *obj, double *rhs,
                    char *sense, int *matbeg, int *matcnt,
                    int *matind, double *matval,
                    double *lb, double *ub, double *rngval,
                    int colspace, int rowspace, int nzspace);
CPXLPptr CPXPUBLIC
   CPXloadlpwnames (CPXENVptr env, char *probname,
                    int numcols, int numrows,
                    int objsen, double *obj, double *rhs,
                    char *sense, int *matbeg, int *matcnt,
                    int *matind, double *matval,
                    double *lb, double *ub, double *rngval,
                    char **colname, char *colnamestore,
                    char **rowname, char *rownamestore,
                    int colspace, int rowspace, int nzspace,
                    unsigned colnamespace, unsigned rownamespace);
CPXLPptr CPXPUBLIC
   CPXcreateprob   (CPXENVptr env, int *status_p, char *probname);


int CPXPUBLIC
   CPXreallocprob (CPXENVptr env, CPXLPptr lp, double **obj_p,
                   double **rhs_p, char **sense_p, int **matbeg_p,
                   int **matcnt_p, int **matind_p, double **matval_p,
                   double **lb_p, double **ub_p, double **rngval_p,
                   char ***colname_p, char **colnamestore_p,
                   char ***rowname_p, char **rownamestore_p,
                   char **ctype_p,
                   int colspace, int rowspace, int nzspace,
                   unsigned colnamespace, unsigned rownamespace);
int CPXPUBLIC
   CPXunscaleprob (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXunloadprob  (CPXENVptr env, CPXLPptr *lp_p);
int CPXPUBLIC
   CPXfreeprob    (CPXENVptr env, CPXLPptr *lp_p);

/* lpread.c */

int CPXPUBLIC
   CPXlpread  (CPXENVptr env, char *filename,
               int *numcols_p, int *numrows_p,
               int *objsen_p, double **obj_p, double **rhs_p,
               char **sense_p, int **matbeg_p, int **matcnt_p,
               int **matind_p, double **matval_p,
               double **lb_p, double **ub_p,
               char **objname_p, char **rhsname_p,
               char ***colname_p, char **colnamestore_p,
               char ***rowname_p, char **rownamestore_p,
               int *colspace_p, int *rowspace_p, int *nzspace_p,
               unsigned *colnamespace_p, unsigned *rownamespace_p);
int CPXPUBLIC
   CPXlpmread (CPXENVptr env, char *filename,
               int *numcols_p, int *numrows_p,
               int *objsen_p, double **obj_p, double **rhs_p,
               char **sense_p, int **matbeg_p, int **matcnt_p,
               int **matind_p, double **matval_p,
               double **lb_p, double **ub_p,
               char **objname_p, char **rhsname_p,
               char ***colname_p, char **colnamestore_p,
               char ***rowname_p, char **rownamestore_p,
               int *colspace_p, int *rowspace_p, int *nzspace_p,
               unsigned *colnamespace_p, unsigned *rownamespace_p,
               char **ctype_p);
int CPXPUBLIC
   CPXlpqread (CPXENVptr env, char *filename,
               int *numcols_p, int *numrows_p,
               int *objsen_p, double **obj_p, double **rhs_p,
               char **sense_p, int **matbeg_p, int **matcnt_p,
               int **matind_p, double **matval_p,
               double **lb_p, double **ub_p,
               char **objname_p, char **rhsname_p,
               char ***colname_p, char **colnamestore_p,
               char ***rowname_p, char **rownamestore_p,
               int *colspace_p, int *rowspace_p, int *nzspace_p,
               unsigned *colnamespace_p, unsigned *rownamespace_p,
               char **ctype_p, int **qmatbeg_p, int **qmatcnt_p, 
               int **qmatind_p, double **qmatval_p, int *qnzspace_p);

/* lpwrite.c */

int CPXPUBLIC
   CPXlpwrite   (CPXENVptr env, CPXLPptr lp, char *filename);
int CPXPUBLIC
   CPXlprewrite (CPXENVptr env, CPXLPptr lp, char *filename);

/* mbaserw.c */

int CPXPUBLIC
   CPXmbaseread   (CPXENVptr env, char *filename,
                   int numcols, int numrows,
                   char **colname, char **rowname,
                   int *cstat, int *rstat);
int CPXPUBLIC
   CPXmbasewrite  (CPXENVptr env, CPXLPptr lp, char *filename);
int CPXPUBLIC
   CPXreadcopyvec (CPXENVptr env, CPXLPptr lp, char *filename);
int CPXPUBLIC
   CPXvecwrite    (CPXENVptr env, CPXLPptr lp, char *filename);

/* message.c */

CPXCHANNELptr CPXPUBLIC
   CPXaddchannel        (CPXENVptr env);

int CPXPUBLIC
   CPXaddfpdest         (CPXENVptr env, CPXCHANNELptr channel,
                         CPXFILEptr fileptr);
int CPXPUBLIC
   CPXdelfpdest         (CPXENVptr env, CPXCHANNELptr channel,
                         CPXFILEptr fileptr);
int CPXPUBLIC
   CPXaddfuncdest       (CPXENVptr env, CPXCHANNELptr channel,
                         void *handle,
                         void (CPXPUBLIC *msgfunction)(void *, char *));
int CPXPUBLIC
   CPXdelfuncdest       (CPXENVptr env, CPXCHANNELptr channel,
                         void *handle,
                         void (CPXPUBLIC *msgfunction)(void *, char *));
int CPXPUBVARARGS
   CPXmsg               (CPXCHANNELptr channel, char *format, ...);

int CPXPUBLIC
   CPXmsgstr            (CPXCHANNELptr channel, char *msg);

void CPXPUBLIC
   CPXdelchannel        (CPXENVptr env, CPXCHANNELptr *channel_p);
void CPXPUBLIC
   CPXdisconnectchannel (CPXENVptr env, CPXCHANNELptr channel);
void CPXPUBLIC
   CPXflushchannel      (CPXENVptr env, CPXCHANNELptr channel);

/* mpsread.c */

int CPXPUBLIC
   CPXmpsread  (CPXENVptr env, char *filename,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p);
int CPXPUBLIC
   CPXmpsmread (CPXENVptr env, char *filename,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p,
                char **ctype_p, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sosbeg_p, int **sosind_p,
                double **sosref_p);
int CPXPUBLIC
   CPXmpsqread (CPXENVptr env, char *filename,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p,
                char **ctype_p, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sosbeg_p, int **sosind_p,
                double **sosref_p,
                int **qmatbeg_p, int **qmatcnt_p, int **qmatind_p,
                double **qmatval_p, int *qnzspace_p);

/* mpsrevis.c */

int CPXPUBLIC
   CPXmpsrevise (CPXENVptr env, CPXLPptr lp, char *filename);

/* mpswrite.c */

int CPXPUBLIC
   CPXmpswrite   (CPXENVptr env, CPXLPptr lp, char *filename);
int CPXPUBLIC
   CPXmpsrewrite (CPXENVptr env, CPXLPptr lp, char *filename);
int CPXPUBLIC
   CPXdualwrite  (CPXENVptr env, CPXLPptr lp, char *filename,
                  double *objshift_p);

/* netmain.c */

int CPXPUBLIC
   CPXhybnetopt (CPXENVptr env, CPXLPptr lp, char method);
int CPXPUBLIC
   CPXnetopt    (CPXENVptr env, CPXLPptr lp, int *netstatus_p,
                 int *numnodes_p, int *numarcs_p, int *itcnt_p);
int CPXPUBLIC
   CPXembwrite  (CPXENVptr env, CPXLPptr lp, char *filename);

/* oddutil.c */

int CPXPUBLIC
   CPXcopystart      (CPXENVptr env, CPXLPptr lp, int *cstat,
                      int *rstat, double *cprim, double *rprim,
                      double *cdual, double *rdual);
int CPXPUBLIC
   CPXcopybase       (CPXENVptr env, CPXLPptr lp, int *cstat,
                      int *rstat);
int CPXPUBLIC
   CPXcopydnorms     (CPXENVptr env, CPXLPptr lp, double *norm,
                     int *head, int len);
int CPXPUBLIC
   CPXcopybasednorms (CPXENVptr env, CPXLPptr lp, int *cstat, 
                      int *rstat, double *dnorm);
int CPXPUBLIC
   CPXcopypnorms     (CPXENVptr env, CPXLPptr lp, double *cnorm,
                      double *rnorm, int len);
int CPXPUBLIC
   CPXgetspace       (CPXENVptr env, CPXLPptr lp, int *colspace_p,
                      int *rowspace_p, int *nzspace_p,
                      unsigned *colnamespace_p,
                      unsigned *rownamespace_p);

/* primopt.c */

int CPXPUBLIC
   CPXprimopt (CPXENVptr env, CPXLPptr lp);

/* otherrw.c */

int CPXPUBLIC
   CPXnetread   (CPXENVptr env, char *filename,
                 int *numcols_p, int *numrows_p,
                 int *objsen_p, double **obj_p, double **rhs_p,
                 char **sense_p, int **matbeg_p, int **matcnt_p,
                 int **matind_p, double **matval_p,
                 double **lb_p, double **ub_p,
                 int *colspace_p, int *rowspace_p, int *nzspace_p);
int CPXPUBLIC
   CPXparread   (CPXENVptr env, char *filename,
                 int *numcols_p, int *numrows_p,
                 int *objsen_p, double **obj_p, double **rhs_p,
                 char **sense_p, int **matbeg_p, int **matcnt_p,
                 int **matind_p, double **matval_p,
                 double **lb_p, double **ub_p,
                 int *colspace_p, int *rowspace_p, int *nzspace_p,
                 char **ctype_p);
int CPXPUBLIC
   CPXpperwrite (CPXENVptr env, CPXLPptr lp, char *filename,
                 double epsilon);
int CPXPUBLIC
   CPXdperwrite (CPXENVptr env, CPXLPptr lp, char *filename,
                 double epsilon);

/* pivotin.c */

int CPXPUBLIC
   CPXpivotin (CPXENVptr env, CPXLPptr lp, int *rlist, int rlen);

/* pivotout.c */

int CPXPUBLIC
   CPXpivotout (CPXENVptr env, CPXLPptr lp, int *clist, int clen);

/* preutil.c */

int CPXPUBLIC
   CPXpreslvwrite (CPXENVptr env, CPXLPptr lp, char *filename,
                   double *objoff_p);

/* quality.c */

double CPXPUBLIC
   CPXcheckax  (CPXENVptr env, CPXLPptr lp, int *imax_p,
                int scalrimtype);
double CPXPUBLIC
   CPXcheckpib (CPXENVptr env, CPXLPptr lp, int *ijmax_p,
                int scalrimtype);

/* query.c */

double CPXPUBLIC
   CPXgetkappa         (CPXENVptr env, CPXLPptr lp);

int CPXPUBLIC
   CPXgetnumcols       (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetnumrows       (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetnumnz         (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetnumrims       (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetnumfreerows   (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetnumfreerownz  (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetnumrimnz      (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetobjsen        (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetobj           (CPXENVptr env, CPXLPptr lp, double *obj,
                        int begin, int end);
int CPXPUBLIC
   CPXgetrhs           (CPXENVptr env, CPXLPptr lp, double *rhs,
                        int begin, int end);
int CPXPUBLIC
   CPXgetsense         (CPXENVptr env, CPXLPptr lp, char *sense,
                        int begin, int end);
int CPXPUBLIC
   CPXgetcols          (CPXENVptr env, CPXLPptr lp, int *nzcnt_p,
                        int *cmatbeg, int *cmatind, double *cmatval,
                        int cmatspace, int *surplus_p,
                        int begin, int end);
int CPXPUBLIC
   CPXgetrows          (CPXENVptr env, CPXLPptr lp, int *nzcnt_p,
                        int *rmatbeg, int *rmatind, double *rmatval,
                        int rmatspace, int *surplus_p,
                        int begin, int end);
int CPXPUBLIC
   CPXgetfreerows      (CPXENVptr env, CPXLPptr lp, int *nzcnt_p,
                        int *rmatbeg, int *rmatind, double *rmatval,
                        int rmatspace, int *surplus_p,
                        int begin, int end);
int CPXPUBLIC
   CPXgetrims          (CPXENVptr env, CPXLPptr lp, int *nzcnt_p,
                        int *rimmatbeg, int *rimmatind,
                        double *rimmatval, int rimmatspace,
                        int *surplus_p, int begin, int end);
int CPXPUBLIC
   CPXgetlb            (CPXENVptr env, CPXLPptr lp, double *lb,
                        int begin, int end);
int CPXPUBLIC
   CPXgetub            (CPXENVptr env, CPXLPptr lp, double *ub,
                        int begin, int end);
int CPXPUBLIC
   CPXgetrngval        (CPXENVptr env, CPXLPptr lp, double *rngval,
                        int begin, int end);
int CPXPUBLIC
   CPXgetfreerowind    (CPXENVptr env, CPXLPptr lp, int *freerowind,
                        int begin, int end);
int CPXPUBLIC
   CPXgetrimtype       (CPXENVptr env, CPXLPptr lp, int *rimtype,
                        int begin, int end);
int CPXPUBLIC
   CPXgetprobname      (CPXENVptr env, CPXLPptr lp, char *buf,
                        int bufspace, int *surplus_p);
int CPXPUBLIC
   CPXgetdataname      (CPXENVptr env, CPXLPptr lp, char *buf);
int CPXPUBLIC
   CPXgetobjname       (CPXENVptr env, CPXLPptr lp, char *buf,
                        int bufspace, int *surplus_p);
int CPXPUBLIC
   CPXgetrhsname       (CPXENVptr env, CPXLPptr lp, char *buf);
int CPXPUBLIC
   CPXgetrngname       (CPXENVptr env, CPXLPptr lp, char *buf);
int CPXPUBLIC
   CPXgetbndname       (CPXENVptr env, CPXLPptr lp, char *buf);
int CPXPUBLIC
   CPXgetcolname       (CPXENVptr env, CPXLPptr lp, char **name,
                        char *namestore, int storespace,
                        int *surplus_p, int begin, int end);
int CPXPUBLIC
   CPXgetrowname       (CPXENVptr env, CPXLPptr lp, char **name,
                        char *namestore, int storespace,
                        int *surplus_p, int begin, int end);
int CPXPUBLIC
   CPXgetrimname       (CPXENVptr env, CPXLPptr lp, char **name,
                        char *namestore, int storespace,
                        int *surplus_p, int begin, int end);
int CPXPUBLIC
   CPXgetcolspace      (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetrowspace      (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetnzspace       (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetrimspace      (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetrimnzspace    (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetbase          (CPXENVptr env, CPXLPptr lp, int *cstat,
                        int *rstat);
int CPXPUBLIC
   CPXgetdnorms        (CPXENVptr env, CPXLPptr lp, double *norm,
                        int *head, int *len_p);
int CPXPUBLIC
   CPXgetbasednorms    (CPXENVptr env, CPXLPptr lp, int *cstat, 
                        int *rstat, double *dnorm);
int CPXPUBLIC
   CPXgetpnorms        (CPXENVptr env, CPXLPptr lp, double *cnorm,
                        double *rnorm, int *len_p);
int CPXPUBLIC
   CPXgetitcnt         (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetphase1cnt     (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetcrossppushcnt (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetcrosspexchcnt (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetcrossdpushcnt (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetcrossdexchcnt (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetgrad          (CPXENVptr env, CPXLPptr lp, int j, int *ix,
                        double *y);
int CPXPUBLIC
   CPXgetcoef          (CPXENVptr env, CPXLPptr lp, int i, int j,
                        double *coef_p);
int CPXPUBLIC
   CPXgetsbcnt         (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetijdiv         (CPXENVptr env, CPXLPptr lp, int *idiv_p,
                        int *jdiv_p);
int CPXPUBLIC
   CPXgetrowindex      (CPXENVptr env, CPXLPptr lp, char *lname,
                        int *index_p);
int CPXPUBLIC
   CPXgetcolindex      (CPXENVptr env, CPXLPptr lp, char *lname,
                        int *index_p);
int CPXPUBLIC
   CPXgetstat          (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetprobtype      (CPXENVptr env, CPXLPptr lp);

unsigned CPXPUBLIC
   CPXgetcolnamespace  (CPXENVptr env, CPXLPptr lp);
unsigned CPXPUBLIC
   CPXgetrownamespace  (CPXENVptr env, CPXLPptr lp);
unsigned CPXPUBLIC
   CPXgetrimnamespace  (CPXENVptr env, CPXLPptr lp);

/* rwutil.c */

int CPXPUBLIC
   CPXreadcopybase     (CPXENVptr env, CPXLPptr lp, char *filename);
int CPXPUBLIC
   CPXreadcopyorder    (CPXENVptr env, CPXLPptr lp, char *filename);
int CPXPUBLIC
   CPXreadcopysos      (CPXENVptr env, CPXLPptr lp, char *filename);
int CPXPUBLIC
   CPXreadcopyqp       (CPXENVptr env, CPXLPptr lp, char *filename);
int CPXPUBLIC
   CPXreadloadqp       (CPXENVptr env, CPXLPptr lp, char *filename,
                        int **qmatbeg_p, int **qmatcnt_p,
                        int **qmatind_p, double **qmatval_p,
                        int *qnzspace_p);
int CPXPUBLIC
   CPXreadcopyprob     (CPXENVptr env, CPXLPptr lp, char *filename,
                        char *filetype);
int CPXPUBLIC
   CPXwriteprob        (CPXENVptr env, CPXLPptr lp, char *filename,
                        char *filetype);

/* savread.c */

int CPXPUBLIC
   CPXsavread  (CPXENVptr env, char *filename,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p, int **cstat_p,
                int **rstat_p);
int CPXPUBLIC
   CPXsavmread (CPXENVptr env, char *filename,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p,
                char **ctype_p, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sospri_p, int **sosbeg_p,
                int **sosind_p, double **sosref,
                int **cstat_p, int **rstat_p);
int CPXPUBLIC
   CPXsavqread (CPXENVptr env, char *filename,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p,
                char **ctype_p, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sospri_p, int **sosbeg_p,
                int **sosind_p, double **sosref_p,
                int **qmatbeg_p, int **qmatcnt_p, int **qmatind_p,
                double **qmatval_p, int *qnzspace_p,
                int **cstat_p, int **rstat_p);

/* savwrite.c */

int CPXPUBLIC
   CPXsavwrite (CPXENVptr env, CPXLPptr lp, char *filename);

/* sensit.c */

int CPXPUBLIC
   CPXrhssa   (CPXENVptr env, CPXLPptr lp, int begin, int end,
               double *lower, double *upper);
int CPXPUBLIC
   CPXboundsa (CPXENVptr env, CPXLPptr lp, int begin, int end,
               double *lblower, double *lbupper, double *ublower,
               double *ubupper);
int CPXPUBLIC
   CPXobjsa   (CPXENVptr env, CPXLPptr lp, int begin, int end,
               double *lower, double *upper);

/* solution.c */

int CPXPUBLIC
   CPXsolution  (CPXENVptr env, CPXLPptr lp, int *lpstat_p,
                 double *objval_p, double *x, double *pi,
                 double *slack, double *dj);
int CPXPUBLIC
   CPXgetobjval (CPXENVptr env, CPXLPptr lp, double *objval_p);
int CPXPUBLIC
   CPXgetx      (CPXENVptr env, CPXLPptr lp, double *x,
                 int begin, int end);
int CPXPUBLIC
   CPXgetpi     (CPXENVptr env, CPXLPptr lp, double *pi,
                 int begin, int end);
int CPXPUBLIC
   CPXgetslack  (CPXENVptr env, CPXLPptr lp, double *slack,
                 int begin, int end);
int CPXPUBLIC
   CPXgetdj     (CPXENVptr env, CPXLPptr lp, double *dj,
                 int begin, int end);
int CPXPUBLIC
   CPXgetmethod (CPXENVptr env, CPXLPptr lp);

/* solwrite.c */

int CPXPUBLIC
   CPXwritesol    (CPXENVptr env, CPXLPptr lp, char *filename,
                   char *filetype);
int CPXPUBLIC
   CPXbinsolwrite (CPXENVptr env, CPXLPptr lp, char *filename);
int CPXPUBLIC
   CPXtxtsolwrite (CPXENVptr env, CPXLPptr lp, char *filename);
int CPXPUBLIC
   CPXsolwrite    (CPXENVptr env, CPXLPptr lp,
                   void (*hsection) (CPXENVptr, CPXLPptr, void *),
                   void (*rsectionbeg) (void *),
                   void (*csectionbeg) (void *),
                   void (*write_entry) (void *, char, int, char *,
                                        char *, double, double,
                                        double, double, double),
                   void (*sectionend) (void *), void *info);


/* stubs.c */

CPXFILEptr CPXPUBLIC
   CPXfopen     (char *filename, char *type);

int CPXPUBLIC
   CPXfclose    (CPXFILEptr stream);
int CPXPUBLIC
   CPXfputs     (char *s, CPXFILEptr stream);

CPXVOIDptr CPXPUBLIC
   CPXmalloc    (size_t size);
CPXVOIDptr CPXPUBLIC
   CPXrealloc   (void *ptr, size_t size);
CPXVOIDptr CPXPUBLIC
   CPXmemcpy    (void *s1, void *s2, size_t n);

void CPXPUBLIC
   CPXfree      (void *ptr);

int CPXPUBLIC
   CPXstrlen    (char *s);

CPXCHARptr CPXPUBLIC
   CPXstrcpy    (char *s1, char *s2);



/* uchange.c */

int CPXPUBLIC
   CPXaddrows      (CPXENVptr env, CPXLPptr lp, int ccnt, int rcnt,
                    int nzcnt, double *rhs, char *sense, 
                    int *rmatbeg, int *rmatind, double *rmatval, 
                    char **colname, char **rowname);
int CPXPUBLIC
   CPXdelrows      (CPXENVptr env, CPXLPptr lp, int begin, int end);
int CPXPUBLIC
   CPXdelsetrows   (CPXENVptr env, CPXLPptr lp, int *delstat);
int CPXPUBLIC
   CPXaddcols      (CPXENVptr env, CPXLPptr lp, int ccnt, int nzcnt,
                    double *obj, int *cmatbeg, int *cmatind,
                    double *cmatval, double *lb, double *ub,
                    char **colname);
int CPXPUBLIC
   CPXdelcols      (CPXENVptr env, CPXLPptr lp, int begin, int end);
int CPXPUBLIC
   CPXdelsetcols   (CPXENVptr env, CPXLPptr lp, int *delstat);
int CPXPUBLIC
   CPXchgname      (CPXENVptr env, CPXLPptr lp, char key, int ij,
                    char *newname);
int CPXPUBLIC
   CPXchgcoef      (CPXENVptr env, CPXLPptr lp, int i, int j,
                    double newvalue);
int CPXPUBLIC
   CPXchgcoeflist  (CPXENVptr env, CPXLPptr lp, int numcoefs,
                    int *rowlist, int *collist, double *vallist);
int CPXPUBLIC
   CPXtightenbds   (CPXENVptr env, CPXLPptr lp, int cnt, 
                    int *indices, char *lu, double *bd);
int CPXPUBLIC
   CPXchgbds       (CPXENVptr env, CPXLPptr lp, int cnt, 
                    int *indices, char *lu, double *bd);
int CPXPUBLIC
   CPXchgobj       (CPXENVptr env, CPXLPptr lp, int cnt, 
                    int *indices, double *values);
int CPXPUBLIC
   CPXchgrhs       (CPXENVptr env, CPXLPptr lp, int cnt, 
                    int *indices, double *values);
int CPXPUBLIC
   CPXchgsense     (CPXENVptr env, CPXLPptr lp, int cnt, 
                    int *indices, char *sense);
int CPXPUBLIC
   CPXnewrows      (CPXENVptr env, CPXLPptr lp, int rcnt, 
                    double *zrhs, char *zsense, double *zrngval, 
                    char **zrowname);
int CPXPUBLIC
   CPXnewcols      (CPXENVptr env, CPXLPptr lp, int ccnt, 
                    double *zobj, double *zlb, double *zub, 
                    char *zctype, char **zcolname);
int CPXPUBLIC
   CPXcopylpwnames (CPXENVptr env, CPXLPptr lp, int numcols, 
                    int numrows, int objsen, double *obj, 
                    double *rhs, char *sense, int *matbeg, 
                    int *matcnt, int *matind, double *matval, 
                    double *lb, double *ub, double *rngval, 
                    char **colname, char **rowname);
int CPXPUBLIC
   CPXcopylp       (CPXENVptr env, CPXLPptr lp, int numcols, 
                    int numrows, int objsen, double *obj, 
                    double *rhs, char *sense, int *matbeg, 
                    int *matcnt, int *matind, double *matval, 
                    double *lb, double *ub, double *rngval);
int CPXPUBLIC
   CPXcopyobjname  (CPXENVptr env, CPXLPptr lp, char *objname);


void CPXPUBLIC
   CPXchgobjsen    (CPXENVptr env, CPXLPptr lp, int maxormin);

/* uset.c */

int CPXPUBLIC
   CPXsetdefaults  (CPXENVptr env);
int CPXPUBLIC
   CPXsetintparam  (CPXENVptr env, int whichparam, int newvalue);
int CPXPUBLIC
   CPXsetdblparam  (CPXENVptr env, int whichparam, double newvalue);
int CPXPUBLIC
   CPXsetstrparam  (CPXENVptr env, int whichparam, char *newvalue);
int CPXPUBLIC
   CPXgetintparam  (CPXENVptr env, int whichparam, int *value_p);
int CPXPUBLIC
   CPXgetdblparam  (CPXENVptr env, int whichparam, double *value_p);
int CPXPUBLIC
   CPXgetstrparam  (CPXENVptr env, int whichparam, char *value);
int CPXPUBLIC
   CPXinfointparam (CPXENVptr env, int whichparam, int *defvalue_p,
                    int *minvalue_p, int *maxvalue_p);
int CPXPUBLIC
   CPXinfodblparam (CPXENVptr env, int whichparam,
                    double *defvalue_p, double *minvalue_p,
                    double *maxvalue_p);
int CPXPUBLIC
   CPXinfostrparam (CPXENVptr env, int whichparam,
                    char *defvalue);




#ifdef __cplusplus
}
#endif

#endif /* __CPXDEFS_H */
/*******************************************************************/
/*  BARDEFS.h                                                      */
/*  Version 6.0                                                    */
/*                                                                 */
/*  Copyright (c) 1997-1998                                        */
/*  ILOG                                                           */
/*  All Rights Reserved                                            */
/*                                                                 */
/*  Last modified 3 March 1998, IJL                                */
/*******************************************************************/

#ifndef __BARDEFS_H
#define __BARDEFS_H

#ifdef __cplusplus
extern "C" {
#endif

/* Has defines for external functions and constants.
   Is equivalent to things that are in cpxdefs.h */

#define CPX_PRIM_INFEAS                  32
#define CPX_DUAL_INFEAS                  33
#define CPX_PRIM_DUAL_INFEAS             34
#define CPX_PRIM_OBJ_LIM                 35
#define CPX_DUAL_OBJ_LIM                 36
#define CPX_OPTIMAL_FACE_UNBOUNDED       37
#define CPX_NUM_BEST_PRIM_DUAL_FEAS      38
#define CPX_NUM_BEST_PRIM_INFEAS         39
#define CPX_NUM_BEST_DUAL_INFEAS         40
#define CPX_NUM_BEST_PRIM_DUAL_INFEAS    41
#define CPX_BARRIER_NUM_ERROR            42
#define CPX_BARRIER_INCONSISTENT         43


/* Barrier error codes */

#define CPXERR_BARRIER_NUMERICAL       4001
#define CPXERR_BARRIER_AUG_SCHUR       4003
#define CPXERR_BARRIER_NO_MEMORY       4004

/* Barrier parameters */

#define CPX_PARAM_BARDSTART            3001
#define CPX_PARAM_BAREPCOMP            3002
#define CPX_PARAM_BARGROWTH            3003
#define CPX_PARAM_BAROBJRNG            3004
#define CPX_PARAM_BARPSTART            3005
#define CPX_PARAM_BARVARUP             3006
#define CPX_PARAM_BARALG               3007
#define CPX_PARAM_BARUNROLL            3008
#define CPX_PARAM_BARCOLNZ             3009
#define CPX_PARAM_BARDISPLAY           3010
#define CPX_PARAM_BARFACTOR            3011
#define CPX_PARAM_BARITLIM             3012
#define CPX_PARAM_BARMAXCOR            3013
#define CPX_PARAM_BARORDER             3014
#define CPX_PARAM_BARROWSDEN           3015
#define CPX_PARAM_BARTHREADS           3016
#define CPX_PARAM_BARSTARTALG          3017


/* baruset.c */

int CPXPUBLIC
   CPXsetorderhookfunc (CPXENVptr env,
                        int (CPXPUBLIC *orderhook)(CPXENVptr, 
                        int, int *, int *, int *));

void CPXPUBLIC
   CPXgetorderhookfunc (CPXENVptr env,
                        int (CPXPUBLIC **orderhook_p)(CPXENVptr, 
                        int, int *, int *, int *));

/* hybopt.c */

int CPXPUBLIC
   CPXhybbaropt (CPXENVptr env, CPXLPptr lp, char method);
int CPXPUBLIC
   CPXbaropt    (CPXENVptr env, CPXLPptr lp);


#ifdef __cplusplus
}
#endif

#endif  /* __BARDEFS_H */
/*******************************************************************/
/*  MIPDEFS.h                                                      */
/*  Version 6.0                                                    */
/*                                                                 */
/*  Copyright (c) 1997-1998                                        */
/*  ILOG                                                           */
/*  All Rights Reserved                                            */
/*                                                                 */
/*  Last modified 27 March 1998, IJL                               */
/*******************************************************************/

#ifndef __MIPDEFS_H
#define __MIPDEFS_H

#ifdef __cplusplus
extern "C" {
#endif


/* MIP error codes */

#define CPXERR_ALREADY_CTYPE          3001
#define CPXERR_BOUNDS_BINARY          3002
#define CPXERR_NOT_MIP                3003
#define CPXERR_SOS_BOUNDS             3004
#define CPXERR_BAD_PRIORITY           3006
#define CPXERR_ORDER_BAD_DIRECTION    3007
#define CPXERR_ARRAY_BAD_SOS_TYPE     3009
#define CPXERR_UNIQUE_WEIGHTS         3010
#define CPXERR_BOUNDS_INT             3011
#define CPXERR_BAD_DIRECTION          3012
#define CPXERR_NO_SOS                 3015
#define CPXERR_NO_ORDER               3016
#define CPXERR_NO_INT_SOLN            3017
#define CPXERR_INT_TOO_BIG            3018
#define CPXERR_SUBPROB_SOLVE          3019
#define CPXERR_NO_MIPSTART            3020
#define CPXERR_BAD_CTYPE              3021
       
#define CPXERR_MISS_SOS_TYPE          3301
       
#define CPXERR_TRE_FILE_DATA          3401
#define CPXERR_TRE_FILE_WRITE         3402
#define CPXERR_TRE_FILE_VERSION       3403
#define CPXERR_TRE_FILE_OBJ           3404
#define CPXERR_TRE_FILE_COLS          3405
#define CPXERR_TRE_FILE_ROWS          3406
#define CPXERR_TRE_FILE_INTS          3407
#define CPXERR_TRE_FILE_NONZ          3408
#define CPXERR_TRE_FILE_TYPES         3409
#define CPXERR_TRE_FILE_PRESOLVE      3410
#define CPXERR_NO_TREE                3412
#define CPXERR_TREE_MEMORY_LIMIT      3413
#define CPXERR_TRE_FILE_FORMAT        3414
       
#define CPXERR_NODE_FILE_OPEN         3501
#define CPXERR_NODE_FILE_READ         3502
#define CPXERR_NODE_FILE_WRITE        3503
#define CPXERR_NODE_ON_DISK           3504
       
#define CPXERR_PTHREAD_MUTEX_INIT     3601
#define CPXERR_SUN_CONCURRENCY        3602
#define CPXERR_PTHREAD_CREATE         3603

/* Values for sostype and branch type */

#define CPX_TYPE_VAR                    '0'
#define CPX_TYPE_SOS1                   '1'
#define CPX_TYPE_SOS2                   '2'
#define CPX_TYPE_SOS3                   '3'
#define CPX_TYPE_USER                   'X'

/* Variable selection values */

#define CPX_VARSEL_MININFEAS            -1
#define CPX_VARSEL_DEFAULT               0
#define CPX_VARSEL_MAXINFEAS             1
#define CPX_VARSEL_PSEUDO                2
#define CPX_VARSEL_STRONG                3

/* Node selection values */

#define CPX_NODESEL_DFS                  0
#define CPX_NODESEL_BESTBOUND            1
#define CPX_NODESEL_BESTEST              2
#define CPX_NODESEL_BESTEST_ALT          3

/* Values for generated priority order */

#define CPX_MIPORDER_COST                1 
#define CPX_MIPORDER_BOUNDS              2 
#define CPX_MIPORDER_SCALEDCOST          3

/* Values for direction array */

#define CPX_BRANCH_GLOBAL                0
#define CPX_BRANCH_DOWN                  1
#define CPX_BRANCH_UP                    2

/* Values for CPX_PARAM_BRDIR */

#define CPX_BRDIR_DOWN                  -1
#define CPX_BRDIR_AUTO                   0
#define CPX_BRDIR_UP                     1
 
/* Use of MIP start values */

#define CPX_MIPSTART_NODE0               1

/* MIP Problem status codes */

#define CPXMIP_OPTIMAL                 101
#define CPXMIP_OPTIMAL_TOL             102
#define CPXMIP_INFEASIBLE              103
#define CPXMIP_SOL_LIM                 104
#define CPXMIP_NODE_LIM_FEAS           105
#define CPXMIP_NODE_LIM_INFEAS         106
#define CPXMIP_TIME_LIM_FEAS           107
#define CPXMIP_TIME_LIM_INFEAS         108
#define CPXMIP_FAIL_FEAS               109
#define CPXMIP_FAIL_INFEAS             110
#define CPXMIP_MEM_LIM_FEAS            111
#define CPXMIP_MEM_LIM_INFEAS          112
#define CPXMIP_ABORT_FEAS              113
#define CPXMIP_ABORT_INFEAS            114
#define CPXMIP_OPTIMAL_INFEAS          115
#define CPXMIP_FAIL_FEAS_NO_TREE       116
#define CPXMIP_FAIL_INFEAS_NO_TREE     117
#define CPXMIP_NODE_FILE_LIM_FEAS      118
#define CPXMIP_NODE_FILE_LIM_INFEAS    119

/* Callback values for wherefrom */

#define CPX_CALLBACK_MIP               101
#define CPX_CALLBACK_MIP_BRANCH        102
#define CPX_CALLBACK_MIP_NODE          103
#define CPX_CALLBACK_MIP_HEURISTIC     104
#define CPX_CALLBACK_MIP_SOLVE         105
/* Be sure to check the LP values */

/* Values for getcallbackinfo function */

#define CPX_CALLBACK_INFO_BEST_INTEGER        101
#define CPX_CALLBACK_INFO_BEST_REMAINING      102
#define CPX_CALLBACK_INFO_NODE_COUNT          103
#define CPX_CALLBACK_INFO_NODES_LEFT          104
#define CPX_CALLBACK_INFO_MIP_ITERATIONS      105
#define CPX_CALLBACK_INFO_CUTOFF              106
#define CPX_CALLBACK_INFO_CLIQUE_COUNT        107
#define CPX_CALLBACK_INFO_COVER_COUNT         108

/* Values for getnodecallbackinfo function */

#define CPX_CALLBACK_INFO_NODE_SIINF          201
#define CPX_CALLBACK_INFO_NODE_NIINF          202
#define CPX_CALLBACK_INFO_NODE_ESTIMATE       203
#define CPX_CALLBACK_INFO_NODE_DEPTH          204
#define CPX_CALLBACK_INFO_NODE_OBJVAL         205
#define CPX_CALLBACK_INFO_NODE_TYPE           206
#define CPX_CALLBACK_INFO_NODE_VAR            207
#define CPX_CALLBACK_INFO_NODE_SOS            208
#define CPX_CALLBACK_INFO_NODE_SEQNUM         209

/* Values for getvarcallbackinfo function */

#define CPX_CALLBACK_INFO_VAR_TYPE            251
#define CPX_CALLBACK_INFO_VAR_DOWN_PSEUDO     252
#define CPX_CALLBACK_INFO_VAR_UP_PSEUDO       253
#define CPX_CALLBACK_INFO_VAR_PRIORITY        254
#define CPX_CALLBACK_INFO_VAR_DIRECTION       255
#define CPX_CALLBACK_INFO_VAR_INTEGER_VALUE   256
#define CPX_CALLBACK_INFO_VAR_IS_INT_FEASIBLE 257
#define CPX_CALLBACK_INFO_VAR_LB              258
#define CPX_CALLBACK_INFO_VAR_UB              259

/* Values for getsoscallbackinfo function */

#define CPX_CALLBACK_INFO_SOS_TYPE            240
#define CPX_CALLBACK_INFO_SOS_SIZE            241
#define CPX_CALLBACK_INFO_SOS_IS_FEASIBLE     242
#define CPX_CALLBACK_INFO_SOS_PRIORITY        243
#define CPX_CALLBACK_INFO_SOS_MEMBER_INDEX    244
#define CPX_CALLBACK_INFO_SOS_MEMBER_IS_COMP  245
#define CPX_CALLBACK_INFO_SOS_MEMBER_REFVAL   246
#define CPX_CALLBACK_INFO_SOS_NUM             247
/* Be sure to check the LP values */

/* To support old CBINFO names */

#ifndef  CPX_MODERN

#define CPX_CBINFO_BEST_INTEGER        CPX_CALLBACK_INFO_BEST_INTEGER        
#define CPX_CBINFO_BEST_REMAINING      CPX_CALLBACK_INFO_BEST_REMAINING      
#define CPX_CBINFO_NODE_COUNT          CPX_CALLBACK_INFO_NODE_COUNT          
#define CPX_CBINFO_NODES_LEFT          CPX_CALLBACK_INFO_NODES_LEFT          
#define CPX_CBINFO_MIP_ITERATIONS      CPX_CALLBACK_INFO_MIP_ITERATIONS      
#define CPX_CBINFO_CUTOFF              CPX_CALLBACK_INFO_CUTOFF              
#define CPX_CBINFO_CLIQUE_COUNT        CPX_CALLBACK_INFO_CLIQUE_COUNT        
#define CPX_CBINFO_COVER_COUNT         CPX_CALLBACK_INFO_COVER_COUNT         
#define CPX_CBINFO_NODE_SIINF          CPX_CALLBACK_INFO_NODE_SIINF          
#define CPX_CBINFO_NODE_NIINF          CPX_CALLBACK_INFO_NODE_NIINF          
#define CPX_CBINFO_NODE_ESTIMATE       CPX_CALLBACK_INFO_NODE_ESTIMATE       
#define CPX_CBINFO_NODE_DEPTH          CPX_CALLBACK_INFO_NODE_DEPTH       
#define CPX_CBINFO_NODE_OBJVAL         CPX_CALLBACK_INFO_NODE_OBJVAL         
#define CPX_CBINFO_NODE_TYPE           CPX_CALLBACK_INFO_NODE_TYPE           
#define CPX_CBINFO_NODE_VAR            CPX_CALLBACK_INFO_NODE_VAR            
#define CPX_CBINFO_NODE_SOS            CPX_CALLBACK_INFO_NODE_SOS            
#define CPX_CBINFO_NODE_SEQNUM         CPX_CALLBACK_INFO_NODE_SEQNUM         
#define CPX_CBINFO_VAR_TYPE            CPX_CALLBACK_INFO_VAR_TYPE            
#define CPX_CBINFO_VAR_DOWN_PSEUDO     CPX_CALLBACK_INFO_VAR_DOWN_PSEUDO     
#define CPX_CBINFO_VAR_UP_PSEUDO       CPX_CALLBACK_INFO_VAR_UP_PSEUDO       
#define CPX_CBINFO_VAR_PRIORITY        CPX_CALLBACK_INFO_VAR_PRIORITY        
#define CPX_CBINFO_VAR_DIRECTION       CPX_CALLBACK_INFO_VAR_DIRECTION       
#define CPX_CBINFO_VAR_INTEGER_VALUE   CPX_CALLBACK_INFO_VAR_INTEGER_VALUE   
#define CPX_CBINFO_VAR_IS_INT_FEASIBLE CPX_CALLBACK_INFO_VAR_IS_INT_FEASIBLE 
#define CPX_CBINFO_VAR_LB              CPX_CALLBACK_INFO_VAR_LB              
#define CPX_CBINFO_VAR_UB              CPX_CALLBACK_INFO_VAR_UB              
#define CPX_CBINFO_SOS_TYPE            CPX_CALLBACK_INFO_SOS_TYPE            
#define CPX_CBINFO_SOS_SIZE            CPX_CALLBACK_INFO_SOS_SIZE            
#define CPX_CBINFO_SOS_IS_FEASIBLE     CPX_CALLBACK_INFO_SOS_IS_FEASIBLE     
#define CPX_CBINFO_SOS_PRIORITY        CPX_CALLBACK_INFO_SOS_PRIORITY        
#define CPX_CBINFO_SOS_MEMBER_INDEX    CPX_CALLBACK_INFO_SOS_MEMBER_INDEX    
#define CPX_CBINFO_SOS_MEMBER_IS_COMP  CPX_CALLBACK_INFO_SOS_MEMBER_IS_COMP  
#define CPX_CBINFO_SOS_MEMBER_REFVAL   CPX_CALLBACK_INFO_SOS_MEMBER_REFVAL   
#define CPX_CBINFO_SOS_NUM             CPX_CALLBACK_INFO_SOS_NUM   

#endif
          
/* Callback return codes */

#define CPX_CALLBACK_DEFAULT             0
#define CPX_CALLBACK_SET                 2
#define CPX_CALLBACK_FAIL                1
#define CPX_CALLBACK_NO_SPACE            3

/* MIP Parameter numbers */
#define CPX_PARAM_BRDIR                2001
#define CPX_PARAM_BTTOL                2002
#define CPX_PARAM_CLIQUES              2003
#define CPX_PARAM_COEREDIND            2004
#define CPX_PARAM_COVERS               2005
#define CPX_PARAM_CUTLO                2006
#define CPX_PARAM_CUTUP                2007
#define CPX_PARAM_EPAGAP               2008
#define CPX_PARAM_EPGAP                2009
#define CPX_PARAM_EPINT                2010
#define CPX_PARAM_HEURISTIC            2011
#define CPX_PARAM_MIPDISPLAY           2012
#define CPX_PARAM_MIPINTERVAL          2013
#define CPX_PARAM_MIPTHREADS           2014
#define CPX_PARAM_INTSOLLIM            2015
#define CPX_PARAM_NODEFILEIND          2016
#define CPX_PARAM_NODELIM              2017
#define CPX_PARAM_NODESEL              2018
#define CPX_PARAM_OBJDIF               2019
#define CPX_PARAM_MIPORDIND            2020
#define CPX_PARAM_RCFIXIND             2021
#define CPX_PARAM_RELOBJDIF            2022
#define CPX_PARAM_SOSIND               2023
#define CPX_PARAM_SOSMINSZ             2024
#define CPX_PARAM_STARTALG             2025
#define CPX_PARAM_SUBALG               2026
#define CPX_PARAM_TRELIM               2027
#define CPX_PARAM_VARSEL               2028
#define CPX_PARAM_BNDSTRENIND          2029
#define CPX_PARAM_NODEFILELIM          2030
#define CPX_PARAM_HEURFREQ             2031
#define CPX_PARAM_MIPORDTYPE           2032
#define CPX_PARAM_CUTSFACTOR           2033
#define CPX_PARAM_RELAXPREIND          2034
#define CPX_PARAM_MIPSTART             2035
#define CPX_PARAM_NODEFILEDIR          2036

/* Old names */

#ifndef  CPX_MODERN

#define CPX_PARAM_NDFILIND  CPX_PARAM_NODEFILEIND
#define CPX_PARAM_NDSEL     CPX_PARAM_NODESEL
#define CPX_PARAM_NDLIM     CPX_PARAM_NODELIM

#define CPXmipoptimize      CPXmipopt
#define CPXreadloadorder    CPXreadcopyorder
#define CPXreadloadsos      CPXreadcopysos
       
#define CPXgetsubprobcbinfo CPXgetsubcallbackinfo
#define CPXgetnodecbinfo    CPXgetnodecallbackinfo
#define CPXgetvarcbinfo     CPXgetvarcallbackinfo
#define CPXgetsoscbinfo     CPXgetsoscallbackinfo

#define CPXgetmx            CPXgetmipx
#define CPXgetmslack        CPXgetmipslack
#define CPXgetmobjval       CPXgetmipobjval
#define CPXgetbobjval       CPXgetbestobjval
#define CPXloadmprob        CPXloadmipprob
#define CPXgetitcm          CPXgetmipitcnt
#define CPXgetndc           CPXgetnodecnt
#define CPXgetndleft        CPXgetnodeleftcnt
#define CPXgetndint         CPXgetnodeint
#define CPXgetclqc          CPXgetclqcnt
#define CPXgetcovc          CPXgetcovcnt
#define CPXgetgclqc         CPXgetgenclqcnt
#define CPXgetintc          CPXgetnumint
#define CPXgetbinc          CPXgetnumbin

#endif

/* Function definitions */


/* mipload.c */

CPXLPptr CPXPUBLIC
   CPXloadmipprob (CPXENVptr env, char *probname,
                   int numcols, int numrows, int numrims,
                   int objsen, double *obj, double *rhs,
                   char *sense, int *matbeg, int *matcnt,
                   int *matind, double *matval, double *lb,
                   double *ub, double *rngval, int *freerowind,
                   int *rimtype, int *rimbeg, int *rimcnt,
                   int *rimind, double *rimval,
                   char *dataname, char *objname, char *rhsname,
                   char *rngname, char *bndname,
                   char **colname, char *colnamestore,
                   char **rowname, char *rownamestore,
                   char **rimname, char *rimnamestore,
                   int colspace, int rowspace, int nzspace,
                   int rimspace, int rimnzspace,
                   unsigned colnamespace, unsigned rnamespace,
                   unsigned rimnamespace, char *xctype);

int CPXPUBLIC
   CPXloadctype    (CPXENVptr env, CPXLPptr lp, char *xctype);
int CPXPUBLIC
   CPXcopyorder    (CPXENVptr env, CPXLPptr lp, int cnt,
                    int *indices, int *priority, int *direction);
int CPXPUBLIC
   CPXcopymipstart (CPXENVptr env, CPXLPptr lp, int cnt,
                    int *indices, double *value);
int CPXPUBLIC
   CPXcopysos      (CPXENVptr env, CPXLPptr lp, int numsos,
                    int numsosnz, char *sostype, int *sospri,
                    int *sosbeg, int *sosind, double *sosref);

/* mipopt.c */

int CPXPUBLIC
   CPXmipopt     (CPXENVptr env, CPXLPptr lp);

/* mipordrw.c */

int CPXPUBLIC
   CPXordread       (CPXENVptr env, char *filename, int numcols,
                     char **colname, int *cnt_p, int *indices,
                     int *priority, int *direction);
int CPXPUBLIC
   CPXordwrite      (CPXENVptr env, CPXLPptr lp, char *filename);

/* mipquery.c */

int CPXPUBLIC
   CPXgetmipx        (CPXENVptr env, CPXLPptr lp, double *x,
                      int begin, int end);
int CPXPUBLIC
   CPXgetmipslack    (CPXENVptr env, CPXLPptr lp, double *slack,
                      int begin, int end);
int CPXPUBLIC
   CPXgetmipobjval   (CPXENVptr env, CPXLPptr lp, 
                      double *objval_p);
int CPXPUBLIC
   CPXgetctype       (CPXENVptr env, CPXLPptr lp, char *xctype,
                      int begin, int end);
int CPXPUBLIC
   CPXgetnumint      (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetnumbin      (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetmipitcnt    (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetbestobjval  (CPXENVptr env, CPXLPptr lp, 
                      double *objval_p);
int CPXPUBLIC
   CPXgetcutoff      (CPXENVptr env, CPXLPptr lp, 
                      double *cutoff_p);
int CPXPUBLIC
   CPXgetnodecnt     (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetnodeleftcnt (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetnodeint     (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetgenclqcnt   (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetclqcnt      (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetcovcnt      (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetorder       (CPXENVptr env, CPXLPptr lp, int *cnt_p,
                      int *indices, int *priority, int *direction,
                      int ordspace, int *surplus_p);
int CPXPUBLIC
   CPXgetmipstart    (CPXENVptr env, CPXLPptr lp, int *cnt_p,
                      int *indices, double *value, int mipstartspace,
                      int *surplus_p);
int CPXPUBLIC
   CPXgetnumsos      (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetsos         (CPXENVptr env, CPXLPptr lp, int *numsosnz_p,
                      char *sostype, int *sospri, int *sosbeg,
                      int *sosind, double *sosref,
                      int sosspace, int *surplus_p, int begin,
                      int end);
int CPXPUBLIC
   CPXgetsubstat     (CPXENVptr env, CPXLPptr lp);

/* mipsosrw.c */

int CPXPUBLIC
   CPXsosread  (CPXENVptr env, char *filename, int numcols,
                char **colname, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sospri_p, int **sosbeg_p,
                int **sosind_p, double **sosref_p);
int CPXPUBLIC
   CPXsoswrite (CPXENVptr env, CPXLPptr lp, char *filename);

/* miptrerw.c */

int CPXPUBLIC
   CPXreadcopytree (CPXENVptr env, CPXLPptr lp, char *filename);
int CPXPUBLIC
   CPXtreewrite    (CPXENVptr env, CPXLPptr lp, char *filename);

/* mipuchg.c */

int CPXPUBLIC
   CPXchgctype    (CPXENVptr env, CPXLPptr lp, int cnt, int *indices,
                   char *xctype);
int CPXPUBLIC
   CPXcopyctype   (CPXENVptr env, CPXLPptr lp, char *zctype);
int CPXPUBLIC
   CPXchgprobtype (CPXENVptr env, CPXLPptr lp, int type);

/* mipuctrl.c */

int CPXPUBLIC
   CPXsetbranchcallbackfunc    (CPXENVptr env,
                                int (CPXPUBLIC *branchcallback)
                                (CPXENVptr, void *, void *, int, 
                                int *, int *, int *, int *, int *, 
                                int *, double *, int *, int *, char *, 
                                int *, int *), void *cbhandle);
int CPXPUBLIC
   CPXsetnodecallbackfunc      (CPXENVptr env,
                                int (CPXPUBLIC *nodecallback)
                                (CPXENVptr, void *, void *, int, 
                                int *, int *), void *cbhandle);
int CPXPUBLIC
   CPXsetheuristiccallbackfunc (CPXENVptr env,
                                int (CPXPUBLIC *heursticcallback)
                                (CPXENVptr, void *, void *, int, 
                                double *, double *, int *, int *),
                                void *cbhandle);
int CPXPUBLIC
   CPXsetsolvecallbackfunc     (CPXENVptr env,
                                int (CPXPUBLIC *solvecallback)
                                (CPXENVptr, void *, void *, int, int *),
                                void *cbhandle);

void CPXPUBLIC
   CPXgetbranchcallbackfunc    (CPXENVptr env,
                                int (CPXPUBLIC **branchcallback_p)
                                (CPXENVptr, void *, void *, int, 
                                int *, int *, int *, int *, int *, 
                                int *, double *, int *, int *, char *, 
                                int *, int *), void **cbhandle_p);
void CPXPUBLIC
   CPXgetnodecallbackfunc      (CPXENVptr env,
                                int (CPXPUBLIC **nodecallback_p)
                                (CPXENVptr, void *, void *, int, 
                                int *, int *), void **cbhandle_p);
void CPXPUBLIC
   CPXgetheuristiccallbackfunc (CPXENVptr env,
                                int (CPXPUBLIC **heuristiccallback_p)
                                (CPXENVptr, void *, void *, int, double *,
                                double *, int *, int *),
                                void **cbhandle_p);
void CPXPUBLIC
   CPXgetsolvecallbackfunc     (CPXENVptr env,
                                int (CPXPUBLIC **solvecallback_p)
                                (CPXENVptr, void *, void *, int, int *),
                                void **cbhandle_p);

int CPXPUBLIC
   CPXgetsubcallbackinfo       (CPXENVptr env, void *cbdata,
                                int wherefrom,
                                CPXLPptr *subproblemlp);
int CPXPUBLIC
   CPXgetnodecallbackinfo      (CPXENVptr env, void *cbdata,
                                int wherefrom, int nodenum,
                                int whichinfo, void *result_p);
int CPXPUBLIC
   CPXgetvarcallbackinfo       (CPXENVptr env, void *cbdata,
                                int wherefrom, int varindex,
                                int whichinfo, void *result_p);
int CPXPUBLIC
   CPXgetsoscallbackinfo       (CPXENVptr env, void *cbdata,
                                int wherefrom, int sosindex,
                                int member, int whichinfo,
                                void *result_p);


#ifdef __cplusplus
}
#endif

#endif /* __MIPDEFS_H */
/*******************************************************************/
/*  QPDEFS.h                                                       */
/*  Version 6.0                                                    */
/*                                                                 */
/*  Copyright (c) 1997-1998                                        */
/*  ILOG                                                           */
/*  All Rights Reserved                                            */
/*                                                                 */
/*  Last modified 27 February 1998, EER                            */
/*******************************************************************/

#ifndef __QPDEFS_H
#define __QPDEFS_H

#ifdef __cplusplus
extern "C" {
#endif


/* QP error codes */

#define CPXERR_BAD_Q           5001
#define CPXERR_Q_NOT_POS_DEF   5002
#define CPXERR_Q_NOT_MATRIX    5003
#define CPXERR_NOT_QP          5004
#define CPXERR_Q_SEP_INDEF     5006
#define CPXERR_QP_BAD_BAR_ALG  5007
#define CPXERR_Q_NO_SPACE      5009
#define CPXERR_Q_NEG_ZERO_COMP 5010
#define CPXERR_Q_DUP_ENTRY     5011
#define CPXERR_Q_NOT_SYMMETRIC 5012

#define CPX_PARAM_QPNZREADLIM 4001
#define CPX_PARAM_QPNZGROWTH  4002

#ifndef  CPX_MODERN

#define  CPXloadqsep   CPXloadqpsep

#endif



/* qpload.c */

int CPXPUBLIC
   CPXloadquad  (CPXENVptr env, CPXLPptr lp, int *qmatbeg,
                 int *qmatcnt, int *qmatind, double *qmatval,
                 int qnzspace);
int CPXPUBLIC
   CPXloadqpsep (CPXENVptr env, CPXLPptr lp, double *qsepvec);
int CPXPUBLIC
   CPXcopyquad  (CPXENVptr env, CPXLPptr lp, int *qmatbeg, 
                 int *qmatcnt, int *qmatind, double *qmatval);
int CPXPUBLIC
   CPXcopyqpsep (CPXENVptr env, CPXLPptr lp, double *qsepvec);

/* qpqrychg.c */

int CPXPUBLIC
   CPXgetnumqpnz (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetnumquad (CPXENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetqpcoef  (CPXENVptr env, CPXLPptr lp, int rownum, int colnum,
                  double *coef_p);
int CPXPUBLIC
   CPXchgqpcoef  (CPXENVptr env, CPXLPptr lp, int i, int j,
                  double newvalue);

/* qprw.c */

int CPXPUBLIC
   CPXqpread  (CPXENVptr env, char *filename, int numcols, 
               int colspace, char **colname, int **qmatbeg_p, 
               int **qmatcnt_p, int **qmatind_p, double **qmatval_p,
               int *qnzspace_p);
int CPXPUBLIC
   CPXqpwrite (CPXENVptr env, CPXLPptr lp, char *filename);


#ifdef __cplusplus
}
#endif

#endif /* __QPDEFS_H */
