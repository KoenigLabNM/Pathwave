/*******************************************************************/
/*  CPXDEFS.h                                                      */
/*  Version 4.0                                                    */
/*                                                                 */
/*  Copyright (c) 1989-1995                                        */
/*  CPLEX Optimization, Inc.                                       */
/*  All Rights Reserved                                            */
/*                                                                 */
/*  Last modified 24 April 1996, MCF                               */
/*******************************************************************/

#ifndef __CPXDEFS_H
#define __CPXDEFS_H

#ifdef  SYSVAX
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSOPENVMS
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSHP
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSHC386
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSWAT386
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSWATOS2
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSIBMOS2
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSVCALPHANT
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSSPARC
#define CPX_PROTOTYPE_CKR
#endif

#ifdef  SYSGNUSPARC
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSNCR
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSSOLARIS
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSGNUSOLARIS
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSDECSTATION
#define CPX_PROTOTYPE_CKR
#endif

#ifdef  SYSALPHA
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSSILICON
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSR8K
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSMAC
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYS3090
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSCONVEX
#define CPX_PROTOTYPE_CKR
#endif

#ifdef  SYSRS6000
#define CPX_PROTOTYPE_ANSI
#endif

#ifdef  SYSCRAY
#define CPX_PROTOTYPE_CKR
#endif

/* It seems necessary to have the include for <stdio.h> after the
   1167 pragma, when that pragma is active. <stdio.h> is include here
   so that the 'FILE' type is defined */

#include <stdio.h>

/* INFBOUND:  Any bound bigger than this is treated as infinity */

#define INFBOUND  1.0E+20

/* Values returned for 'stat' by solution () */

#define  CPX_OPTIMAL                      1
#define  CPX_INFEASIBLE                   2
#define  CPX_UNBOUNDED                    3
#define  CPX_OBJ_LIM                      4
#define  CPX_IT_LIM_FEAS                  5
#define  CPX_IT_LIM_INFEAS                6
#define  CPX_TIME_LIM_FEAS                7
#define  CPX_TIME_LIM_INFEAS              8
#define  CPX_NUM_BEST_FEAS                9
#define  CPX_NUM_BEST_INFEAS             10
#define  CPX_OPTIMAL_INFEAS              11
#define  CPX_ABORT_FEAS                  12
#define  CPX_ABORT_INFEAS                13
#define  CPX_ABORT_DUAL_INFEAS           14
#define  CPX_ABORT_PRIM_INFEAS           15
#define  CPX_ABORT_PRIM_DUAL_INFEAS      16
#define  CPX_ABORT_PRIM_DUAL_FEAS        17
#define  CPX_ABORT_CROSSOVER             18

/* Error codes */

#define  CPXERR_MISC                   1000
#define  CPXERR_NO_MEMORY              1001
#define  CPXERR_NO_ENVIRONMENT         1002
#define  CPXERR_BAD_PARAMETER          1003
#define  CPXERR_NULL_POINTER           1004
#define  CPXERR_POINTER_MISMATCH       1005
#define  CPXERR_CALLBACK               1006
#define  CPXERR_NO_PROBLEM             1009
#define  CPXERR_NO_ROWS                1010
#define  CPXERR_NO_COLS                1011
#define  CPXERR_NOT_LP                 1012
#define  CPXERR_LIMITS_TOO_BIG         1016
#define  CPXERR_BAD_PARAMNUM           1017
#define  CPXERR_PARAM_TOO_SMALL        1018
#define  CPXERR_PARAM_TOO_BIG          1019
#define  CPXERR_STUDENTVERSION         1020
#define  CPXERR_NOT_FOR_QP             1021
#define  CPXERR_CHILD_OF_CHILD         1022
#define  CPXERR_TOO_MANY_THREADS       1023
#define  CPXERR_CANT_CLOSE_CHILD       1024
#define  CPXERR_BAD_PROB_TYPE          1025

#define  CPXERR_MSG_NO_CHANNEL         1051
#define  CPXERR_MSG_NO_FILEPTR         1052
#define  CPXERR_MSG_NO_FUNCTION        1053

#define  CPXERR_BOUNDS_INFEAS          1100
#define  CPXERR_PRESLV_INForUNBD       1101
#define  CPXERR_PRESLV_RANGE_NAME      1102
#define  CPXERR_PRESLV_NO_PROB         1103
#define  CPXERR_PRESLV_NOLOAD          1104
#define  CPXERR_PRESLV_BADBASIS        1105
#define  CPXERR_PRESLV_ABORT           1106
#define  CPXERR_PRESLV_BASIS_MEM       1107
#define  CPXERR_PRESLV_LOADSOS         1108
#define  CPXERR_PRESLV_LOADORDER       1109
#define  CPXERR_PRESLV_SOLN_MIP        1110
#define  CPXERR_PRESLV_SOLN_QP         1111
#define  CPXERR_PRESLV_START_LP        1112
#define  CPXERR_PRESLV_BADSTART        1113
#define  CPXERR_PRESLV_FAILBASIS       1114
#define  CPXERR_PRESLV_NOBASIS         1115

/* Callable library misc. routines */

#define  CPXERR_INDEX_RANGE            1200
#define  CPXERR_COL_INDEX_RANGE        1201
#define  CPXERR_COL_NEW_INDEX_RNG      1202
#define  CPXERR_ROW_INDEX_RANGE        1203
#define  CPXERR_ROW_NEW_INDEX_RNG      1204
#define  CPXERR_INDEX_RANGE_LOW        1205
#define  CPXERR_INDEX_RANGE_HIGH       1206
#define  CPXERR_NEGATIVE_SURPLUS       1207
#define  CPXERR_ARRAY_TOO_LONG         1208
#define  CPXERR_NAME_CREATION          1209
#define  CPXERR_NAME_NOT_FOUND         1210
#define  CPXERR_NO_RHS_IN_OBJ          1211
#define  CPXERR_RANGE_NOT_ALLOWED      1212
#define  CPXERR_NROWS_NOT_ALLOWED      1213
#define  CPXERR_CANT_REALLOC_RIMS      1214
#define  CPXERR_BAD_SENSE              1215
#define  CPXERR_NO_RNGVAL              1216
#define  CPXERR_NO_SOLUTION            1217
#define  CPXERR_NO_RIM                 1218
#define  CPXERR_NO_NAMES               1219


/* Simplex related */
#define  CPXERR_INDEX_NOT_BASIC        1251
#define  CPXERR_NEED_OPT_SOLN          1252
#define  CPXERR_BAD_STATUS             1253
#define  CPXERR_NOT_UNBOUNDED          1254
#define  CPXERR_SB_INCOMPAT            1255
#define  CPXERR_SINGULAR               1256
#define  CPXERR_PRIIND                 1257
#define  CPXERR_NO_LUFACTOR            1258
#define  CPXERR_NO_SENSIT              1260
#define  CPXERR_NO_BASIC_SOLUTION      1261
#define  CPXERR_NO_BASIS               1262
#define  CPXERR_ABORT_STRONGBRANCH     1263
#define  CPXERR_NO_NORMS               1264

/* Network related */

#define  CPXERR_NET_SMALL              1290
#define  CPXERR_NET_IMBALANCE          1291
#define  CPXERR_BAD_METHOD             1292

#define  CPXERR_LOCK_TAMPER            1300


/* Space related.  Only CPXERR_NO_SPACE should be returned */

#define  CPXERR_NO_SPACE               1401
#define  CPXERR_NO_SPACE_FREE          1402
#define  CPXERR_NO_SPACE_FREE_NZ       1403
#define  CPXERR_NO_SPACE_FREE_NAM      1404
#define  CPXERR_NO_SPACE_NONZ          1405
#define  CPXERR_NO_SPACE_NAMES         1406

/* For readers and writers */

#define  CPXERR_NO_FILENAME            1421
#define  CPXERR_FAIL_OPEN_WRITE        1422
#define  CPXERR_FAIL_OPEN_READ         1423


/* Common to LP, MPS, and related readers */

#define  CPXERR_NO_COEFFICIENTS        1430
#define  CPXERR_TOO_MANY_ROWS          1431
#define  CPXERR_TOO_MANY_COLUMNS       1432
#define  CPXERR_TOO_MANY_COEFFS        1433
#define  CPXERR_BAD_NUMBER             1434
#define  CPXERR_BAD_EXPO_RANGE         1435
#define  CPXERR_NO_OBJ_SENSE           1436

/* Common to MPS and related readers */

#define  CPXERR_NO_NAME_SECTION        1441
#define  CPXERR_BAD_SOS_TYPE           1442
#define  CPXERR_COL_ROW_REPEATS        1443
#define  CPXERR_RIM_ROW_REPEATS        1444
#define  CPXERR_ROW_REPEATS            1445
#define  CPXERR_COLUMN_REPEATS         1446
#define  CPXERR_RIM_REPEATS            1447
#define  CPXERR_ROW_UNKNOWN            1448
#define  CPXERR_COLUMN_UNKNOWN         1449
#define  CPXERR_RHS_UNKNOWN            1450
#define  CPXERR_BOUND_UNKNOWN          1451
#define  CPXERR_RANGE_UNKNOWN          1452
#define  CPXERR_NO_ROW_SENSE           1453
#define  CPXERR_EXTRA_FX_BOUND         1454
#define  CPXERR_EXTRA_FR_BOUND         1455
#define  CPXERR_EXTRA_BV_BOUND         1456
#define  CPXERR_BAD_BOUND_TYPE         1457
#define  CPXERR_UP_BOUND_REPEATS       1458
#define  CPXERR_LO_BOUND_REPEATS       1459
#define  CPXERR_NO_BOUND_TYPE          1460
#define  CPXERR_NO_QMATRIX_SECTION     1461
#define  CPXERR_BAD_SECTION_ENDATA     1462

/* Unique to MPS reader */

#define  CPXERR_NO_ROWS_SECTION        1471
#define  CPXERR_NO_COLUMNS_SECTION     1472
#define  CPXERR_BAD_SECTION_BOUNDS     1473
#define  CPXERR_RANGE_SECTION_ORDER    1474
#define  CPXERR_BAD_SECTION_QMATRIX    1475
#define  CPXERR_NO_OBJECTIVE           1476
#define  CPXERR_ROW_REPEAT_PRINT       1477
#define  CPXERR_COL_REPEAT_PRINT       1478
#define  CPXERR_RIMNZ_REPEATS          1479
#define  CPXERR_EXTRA_INTORG           1480
#define  CPXERR_EXTRA_INTEND           1481
#define  CPXERR_EXTRA_SOSORG           1482
#define  CPXERR_EXTRA_SOSEND           1483
#define  CPXERR_TOO_MANY_RIMS          1484
#define  CPXERR_TOO_MANY_RIMNZ         1485
#define  CPXERR_NO_ROW_NAME            1486
#define  CPXERR_BAD_OBJ_SENSE          1487

/* For REVISE files */

#define  CPXERR_REV_INDICATOR          1501
#define  CPXERR_REV_REPEATS            1502
#define  CPXERR_REV_OBJROW_ILLEG       1503
#define  CPXERR_REV_SEN_N_ILLEG        1504
#define  CPXERR_REV_EXTRA_RIM          1505
#define  CPXERR_REV_RIM_NAMES          1506
#define  CPXERR_REV_DELRHS_ILLEG       1507
#define  CPXERR_REV_RHS_COEFF          1508
#define  CPXERR_REV_DELRNG_ILLEG       1509
#define  CPXERR_REV_RANGE_COEFF        1510
#define  CPXERR_REV_NO_RANGES          1511
#define  CPXERR_REV_DELBND_ILLEG       1512
#define  CPXERR_REV_BIN_UB             1513
#define  CPXERR_REV_BND_COEFF          1514
#define  CPXERR_REV_RIM_COEFF          1515
#define  CPXERR_REV_TOO_MANY_ROWS      1516
#define  CPXERR_REV_TOO_MANY_COLS      1517
#define  CPXERR_REV_TOO_MANY_NZS       1518
#define  CPXERR_REV_TOO_MANY_RIMV      1519

/* PAR Files */

#define  CPXERR_PAR_NO_HEADER          1525
#define  CPXERR_PAR_BAD_HEADER         1526
#define  CPXERR_PAR_SHORT              1527
#define  CPXERR_PAR_DATA               1528

/* NET files */

#define  CPXERR_NET_DATA               1530
#define  CPXERR_NOT_MIN_COST_FLOW      1531
#define  CPXERR_BAD_ROW_ID             1532
#define  CPXERR_DEMAND_BALANCE         1533
#define  CPXERR_LO_BIGGER_UP           1534
#define  CPXERR_NET_NO_PROBLEM         1535
#define  CPXERR_NET_FIRST_CHAR         1536
#define  CPXERR_BAD_CHAR               1537

/* BAS files */

#define  CPXERR_BAS_FILE_SHORT         1550
#define  CPXERR_BAD_INDICATOR          1551
#define  CPXERR_NO_ENDATA              1552
#define  CPXERR_FILE_ENTRIES           1553
#define  CPXERR_SBASE_ILLEGAL          1554
#define  CPXERR_BAS_FILE_SIZE          1555
#define  CPXERR_NO_VECTOR_SOL          1556

/* SAV files */

#define  CPXERR_NOT_SAV_FILE           1560
#define  CPXERR_SAV_FILE_DATA          1561
#define  CPXERR_SAV_FILE_WRITE         1562
#define  CPXERR_FILE_FORMAT            1563


/* LP reader errors */

#define  CPXERR_ADJACENT_SIGNS         1602
#define  CPXERR_RHS_IN_OBJ             1603
#define  CPXERR_ADJ_SIGN_SENSE         1604
#define  CPXERR_QUAD_IN_ROW            1605
#define  CPXERR_ADJ_SIGN_QUAD          1606
#define  CPXERR_NO_OPERATOR            1607
#define  CPXERR_NO_OP_OR_SENSE         1608
#define  CPXERR_NO_ID_FIRST            1609
#define  CPXERR_NO_RHSCOEFF            1610
#define  CPXERR_NO_NUMBER_FIRST        1611
#define  CPXERR_NO_QUAD_EXP            1612
#define  CPXERR_QUAD_EXP_NOT_2         1613
#define  CPXERR_NO_QP_OPERATOR         1614
#define  CPXERR_NO_NUMBER              1615
#define  CPXERR_NO_ID                  1616
#define  CPXERR_BAD_ID                 1617
#define  CPXERR_BAD_EXPONENT           1618
#define  CPXERR_NO_BOUND_SENSE         1621
#define  CPXERR_BAD_BOUND_SENSE        1622
#define  CPXERR_NO_NUMBER_BOUND        1623
#define  CPXERR_LPTOO_MANY_ROWS        1624
#define  CPXERR_LPTOO_MANY_COLS        1625
#define  CPXERR_LPTOO_MANY_COEFFS      1626

#define  CPXERR_IIS_NOINFO             1701
#define  CPXERR_IIS_NOSOLN             1702
#define  CPXERR_IIS_FEAS               1703
#define  CPXERR_IIS_NOT_INFEAS         1704
#define  CPXERR_IIS_OPT_INFEAS         1705
#define  CPXERR_IIS_DEFAULT            1706
#define  CPXERR_IIS_NOBASIC            1707
#define  CPXERR_IIS_NOPRIMAL           1708
#define  CPXERR_IIS_NOLOAD             1709
#define  CPXERR_IIS_SUBOBJLIM          1710
#define  CPXERR_IIS_SUBITLIM           1711
#define  CPXERR_IIS_SUBTIMELIM         1712
#define  CPXERR_IIS_NUMBEST            1713

/* Private errors are 2000-2999 (cpxpriv.h)
   MIP errors are 3000-3999 (mipdefs.h)
   Barrier errors are 4000-4999 (bardefs.h)
   QP errors are 5000-5999 (qpdefs.h) */

#define  CPXERR_LICENSE_MIN           32000
#define  CPXERR_NO_MIP_LIC            32301
#define  CPXERR_NO_BARRIER_LIC        32302
#define  CPXERR_LICENSE_MAX           32999

/* Generic constants */

#define  CPX_ON                           1
#define  CPX_OFF                          0
#define  CPX_MAX                         -1
#define  CPX_MIN                          1

/* Pricing options */

#define  CPX_PPRIIND_PARTIAL             -1
#define  CPX_PPRIIND_AUTO                 0
#define  CPX_PPRIIND_DEVEX                1
#define  CPX_PPRIIND_STEEP                2
#define  CPX_PPRIIND_STEEPQSTART          3
#define  CPX_PPRIIND_FULL                 4

#define  CPX_DPRIIND_AUTO                 0
#define  CPX_DPRIIND_FULL                 1
#define  CPX_DPRIIND_STEEP                2
#define  CPX_DPRIIND_FULLSTEEP            3
#define  CPX_DPRIIND_STEEPQSTART          4

/* Values returned by getmethod (). Also used by MIP algorithms */

#define  CPXALG_NONE                      0
#define  CPXALG_PRIMAL                    1
#define  CPXALG_DUAL                      2
#define  CPXALG_NETWORK                   3
#define  CPXALG_BARRIER                   4
#define  CPXALG_DUAL_BARRIER              5
#define  CPXALG_PIVOT                     5

/* Infeasibility Finder return values */

#define  CPXIIS_COMPLETE                  1
#define  CPXIIS_PARTIAL                   2

/* Infeasibility Finder display values */

#define CPXIIS_TERSE                      1
#define CPXIIS_VERBOSE                    2

/* NETOPT optimization status values */

#define CPX_NETOPTIMAL                   -1
#define CPX_NETINFEASIBLE                -2
#define CPX_NETUNBOUNDED                 -3
#define CPX_NETUNBOUNDED_INF             -4

/* Extra rim vector types used in 'etype'/'rimtype' array */

#define EXTRANROW                         1
#define EXTRARHS                          2
#define EXTRARNG                          3
#define EXTRABDL                          4
#define EXTRABDU                          5

/* Variable types for ctype array */

#define CONTINUOUS                      'C'
#define BINARY                          'B'
#define INTEGER                         'I'

/* Problem Types
   Types 0 through 5 are user types, 6 through 8 are internal */

#define  CPXPROB_LP                       0
#define  CPXPROB_MIP                      1
#define  CPXPROB_RELAX                    2
#define  CPXPROB_FIX                      3
#define  CPXPROB_QP                       4
#define  CPXPROB_RELAXEDQP                5
#define  CPXPROB_ZERO_Q                   6
#define  CPXPROB_SUBLP                    7
#define  CPXPROB_MIP_LP                   8

/* CPLEX Parameter numbers. */
#define CPX_PARAM_ADVIND               1001
#define CPX_PARAM_AGGFILL              1002
#define CPX_PARAM_AGGIND               1003
#define CPX_PARAM_BASINTV              1004   /* Old name */
#define CPX_PARAM_BASINTERVAL          1004   /* New name */
#define CPX_PARAM_CFILEMUL             1005
#define CPX_PARAM_CLOCKTYPE            1006
#define CPX_PARAM_CRAIND               1007
#define CPX_PARAM_DEPIND               1008
#define CPX_PARAM_DPRIIND              1009
#define CPX_PARAM_EDLIMU               1010   /* Old name */
#define CPX_PARAM_PRICELIM             1010   /* New name */
#define CPX_PARAM_ELIM                 1011   /* Old name */
#define CPX_PARAM_RIMREADLIM           1011   /* New name */
#define CPX_PARAM_ENZLIM               1012   /* Old name */
#define CPX_PARAM_RIMNZREADLIM         1012   /* New name */
#define CPX_PARAM_EPMRK                1013
#define CPX_PARAM_EPOPT                1014
#define CPX_PARAM_EPPER                1015
#define CPX_PARAM_EPRHS                1016
#define CPX_PARAM_FASTMIP              1017
#define CPX_PARAM_IISIND               1018
#define CPX_PARAM_ITFOIND              1019   /* Old name */
#define CPX_PARAM_SIMDISPLAY           1019   /* New name */
#define CPX_PARAM_ITLIM                1020
#define CPX_PARAM_MLIM                 1021   /* Old name */
#define CPX_PARAM_ROWREADLIM           1021   /* New name */
#define CPX_PARAM_NETFIND              1022
#define CPX_PARAM_NLIM                 1023   /* Old name */
#define CPX_PARAM_COLREADLIM           1023   /* New name */
#define CPX_PARAM_NZLIM                1024   /* Old name */
#define CPX_PARAM_NZREADLIM            1024   /* New name */
#define CPX_PARAM_OBJLLIM              1025
#define CPX_PARAM_OBJULIM              1026
#define CPX_PARAM_PERIND               1027
#define CPX_PARAM_PPRIIND              1028
#define CPX_PARAM_PREIND               1029
#define CPX_PARAM_REINV                1030
#define CPX_PARAM_REVERSEIND           1031
#define CPX_PARAM_RFILEMUL             1032
#define CPX_PARAM_SCAIND               1033
#define CPX_PARAM_SCR_IND              1034   /* Old name */
#define CPX_PARAM_SCRIND               1034   /* New name */
#define CPX_PARAM_SIMTHREADS           1035
#define CPX_PARAM_SINGLIM              1036
#define CPX_PARAM_SINGTOL              1037
#define CPX_PARAM_TILIM                1038
#define CPX_PARAM_PPPIND               1039
#define CPX_PARAM_XXXIND               1040
#define CPX_PARAM_EFFSLACKIND          1041
#define CPX_PARAM_PREDISP              1042

/* Barrier is in bardefs.h, MIP is in mipdefs.h, QP is in qpdefs.h */

#define CPX_PARAM_ALL_MIN              1000
#define CPX_PARAM_ALL_MAX              5000

/* Callback values for wherefrom   */

#define  CPX_CALLBACK_PRIMAL              1
#define  CPX_CALLBACK_DUAL                2
#define  CPX_CALLBACK_NETWORK             3
#define  CPX_CALLBACK_PRIMAL_CROSSOVER    4
#define  CPX_CALLBACK_DUAL_CROSSOVER      5
#define  CPX_CALLBACK_BARRIER             6
#define  CPX_CALLBACK_PRESOLVE            7
/* Be sure to check the MIP values */

/* Values for getcallbackinfo function */

#define  CPX_CBINFO_PRIMAL_OBJ            1
#define  CPX_CBINFO_DUAL_OBJ              2
#define  CPX_CBINFO_PRIMAL_INFMEAS        3
#define  CPX_CBINFO_DUAL_INFMEAS          4
#define  CPX_CBINFO_PRIMAL_FEAS           5
#define  CPX_CBINFO_DUAL_FEAS             6
#define  CPX_CBINFO_ITCOUNT               7
#define  CPX_CBINFO_CROSSOVER_SBCNT       8
#define  CPX_CBINFO_PRESOLVE_ROWSGONE     9
#define  CPX_CBINFO_PRESOLVE_COLSGONE    10
#define  CPX_CBINFO_PRESOLVE_AGGSUBST    11
#define  CPX_CBINFO_PRESOLVE_COEFFS      12
/* Be sure to check the MIP values */

/* structure types */

struct cpxlp;
typedef struct cpxlp  *CPXLPptr;

struct cpxchannel;
typedef struct cpxchannel *CPXCHANNELptr;

struct cpxenv;
typedef struct cpxenv *CPXENVptr;

#define  CPXchgprtype   CPXchgprobtype
#define  CPXgetprtype   CPXgetprobtype
#define  CPXchgfromnrow CPXchgfromfreerow
#define  CPXchgtonrow   CPXchgtofreerow
#define  CPXchgncoef    CPXchgfreecoef
#define  CPXgetmac      CPXgetnumcols
#define  CPXgetmar      CPXgetnumrows
#define  CPXgetmat      CPXgetnumnz
#define  CPXgetmae      CPXgetnumrims
#define  CPXgetnr       CPXgetnumfreerows
#define  CPXgetnrnz     CPXgetnumfreerownz
#define  CPXgetenz      CPXgetnumrimnz
#define  CPXgetnrows    CPXgetfreerows
#define  CPXgetextra    CPXgetrims
#define  CPXgetbdl      CPXgetlb
#define  CPXgetbdu      CPXgetub
#define  CPXgetnrind    CPXgetfreerowind
#define  CPXgetetype    CPXgetrimtype
#define  CPXgetcname    CPXgetcolname
#define  CPXgetrname    CPXgetrowname
#define  CPXgetename    CPXgetrimname
#define  CPXgetmacsz    CPXgetcolspace
#define  CPXgetmarsz    CPXgetrowspace
#define  CPXgetmatsz    CPXgetnzspace
#define  CPXgetmaesz    CPXgetrimspace
#define  CPXgetenzsz    CPXgetrimnzspace
#define  CPXgetcstorsz  CPXgetcolnamespace
#define  CPXgetrstorsz  CPXgetrownamespace
#define  CPXgetestorsz  CPXgetrimnamespace
#define  CPXperwrite    CPXpperwrite

#ifndef  CPX_PROTOTYPE_ANSI
#ifndef  CPX_PROTOTYPE_CKR
/* The following will cause a compilation to die */
You must define a SYStem in order to compile a CPLEX application
#endif
#endif

/* Argument checking enabled */

#ifdef  CPX_PROTOTYPE_ANSI

/* advance.c */

int
   CPXgetbhead     (CPXENVptr env, CPXLPptr lp, int *head,
                    double *x),
   CPXbinvcol      (CPXENVptr env, CPXLPptr lp, int j, double *x),
   CPXbinvrow      (CPXENVptr env, CPXLPptr lp, int i, double *y),
   CPXbinvacol     (CPXENVptr env, CPXLPptr lp, int j, double *x),
   CPXbinvarow     (CPXENVptr env, CPXLPptr lp, int i, double *z),
   CPXftran        (CPXENVptr env, CPXLPptr lp, double *x),
   CPXbtran        (CPXENVptr env, CPXLPptr lp, double *y),
   CPXgetijrow     (CPXENVptr env, CPXLPptr lp, int i, int j,
                    int *row),
   CPXgetweight    (CPXENVptr env, CPXLPptr lp, int rcnt,
                    int *rmatbeg, int *rmatind, double *rmatval,
                    double *weight, int dpriind),
   CPXstrongbranch (CPXENVptr env, CPXLPptr lp, int *goodlist,
                    int goodlen, double *downpen, double *uppen,
                    int itlim);

/* callback.c */

int
   CPXsetlpcallbackfunc  (CPXENVptr env, int (*callback)(CPXENVptr,
                          CPXLPptr, int)),
   CPXsetmipcallbackfunc (CPXENVptr env, int (*callback)(CPXENVptr,
                          CPXLPptr, int)),
   CPXgetcallbackinfo    (CPXENVptr env, CPXLPptr lpinfo,
                          int wherefrom, int whichinfo,
                          void *result_p);

void
   CPXgetlpcallbackfunc  (CPXENVptr env,
                          int (**callback_p)(CPXENVptr,
                          CPXLPptr, int)),
   CPXgetmipcallbackfunc (CPXENVptr env,
                          int (**callback_p)(CPXENVptr,
                          CPXLPptr, int));

/* check.c */

int
   CPXcheckprob     (CPXENVptr env, char *probname,
                     int numcols, int numrows, int numrims,
                     int objsen, double *obj, double *rhs,
                     char *sense, int *matbeg, int *matcnt,
                     int *matind, double *matval,
                     double *lb, double *ub, double *rngval,
                     int *freerowind, int *rimtype, int *rimbeg,
                     int *rimcnt, int *rimind, double *rimval,
                     char *dataname, char *objname,
                     char *rhsname, char *rngname, char *bndname,
                     char **colname, char *colnamestore,
                     char **rowname, char *rownamestore,
                     char **rimname, char *rimnamestore,
                     int colspace, int rowspace, int nzspace,
                     int rimspace, int rimnzspace,
                     unsigned colnamespace, unsigned rownamespace,
                     unsigned rimnamespace, char *ctype),
   CPXchecklp       (CPXENVptr env, char *probname,
                     int numcols, int numrows,
                     int objsen, double *obj, double *rhs,
                     char *sense, int *matbeg, int *matcnt,
                     int *matind, double *matval,
                     double *lb, double *ub, double *rngval,
                     int colspace, int rowspace, int nzspace),
   CPXchecklpwnames (CPXENVptr env, char *probname,
                     int numcols, int numrows,
                     int objsen, double *obj, double *rhs,
                     char *sense, int *matbeg, int *matcnt,
                     int *matind, double *matval,
                     double *lb, double *ub, double *rngval,
                     char **colname, char *colnamestore,
                     char **rowname, char *rownamestore,
                     int colspace, int rowspace, int nzspace,
                     unsigned colnamespace, unsigned rownamespace),
   CPXcheckqsep     (CPXENVptr env, CPXLPptr lp, double *qsepvec),
   CPXcheckquad     (CPXENVptr env, CPXLPptr lp, int *qmatbeg,
                     int *qmatcnt, int *qmatind, double *qmatval,
                     int qnzspace);

/* cpxuset.c */

int
   CPXsetlogfile (CPXENVptr env, FILE *lfile),
   CPXgetlogfile (CPXENVptr env, FILE **logfile_p);

/* dualopt.c */

int
   CPXdualopt  (CPXENVptr env, CPXLPptr lp),
   CPXmdualopt (CPXENVptr env, CPXLPptr lp, int *goodlist,
                int *goodlen, double *downpen, double *uppen);

/* env.c */

CPXENVptr
   CPXopenCPLEX        (int *status_p),
   CPXparenv           (CPXENVptr env, int *status_p);

int
   CPXfreeparenv       (CPXENVptr env, CPXENVptr *child_p),
   CPXcloseCPLEX       (CPXENVptr *env_p),
   CPXgetchannels      (CPXENVptr env, CPXCHANNELptr *cpxresults_p,
                        CPXCHANNELptr *cpxwarning_p,
                        CPXCHANNELptr *cpxerror_p,
                        CPXCHANNELptr *cpxlog_p),
   CPXflushstdchannels (CPXENVptr env);

/* error.c */

char *
   CPXgeterrorstring (CPXENVptr env, int errcode, char *buffer);

/* fchange.c */

int
   CPXchgfromfreerow (CPXENVptr env, CPXLPptr lp, int cnt,
                      int *index, char *sense, double *rhs,
                      int *rowmap),
   CPXchgtofreerow   (CPXENVptr env, CPXLPptr lp, int cnt,
                      int *index, int *rowmap),
   CPXchgfreecoef    (CPXENVptr env, CPXLPptr lp, int i, int j,
                      double newvalue);

/* findiis.c */

int
   CPXgetiis     (CPXENVptr env, CPXLPptr lp, int *iisstat_p,
                  int *rowind, int *rowbdstat, int *iisnumrows_p,
                  int *colind, int *colbdstat, int *iisnumcols_p),
   CPXfindiis    (CPXENVptr env, CPXLPptr lp, int *iisnumrows_p,
                  int *iisnumcols_p),
   CPXdisplayiis (CPXENVptr env, CPXLPptr lp, CPXCHANNELptr channel,
                  int display),
   CPXiiswrite   (CPXENVptr env, CPXLPptr lp, char *filename);

/* load.c */

CPXLPptr
   CPXloadprob     (CPXENVptr env, char *probname,
                    int numcols, int numrows, int numrims,
                    int objsen, double *obj, double *rhs,
                    char *sense, int *matbeg, int *matcnt,
                    int *matind, double *matval,
                    double *lb, double *ub, double *rngval,
                    int *freerowind, int *rimtype, int *rimbeg,
                    int *rimcnt, int *rimind, double *rimval,
                    char *dataname, char *objname,
                    char *rhsname, char *rngname, char *bndname,
                    char **colname, char *colnamestore,
                    char **rowname, char *rownamestore,
                    char **rimname, char *rimnamestore,
                    int colspace, int rowspace, int nzspace,
                    int rimspace, int rimnzspace,
                    unsigned colnamespace, unsigned rownamespace,
                    unsigned rimnamespace),
   CPXloadlp       (CPXENVptr env, char *probname,
                    int numcols, int numrows,
                    int objsen, double *obj, double *rhs,
                    char *sense, int *matbeg, int *matcnt,
                    int *matind, double *matval,
                    double *lb, double *ub, double *rngval,
                    int colspace, int rowspace, int nzspace),
   CPXloadlpwnames (CPXENVptr env, char *probname,
                    int numcols, int numrows,
                    int objsen, double *obj, double *rhs,
                    char *sense, int *matbeg, int *matcnt,
                    int *matind, double *matval,
                    double *lb, double *ub, double *rngval,
                    char **colname, char *colnamestore,
                    char **rowname, char *rownamestore,
                    int colspace, int rowspace, int nzspace,
                    unsigned colnamespace, unsigned rownamespace);

int
   CPXreallocprob (CPXENVptr env, CPXLPptr lp, double **obj_p,
                   double **rhs_p, char **sense_p, int **matbeg_p,
                   int **matcnt_p, int **matind_p, double **matval_p,
                   double **lb_p, double **ub_p, double **rngval_p,
                   char ***colname_p, char **colnamestore_p,
                   char ***rowname_p, char **rownamestore_p,
                   char **ctype_p,
                   int colspace, int rowspace, int nzspace,
                   unsigned colnamespace, unsigned rownamespace),
   CPXunscaleprob (CPXENVptr env, CPXLPptr lp),
   CPXunloadprob  (CPXENVptr env, CPXLPptr *lp_p),
   CPXfreeprob    (CPXENVptr env, CPXLPptr *lp_p);

/* lpread.c */

int
   CPXlpread  (CPXENVptr env, char *filename,
               int *numcols_p, int *numrows_p,
               int *objsen_p, double **obj_p, double **rhs_p,
               char **sense_p, int **matbeg_p, int **matcnt_p,
               int **matind_p, double **matval_p,
               double **lb_p, double **ub_p,
               char **objname_p, char **rhsname_p,
               char ***colname_p, char **colnamestore_p,
               char ***rowname_p, char **rownamestore_p,
               int *colspace_p, int *rowspace_p, int *nzspace_p,
               unsigned *colnamespace_p, unsigned *rownamespace_p),
   CPXlpmread (CPXENVptr env, char *filename,
               int *numcols_p, int *numrows_p,
               int *objsen_p, double **obj_p, double **rhs_p,
               char **sense_p, int **matbeg_p, int **matcnt_p,
               int **matind_p, double **matval_p,
               double **lb_p, double **ub_p,
               char **objname_p, char **rhsname_p,
               char ***colname_p, char **colnamestore_p,
               char ***rowname_p, char **rownamestore_p,
               int *colspace_p, int *rowspace_p, int *nzspace_p,
               unsigned *colnamespace_p, unsigned *rownamespace_p,
               char **ctype_p),
   CPXlpqread (CPXENVptr env, char *filename,
               int *numcols_p, int *numrows_p,
               int *objsen_p, double **obj_p, double **rhs_p,
               char **sense_p, int **matbeg_p, int **matcnt_p,
               int **matind_p, double **matval_p,
               double **lb_p, double **ub_p,
               char **objname_p, char **rhsname_p,
               char ***colname_p, char **colnamestore_p,
               char ***rowname_p, char **rownamestore_p,
               int *colspace_p, int *rowspace_p, int *nzspace_p,
               unsigned *colnamespace_p, unsigned *rownamespace_p,
               char **ctype_p,
               int **qmatbeg_p, int **qmatcnt_p, int **qmatind_p,
               double **qmatval_p, int *qnzspace_p);

/* lpwrite.c */

int
   CPXlpwrite   (CPXENVptr env, CPXLPptr lp, char *filename),
   CPXlprewrite (CPXENVptr env, CPXLPptr lp, char *filename);

/* mbaserw.c */

int
   CPXmbaseread  (CPXENVptr env, char *filename,
                  int numcols, int numrows,
                  char **colname, char **rowname,
                  int *cstat, int *rstat),
   CPXmbasewrite (CPXENVptr env, CPXLPptr lp, char *filename),
   CPXvecread    (CPXENVptr env, CPXLPptr lp, char *filename),
   CPXvecwrite   (CPXENVptr env, CPXLPptr lp, char *filename);

/* message.c */

CPXCHANNELptr
   CPXaddchannel        (CPXENVptr env);

int
   CPXaddfpdest         (CPXENVptr env, CPXCHANNELptr channel,
                         FILE *fileptr),
   CPXdelfpdest         (CPXENVptr env, CPXCHANNELptr channel,
                         FILE *fileptr),
   CPXaddfuncdest       (CPXENVptr env, CPXCHANNELptr channel,
                         void *handle,
                         void (*msgfunction)(void *, char *)),
   CPXdelfuncdest       (CPXENVptr env, CPXCHANNELptr channel,
                         void *handle,
                         void (*msgfunction)(void *, char *)),
   CPXmsg               (CPXCHANNELptr channel, char *format, ...);

void
   CPXdelchannel        (CPXENVptr env, CPXCHANNELptr *channel_p),
   CPXdisconnectchannel (CPXENVptr env, CPXCHANNELptr channel),
   CPXflushchannel      (CPXENVptr env, CPXCHANNELptr channel);

/* mpsread.c */

int
   CPXmpsread  (CPXENVptr env, char *filename,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p),
   CPXmpsmread (CPXENVptr env, char *filename,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p,
                char **ctype_p, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sosbeg_p, int **sosind_p,
                double **sosref_p),
   CPXmpsqread (CPXENVptr env, char *filename,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p,
                char **ctype_p, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sosbeg_p, int **sosind_p,
                double **sosref_p,
                int **qmatbeg_p, int **qmatcnt_p, int **qmatind_p,
                double **qmatval_p, int *qnzspace_p);

/* mpsrevis.c */

int
   CPXmpsrevise (CPXENVptr env, CPXLPptr lp, char *filename);

/* mpswrite.c */

int
   CPXmpswrite   (CPXENVptr env, CPXLPptr lp, char *filename),
   CPXmpsrewrite (CPXENVptr env, CPXLPptr lp, char *filename),
   CPXdualwrite  (CPXENVptr env, CPXLPptr lp, char *filename,
                  double *objshift_p);

/* netmain.c */

int
   CPXhybnetopt (CPXENVptr env, CPXLPptr lp, char method),
   CPXnetopt    (CPXENVptr env, CPXLPptr lp, int *netstatus_p,
                 int *numnodes_p, int *numarcs_p, int *itcnt_p),
   CPXembwrite  (CPXENVptr env, CPXLPptr lp, char *filename);

/* oddutil.c */

int
   CPXloadbase   (CPXENVptr env, CPXLPptr lp, int *cstat,
                  int *rstat),
   CPXloadstart  (CPXENVptr env, CPXLPptr lp, int *cstat,
                  int *rstat, double *cprim, double *rprim,
                  double *cdual, double *rdual),
   CPXloaddnorms (CPXENVptr env, CPXLPptr lp, double *norm,
                  int *head, int len),
   CPXloadpnorms (CPXENVptr env, CPXLPptr lp, double *cnorm,
                  double *rnorm, int len),
   CPXgetspace   (CPXENVptr env, CPXLPptr lp, int *colspace_p,
                  int *rowspace_p, int *nzspace_p,
                  unsigned *colnamespace_p,
                  unsigned *rownamespace_p);

/* opt.c */

int
   CPXoptimize (CPXENVptr env, CPXLPptr lp);

/* otherrw.c */

int
   CPXnetread   (CPXENVptr env, char *filename,
                 int *numcols_p, int *numrows_p,
                 int *objsen_p, double **obj_p, double **rhs_p,
                 char **sense_p, int **matbeg_p, int **matcnt_p,
                 int **matind_p, double **matval_p,
                 double **lb_p, double **ub_p,
                 int *colspace_p, int *rowspace_p, int *nzspace_p),
   CPXparread   (CPXENVptr env, char *filename,
                 int *numcols_p, int *numrows_p,
                 int *objsen_p, double **obj_p, double **rhs_p,
                 char **sense_p, int **matbeg_p, int **matcnt_p,
                 int **matind_p, double **matval_p,
                 double **lb_p, double **ub_p,
                 int *colspace_p, int *rowspace_p, int *nzspace_p,
                 char **ctype_p),
   CPXpperwrite (CPXENVptr env, CPXLPptr lp, char *filename,
                 double epsilon),
   CPXdperwrite (CPXENVptr env, CPXLPptr lp, char *filename,
                 double epsilon);

/* pivotin.c */

int
   CPXpivotin (CPXENVptr env, CPXLPptr lp, int *rlist, int rlen);

/* preutil.c */

int
   CPXpreslvwrite    (CPXENVptr env, CPXLPptr lp, char *filename),
   CPXobjpreslvwrite (CPXENVptr env, CPXLPptr lp, char *filename, 
                      double *objoff_p);

/* quality.c */

double
   CPXcheckax  (CPXENVptr env, CPXLPptr lp, int *imax_p,
                int scalrimtype),
   CPXcheckpib (CPXENVptr env, CPXLPptr lp, int *ijmax_p,
                int scalrimtype);

/* query.c */

double
   CPXgetkappa        (CPXENVptr env, CPXLPptr lp);

int
   CPXgetnumcols      (CPXENVptr env, CPXLPptr lp),
   CPXgetnumrows      (CPXENVptr env, CPXLPptr lp),
   CPXgetnumnz        (CPXENVptr env, CPXLPptr lp),
   CPXgetnumrims      (CPXENVptr env, CPXLPptr lp),
   CPXgetnumfreerows  (CPXENVptr env, CPXLPptr lp),
   CPXgetnumfreerownz (CPXENVptr env, CPXLPptr lp),
   CPXgetnumrimnz     (CPXENVptr env, CPXLPptr lp),
   CPXgetobjsen       (CPXENVptr env, CPXLPptr lp),
   CPXgetobj          (CPXENVptr env, CPXLPptr lp, double *obj,
                       int begin, int end),
   CPXgetrhs          (CPXENVptr env, CPXLPptr lp, double *rhs,
                       int begin, int end),
   CPXgetsense        (CPXENVptr env, CPXLPptr lp, char *sense,
                       int begin, int end),
   CPXgetcols         (CPXENVptr env, CPXLPptr lp, int *nzcnt_p,
                       int *cmatbeg, int *cmatind, double *cmatval,
                       int cmatspace, int *surplus_p,
                       int begin, int end),
   CPXgetrows         (CPXENVptr env, CPXLPptr lp, int *nzcnt_p,
                       int *rmatbeg, int *rmatind, double *rmatval,
                       int rmatspace, int *surplus_p,
                       int begin, int end),
   CPXgetfreerows     (CPXENVptr env, CPXLPptr lp, int *nzcnt_p,
                       int *rmatbeg, int *rmatind, double *rmatval,
                       int rmatspace, int *surplus_p,
                       int begin, int end),
   CPXgetrims         (CPXENVptr env, CPXLPptr lp, int *nzcnt_p,
                       int *rimmatbeg, int *rimmatind,
                       double *rimmatval, int rimmatspace,
                       int *surplus_p, int begin, int end),
   CPXgetlb           (CPXENVptr env, CPXLPptr lp, double *lb,
                       int begin, int end),
   CPXgetub           (CPXENVptr env, CPXLPptr lp, double *ub,
                       int begin, int end),
   CPXgetrngval       (CPXENVptr env, CPXLPptr lp, double *rngval,
                       int begin, int end),
   CPXgetfreerowind   (CPXENVptr env, CPXLPptr lp, int *freerowind,
                       int begin, int end),
   CPXgetrimtype      (CPXENVptr env, CPXLPptr lp, int *rimtype,
                       int begin, int end),
   CPXgetprobname     (CPXENVptr env, CPXLPptr lp, char *buf),
   CPXgetdataname     (CPXENVptr env, CPXLPptr lp, char *buf),
   CPXgetobjname      (CPXENVptr env, CPXLPptr lp, char *buf),
   CPXgetrhsname      (CPXENVptr env, CPXLPptr lp, char *buf),
   CPXgetrngname      (CPXENVptr env, CPXLPptr lp, char *buf),
   CPXgetbndname      (CPXENVptr env, CPXLPptr lp, char *buf),
   CPXgetcolname      (CPXENVptr env, CPXLPptr lp, char **name,
                       char *namestore, int xnamespace,
                       int *surplus_p, int begin, int end),
   CPXgetrowname      (CPXENVptr env, CPXLPptr lp, char **name,
                       char *namestore, int xnamespace,
                       int *surplus_p, int begin, int end),
   CPXgetrimname      (CPXENVptr env, CPXLPptr lp, char **name,
                       char *namestore, int xnamespace,
                       int *surplus_p, int begin, int end),
   CPXgetcolspace     (CPXENVptr env, CPXLPptr lp),
   CPXgetrowspace     (CPXENVptr env, CPXLPptr lp),
   CPXgetnzspace      (CPXENVptr env, CPXLPptr lp),
   CPXgetrimspace     (CPXENVptr env, CPXLPptr lp),
   CPXgetrimnzspace   (CPXENVptr env, CPXLPptr lp),
   CPXgetbase         (CPXENVptr env, CPXLPptr lp, int *cstat,
                       int *rstat),
   CPXgetdnorms       (CPXENVptr env, CPXLPptr lp, double *norm,
                       int *head, int *len),
   CPXgetpnorms       (CPXENVptr env, CPXLPptr lp, double *cnorm,
                       double *rnorm, int *len),
   CPXgetitc          (CPXENVptr env, CPXLPptr lp),
   CPXgetitci         (CPXENVptr env, CPXLPptr lp),
   CPXgetgrad         (CPXENVptr env, CPXLPptr lp, int j, int *ix,
                       double *y),
   CPXgetcoef         (CPXENVptr env, CPXLPptr lp, int i, int j,
                       double *coef_p),
   CPXgetsbcnt        (CPXENVptr env, CPXLPptr lp),
   CPXgetijdiv        (CPXENVptr env, CPXLPptr lp, int *idiv_p,
                       int *jdiv_p),
   CPXgetrowindex     (CPXENVptr env, CPXLPptr lp, char *lname,
                       int *index_p),
   CPXgetcolindex     (CPXENVptr env, CPXLPptr lp, char *lname,
                       int *index_p),
   CPXgetstat         (CPXENVptr env, CPXLPptr lp),
   CPXgetprobtype     (CPXENVptr env, CPXLPptr lp);

unsigned
   CPXgetcolnamespace (CPXENVptr env, CPXLPptr lp),
   CPXgetrownamespace (CPXENVptr env, CPXLPptr lp),
   CPXgetrimnamespace (CPXENVptr env, CPXLPptr lp);

/* readutil.c */

int
   CPXreadloadbase  (CPXENVptr env, CPXLPptr lp, char *filename),
   CPXreadloadorder (CPXENVptr env, CPXLPptr lp, char *filename),
   CPXreadloadsos   (CPXENVptr env, CPXLPptr lp, char *filename),
   CPXreadloadqp    (CPXENVptr env, CPXLPptr lp, char *filename,
                     int **qmatbeg_p, int **qmatcnt_p,
                     int **qmatind_p, double **qmatval_p,
                     int *qnzspace_p);

/* savread.c */

int
   CPXsavread  (CPXENVptr env, char *filename,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p, int **cstat_p,
                int **rstat_p),
   CPXsavmread (CPXENVptr env, char *filename,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p,
                char **ctype_p, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sospri_p, int **sosbeg_p,
                int **sosind_p, double **sosref,
                int **cstat_p, int **rstat_p),
   CPXsavqread (CPXENVptr env, char *filename,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p,
                char **ctype_p, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sospri_p, int **sosbeg_p,
                int **sosind_p, double **sosref_p,
                int **qmatbeg_p, int **qmatcnt_p, int **qmatind_p,
                double **qmatval_p, int *qnzspace_p,
                int **cstat_p, int **rstat_p);

/* savwrite.c */

int
   CPXsavwrite (CPXENVptr env, CPXLPptr lp, char *filename);

/* sensit.c */

int
   CPXrhssa (CPXENVptr env, CPXLPptr lp, int begin, int end,
             double *lower, double *upper),
   CPXobjsa (CPXENVptr env, CPXLPptr lp, int begin, int end,
             double *lower, double *upper);

/* solution.c */

int
   CPXsolution  (CPXENVptr env, CPXLPptr lp, int *lpstat_p,
                 double *objval_p, double *x, double *pi,
                 double *slack, double *dj),
   CPXgetobjval (CPXENVptr env, CPXLPptr lp, double *objval_p),
   CPXgetx      (CPXENVptr env, CPXLPptr lp, double *x,
                 int begin, int end),
   CPXgetpi     (CPXENVptr env, CPXLPptr lp, double *pi,
                 int begin, int end),
   CPXgetslack  (CPXENVptr env, CPXLPptr lp, double *slack,
                 int begin, int end),
   CPXgetdj     (CPXENVptr env, CPXLPptr lp, double *dj,
                 int begin, int end),
   CPXgetmethod (CPXENVptr env, CPXLPptr lp);

/* solwrite.c */

int
   CPXbinsolwrite (CPXENVptr env, CPXLPptr lp, char *filename),
   CPXtxtsolwrite (CPXENVptr env, CPXLPptr lp, char *filename),
   CPXsolwrite    (CPXENVptr env, CPXLPptr lp,
                   void (*hsection) (CPXENVptr, CPXLPptr, void *),
                   void (*rsectionbeg) (void *),
                   void (*csectionbeg) (void *),
                   void (*write_entry) (void *, char, int, char *,
                                        char *, double, double,
                                        double, double, double),
                   void (*sectionend) (void *), void *info);

/* uchange.c */

int
   CPXaddrows    (CPXENVptr env, CPXLPptr lp, int ccnt, int rcnt,
                  int nzcnt, double *rhs, char *sense, int *rmatbeg,
                  int *rmatind, double *rmatval, char **colname,
                  char **rowname),
   CPXfaddrows   (CPXENVptr env, CPXLPptr lp, int ccnt, int rcnt,
                  int nzcnt, double *rhs, char *sense, int *rmatbeg,
                  int *rmatind, double *rmatval, char **colname,
                  char **rowname),
   CPXdelrows    (CPXENVptr env, CPXLPptr lp, int begin, int end),
   CPXdelsetrows (CPXENVptr env, CPXLPptr lp, int *delstat),
   CPXaddcols    (CPXENVptr env, CPXLPptr lp, int ccnt, int nzcnt,
                  double *obj, int *cmatbeg, int *cmatind,
                  double *cmatval, double *lb, double *ub,
                  char **colname),
   CPXdelcols    (CPXENVptr env, CPXLPptr lp, int begin, int end),
   CPXdelsetcols (CPXENVptr env, CPXLPptr lp, int *delstat),
   CPXchgname    (CPXENVptr env, CPXLPptr lp, char key, int index,
                  char *newname),
   CPXchgcoef    (CPXENVptr env, CPXLPptr lp, int i, int j,
                  double newvalue),
   CPXchgbds     (CPXENVptr env, CPXLPptr lp, int cnt, int *index,
                  char *lu, double *bd),
   CPXchgobj     (CPXENVptr env, CPXLPptr lp, int cnt, int *index,
                  double *values),
   CPXchgrhs     (CPXENVptr env, CPXLPptr lp, int cnt, int *index,
                  double *values),
   CPXchgsense   (CPXENVptr env, CPXLPptr lp, int cnt, int *index,
                  char *sense);

void
   CPXchgobjsen  (CPXENVptr env, CPXLPptr lp, int maxormin);

/* uset.c */

int
   CPXsetdefaults  (CPXENVptr env),
   CPXsetintparam  (CPXENVptr env, int whichparam, int newvalue),
   CPXsetdblparam  (CPXENVptr env, int whichparam, double newvalue),
   CPXgetintparam  (CPXENVptr env, int whichparam, int *value_p),
   CPXgetdblparam  (CPXENVptr env, int whichparam, double *value_p),
   CPXinfointparam (CPXENVptr env, int whichparam, int *defvalue_p,
                    int *minvalue_p, int *maxvalue_p),
   CPXinfodblparam (CPXENVptr env, int whichparam,
                    double *defvalue_p, double *minvalue_p,
                    double *maxvalue_p);

#else

/* advance.c */

int
   CPXgetbhead     (),
   CPXbinvcol      (),
   CPXbinvrow      (),
   CPXbinvacol     (),
   CPXbinvarow     (),
   CPXftran        (),
   CPXbtran        (),
   CPXgetijrow     (),
   CPXgetweight    (),
   CPXstrongbranch ();

/* callback.c */

int
   CPXsetlpcallbackfunc  (),
   CPXsetmipcallbackfunc (),
   CPXgetcallbackinfo    ();

void
   CPXgetlpcallbackfunc  (),
   CPXgetmipcallbackfunc ();

/* check.c */

int
   CPXcheckprob     (),
   CPXchecklp       (),
   CPXchecklpwnames (),
   CPXcheckqsep     (),
   CPXcheckquad     ();

/* cpxuset.c */

int
   CPXsetlogfile (),
   CPXgetlogfile ();

/* dualopt.c */

int
   CPXdualopt  (),
   CPXmdualopt ();

/* env.c */

CPXENVptr
   CPXopenCPLEX        (),
   CPXparenv           ();

int
   CPXfreeparenv       (),
   CPXcloseCPLEX       (),
   CPXgetchannels      (),
   CPXflushstdchannels ();

/* error.c */

char *
   CPXgeterrorstring ();

/* fchange.c */

int
   CPXchgfromfreerow (),
   CPXchgtofreerow   (),
   CPXchgfreecoef    ();

/* findiis.c */

int
   CPXgetiis     (),
   CPXfindiis    (),
   CPXdisplayiis (),
   CPXiiswrite   ();

/* load.c */

CPXLPptr
   CPXloadprob     (),
   CPXloadlp       (),
   CPXloadlpwnames ();

int
   CPXreallocprob  (),
   CPXunscaleprob  (),
   CPXunloadprob   (),
   CPXfreeprob     ();

/* lpread.c */

int
   CPXlpread  (),
   CPXlpmread (),
   CPXlpqread ();

/* lpwrite.c */

int
   CPXlpwrite   (),
   CPXlprewrite ();

/* mbaserw.c */

int
   CPXmbaseread  (),
   CPXmbasewrite (),
   CPXvecread    (),
   CPXvecwrite   ();

/* message.c */

CPXCHANNELptr
   CPXaddchannel        ();

int
   CPXaddfpdest         (),
   CPXdelfpdest         (),
   CPXaddfuncdest       (),
   CPXdelfuncdest       (),
   CPXmsg               ();

void
   CPXdelchannel        (),
   CPXdisconnectchannel (),
   CPXflushchannel      ();

/* mpsread.c */

int
   CPXmpsread  (),
   CPXmpsmread (),
   CPXmpsqread ();

/* mpsrevis.c */

int
   CPXmpsrevise ();

/* mpswrite.c */

int
   CPXmpswrite   (),
   CPXmpsrewrite (),
   CPXdualwrite  ();

/* netmain.c */

int
   CPXhybnetopt (),
   CPXnetopt    (),
   CPXembwrite  ();

/* oddutil.c */

int
   CPXloadbase   (),
   CPXloadstart  (),
   CPXloaddnorms (),
   CPXloadpnorms (),
   CPXgetspace   ();

/* opt.c */

int
   CPXoptimize ();

/* otherrw.c */

int
   CPXnetread   (),
   CPXparread   (),
   CPXpperwrite (),
   CPXdperwrite ();

/* pivotin.c */

int
   CPXpivotin ();

/* preutil.c */

int
   CPXpreslvwrite    (),
   CPXobjpreslvwrite ();

/* quality.c */

double
   CPXcheckax  (),
   CPXcheckpib ();

/* query.c */

double
   CPXgetkappa        ();

int
   CPXgetnumcols      (),
   CPXgetnumrows      (),
   CPXgetnumnz        (),
   CPXgetnumrims      (),
   CPXgetnumfreerows  (),
   CPXgetnumfreerownz (),
   CPXgetnumrimnz     (),
   CPXgetobjsen       (),
   CPXgetobj          (),
   CPXgetrhs          (),
   CPXgetsense        (),
   CPXgetcols         (),
   CPXgetrows         (),
   CPXgetfreerows     (),
   CPXgetrims         (),
   CPXgetlb           (),
   CPXgetub           (),
   CPXgetrngval       (),
   CPXgetfreerowind   (),
   CPXgetrimtype      (),
   CPXgetprobname     (),
   CPXgetdataname     (),
   CPXgetobjname      (),
   CPXgetrhsname      (),
   CPXgetrngname      (),
   CPXgetbndname      (),
   CPXgetcolname      (),
   CPXgetrowname      (),
   CPXgetrimname      (),
   CPXgetcolspace     (),
   CPXgetrowspace     (),
   CPXgetnzspace      (),
   CPXgetrimspace     (),
   CPXgetrimnzspace   (),
   CPXgetbase         (),
   CPXgetdnorms       (),
   CPXgetpnorms       (),
   CPXgetitc          (),
   CPXgetitci         (),
   CPXgetgrad         (),
   CPXgetcoef         (),
   CPXgetsbcnt        (),
   CPXgetijdiv        (),
   CPXgetrowindex     (),
   CPXgetcolindex     (),
   CPXgetstat         (),
   CPXgetprobtype     ();

unsigned
   CPXgetcolnamespace (),
   CPXgetrownamespace (),
   CPXgetrimnamespace ();

/* readutil.c */

int
   CPXreadloadbase  (),
   CPXreadloadorder (),
   CPXreadloadsos   (),
   CPXreadloadqp    ();

/* savread.c */

int
   CPXsavread  (),
   CPXsavmread (),
   CPXsavqread ();

/* savwrite.c */

int
   CPXsavwrite ();

/* sensit.c */

int
   CPXrhssa (),
   CPXobjsa ();

/* solution.c */

int
   CPXsolution  (),
   CPXgetobjval (),
   CPXgetx      (),
   CPXgetpi     (),
   CPXgetslack  (),
   CPXgetdj     (),
   CPXgetmethod ();

/* solwrite.c */

int
   CPXbinsolwrite (),
   CPXtxtsolwrite (),
   CPXsolwrite    ();

/* uchange.c */

int
   CPXaddrows    (),
   CPXfaddrows   (),
   CPXdelrows    (),
   CPXdelsetrows (),
   CPXaddcols    (),
   CPXdelcols    (),
   CPXdelsetcols (),
   CPXchgname    (),
   CPXchgcoef    (),
   CPXchgbds     (),
   CPXchgobj     (),
   CPXchgrhs     (),
   CPXchgsense   ();

void
   CPXchgobjsen  ();

/* uset.c */

int
   CPXsetdefaults  (),
   CPXsetintparam  (),
   CPXsetdblparam  (),
   CPXgetintparam  (),
   CPXgetdblparam  (),
   CPXinfointparam (),
   CPXinfodblparam ();

#endif

#endif /* __CPXDEFS_H */

/*******************************************************************/
/*  BARDEFS.h                                                      */
/*  Version 4.0                                                    */
/*                                                                 */
/*  Copyright (c) 1993-1995                                        */
/*  CPLEX Optimization, Inc.                                       */
/*  All Rights Reserved                                            */
/*                                                                 */
/*  Last modified  6 December 1995, IJL                            */
/*******************************************************************/

#ifndef __BARDEFS_H
#define __BARDEFS_H

/* Has defines for external functions and constants.
   Is equivalent to things that are in cpxdefs.h */

#define CPX_PRIM_INFEAS                  32
#define CPX_DUAL_INFEAS                  33
#define CPX_PRIM_DUAL_INFEAS             34
#define CPX_PRIM_OBJ_LIM                 35
#define CPX_DUAL_OBJ_LIM                 36
#define CPX_OPTIMAL_FACE_UNBOUNDED       37
#define CPX_NUM_BEST_PRIM_DUAL_FEAS      38
#define CPX_NUM_BEST_PRIM_INFEAS         39
#define CPX_NUM_BEST_DUAL_INFEAS         40
#define CPX_NUM_BEST_PRIM_DUAL_INFEAS    41
#define CPX_BARRIER_NUM_ERROR            42

#define CPXERR_BARRIER_NUMERICAL       4001
#define CPXERR_BARRIER_AUGSCHUR        4003
#define CPXERR_BARRIER_NO_MEMORY       4004

/* Barrier parameters */

#define CPX_PARAM_BARDSTART            3001
#define CPX_PARAM_BAREPCOMP            3002
#define CPX_PARAM_BARGROWTH            3003
#define CPX_PARAM_BAROBJRNG            3004
#define CPX_PARAM_BARPSTART            3005
#define CPX_PARAM_BARVARUP             3006
#define CPX_PARAM_BARALG               3007
#define CPX_PARAM_BARUNROLL            3008
#define CPX_PARAM_BARCOLNZ             3009
#define CPX_PARAM_BARDISPLAY           3010
#define CPX_PARAM_BARFACTOR            3011
#define CPX_PARAM_BARITLIM             3012
#define CPX_PARAM_BARMAXCOR            3013
#define CPX_PARAM_BARORDER             3014
#define CPX_PARAM_BARROWSDEN           3015
#define CPX_PARAM_BARTHREADS           3016

#ifdef  CPX_PROTOTYPE_ANSI

/* baruset.c */

int
   CPXsetorderhookfunc (CPXENVptr env,
                        int (*orderhook)(CPXENVptr, int, int *,
                        int *, int *));
void
   CPXgetorderhookfunc (CPXENVptr env,
                        int (**orderhook_p)(CPXENVptr, int, int *,
                        int *, int *));

/* hybopt.c */

int
   CPXhybbaropt (CPXENVptr env, CPXLPptr lp, char method),
   CPXbaropt    (CPXENVptr env, CPXLPptr lp);

#else

/* baruset.c */

int
   CPXsetorderhookfunc ();

void
   CPXgetorderhookfunc ();

/* hybopt.c */

int
   CPXhybbaropt (),
   CPXbaropt    ();

#endif

#endif  /* __BARDEFS_H */

/*******************************************************************/
/*  MIPDEFS.h                                                      */
/*  Version 4.0                                                    */
/*                                                                 */
/*  Copyright (c) 1989-1995                                        */
/*  CPLEX Optimization, Inc.                                       */
/*  All Rights Reserved                                            */
/*                                                                 */
/*  Last modified  9 February 1996, REB                            */
/*******************************************************************/

#ifndef __MIPDEFS_H
#define __MIPDEFS_H

/* MIP error codes */

#define  CPXERR_ALREADY_CTYPE          3001
#define  CPXERR_BOUNDS_BINARY          3002
#define  CPXERR_NOT_MIP                3003
#define  CPXERR_SOS_BDS                3004
#define  CPXERR_ORDER_ARRAY_ENTRY      3005
#define  CPXERR_BAD_PRIORITY           3006
#define  CPXERR_ORDER_BAD_DIRECTION    3007
#define  CPXERR_SOSIND_ARRAY_ENTRY     3008
#define  CPXERR_ARRAY_BAD_SOS_TYPE     3009
#define  CPXERR_UNIQUE_WEIGHTS         3010
#define  CPXERR_BOUNDS_INT             3011
#define  CPXERR_BAD_DIRECTION          3012
#define  CPXERR_NO_CTYPE               3014
#define  CPXERR_NO_SOS                 3015
#define  CPXERR_NO_ORDER               3016
#define  CPXERR_NO_INT_SOLUTION        3017
#define  CPXERR_INT_TOO_BIG            3018

#define  CPXERR_CLONE_NOLOAD           3101

#define  CPXERR_MISS_SOS_TYPE          3301

#define  CPXERR_TRE_FILE_DATA          3401
#define  CPXERR_TRE_FILE_WRITE         3402
#define  CPXERR_TRE_FILE_VERSION       3403
#define  CPXERR_TRE_FILE_OBJ           3404
#define  CPXERR_TRE_FILE_COLUMNS       3405
#define  CPXERR_TRE_FILE_ROWS          3406
#define  CPXERR_TRE_FILE_INTS          3407
#define  CPXERR_TRE_FILE_NONZ          3408
#define  CPXERR_TRE_FILE_TYPES         3409
#define  CPXERR_TRE_FILE_PRESOLVE      3410
#define  CPXERR_TRE_FILE_MATCH         3411
#define  CPXERR_NO_TREE                3412
#define  CPXERR_TREE_MEMORY_LIMIT      3413
#define  CPXERR_TRE_FILE_FORMAT        3414

#define  CPXERR_NODE_FILE_OPEN         3501
#define  CPXERR_NODE_FILE_READ         3502
#define  CPXERR_NODE_FILE_WRITE        3503

/* Values for sostype and branch type */

#define CPX_TYPE_VAR                    '0'
#define CPX_TYPE_SOS1                   '1'
#define CPX_TYPE_SOS2                   '2'
#define CPX_TYPE_SOS3                   '3'
#define CPX_TYPE_USER                   'X'

/* Variable selection codes */

#define  CPX_VARSEL_MININFEAS            -1
#define  CPX_VARSEL_DEFAULT               0
#define  CPX_VARSEL_MAXINFEAS             1
#define  CPX_VARSEL_PSEUDO                2
#define  CPX_VARSEL_STRONG                3

/* Node selection codes */

#define  CPX_NODESEL_DFS                  0
#define  CPX_NODESEL_BESTBOUND            1
#define  CPX_NODESEL_BESTEST              2

/* MIP Problem status codes */

#define  CPXMIP_OPTIMAL                 101
#define  CPXMIP_OPTIMAL_TOL             102
#define  CPXMIP_INFEASIBLE              103
#define  CPXMIP_SOL_LIM                 104
#define  CPXMIP_NODE_LIM_FEAS           105
#define  CPXMIP_NODE_LIM_INFEAS         106
#define  CPXMIP_TIME_LIM_FEAS           107
#define  CPXMIP_TIME_LIM_INFEAS         108
#define  CPXMIP_FAIL_FEAS               109
#define  CPXMIP_FAIL_INFEAS             110
#define  CPXMIP_MEM_LIM_FEAS            111
#define  CPXMIP_MEM_LIM_INFEAS          112
#define  CPXMIP_ABORT_FEAS              113
#define  CPXMIP_ABORT_INFEAS            114
#define  CPXMIP_OPTIMAL_INFEAS          115
#define  CPXMIP_FAIL_FEAS_NO_TREE       116
#define  CPXMIP_FAIL_INFEAS_NO_TREE     117

/* Callback values for wherefrom */

#define  CPX_CALLBACK_MIP               101
#define  CPX_CALLBACK_MIP_BRANCH        102
#define  CPX_CALLBACK_MIP_NODE          103
#define  CPX_CALLBACK_MIP_HEURISTIC     104
#define  CPX_CALLBACK_MIP_SOLVE         105
/* Be sure to check the LP values */

/* Values for getcallbackinfo function */

#define  CPX_CBINFO_BEST_INTEGER        101
#define  CPX_CBINFO_BEST_REMAINING      102
#define  CPX_CBINFO_NODE_COUNT          103
#define  CPX_CBINFO_NODES_LEFT          104
#define  CPX_CBINFO_MIP_ITERATIONS      105
#define  CPX_CBINFO_CUTOFF              106
#define  CPX_CBINFO_CLIQUE_COUNT        107
#define  CPX_CBINFO_COVER_COUNT         108

#define  CPXgetsubprobcbinfo  CPXgetsubproblem

/* Values for getnodecbinfo function */

#define  CPX_CBINFO_NODE_SIINF          201
#define  CPX_CBINFO_NODE_NIINF          202
#define  CPX_CBINFO_NODE_ESTIMATE       203
#define  CPX_CBINFO_NODE_DEPTH          204
#define  CPX_CBINFO_NODE_OBJVAL         205
#define  CPX_CBINFO_NODE_TYPE           206
#define  CPX_CBINFO_NODE_VAR            207
#define  CPX_CBINFO_NODE_SOS            208
#define  CPX_CBINFO_NODE_SEQNUM         209

/* Values for getvarcbinfo function */

#define  CPX_CBINFO_VAR_TYPE            251
#define  CPX_CBINFO_VAR_DOWN_PSEUDO     252
#define  CPX_CBINFO_VAR_UP_PSEUDO       253
#define  CPX_CBINFO_VAR_PRIORITY        254
#define  CPX_CBINFO_VAR_DIRECTION       255
#define  CPX_CBINFO_VAR_INTEGER_VALUE   256
#define  CPX_CBINFO_VAR_IS_INT_FEASIBLE 257
#define  CPX_CBINFO_VAR_LB              258
#define  CPX_CBINFO_VAR_UB              259

/* Values for getsoscbinfo function */

#define  CPX_CBINFO_SOS_TYPE            240
#define  CPX_CBINFO_SOS_SIZE            241
#define  CPX_CBINFO_SOS_IS_FEASIBLE     242
#define  CPX_CBINFO_SOS_PRIORITY        243
#define  CPX_CBINFO_SOS_MEMBER_INDEX    244
#define  CPX_CBINFO_SOS_MEMBER_IS_COMP  245
#define  CPX_CBINFO_SOS_MEMBER_REFVAL   246
#define  CPX_CBINFO_SOS_NUM             247
/* Be sure to check the LP values */

/* Callback return codes */

#define  CPX_CALLBACK_DEFAULT             0
#define  CPX_CALLBACK_SET                 2
#define  CPX_CALLBACK_FAIL                1


/* MIP Parameter numbers */
#define CPX_PARAM_BRDIR                2001
#define CPX_PARAM_BTTOL                2002
#define CPX_PARAM_CLIQUES              2003
#define CPX_PARAM_COEREDIND            2004
#define CPX_PARAM_COVERS               2005
#define CPX_PARAM_CUTLO                2006
#define CPX_PARAM_CUTUP                2007
#define CPX_PARAM_EPAGAP               2008
#define CPX_PARAM_EPGAP                2009
#define CPX_PARAM_EPINT                2010
#define CPX_PARAM_HEURISTIC            2011
#define CPX_PARAM_MIFO                 2012  /* Old name */
#define CPX_PARAM_MIPDISPLAY           2012  /* New name */
#define CPX_PARAM_MINT                 2013  /* Old name */
#define CPX_PARAM_MIPINTERVAL          2013  /* New name */
#define CPX_PARAM_MIPTHREADS           2014
#define CPX_PARAM_MSLIM                2015  /* Old name */
#define CPX_PARAM_INTSOLLIM            2015  /* New name */
#define CPX_PARAM_NDFILIND             2016
#define CPX_PARAM_NDLIM                2017
#define CPX_PARAM_NDSEL                2018
#define CPX_PARAM_OBJDIF               2019
#define CPX_PARAM_ORDIND               2020  /* Old name */
#define CPX_PARAM_MIPORDIND            2020  /* New name */
#define CPX_PARAM_RCFIXIND             2021
#define CPX_PARAM_RELOBJDIF            2022
#define CPX_PARAM_SOSIND               2023
#define CPX_PARAM_SOSMINSZ             2024
#define CPX_PARAM_STARTALG             2025
#define CPX_PARAM_SUBALG               2026
#define CPX_PARAM_TRELIM               2027
#define CPX_PARAM_VARSEL               2028

/* Function definitions */

#ifdef  CPX_PROTOTYPE_ANSI

/* mipload.c */

CPXLPptr
   CPXloadmprob (CPXENVptr env, char *probname,
                 int numcols, int numrows, int numrims,
                 int objsen, double *obj, double *rhs,
                 char *sense, int *matbeg, int *matcnt,
                 int *matind, double *matval, double *lb,
                 double *ub, double *rngval, int *freerowind,
                 int *rimtype, int *rimbeg, int *rimcnt,
                 int *rimind, double *rimval,
                 char *dataname, char *objname, char *rhsname,
                 char *rngname, char *bndname,
                 char **colname, char *colnamestore,
                 char **rowname, char *rownamestore,
                 char **rimname, char *rimnamestore,
                 int colspace, int rowspace, int nzspace,
                 int rimspace, int rimnzspace,
                 unsigned colnamespace, unsigned rnamespace,
                 unsigned rimnamespace, char *ctype);

int
   CPXloadctype (CPXENVptr env, CPXLPptr lp, char *ctype),
   CPXloadorder (CPXENVptr env, CPXLPptr lp, int cnt,
                 int *colindex, int *priority, int *direction),
   CPXloadsos   (CPXENVptr env, CPXLPptr lp, int numsos,
                 int numsosnz, char *sostype, int *sospri,
                 int *sosbeg, int *sosind, double *sosref);

/* mipopt.c */

int
   CPXmipoptimize     (CPXENVptr env, CPXLPptr lp),
   CPXusermipoptimize (CPXENVptr env, CPXLPptr lp, void *userinfo);

/* mipordrw.c */

int
   CPXordread  (CPXENVptr env, char *filename, int numcols,
                char **colname, int *cnt_p, int *colindex,
                int *priority, int *direction),
   CPXordwrite (CPXENVptr env, CPXLPptr lp, char *filename);

/* mipquery.c */

int
   CPXgetmx      (CPXENVptr env, CPXLPptr lp, double *x,
                  int begin, int end),
   CPXgetmslack  (CPXENVptr env, CPXLPptr lp, double *slack,
                  int begin, int end),
   CPXgetmobjval (CPXENVptr env, CPXLPptr lp, double *objval_p),
   CPXgetctype   (CPXENVptr env, CPXLPptr lp, char *ctype,
                  int begin, int end),
   CPXgetintc    (CPXENVptr env, CPXLPptr lp),
   CPXgetbinc    (CPXENVptr env, CPXLPptr lp),
   CPXgetitcm    (CPXENVptr env, CPXLPptr lp),
   CPXgetbobjval (CPXENVptr env, CPXLPptr lp, double *objval_p),
   CPXgetcutoff  (CPXENVptr env, CPXLPptr lp, double *cutoff_p),
   CPXgetndc     (CPXENVptr env, CPXLPptr lp),
   CPXgetndleft  (CPXENVptr env, CPXLPptr lp),
   CPXgetndint   (CPXENVptr env, CPXLPptr lp),
   CPXgetgclqc   (CPXENVptr env, CPXLPptr lp),
   CPXgetclqc    (CPXENVptr env, CPXLPptr lp),
   CPXgetcovc    (CPXENVptr env, CPXLPptr lp);

/* mipsosrw.c */

int
   CPXsosread  (CPXENVptr env, char *filename, int numcols,
                char **colname, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sospri_p, int **sosbeg_p,
                int **sosind_p, double **sosref_p),
   CPXsoswrite (CPXENVptr env, CPXLPptr lp, char *filename);

/* miptrerw.c */

int
   CPXtreeread  (CPXENVptr env, CPXLPptr lp, char *filename),
   CPXtreewrite (CPXENVptr env, CPXLPptr lp, char *filename);

/* mipuchg.c */

int
   CPXchgctype    (CPXENVptr env, CPXLPptr lp, int cnt, int *index,
                   char *ctype),
   CPXchgprobtype (CPXENVptr env, CPXLPptr lp, int type);

/* mipuctrl.c */

int
   CPXsetbranchcallbackfunc    (CPXENVptr env,
                                int (*branchcallback)(CPXENVptr,
                                CPXLPptr, void *, int, int *, int *,
                                int *, int *, int *, int *, double *,
                                int *, int *, char *, int *)),
   CPXsetnodecallbackfunc      (CPXENVptr env,
                                int (*nodecallback)(CPXENVptr,
                                CPXLPptr, void *, int, int *)),
   CPXsetheuristiccallbackfunc (CPXENVptr env,
                                int (*heursticcallback)(CPXENVptr,
                                CPXLPptr, void *, int, double *,
                                double *, int *)),
   CPXsetsolvecallbackfunc     (CPXENVptr env,
                                int (*solvecallback)(CPXENVptr,
                                CPXLPptr, void *, int));

void
   CPXgetbranchcallbackfunc    (CPXENVptr env,
                                int (**branchcallback_p)(CPXENVptr,
                                CPXLPptr, void *, int, int *, int *,
                                int *, int *, int *, int *, double *,
                                int *, int *, char *, int *)),
   CPXgetnodecallbackfunc      (CPXENVptr env,
                                int (**nodecallback_p)(CPXENVptr,
                                CPXLPptr, void *, int, int *)),
   CPXgetheuristiccallbackfunc (CPXENVptr env,
                               int (**heuristiccallback_p)(CPXENVptr,
                                CPXLPptr, void *, int, double *,
                                double *, int *)),
   CPXgetsolvecallbackfunc     (CPXENVptr env,
                                int (**solvecallback_p)(CPXENVptr,
                                CPXLPptr, void *, int));

int
   CPXgetsubprobcbinfo         (CPXENVptr env, CPXLPptr lp,
                                int wherefrom,
                                CPXLPptr *subproblemlp),
   CPXgetnodecbinfo            (CPXENVptr env, CPXLPptr lp,
                                int wherefrom, int nodenum,
                                int whichinfo, void *result_p),
   CPXgetvarcbinfo             (CPXENVptr env, CPXLPptr lp,
                                int wherefrom, int varindex,
                                int whichinfo, void *result_p),
   CPXgetsoscbinfo             (CPXENVptr env, CPXLPptr lp,
                                int wherefrom, int sosindex,
                                int member, int whichinfo,
                                void *result_p);

#else

/* mipload.c */

CPXLPptr
   CPXloadmprob ();

int
   CPXloadctype (),
   CPXloadorder (),
   CPXloadsos   ();

/* mipopt.c */

int
   CPXmipoptimize     (),
   CPXusermipoptimize ();

/* mipordrw.c */

int
   CPXordread  (),
   CPXordwrite ();

/* mipquery.c */

int
   CPXgetmx      (),
   CPXgetmslack  (),
   CPXgetmobjval (),
   CPXgetctype   (),
   CPXgetintc    (),
   CPXgetbinc    (),
   CPXgetitcm    (),
   CPXgetbobjval (),
   CPXgetcutoff  (),
   CPXgetndc     (),
   CPXgetndleft  (),
   CPXgetndint   (),
   CPXgetgclqc   (),
   CPXgetclqc    (),
   CPXgetcovc    ();

/* mipsosrw.c */

int
   CPXsosread  (),
   CPXsoswrite ();

/* miptrerw.c */

int
   CPXtreeread  (),
   CPXtreewrite ();

/* mipuchg.c */

int
   CPXchgctype    (),
   CPXchgprobtype ();

/* mipuctrl.c */

int
   CPXsetnodecallbackfunc      (),
   CPXsetbranchcallbackfunc    (),
   CPXsetheuristiccallbackfunc (),
   CPXsetsolvecallbackfunc     ();

void
   CPXgetnodecallbackfunc      (),
   CPXgetbranchcallbackfunc    (),
   CPXgetheuristiccallbackfunc (),
   CPXgetsolvecallbackfunc     ();

int
   CPXgetsubprobcbinfo (),
   CPXgetnodecbinfo    (),
   CPXgetvarcbinfo     (),
   CPXgetsoscbinfo     ();

#endif

#endif /* __MIPDEFS_H */

/*******************************************************************/
/*  QPDEFS.h                                                       */
/*  Version 4.0                                                    */
/*                                                                 */
/*  Copyright (c) 1989-1995                                        */
/*  CPLEX Optimization, Inc.                                       */
/*  All Rights Reserved                                            */
/*                                                                 */
/*  Last modified 28 November 1995, IJL                            */
/*******************************************************************/

#ifndef __QPDEFS_H
#define __QPDEFS_H


#define CPXERR_BAD_Q          5001
#define CPXERR_Q_NOTPOSDEF    5002
#define CPXERR_QP_NOTMATRIX   5003
#define CPXERR_NOT_QP         5004
#define CPXERR_QP_SEP_INDEF   5006
#define CPXERR_QP_BADBARALG   5007
#define CPXERR_NOT_RELAXEDQP  5008
#define CPXERR_QP_NOSPACE     5009
#define CPXERR_Q_NEGZEROCOMP  5010
#define CPXERR_Q_DUPENTRY     5011
#define CPXERR_Q_NOTSYMMETRIC 5012

#define CPX_PARAM_QPNZREADLIM 4001


#ifdef  CPX_PROTOTYPE_ANSI

/* qpload.c */

int
   CPXloadquad (CPXENVptr env, CPXLPptr lp, int *qmatbeg,
                int *qmatcnt, int *qmatind, double *qmatval,
                int qnzspace),
   CPXloadqsep (CPXENVptr env, CPXLPptr lp, double *qsepvec);

/* qpqrychg.c */

int
   CPXgetnumqpnz (CPXENVptr env, CPXLPptr lp),
   CPXgetnumquad (CPXENVptr env, CPXLPptr lp),
   CPXgetqpcoef  (CPXENVptr env, CPXLPptr lp, int rownum, int colnum,
                  double *coef_p),
   CPXchgqpcoef  (CPXENVptr env, CPXLPptr lp, int i, int j,
                  double newvalue);


/* qprw.c */

int
   CPXqpread  (CPXENVptr env, char *filename, int numcols, int colspace,
               char **colname, int **qmatbeg_p, int **qmatcnt_p,
               int **qmatind_p, double **qmatval_p, int *qnzspace_p),
   CPXqpwrite (CPXENVptr env, CPXLPptr lp, char *filename);

#else

/* qpload.c */

int
   CPXloadquad (),
   CPXloadqsep ();

/* qpqrychg.c */

int
   CPXgetnumqpnz (),
   CPXgetnumquad (),
   CPXgetqpcoef  (),
   CPXchgqpcoef  ();

/* qprw.c */

int
   CPXqpread  (),
   CPXqpwrite ();

#endif

#endif /* __QPDEFS_H */

