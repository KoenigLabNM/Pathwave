/*------------------------------------------------------------------------*/
/*  File: cplex.h                                                         */
/*  Version 8.1                                                           */
/*                                                                        */
/*  Copyright (C) 1997-2002 by ILOG.                                      */
/*  All Rights Reserved.                                                  */
/*                                                                        */
/*  N O T I C E                                                           */
/*                                                                        */
/*  THIS MATERIAL IS CONSIDERED A TRADE SECRET BY ILOG.                   */
/*  UNAUTHORIZED ACCESS, USE, REPRODUCTION OR DISTRIBUTION IS PROHIBITED. */
/*------------------------------------------------------------------------*/
/*  $Revision: 1.1 $                                                     */
/*  Last modified $Date: 2003/08/05 13:58:29 $ $Author: elf $           */
/*------------------------------------------------------------------------*/


#ifndef __CPXDEFS_H
#define __CPXDEFS_H

#ifdef __cplusplus
extern "C" {
#endif


/* Safeguard for CPXWIN32 */

#if !defined(CPXWIN32) && defined(_WIN32) && !defined(_WIN64)
#define CPXWIN32
#endif

#if !defined(CPXWIN64) && defined(_WIN64)
#define CPXWIN64
#endif


/* The version is an integer, to allow testing in user include
   files */

#define  CPX_VERSION  810

/* Also include an SCCS version string */

#if defined(CPXWIN32) || defined(CPXWIN64)
#define CPX_VERSIONSTRING "@(#)ILOG Software: product CPLEX, library cplex81.lib, version 8.1.0, date 10/29/2002, Copyright (C) 1997-2002 by ILOG"
#else
#define CPX_VERSIONSTRING "@(#)ILOG Software: product CPLEX, library libcplex.a, version 8.1.0, date 10/29/2002, Copyright (C) 1997-2002 by ILOG"
#endif


/* <stdio.h> is include here so that the 'FILE' type is defined */

#include <stdio.h>

#ifdef   CPXWIN32
#define  CPXPUBLIC      __stdcall
#define  CPXPUBVARARGS  __cdecl
#define  CPXCDECL       __cdecl
typedef  void *CPXFILEptr;
#else
#ifdef   CPXWIN64
#define  CPXPUBLIC      __stdcall
#define  CPXPUBVARARGS  __cdecl
#define  CPXCDECL       __cdecl
typedef  void *CPXFILEptr;
#else
#define  CPXPUBLIC
#define  CPXPUBVARARGS
#define  CPXCDECL
typedef  FILE *CPXFILEptr;
#endif
#endif

#ifdef  SYSGNUSPARC
#include <sys/stdtypes.h>
#endif

/* CPX_INFBOUND:  Any bound bigger than this is treated as infinity */

#define CPX_INFBOUND  1.0E+20


#define  CPX_STR_PARAM_MAX    512


/* Values returned for 'stat' by solution () */

#define CPX_STAT_OPTIMAL                  1
#define CPX_STAT_UNBOUNDED                2
#define CPX_STAT_INFEASIBLE               3
#define CPX_STAT_INForUNBD                4
#define CPX_STAT_OPTIMAL_INFEAS           5
#define CPX_STAT_NUM_BEST                 6
#define CPX_STAT_ABORT_IT_LIM            10
#define CPX_STAT_ABORT_TIME_LIM          11
#define CPX_STAT_ABORT_OBJ_LIM           12
#define CPX_STAT_ABORT_USER              13


/* Solution type return values from CPXsolninfo() */
#define CPX_NO_SOLN        0
#define CPX_BASIC_SOLN     1
#define CPX_NONBASIC_SOLN  2

/* Values of presolve 'stats' for columns and rows */
#define CPX_PRECOL_LOW               -1
#define CPX_PRECOL_UP                -2
#define CPX_PRECOL_FIX               -3
#define CPX_PRECOL_AGG               -4
#define CPX_PRECOL_OTHER             -5
#define CPX_PREROW_RED               -1
#define CPX_PREROW_AGG               -2
#define CPX_PREROW_OTHER             -3

/* Error codes */

#define CPXERR_NO_MEMORY              1001
#define CPXERR_NO_ENVIRONMENT         1002
#define CPXERR_BAD_ARGUMENT           1003
#define CPXERR_NULL_POINTER           1004
#define CPXERR_CALLBACK               1006
#define CPXERR_NO_PROBLEM             1009
#define CPXERR_LIMITS_TOO_BIG         1012
#define CPXERR_BAD_PARAM_NUM          1013
#define CPXERR_PARAM_TOO_SMALL        1014
#define CPXERR_PARAM_TOO_BIG          1015
#define CPXERR_PROMOTION_VERSION      1016
#define CPXERR_NOT_FOR_MIP            1017
#define CPXERR_NOT_FOR_QP             1018
#define CPXERR_CHILD_OF_CHILD         1019
#define CPXERR_TOO_MANY_THREADS       1020
#define CPXERR_CANT_CLOSE_CHILD       1021
#define CPXERR_BAD_PROB_TYPE          1022
#define CPXERR_NOT_ONE_PROBLEM        1023
#define CPXERR_NOT_MILPCLASS          1024
#define CPXERR_NOT_QPCLASS            1025
#define CPXERR_STR_PARAM_TOO_LONG     1026
#define CPXERR_DECOMPRESSION          1027
#define CPXERR_BAD_PARAM_NAME         1028
#define CPXERR_NOT_MIQPCLASS          1029

#define CPXERR_MSG_NO_CHANNEL         1051
#define CPXERR_MSG_NO_FILEPTR         1052
#define CPXERR_MSG_NO_FUNCTION        1053

#define CPXERR_BOUNDS_INFEAS          1100
#define CPXERR_PRESLV_INForUNBD       1101
#define CPXERR_PRESLV_NO_PROB         1103
#define CPXERR_PRESLV_ABORT           1106
#define CPXERR_PRESLV_BASIS_MEM       1107
#define CPXERR_PRESLV_COPYSOS         1108
#define CPXERR_PRESLV_COPYORDER       1109
#define CPXERR_PRESLV_SOLN_MIP        1110
#define CPXERR_PRESLV_SOLN_QP         1111
#define CPXERR_PRESLV_START_LP        1112
#define CPXERR_PRESLV_FAIL_BASIS      1114
#define CPXERR_PRESLV_NO_BASIS        1115
#define CPXERR_PRESLV_INF             1117
#define CPXERR_PRESLV_UNBD            1118
#define CPXERR_PRESLV_DUAL            1119
#define CPXERR_PRESLV_UNCRUSHFORM     1120
#define CPXERR_PRESLV_CRUSHFORM       1121
#define CPXERR_PRESLV_BAD_PARAM       1122

/* Callable library miscellaneous routines */

#define CPXERR_INDEX_RANGE            1200
#define CPXERR_COL_INDEX_RANGE        1201
#define CPXERR_ROW_INDEX_RANGE        1203
#define CPXERR_INDEX_RANGE_LOW        1205
#define CPXERR_INDEX_RANGE_HIGH       1206
#define CPXERR_NEGATIVE_SURPLUS       1207
#define CPXERR_ARRAY_TOO_LONG         1208
#define CPXERR_NAME_CREATION          1209
#define CPXERR_NAME_NOT_FOUND         1210
#define CPXERR_NO_RHS_IN_OBJ          1211
#define CPXERR_BAD_SENSE              1215
#define CPXERR_NO_RNGVAL              1216
#define CPXERR_NO_SOLN                1217
#define CPXERR_NO_NAMES               1219
#define CPXERR_NOT_FIXED              1221
#define CPXERR_DUP_ENTRY              1222
#define CPXERR_NO_BARRIER_SOLN        1223
#define CPXERR_NULL_NAME              1224
#define CPXERR_NAN                    1225
#define CPXERR_ARRAY_NOT_ASCENDING    1226
#define CPXERR_COUNT_RANGE            1227
#define CPXERR_COUNT_OVERLAP          1228
#define CPXERR_BAD_LUB                1229
#define CPXERR_NODE_INDEX_RANGE       1230
#define CPXERR_ARC_INDEX_RANGE        1231

/* Simplex related */

#define CPXERR_INDEX_NOT_BASIC        1251
#define CPXERR_NEED_OPT_SOLN          1252
#define CPXERR_BAD_STATUS             1253
#define CPXERR_NOT_UNBOUNDED          1254
#define CPXERR_SBASE_INCOMPAT         1255
#define CPXERR_SINGULAR               1256
#define CPXERR_PRIIND                 1257
#define CPXERR_NO_LU_FACTOR           1258
#define CPXERR_NO_SENSIT              1260
#define CPXERR_NO_BASIC_SOLN          1261
#define CPXERR_NO_BASIS               1262
#define CPXERR_ABORT_STRONGBRANCH     1263
#define CPXERR_NO_NORMS               1264
#define CPXERR_NOT_DUAL_UNBOUNDED     1265
#define CPXERR_TILIM_STRONGBRANCH     1266
#define CPXERR_BAD_PIVOT              1267
#define CPXERR_TILIM_CONDITION_NO     1268
#define CPXERR_ABORT_CONDITION_NO     1269

/* hybrid solvers */

#define CPXERR_BAD_METHOD             1292

/* For readers and writers */

#define CPXERR_NO_FILENAME            1421
#define CPXERR_FAIL_OPEN_WRITE        1422
#define CPXERR_FAIL_OPEN_READ         1423
#define CPXERR_BAD_FILETYPE           1424

/* Common to LP, MPS, and related readers */

#define CPXERR_TOO_MANY_ROWS          1431
#define CPXERR_TOO_MANY_COLS          1432
#define CPXERR_TOO_MANY_COEFFS        1433
#define CPXERR_BAD_NUMBER             1434
#define CPXERR_BAD_EXPO_RANGE         1435
#define CPXERR_NO_OBJ_SENSE           1436

/* Common to MPS and related readers */

#define CPXERR_NO_NAME_SECTION        1441
#define CPXERR_BAD_SOS_TYPE           1442
#define CPXERR_COL_ROW_REPEATS        1443
#define CPXERR_RIM_ROW_REPEATS        1444
#define CPXERR_ROW_REPEATS            1445
#define CPXERR_COL_REPEATS            1446
#define CPXERR_RIM_REPEATS            1447
#define CPXERR_ROW_UNKNOWN            1448
#define CPXERR_COL_UNKNOWN            1449
#define CPXERR_NO_ROW_SENSE           1453
#define CPXERR_EXTRA_FX_BOUND         1454
#define CPXERR_EXTRA_FR_BOUND         1455
#define CPXERR_EXTRA_BV_BOUND         1456
#define CPXERR_BAD_BOUND_TYPE         1457
#define CPXERR_UP_BOUND_REPEATS       1458
#define CPXERR_LO_BOUND_REPEATS       1459
#define CPXERR_NO_BOUND_TYPE          1460
#define CPXERR_NO_QMATRIX_SECTION     1461
#define CPXERR_BAD_SECTION_ENDATA     1462
#define CPXERR_INT_TOO_BIG_INPUT      1463
#define CPXERR_NAME_TOO_LONG          1464

/* Unique to MPS reader */

#define CPXERR_NO_ROWS_SECTION        1471
#define CPXERR_NO_COLUMNS_SECTION     1472
#define CPXERR_BAD_SECTION_BOUNDS     1473
#define CPXERR_RANGE_SECTION_ORDER    1474
#define CPXERR_BAD_SECTION_QMATRIX    1475
#define CPXERR_NO_OBJECTIVE           1476
#define CPXERR_ROW_REPEAT_PRINT       1477
#define CPXERR_COL_REPEAT_PRINT       1478
#define CPXERR_RIMNZ_REPEATS          1479
#define CPXERR_EXTRA_INTORG           1480
#define CPXERR_EXTRA_INTEND           1481
#define CPXERR_EXTRA_SOSORG           1482
#define CPXERR_EXTRA_SOSEND           1483
#define CPXERR_TOO_MANY_RIMS          1484
#define CPXERR_TOO_MANY_RIMNZ         1485
#define CPXERR_NO_ROW_NAME            1486
#define CPXERR_BAD_OBJ_SENSE          1487

/* PAR Files */

#define CPXERR_PAR_NO_HEADER          1525
#define CPXERR_PAR_BAD_HEADER         1526
#define CPXERR_PAR_SHORT              1527
#define CPXERR_PAR_DATA               1528

/* BAS files */

#define CPXERR_BAS_FILE_SHORT         1550
#define CPXERR_BAD_INDICATOR          1551
#define CPXERR_NO_ENDATA              1552
#define CPXERR_FILE_ENTRIES           1553
#define CPXERR_SBASE_ILLEGAL          1554
#define CPXERR_BAS_FILE_SIZE          1555
#define CPXERR_NO_VECTOR_SOLN         1556

/* SAV files */

#define CPXERR_NOT_SAV_FILE           1560
#define CPXERR_SAV_FILE_DATA          1561
#define CPXERR_SAV_FILE_WRITE         1562
#define CPXERR_FILE_FORMAT            1563

/* LP reader errors */

#define CPXERR_ADJ_SIGNS              1602
#define CPXERR_RHS_IN_OBJ             1603
#define CPXERR_ADJ_SIGN_SENSE         1604
#define CPXERR_QUAD_IN_ROW            1605
#define CPXERR_ADJ_SIGN_QUAD          1606
#define CPXERR_NO_OPERATOR            1607
#define CPXERR_NO_OP_OR_SENSE         1608
#define CPXERR_NO_ID_FIRST            1609
#define CPXERR_NO_RHS_COEFF           1610
#define CPXERR_NO_NUMBER_FIRST        1611
#define CPXERR_NO_QUAD_EXP            1612
#define CPXERR_QUAD_EXP_NOT_2         1613
#define CPXERR_NO_QP_OPERATOR         1614
#define CPXERR_NO_NUMBER              1615
#define CPXERR_NO_ID                  1616
#define CPXERR_BAD_ID                 1617
#define CPXERR_BAD_EXPONENT           1618
#define CPXERR_Q_DIVISOR              1619
#define CPXERR_NO_BOUND_SENSE         1621
#define CPXERR_BAD_BOUND_SENSE        1622
#define CPXERR_NO_NUMBER_BOUND        1623
#define CPXERR_LP_TOO_MANY_ROWS       1624
#define CPXERR_LP_TOO_MANY_COLS       1625
#define CPXERR_LP_TOO_MANY_COEFFS     1626
#define CPXERR_NO_SOS_SEPARATOR       1627
#define CPXERR_INVALID_NUMBER         1650

#define CPXERR_IIS_NO_INFO            1701
#define CPXERR_IIS_NO_SOLN            1702
#define CPXERR_IIS_FEAS               1703
#define CPXERR_IIS_NOT_INFEAS         1704
#define CPXERR_IIS_OPT_INFEAS         1705
#define CPXERR_IIS_DEFAULT            1706
#define CPXERR_IIS_NO_BASIC           1707
#define CPXERR_IIS_NO_PRIMAL          1708
#define CPXERR_IIS_NO_LOAD            1709
#define CPXERR_IIS_SUB_OBJ_LIM        1710
#define CPXERR_IIS_SUB_IT_LIM         1711
#define CPXERR_IIS_SUB_TIME_LIM       1712
#define CPXERR_IIS_NUM_BEST           1713

/* temporary file errors */

#define CPXERR_WORK_FILE_OPEN         1801
#define CPXERR_WORK_FILE_READ         1802
#define CPXERR_WORK_FILE_WRITE        1803

/* Private errors are 2000-2999 (cpxpriv.h)
   MIP errors are 3000-3999 (mipdefs.h)
   Barrier errors are 4000-4999 (bardefs.h)
   QP errors are 5000-5999 (qpdefs.h) */

#define CPXERR_LICENSE_MIN           32000
#define CPXERR_NO_MIP_LIC            32301
#define CPXERR_NO_BARRIER_LIC        32302
#define CPXERR_NO_MIQP_LIC           32305
#define CPXERR_LICENSE_MAX           32999

/* Generic constants */

#define CPX_ON                           1
#define CPX_OFF                          0
#define CPX_MAX                         -1
#define CPX_MIN                          1

/* Pricing options */

#define CPX_PPRIIND_PARTIAL             -1
#define CPX_PPRIIND_AUTO                 0
#define CPX_PPRIIND_DEVEX                1
#define CPX_PPRIIND_STEEP                2
#define CPX_PPRIIND_STEEPQSTART          3
#define CPX_PPRIIND_FULL                 4

#define CPX_DPRIIND_AUTO                 0
#define CPX_DPRIIND_FULL                 1
#define CPX_DPRIIND_STEEP                2
#define CPX_DPRIIND_FULLSTEEP            3
#define CPX_DPRIIND_STEEPQSTART          4


/* LP/QP solution algorithms, used as possible values for
   CPX_PARAM_LPMETHOD/CPX_PARAM_QPMETHOD/CPX_PARAM_BARCROSSALG/
   CPXgetmethod()/... */

#define CPX_ALG_NONE                     -1
#define CPX_ALG_AUTOMATIC                 0
#define CPX_ALG_PRIMAL                    1
#define CPX_ALG_DUAL                      2
#define CPX_ALG_NET                       3
#define CPX_ALG_BARRIER                   4
#define CPX_ALG_SIFTING                   5
#define CPX_ALG_CONCURRENT                6
#define CPX_ALG_BAROPT                    7
#define CPX_ALG_PIVOTIN                   8
#define CPX_ALG_PIVOTOUT                  9
#define CPX_ALG_PIVOT                    10
#define CPX_ALG_ANY                       BIGINT

/* Basis status values */

#define CPX_AT_LOWER                     0
#define CPX_BASIC                        1
#define CPX_AT_UPPER                     2
#define CPX_FREE_SUPER                   3

/* Used in pivoting interface */

#define CPX_NO_VARIABLE         2100000000

/* Infeasibility Finder return values */

#define CPXIIS_COMPLETE                  1
#define CPXIIS_PARTIAL                   2

/* Infeasibility Finder display values */

#define CPXIIS_TERSE                      1
#define CPXIIS_VERBOSE                    2

/* Infeasibility Finder row and column statuses */

#define CPXIIS_AT_LOWER                   0
#define CPXIIS_FIXED                      1
#define CPXIIS_AT_UPPER                   2

/* Variable types for ctype array */

#define CPX_CONTINUOUS                   'C'
#define CPX_BINARY                       'B'
#define CPX_INTEGER                      'I'
#define CPX_SEMICONT                     'S'
#define CPX_SEMIINT                      'N'

/* PREREDUCE settings */
 
#define CPX_PREREDUCE_PRIMALANDDUAL       3
#define CPX_PREREDUCE_DUALONLY            2
#define CPX_PREREDUCE_PRIMALONLY          1
#define CPX_PREREDUCE_NOPRIMALORDUAL      0

/* Problem Types
   Types 4 and 9 are internal, the others are for users */
 
#define CPXPROB_LP                       0
#define CPXPROB_MILP                     1
#define CPXPROB_FIXEDMILP                3
#define CPXPROB_NODELP                   4
#define CPXPROB_QP                       5
#define CPXPROB_MIQP                     7
#define CPXPROB_FIXEDMIQP                8
#define CPXPROB_NODEQP                   9

/* Obsolete (and undocumented) problem types; will be removed next release */
#define CPXPROB_RELAXEDMILP              2
#define CPXPROB_ZEROEDQP                 6

/* CPLEX Parameter numbers */

#define CPX_PARAM_ADVIND               1001
#define CPX_PARAM_AGGFILL              1002
#define CPX_PARAM_AGGIND               1003
#define CPX_PARAM_BASINTERVAL          1004
#define CPX_PARAM_CFILEMUL             1005
#define CPX_PARAM_CLOCKTYPE            1006
#define CPX_PARAM_CRAIND               1007
#define CPX_PARAM_DEPIND               1008
#define CPX_PARAM_DPRIIND              1009
#define CPX_PARAM_PRICELIM             1010
#define CPX_PARAM_EPMRK                1013
#define CPX_PARAM_EPOPT                1014
#define CPX_PARAM_EPPER                1015
#define CPX_PARAM_EPRHS                1016
#define CPX_PARAM_FASTMIP              1017
#define CPX_PARAM_IISIND               1018
#define CPX_PARAM_SIMDISPLAY           1019
#define CPX_PARAM_ITLIM                1020
#define CPX_PARAM_ROWREADLIM           1021
#define CPX_PARAM_NETFIND              1022
#define CPX_PARAM_COLREADLIM           1023
#define CPX_PARAM_NZREADLIM            1024
#define CPX_PARAM_OBJLLIM              1025
#define CPX_PARAM_OBJULIM              1026
#define CPX_PARAM_PERIND               1027
#define CPX_PARAM_PERLIM               1028
#define CPX_PARAM_PPRIIND              1029
#define CPX_PARAM_PREIND               1030
#define CPX_PARAM_REINV                1031
#define CPX_PARAM_REVERSEIND           1032
#define CPX_PARAM_RFILEMUL             1033
#define CPX_PARAM_SCAIND               1034
#define CPX_PARAM_SCRIND               1035
#define CPX_PARAM_SIMTHREADS           1036
#define CPX_PARAM_SINGLIM              1037
#define CPX_PARAM_SINGTOL              1038
#define CPX_PARAM_TILIM                1039
#define CPX_PARAM_XXXIND               1041
#define CPX_PARAM_PREDUAL              1044
#define CPX_PARAM_ROWGROWTH            1046
#define CPX_PARAM_COLGROWTH            1047
#define CPX_PARAM_NZGROWTH             1048
#define CPX_PARAM_EPOPT_H              1049
#define CPX_PARAM_EPRHS_H              1050
#define CPX_PARAM_PREPASS              1052
#define CPX_PARAM_DATACHECK            1056
#define CPX_PARAM_REDUCE               1057
#define CPX_PARAM_PRELINEAR            1058
#define CPX_PARAM_LPMETHOD             1062
#define CPX_PARAM_QPMETHOD             1063
#define CPX_PARAM_WORKDIR              1064
#define CPX_PARAM_WORKMEM              1065
#define CPX_PARAM_PRECOMPRESS          1066
#define CPX_PARAM_THREADS              1067
#define CPX_PARAM_SIFTDISPLAY          1076
#define CPX_PARAM_SIFTALG              1077
#define CPX_PARAM_SIFTITLIM            1078

/* Barrier is in bardefs.h, MIP is in mipdefs.h, QP is in qpdefs.h */

#define CPX_PARAM_ALL_MIN              1000
#define CPX_PARAM_ALL_MAX              6000

/* Callback values for wherefrom   */

#define CPX_CALLBACK_PRIMAL               1
#define CPX_CALLBACK_DUAL                 2
#define CPX_CALLBACK_NETWORK              3
#define CPX_CALLBACK_PRIMAL_CROSSOVER     4
#define CPX_CALLBACK_DUAL_CROSSOVER       5
#define CPX_CALLBACK_BARRIER              6
#define CPX_CALLBACK_PRESOLVE             7
#define CPX_CALLBACK_QPBARRIER            8
#define CPX_CALLBACK_QPSIMPLEX            9
/* Be sure to check the MIP values */

/* Values for getcallbackinfo function */

#define CPX_CALLBACK_INFO_PRIMAL_OBJ            1
#define CPX_CALLBACK_INFO_DUAL_OBJ              2
#define CPX_CALLBACK_INFO_PRIMAL_INFMEAS        3
#define CPX_CALLBACK_INFO_DUAL_INFMEAS          4
#define CPX_CALLBACK_INFO_PRIMAL_FEAS           5
#define CPX_CALLBACK_INFO_DUAL_FEAS             6
#define CPX_CALLBACK_INFO_ITCOUNT               7
#define CPX_CALLBACK_INFO_CROSSOVER_PPUSH       8
#define CPX_CALLBACK_INFO_CROSSOVER_PEXCH       9
#define CPX_CALLBACK_INFO_CROSSOVER_DPUSH      10
#define CPX_CALLBACK_INFO_CROSSOVER_DEXCH      11
#define CPX_CALLBACK_INFO_CROSSOVER_SBCNT      12
#define CPX_CALLBACK_INFO_PRESOLVE_ROWSGONE    13
#define CPX_CALLBACK_INFO_PRESOLVE_COLSGONE    14
#define CPX_CALLBACK_INFO_PRESOLVE_AGGSUBST    15
#define CPX_CALLBACK_INFO_PRESOLVE_COEFFS      16
#define CPX_CALLBACK_INFO_USER_PROBLEM         17
/* Be sure to check the MIP values */

/* quality query identifiers */

#define CPX_MAX_PRIMAL_INFEAS          1
#define CPX_MAX_SCALED_PRIMAL_INFEAS   2
#define CPX_SUM_PRIMAL_INFEAS          3
#define CPX_SUM_SCALED_PRIMAL_INFEAS   4
#define CPX_MAX_DUAL_INFEAS            5
#define CPX_MAX_SCALED_DUAL_INFEAS     6
#define CPX_SUM_DUAL_INFEAS            7
#define CPX_SUM_SCALED_DUAL_INFEAS     8
#define CPX_MAX_INT_INFEAS             9
#define CPX_SUM_INT_INFEAS             10
#define CPX_MAX_PRIMAL_RESIDUAL        11
#define CPX_MAX_SCALED_PRIMAL_RESIDUAL 12
#define CPX_SUM_PRIMAL_RESIDUAL        13
#define CPX_SUM_SCALED_PRIMAL_RESIDUAL 14
#define CPX_MAX_DUAL_RESIDUAL          15
#define CPX_MAX_SCALED_DUAL_RESIDUAL   16
#define CPX_SUM_DUAL_RESIDUAL          17
#define CPX_SUM_SCALED_DUAL_RESIDUAL   18
#define CPX_MAX_COMP_SLACK             19
#define CPX_SUM_COMP_SLACK             21
#define CPX_MAX_X                      23
#define CPX_MAX_SCALED_X               24
#define CPX_MAX_PI                     25
#define CPX_MAX_SCALED_PI              26
#define CPX_MAX_SLACK                  27
#define CPX_MAX_SCALED_SLACK           28
#define CPX_MAX_RED_COST               29
#define CPX_MAX_SCALED_RED_COST        30
#define CPX_SUM_X                      31
#define CPX_SUM_SCALED_X               32
#define CPX_SUM_PI                     33
#define CPX_SUM_SCALED_PI              34
#define CPX_SUM_SLACK                  35
#define CPX_SUM_SCALED_SLACK           36
#define CPX_SUM_RED_COST               37
#define CPX_SUM_SCALED_RED_COST        38
#define CPX_KAPPA                      39
#define CPX_OBJ_GAP                    40
#define CPX_DUAL_OBJ                   41
#define CPX_PRIMAL_OBJ                 42


/* structure types */

struct cpxenv;
typedef struct cpxenv       *CPXENVptr;
typedef const struct cpxenv *CPXCENVptr;

struct cpxchannel;
typedef struct cpxchannel  *CPXCHANNELptr;

struct cpxlp;
typedef struct cpxlp        *CPXLPptr;
typedef const struct cpxlp  *CPXCLPptr;

struct cpxnet;
typedef struct cpxnet       *CPXNETptr;
typedef const struct cpxnet *CPXCNETptr;

typedef char       *CPXCHARptr;  /* to simplify CPXPUBLIC syntax */
typedef const char *CPXCCHARptr; /* to simplify CPXPUBLIC syntax */
typedef void       *CPXVOIDptr;  /* to simplify CPXPUBLIC syntax */

#ifndef  CPX_MODERN
#define CPXoptimize     CPXlpopt
#define CPXgetsbcnt     CPXgetpsbcnt
#endif


/* Creating/Deleting Problems and Copying Data */

CPXLPptr CPXPUBLIC
   CPXcreateprob   (CPXCENVptr env, int *status_p, const char *probname_str);
CPXLPptr CPXPUBLIC
   CPXcloneprob    (CPXCENVptr env, CPXCLPptr lp, int *status_p);
int CPXPUBLIC
   CPXcopylpwnames (CPXCENVptr env, CPXLPptr lp, int numcols,
                    int numrows, int objsen, const double *obj,
                    const double *rhs, const char *sense, const int *matbeg,
                    const int *matcnt, const int *matind, const double *matval,
                    const double *lb, const double *ub, const double *rngval,
                    char **colname, char **rowname);
int CPXPUBLIC
   CPXcopylp       (CPXCENVptr env, CPXLPptr lp, int numcols,
                    int numrows, int objsen, const double *obj,
                    const double *rhs, const char *sense, const int *matbeg,
                    const int *matcnt, const int *matind, const double *matval,
                    const double *lb, const double *ub, const double *rngval);
int CPXPUBLIC
   CPXcopyobjname  (CPXCENVptr env, CPXLPptr lp, const char *objname_str);
int CPXPUBLIC
   CPXcopybase     (CPXCENVptr env, CPXLPptr lp, const int *cstat,
                    const int *rstat);
int CPXPUBLIC
   CPXcopystart    (CPXCENVptr env, CPXLPptr lp, const int *cstat,
                    const int *rstat, const double *cprim, const double *rprim,
                    const double *cdual, const double *rdual);
int CPXPUBLIC
   CPXfreeprob     (CPXCENVptr env, CPXLPptr *lp_p);
int CPXPUBLIC
   CPXcopynettolp (CPXCENVptr env, CPXLPptr lp, CPXCNETptr net);
int CPXPUBLIC
   CPXNETextract  (CPXCENVptr env, CPXNETptr net, CPXCLPptr lp,
                   int *colmap, int *rowmap);


/* Optimizing Problems */

int CPXPUBLIC
   CPXlpopt         (CPXCENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXconcurrentopt (CPXCENVptr env, CPXCENVptr *childenv,
                     CPXLPptr lp, int P);
int CPXPUBLIC
   CPXprimopt       (CPXCENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXdualopt       (CPXCENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXhybnetopt     (CPXCENVptr env, CPXLPptr lp, int method);
int CPXPUBLIC
   CPXsiftopt       (CPXCENVptr env, CPXLPptr lp);


/* Pivoting Interface Routines */

int CPXPUBLIC
   CPXpratio     (CPXCENVptr env, CPXLPptr lp, const int *goodlist,
                  int goodlen, double *downratio, double *upratio,
                  int *downleave, int *upleave,
                  int *downleavestatus, int *upleavestatus,
                  int *downstatus, int *upstatus);
int CPXPUBLIC
   CPXdratio     (CPXCENVptr env, CPXLPptr lp, const int *goodlist,
                  int goodlen, double *downratio, double *upratio,
                  int *downenter, int *upenter,
                  int *downstatus, int *upstatus);
int CPXPUBLIC
   CPXpivot      (CPXCENVptr env, CPXLPptr lp, int jenter,
                  int jleave, int leavestat);
int CPXPUBLIC
   CPXsetphase2  (CPXCENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXcheckpfeas (CPXCENVptr env, CPXLPptr lp, int *infeas_p);
int CPXPUBLIC
   CPXcheckdfeas (CPXCENVptr env, CPXLPptr lp, int *infeas_p);
int CPXPUBLIC
   CPXchecksoln  (CPXCENVptr env, CPXLPptr lp, int *lpstatus_p);


/* Accessing LP results */

int CPXPUBLIC
   CPXsolution         (CPXCENVptr env, CPXCLPptr lp, int *lpstat_p,
                        double *objval_p, double *x, double *pi,
                        double *slack, double *dj);
int CPXPUBLIC
   CPXsolninfo         (CPXCENVptr env, CPXCLPptr lp,
                        int *solnmethod_p, int *solntype_p,
                        int *pfeasind_p, int *dfeasind_p);
int CPXPUBLIC
   CPXgetstat          (CPXCENVptr env, CPXCLPptr lp);
CPXCHARptr CPXPUBLIC
   CPXgetstatstring    (CPXCENVptr env, int statind, char *buffer_str);
int CPXPUBLIC
   CPXgetmethod        (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetobjval        (CPXCENVptr env, CPXCLPptr lp,
                        double *objval_p);
int CPXPUBLIC
   CPXgetx             (CPXCENVptr env, CPXCLPptr lp, double *x,
                        int begin, int end);
int CPXPUBLIC
   CPXgetax            (CPXCENVptr env, CPXCLPptr lp, double *x,
                        int begin, int end);
int CPXPUBLIC
   CPXgetpi            (CPXCENVptr env, CPXCLPptr lp, double *pi,
                        int begin, int end);
int CPXPUBLIC
   CPXgetslack         (CPXCENVptr env, CPXCLPptr lp, double *slack,
                        int begin, int end);
int CPXPUBLIC
   CPXgetdj            (CPXCENVptr env, CPXCLPptr lp, double *dj,
                        int begin, int end);
int CPXPUBLIC
   CPXgetgrad          (CPXCENVptr env, CPXCLPptr lp, int j, int *head,
                        double *y);
int CPXPUBLIC
   CPXgetijdiv         (CPXCENVptr env, CPXCLPptr lp, int *idiv_p,
                        int *jdiv_p);
int CPXPUBLIC
   CPXcangetbase       (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetbase          (CPXCENVptr env, CPXCLPptr lp, int *cstat,
                        int *rstat);
int CPXPUBLIC
   CPXgetitcnt         (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetphase1cnt     (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetsiftitcnt     (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetsiftphase1cnt (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetbaritcnt      (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetcrossppushcnt (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetcrosspexchcnt (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetcrossdpushcnt (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetcrossdexchcnt (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetpsbcnt        (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetdsbcnt        (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetdblquality    (CPXCENVptr env, CPXCLPptr lp,
                        double *quality_p, int what);
int CPXPUBLIC
   CPXgetintquality    (CPXCENVptr env, CPXCLPptr lp, int *quality_p,
                        int what);


/* Sensitivity Analysis Results */

int CPXPUBLIC
   CPXrhssa   (CPXCENVptr env, CPXCLPptr lp, int begin, int end,
               double *lower, double *upper);
int CPXPUBLIC
   CPXboundsa (CPXCENVptr env, CPXCLPptr lp, int begin, int end,
               double *lblower, double *lbupper, double *ublower,
               double *ubupper);
int CPXPUBLIC
   CPXobjsa   (CPXCENVptr env, CPXCLPptr lp, int begin, int end,
               double *lower, double *upper);
int CPXPUBLIC
   CPXErangesa(CPXENVptr env, CPXLPptr lp, int begin, int end,
               double *lblower, double *lbupper, double *ublower,
               double *ubupper);


/* Infeasibility Finder */

int CPXPUBLIC
   CPXgetiis     (CPXCENVptr env, CPXCLPptr lp, int *iisstat_p,
                  int *rowind, int *rowbdstat, int *iisnumrows_p,
                  int *colind, int *colbdstat, int *iisnumcols_p);
int CPXPUBLIC
   CPXfindiis    (CPXCENVptr env, CPXLPptr lp, int *iisnumrows_p,
                  int *iisnumcols_p);
int CPXPUBLIC
   CPXdisplayiis (CPXCENVptr env, CPXCLPptr lp, CPXCHANNELptr channel,
                  int display);


/* Problem Modification Routines */

int CPXPUBLIC
   CPXnewrows     (CPXCENVptr env, CPXLPptr lp, int rcnt,
                   const double *rhs, const char *sense, const double *rngval,
                   char **rowname);
int CPXPUBLIC
   CPXaddrows     (CPXCENVptr env, CPXLPptr lp, int ccnt, int rcnt,
                   int nzcnt, const double *rhs, const char *sense,
                   const int *rmatbeg, const int *rmatind,
                   const double *rmatval, char **colname, char **rowname);
int CPXPUBLIC
   CPXnewcols     (CPXCENVptr env, CPXLPptr lp, int ccnt,
                   const double *obj, const double *lb, const double *ub,
                   const char *xctype, char **colname);
int CPXPUBLIC
   CPXaddcols     (CPXCENVptr env, CPXLPptr lp, int ccnt, int nzcnt,
                   const double *obj, const int *cmatbeg, const int *cmatind,
                   const double *cmatval, const double *lb, const double *ub,
                   char **colname);
int CPXPUBLIC
   CPXdelrows     (CPXCENVptr env, CPXLPptr lp, int begin, int end);
int CPXPUBLIC
   CPXdelsetrows  (CPXCENVptr env, CPXLPptr lp, int *delstat);
int CPXPUBLIC
   CPXdelcols     (CPXCENVptr env, CPXLPptr lp, int begin, int end);
int CPXPUBLIC
   CPXdelsetcols  (CPXCENVptr env, CPXLPptr lp, int *delstat);
int CPXPUBLIC
   CPXchgname     (CPXCENVptr env, CPXLPptr lp, int key, int ij,
                   const char *newname_str);
int CPXPUBLIC
   CPXchgrowname  (CPXCENVptr env, CPXLPptr lp, int cnt, const int *indices,
                   char **newname);
int CPXPUBLIC
   CPXchgcolname  (CPXCENVptr env, CPXLPptr lp, int cnt, const int *indices,
                   char **newname);
int CPXPUBLIC
   CPXdelnames    (CPXCENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXchgprobname (CPXCENVptr env, CPXLPptr lp, const char *probname_str);
int CPXPUBLIC
   CPXchgcoef     (CPXCENVptr env, CPXLPptr lp, int i, int j,
                   double newvalue);
int CPXPUBLIC
   CPXchgcoeflist (CPXCENVptr env, CPXLPptr lp, int numcoefs,
                   const int *rowlist, const int *collist,
                   const double *vallist);
int CPXPUBLIC
   CPXchgbds      (CPXCENVptr env, CPXLPptr lp, int cnt,
                   const int *indices, const char *lu, const double *bd);
int CPXPUBLIC
   CPXchgobj      (CPXCENVptr env, CPXLPptr lp, int cnt,
                   const int *indices, const double *values);
int CPXPUBLIC
   CPXchgrhs      (CPXCENVptr env, CPXLPptr lp, int cnt,
                   const int *indices, const double *values);
int CPXPUBLIC
   CPXchgrngval   (CPXCENVptr env, CPXLPptr lp, int cnt,
                   const int *indices, const double *values);
int CPXPUBLIC
   CPXchgsense    (CPXCENVptr env, CPXLPptr lp, int cnt,
                   const int *indices, const char *sense);
void CPXPUBLIC
   CPXchgobjsen   (CPXCENVptr env, CPXLPptr lp, int maxormin);
int CPXPUBLIC
   CPXchgprobtype (CPXCENVptr env, CPXLPptr lp, int type);
int CPXPUBLIC
   CPXcompletelp  (CPXCENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXpreaddrows  (CPXCENVptr env, CPXLPptr lp, int rcnt, int nzcnt,
                   const double *rhs, const char *sense, const int *rmatbeg,
                   const int *rmatind, const double *rmatval, char **rowname);
int CPXPUBLIC
   CPXprechgobj   (CPXCENVptr env, CPXLPptr lp, int cnt, const int *indices,
                   const double *values);




/* Problem Query Routines */

int CPXPUBLIC
   CPXgetnumcols  (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetnumrows  (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetnumnz    (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetobjsen   (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetobj      (CPXCENVptr env, CPXCLPptr lp, double *obj,
                   int begin, int end);
int CPXPUBLIC
   CPXgetrhs      (CPXCENVptr env, CPXCLPptr lp, double *rhs,
                   int begin, int end);
int CPXPUBLIC
   CPXgetsense    (CPXCENVptr env, CPXCLPptr lp, char *sense,
                   int begin, int end);
int CPXPUBLIC
   CPXgetcols     (CPXCENVptr env, CPXCLPptr lp, int *nzcnt_p,
                   int *cmatbeg, int *cmatind, double *cmatval,
                   int cmatspace, int *surplus_p,
                   int begin, int end);
int CPXPUBLIC
   CPXgetrows     (CPXCENVptr env, CPXCLPptr lp, int *nzcnt_p,
                   int *rmatbeg, int *rmatind, double *rmatval,
                   int rmatspace, int *surplus_p,
                   int begin, int end);
int CPXPUBLIC
   CPXgetlb       (CPXCENVptr env, CPXCLPptr lp, double *lb,
                   int begin, int end);
int CPXPUBLIC
   CPXgetub       (CPXCENVptr env, CPXCLPptr lp, double *ub,
                   int begin, int end);
int CPXPUBLIC
   CPXgetrngval   (CPXCENVptr env, CPXCLPptr lp, double *rngval,
                   int begin, int end);
int CPXPUBLIC
   CPXgetprobname (CPXCENVptr env, CPXCLPptr lp, char *buf_str,
                   int bufspace, int *surplus_p);
int CPXPUBLIC
   CPXgetobjname  (CPXCENVptr env, CPXCLPptr lp, char *buf_str,
                   int bufspace, int *surplus_p);
int CPXPUBLIC
   CPXgetcolname  (CPXCENVptr env, CPXCLPptr lp, char **name,
                   char *namestore, int storespace,
                   int *surplus_p, int begin, int end);
int CPXPUBLIC
   CPXgetrowname  (CPXCENVptr env, CPXCLPptr lp, char **name,
                   char *namestore, int storespace,
                   int *surplus_p, int begin, int end);
int CPXPUBLIC
   CPXgetcoef     (CPXCENVptr env, CPXCLPptr lp, int i, int j,
                   double *coef_p);
int CPXPUBLIC
   CPXgetrowindex (CPXCENVptr env, CPXCLPptr lp, const char *lname_str,
                   int *index_p);
int CPXPUBLIC
   CPXgetcolindex (CPXCENVptr env, CPXCLPptr lp, const char *lname_str,
                   int *index_p);
int CPXPUBLIC
   CPXgetprobtype (CPXCENVptr env, CPXCLPptr lp);


/* File Reading Routines */

int CPXPUBLIC
   CPXreadcopyprob     (CPXCENVptr env, CPXLPptr lp, const char *filename_str,
                        const char *filetype_str);
int CPXPUBLIC
   CPXreadcopybase     (CPXCENVptr env, CPXLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXreadcopyvec      (CPXCENVptr env, CPXLPptr lp, const char *filename_str);


/* File Writing Routines */

int CPXPUBLIC
   CPXwriteprob   (CPXCENVptr env, CPXCLPptr lp, const char *filename_str,
                   const char *filetype_str);
int CPXPUBLIC
   CPXmbasewrite  (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXvecwrite    (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXwritesol    (CPXCENVptr env, CPXCLPptr lp, const char *filename_str,
                   const char *filetype_str);
int CPXPUBLIC
CPXiiswrite    (CPXCENVptr env, CPXLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXembwrite    (CPXCENVptr env, CPXLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXdperwrite   (CPXCENVptr env, CPXLPptr lp, const char *filename_str,
                   double epsilon);
int CPXPUBLIC
   CPXpperwrite   (CPXCENVptr env, CPXLPptr lp, const char *filename_str,
                   double epsilon);
int CPXPUBLIC
   CPXpreslvwrite (CPXCENVptr env, CPXLPptr lp, const char *filename_str,
                   double *objoff_p);
int CPXPUBLIC
   CPXdualwrite   (CPXCENVptr env, CPXCLPptr lp, const char *filename_str,
                   double *objshift_p);


/* Parameter Setting and Query Routines */

int CPXPUBLIC
   CPXsetdefaults  (CPXENVptr env);
int CPXPUBLIC
   CPXsetintparam  (CPXENVptr env, int whichparam, int newvalue);
int CPXPUBLIC
   CPXsetdblparam  (CPXENVptr env, int whichparam, double newvalue);
int CPXPUBLIC
   CPXsetstrparam  (CPXENVptr env, int whichparam, const char *newvalue_str);
int CPXPUBLIC
   CPXgetintparam  (CPXCENVptr env, int whichparam, int *value_p);
int CPXPUBLIC
   CPXgetdblparam  (CPXCENVptr env, int whichparam, double *value_p);
int CPXPUBLIC
   CPXgetstrparam  (CPXCENVptr env, int whichparam, char *value_str);
int CPXPUBLIC
   CPXinfointparam (CPXCENVptr env, int whichparam, int *defvalue_p,
                    int *minvalue_p, int *maxvalue_p);
int CPXPUBLIC
   CPXinfodblparam (CPXCENVptr env, int whichparam,
                    double *defvalue_p, double *minvalue_p,
                    double *maxvalue_p);
int CPXPUBLIC
   CPXinfostrparam (CPXCENVptr env, int whichparam,
                    char *defvalue_str);
int CPXPUBLIC
   CPXgetparamname (CPXCENVptr env, int whichparam,
                    char *name_str);
int CPXPUBLIC
   CPXgetparamnum  (CPXCENVptr env, char *name_str,
                    int *whichparam_p);


/* Utility Routines */

CPXCCHARptr CPXPUBLIC
   CPXversion            (CPXCENVptr env);
CPXENVptr CPXPUBLIC
   CPXopenCPLEX          (int *status_p);
CPXENVptr CPXPUBLIC
   CPXopenCPLEXruntime   (int *status_p, int serialnum,
                          const char *licenvstring_str);
int CPXPUBLIC
   CPXcloseCPLEX         (CPXENVptr *env_p);

#define CPXRegisterLicense CPXsetstaringsol
int CPXPUBLIC
   CPXRegisterLicense    (const char *ilm_license_str,
                          int ilm_license_signature);
CPXENVptr CPXPUBLIC
   CPXparenv             (CPXENVptr env, int *status_p);
int CPXPUBLIC
   CPXfreeparenv         (CPXENVptr env, CPXENVptr *child_p);
 

/* Data Debugging Routines */

int CPXPUBLIC
   CPXcheckcopylp       (CPXCENVptr env, CPXCLPptr lp, int numcols,
                         int numrows, int objsen, const double *obj,
                         const double *rhs, const char *sense,
                         const int *matbeg, const int *matcnt,
                         const int *matind, const double *matval,
                         const double *lb, const double *ub,
                         const double *rngval);
int CPXPUBLIC
   CPXcheckcopylpwnames (CPXCENVptr env, CPXCLPptr lp, int numcols,
                         int numrows, int objsen, const double *obj,
                         const double *rhs, const char *sense,
                         const int *matbeg, const int *matcnt,
                         const int *matind, const double *matval,
                         const double *lb, const double *ub,
                         const double *rngval,
                         char **colname, char **rowname);

int CPXPUBLIC
   CPXcheckaddcols      (CPXCENVptr env, CPXCLPptr lp, int ccnt,
                         int nzcnt, const double *obj, const int *cmatbeg,
                         const int *cmatind, const double *cmatval,
                         const double *lb, const double *ub, char **colname);
int CPXPUBLIC
   CPXcheckaddrows      (CPXCENVptr env, CPXCLPptr lp, int ccnt,
                         int rcnt, int nzcnt, const double *rhs,
                         const char *sense, const int *rmatbeg,
                         const int *rmatind, const double *rmatval,
                         char **colname, char **rowname);
int CPXPUBLIC
   CPXcheckchgcoeflist  (CPXCENVptr env, CPXCLPptr lp, int numcoefs,
                         const int *rowlist, const int *collist,
                         const double *vallist);
int CPXPUBLIC
   CPXcheckvals         (CPXCENVptr env, CPXCLPptr lp, int cnt,
                         const int *rowind, const int *colind,
                         const double *values);


/* Message Handling Routines */

int CPXPUBLIC
   CPXgetchannels       (CPXCENVptr env, CPXCHANNELptr *cpxresults_p,
                         CPXCHANNELptr *cpxwarning_p,
                         CPXCHANNELptr *cpxerror_p,
                         CPXCHANNELptr *cpxlog_p);
int CPXPUBLIC
   CPXsetlogfile        (CPXENVptr env, CPXFILEptr lfile);
int CPXPUBLIC
   CPXgetlogfile        (CPXCENVptr env, CPXFILEptr *logfile_p);
int CPXPUBVARARGS
   CPXmsg               (CPXCHANNELptr channel, const char *format, ...);
int CPXPUBLIC
   CPXmsgstr            (CPXCHANNELptr channel, const char *msg_str);
void CPXPUBLIC
   CPXflushchannel      (CPXCENVptr env, CPXCHANNELptr channel);
int CPXPUBLIC
   CPXflushstdchannels  (CPXCENVptr env);
CPXCHANNELptr CPXPUBLIC
   CPXaddchannel        (CPXENVptr env);
int CPXPUBLIC
   CPXaddfpdest         (CPXCENVptr env, CPXCHANNELptr channel,
                         CPXFILEptr fileptr);
int CPXPUBLIC
   CPXdelfpdest         (CPXCENVptr env, CPXCHANNELptr channel,
                         CPXFILEptr fileptr);
int CPXPUBLIC
   CPXaddfuncdest       (CPXCENVptr env, CPXCHANNELptr channel,
                         void *handle,
                         void (CPXPUBLIC *msgfunction)(void *, const char *));
int CPXPUBLIC
   CPXdelfuncdest       (CPXCENVptr env, CPXCHANNELptr channel,
                         void *handle,
                         void (CPXPUBLIC *msgfunction)(void *, const char *));
void CPXPUBLIC
   CPXdelchannel        (CPXENVptr env, CPXCHANNELptr *channel_p);
void CPXPUBLIC
   CPXdisconnectchannel (CPXCENVptr env, CPXCHANNELptr channel);

CPXCCHARptr CPXPUBLIC
   CPXgeterrorstring    (CPXCENVptr env, int errcode, char *buffer_str);


/* Callback Routines */

int CPXPUBLIC
   CPXsetlpcallbackfunc  (CPXENVptr env,
                          int (CPXPUBLIC *callback)(CPXCENVptr,
                          void *, int, void *), void *cbhandle);
int CPXPUBLIC
   CPXsetnetcallbackfunc (CPXENVptr env,
                          int (CPXPUBLIC *callback)(CPXCENVptr,
                          void *, int, void *), void *cbhandle);
int CPXPUBLIC
   CPXgetcallbackinfo    (CPXCENVptr env, void *cbdata,
                          int wherefrom, int whichinfo,
                          void *result_p);

int CPXPUBLIC
   CPXgetlpcallbackfunc  (CPXCENVptr env,
                          int (CPXPUBLIC **callback_p)(CPXCENVptr,
                          void *, int, void *), void **cbhandle_p);
int CPXPUBLIC
   CPXgetnetcallbackfunc (CPXCENVptr env,
                          int (CPXPUBLIC **callback_p)(CPXCENVptr,
                          void *, int, void *), void **cbhandle_p);


/* Portability Routines */

CPXFILEptr CPXPUBLIC
   CPXfopen     (const char *filename_str, const char *type_str);
int CPXPUBLIC
   CPXfclose    (CPXFILEptr stream);
int CPXPUBLIC
   CPXfputs     (const char *s_str, CPXFILEptr stream);
CPXVOIDptr CPXPUBLIC
   CPXmalloc    (size_t size);
CPXVOIDptr CPXPUBLIC
   CPXrealloc   (void *ptr, size_t size);
CPXVOIDptr CPXPUBLIC
   CPXmemcpy    (void *s1, void *s2, size_t n);
void CPXPUBLIC
   CPXfree      (void *ptr);
int CPXPUBLIC
   CPXstrlen    (const char *s_str);
CPXCHARptr CPXPUBLIC
   CPXstrcpy    (char *s1_str, const char *s2_str);
int CPXPUBLIC 
   CPXputenv    (const char *envsetting_str);


/* External Interface Routines */

int CPXPUBLIC
   CPXEgetThreadNumber(CPXCENVptr env);

int CPXPUBLIC
   CPXEsetnamefunctions (CPXENVptr env, void* userdata,
                         const char* (CPXPUBLIC *getcname)(void*, int),
                         const char* (CPXPUBLIC *getrname)(void*, int));
CPXVOIDptr CPXPUBLIC
   CPXEgetCache         (CPXLPptr lp);

int CPXPUBLIC
   CPXEcacheNewCols     (CPXCENVptr env, CPXLPptr lp,
                         int ccnt, const double *zobj, const double *zlb,
                         const double *zub, const char *zctype,
                         const char *const *zcname);
int CPXPUBLIC
   CPXEcacheNewRows     (CPXCENVptr env, CPXLPptr lp,
                         int rcnt, const double *zrhs, const char *zsense,
                         const double *rngval,
                         const char *const *zrname);
int CPXPUBLIC
   CPXEcacheNewNZsByNZ  (CPXCENVptr env, CPXLPptr lp,
                         int nzcnt, const int *rowlist, const int *collist,
                         const double *vallist);
int CPXPUBLIC
   CPXEgetorigcolind    (CPXCENVptr env, CPXCLPptr lp, int j);
 
int CPXPUBLIC
   CPXEgetorigrowind    (CPXCENVptr env, CPXCLPptr lp, int i);

double CPXPUBLIC
   CPXEgetbigreal       (CPXCENVptr env);

int CPXPUBLIC
   CPXEispromotion      (CPXCENVptr env, int rspace, int cspace);


/* Advanced LP Routines */ 

double CPXPUBLIC
   CPXcheckax         (CPXCENVptr env, CPXCLPptr lp, int *imax_p,
                       int scalrimtype);
double CPXPUBLIC
   CPXcheckpib        (CPXCENVptr env, CPXCLPptr lp, int *ijmax_p,
                       int scalrimtype);
int CPXPUBLIC
   CPXgetbhead        (CPXCENVptr env, CPXCLPptr lp, int *head,
                       double *x);
int CPXPUBLIC
   CPXbinvcol         (CPXCENVptr env, CPXCLPptr lp, int j, double *x);
int CPXPUBLIC
   CPXbinvrow         (CPXCENVptr env, CPXCLPptr lp, int i, double *y);
int CPXPUBLIC
   CPXbinvacol        (CPXCENVptr env, CPXCLPptr lp, int j, double *x);
int CPXPUBLIC
   CPXbinvarow        (CPXCENVptr env, CPXCLPptr lp, int i, double *z);
int CPXPUBLIC
   CPXftran           (CPXCENVptr env, CPXCLPptr lp, double *x);
int CPXPUBLIC
   CPXbtran           (CPXCENVptr env, CPXCLPptr lp, double *y);
int CPXPUBLIC
   CPXgetijrow        (CPXCENVptr env, CPXCLPptr lp, int i, int j,
                       int *row_p);
int CPXPUBLIC
   CPXgetray          (CPXCENVptr env, CPXCLPptr lp, double *z);
double CPXPUBLIC
   CPXgetkappa        (CPXCENVptr env, CPXCLPptr lp);
double CPXPUBLIC
   CPXgetExactkappa   (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetweight       (CPXCENVptr env, CPXCLPptr lp, int rcnt,
                       const int *rmatbeg, const int *rmatind,
                       const double *rmatval,
                       double *weight, int dpriind);
int CPXPUBLIC
   CPXmdleave         (CPXCENVptr env, CPXLPptr lp, const int *goodlist,
                       int goodlen, double *downratio,
                       double *upratio);
int CPXPUBLIC
   CPXstrongbranch    (CPXCENVptr env, CPXLPptr lp, const int *goodlist,
                       int goodlen, double *downpen, double *uppen,
                       int itlim);
int CPXPUBLIC
   CPXdualfarkas      (CPXCENVptr env, CPXCLPptr lp, double *y,
                       double *proof_p);
int CPXPUBLIC
   CPXgetobjoffset    (CPXCENVptr env, CPXCLPptr lp,
                       double *objoffset_p);

int CPXPUBLIC
   CPXcopypartialbase (CPXCENVptr env, CPXLPptr lp,
                       int ccnt, const int *cindices, const int *cstat,
                       int rcnt, const int *rindices, const int *rstat);
int CPXPUBLIC
   CPXgetbasednorms   (CPXCENVptr env, CPXCLPptr lp, int *cstat,
                       int *rstat, double *dnorm);
int CPXPUBLIC
   CPXcopybasednorms  (CPXCENVptr env, CPXLPptr lp, const int *cstat,
                       const int *rstat, const double *dnorm);
int CPXPUBLIC
   CPXgetdnorms       (CPXCENVptr env, CPXCLPptr lp, double *norm,
                       int *head, int *len_p);
int CPXPUBLIC
   CPXcopydnorms      (CPXCENVptr env, CPXLPptr lp, const double *norm,
                       const int *head, int len);
void CPXPUBLIC
   CPXkilldnorms      (CPXLPptr lp);
int CPXPUBLIC
   CPXgetpnorms       (CPXCENVptr env, CPXCLPptr lp, double *cnorm,
                       double *rnorm, int *len_p);
int CPXPUBLIC
   CPXcopypnorms      (CPXCENVptr env, CPXLPptr lp, const double *cnorm,
                       const double *rnorm, int len);
void CPXPUBLIC
   CPXkillpnorms      (CPXLPptr lp);
int CPXPUBLIC
   CPXpivotin         (CPXCENVptr env, CPXLPptr lp, const int *rlist,
                       int rlen);
int CPXPUBLIC
   CPXpivotout        (CPXCENVptr env, CPXLPptr lp, const int *clist,
                       int clen);
int CPXPUBLIC
   CPXunscaleprob     (CPXCENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXtightenbds      (CPXCENVptr env, CPXLPptr lp, int cnt,
                       const int *indices, const char *lu, const double *bd);


/* Advanced Presolve Routines */

int CPXPUBLIC
   CPXpresolve      (CPXCENVptr env, CPXLPptr lp, int method);
int CPXPUBLIC
   CPXbasicpresolve (CPXCENVptr env, CPXLPptr lp, double *redlb,
                     double *redub, int *rstat);
int CPXPUBLIC
   CPXslackfromx    (CPXCENVptr env, CPXCLPptr lp, const double *x,
                     double *slack);
int CPXPUBLIC
   CPXdjfrompi      (CPXCENVptr env, CPXCLPptr lp, const double *pi,
                     double *dj);
int CPXPUBLIC
   CPXqpdjfrompi    (CPXCENVptr env, CPXCLPptr lp, const double *pi,
                     const double *x, double *dj);
int CPXPUBLIC
   CPXfreepresolve  (CPXCENVptr env, CPXLPptr lp);
int CPXPUBLIC
   CPXgetredlp      (CPXCENVptr env, CPXCLPptr lp, CPXCLPptr *redlp_p);
int CPXPUBLIC
   CPXcrushx        (CPXCENVptr env, CPXCLPptr lp, const double *x,
                     double *prex);
int CPXPUBLIC
   CPXuncrushx      (CPXCENVptr env, CPXCLPptr lp, double *x,
                     double *prex);
int CPXPUBLIC
   CPXcrushpi       (CPXCENVptr env, CPXCLPptr lp, const double *pi,
                     double *prepi);
int CPXPUBLIC
   CPXuncrushpi     (CPXCENVptr env, CPXCLPptr lp, double *pi,
                     const double *prepi);
int CPXPUBLIC
   CPXqpuncrushpi   (CPXCENVptr env, CPXCLPptr lp, double *pi,
                     const double *prepi, const double *x);
int CPXPUBLIC
   CPXcrushform     (CPXCENVptr env, CPXCLPptr lp, int len, const int *ind,
                     const double *val, int *plen_p, double *poffset_p,
                     int *pind, double *pval);
int CPXPUBLIC
   CPXuncrushform   (CPXCENVptr env, CPXCLPptr lp, int plen,
                     const int *pind, const double *pval, int *len_p,
                     double *offset_p, int *ind, double *val);
int CPXPUBLIC
   CPXgetprestat    (CPXCENVptr env, CPXCLPptr lp, int *prestat_p,
                     int *pcstat, int *prstat, int *ocstat, 
                     int *orstat);
int CPXPUBLIC
   CPXcopyprotected (CPXCENVptr env, CPXLPptr lp, int cnt,
                     const int *indices);
int CPXPUBLIC
   CPXgetprotected  (CPXCENVptr env, CPXCLPptr lp, int *cnt_p,
                     int *indices, int pspace, int *surplus_p);


/* Old-Style File Reading and Writing */

int CPXPUBLIC
   CPXlpread  (CPXCENVptr env, const char *filename_str,
               int *numcols_p, int *numrows_p,
               int *objsen_p, double **obj_p, double **rhs_p,
               char **sense_p, int **matbeg_p, int **matcnt_p,
               int **matind_p, double **matval_p,
               double **lb_p, double **ub_p,
               char **objname_p, char **rhsname_p,
               char ***colname_p, char **colnamestore_p,
               char ***rowname_p, char **rownamestore_p,
               int *colspace_p, int *rowspace_p, int *nzspace_p,
               unsigned *colnamespace_p, unsigned *rownamespace_p);
int CPXPUBLIC
   CPXlpmread (CPXCENVptr env, const char *filename_str,
               int *numcols_p, int *numrows_p,
               int *objsen_p, double **obj_p, double **rhs_p,
               char **sense_p, int **matbeg_p, int **matcnt_p,
               int **matind_p, double **matval_p,
               double **lb_p, double **ub_p,
               char **objname_p, char **rhsname_p,
               char ***colname_p, char **colnamestore_p,
               char ***rowname_p, char **rownamestore_p,
               int *colspace_p, int *rowspace_p, int *nzspace_p,
               unsigned *colnamespace_p, unsigned *rownamespace_p,
               char **ctype_p);
int CPXPUBLIC
   CPXlpqread (CPXCENVptr env, const char *filename_str,
               int *numcols_p, int *numrows_p,
               int *objsen_p, double **obj_p, double **rhs_p,
               char **sense_p, int **matbeg_p, int **matcnt_p,
               int **matind_p, double **matval_p,
               double **lb_p, double **ub_p,
               char **objname_p, char **rhsname_p,
               char ***colname_p, char **colnamestore_p,
               char ***rowname_p, char **rownamestore_p,
               int *colspace_p, int *rowspace_p, int *nzspace_p,
               unsigned *colnamespace_p, unsigned *rownamespace_p,
               char **ctype_p, int **qmatbeg_p, int **qmatcnt_p,
               int **qmatind_p, double **qmatval_p, int *qnzspace_p);

/* Extra rim vector types used in 'rimtype' array */

#define EXTRANROW                         1
#define EXTRARHS                          2
#define EXTRARNG                          3
#define EXTRABDL                          4
#define EXTRABDU                          5  

int CPXPUBLIC
   CPXmpsread  (CPXCENVptr env, const char *filename_str,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p);
int CPXPUBLIC
   CPXmpsmread (CPXCENVptr env, const char *filename_str,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p,
                char **ctype_p, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sosbeg_p, int **sosind_p,
                double **soswt_p);
int CPXPUBLIC
   CPXmpsqread (CPXCENVptr env, const char *filename_str,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p,
                char **ctype_p, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sosbeg_p, int **sosind_p,
                double **soswt_p,
                int **qmatbeg_p, int **qmatcnt_p, int **qmatind_p,
                double **qmatval_p, int *qnzspace_p);

int CPXPUBLIC
   CPXsavread  (CPXCENVptr env, const char *filename_str,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p, int **cstat_p,
                int **rstat_p);
int CPXPUBLIC
   CPXsavmread (CPXCENVptr env, const char *filename_str,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p,
                char **ctype_p, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sospri_p, int **sosbeg_p,
                int **sosind_p, double **soswt_p,
                int **cstat_p, int **rstat_p);
int CPXPUBLIC
   CPXsavqread (CPXCENVptr env, const char *filename_str,
                int *numcols_p, int *numrows_p, int *numrims_p,
                int *objsen_p, double **obj_p, double **rhs_p,
                char **sense_p, int **matbeg_p, int **matcnt_p,
                int **matind_p, double **matval_p,
                double **lb_p, double **ub_p, double **rngval_p,
                int **freerowind_p, int **rimtype_p, int **rimbeg_p,
                int **rimcnt_p, int **rimind_p, double **rimval_p,
                char **dataname_p, char **objname_p,
                char **rhsname_p, char **rngname_p, char **bndname_p,
                char ***colname_p, char **colnamestore_p,
                char ***rowname_p, char **rownamestore_p,
                char ***rimname_p, char **rimnamestore_p,
                int *colspace_p, int *rowspace_p, int *nzspace_p,
                int *rimspace_p, int *rimnzspace_p,
                unsigned *colnamespace_p, unsigned *rownamespace_p,
                unsigned *rimnamespace_p,
                char **ctype_p, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sospri_p, int **sosbeg_p,
                int **sosind_p, double **soswt_p,
                int **qmatbeg_p, int **qmatcnt_p, int **qmatind_p,
                double **qmatval_p, int *qnzspace_p,
                int **cstat_p, int **rstat_p);

int CPXPUBLIC
   CPXmbaseread (CPXCENVptr env, const char *filename_str,
                 int numcols, int numrows,
                 char **colname, char **rowname,
                 int *cstat, int *rstat);
int CPXPUBLIC
   CPXparread   (CPXCENVptr env, const char *filename_str,
                 int *numcols_p, int *numrows_p,
                 int *objsen_p, double **obj_p, double **rhs_p,
                 char **sense_p, int **matbeg_p, int **matcnt_p,
                 int **matind_p, double **matval_p,
                 double **lb_p, double **ub_p,
                 int *colspace_p, int *rowspace_p, int *nzspace_p,
                 char **ctype_p);


int CPXPUBLIC
   CPXlpwrite     (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXlprewrite   (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXmpswrite    (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXmpsrewrite  (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXsavwrite    (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXbinsolwrite (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXtxtsolwrite (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXsolwrite    (CPXCENVptr env, CPXCLPptr lp,
                   void (CPXPUBLIC *hsection) (CPXCENVptr, CPXCLPptr,
                                               void *),
                   void (CPXPUBLIC *rsectionbeg) (void *),
                   void (CPXPUBLIC *csectionbeg) (void *),
                   void (CPXPUBLIC *write_entry) (void *, int, int,
                                                  char *, char *,
                                                  double, double,
                                                  double, double,
                                                  double),
                   void (CPXPUBLIC *sectionend) (void *),
                   void *info);

#ifdef __cplusplus
}
#endif

#endif /* __CPXDEFS_H */

/*------------------------------------------------------------------------*/
/*  File: BARDEFS.h                                                       */
/*  Version 8.1                                                           */
/*                                                                        */
/*  Copyright (C) 1997-2002 by ILOG.                                      */
/*  All Rights Reserved.                                                  */
/*                                                                        */
/*  N O T I C E                                                           */
/*                                                                        */
/*  THIS MATERIAL IS CONSIDERED A TRADE SECRET BY ILOG.                   */
/*  UNAUTHORIZED ACCESS, USE, REPRODUCTION OR DISTRIBUTION IS PROHIBITED. */
/*------------------------------------------------------------------------*/
/*  $Revision: 1.1 $                                           */
/*  Last modified on $Date: 2003/08/05 13:58:29 $ by $Author: elf $ */
/*------------------------------------------------------------------------*/


#ifndef __BARDEFS_H
#define __BARDEFS_H

#ifdef __cplusplus
extern "C" {
#endif

#define CPX_STAT_OPTIMAL_FACE_UNBOUNDED   20
#define CPX_STAT_ABORT_PRIM_OBJ_LIM       21
#define CPX_STAT_ABORT_DUAL_OBJ_LIM       22


/* Barrier parameters */

#define CPX_PARAM_BARDSTART            3001
#define CPX_PARAM_BAREPCOMP            3002
#define CPX_PARAM_BARGROWTH            3003
#define CPX_PARAM_BAROBJRNG            3004
#define CPX_PARAM_BARPSTART            3005
#define CPX_PARAM_BARVARUP             3006
#define CPX_PARAM_BARALG               3007
#define CPX_PARAM_BARCOLNZ             3009
#define CPX_PARAM_BARDISPLAY           3010
#define CPX_PARAM_BARITLIM             3012
#define CPX_PARAM_BARMAXCOR            3013
#define CPX_PARAM_BARORDER             3014
#define CPX_PARAM_BARROWSDEN           3015
#define CPX_PARAM_BARTHREADS           3016
#define CPX_PARAM_BARSTARTALG          3017
#define CPX_PARAM_BARCROSSALG          3018
#define CPX_PARAM_BAROOC               3019

/* Optimizing Problems */

#define CPX_BARORDER_AUTO 0
#define CPX_BARORDER_AMD  1
#define CPX_BARORDER_AMF  2
#define CPX_BARORDER_ND   3


int CPXPUBLIC
   CPXhybbaropt (CPXCENVptr env, CPXLPptr lp, int method);
int CPXPUBLIC
   CPXbaropt    (CPXCENVptr env, CPXLPptr lp);

void CPXPUBLIC
   CPXEgeneric_lock   (volatile int *lock);
void CPXPUBLIC
   CPXEgeneric_unlock (volatile int *lock);

/* Advanced Barrier Routines */

int CPXPUBLIC
   CPXsetorderhookfunc (CPXENVptr env,
                        int (CPXPUBLIC *orderhook)(CPXCENVptr, 
                        int, int *, int **, int *));
void CPXPUBLIC
   CPXgetorderhookfunc (CPXCENVptr env,
                        int (CPXPUBLIC **orderhook_p)(CPXCENVptr, 
                        int, int *, int **, int *));


#ifdef __cplusplus
}
#endif

#endif  /* __BARDEFS_H */

/*------------------------------------------------------------------------*/
/*  File: MIPDEFS.h                                                       */
/*  Version 8.1                                                           */
/*                                                                        */
/*  Copyright (C) 1997-2002 by ILOG.                                      */
/*  All Rights Reserved.                                                  */
/*                                                                        */
/*  N O T I C E                                                           */
/*                                                                        */
/*  THIS MATERIAL IS CONSIDERED A TRADE SECRET BY ILOG.                   */
/*  UNAUTHORIZED ACCESS, USE, REPRODUCTION OR DISTRIBUTION IS PROHIBITED. */
/*------------------------------------------------------------------------*/
/*  $Revision: 1.1 $                                           */
/*  Last modified on $Date: 2003/08/05 13:58:29 $ by $Author: elf $ */
/*------------------------------------------------------------------------*/


#ifndef __MIPDEFS_H
#define __MIPDEFS_H

#ifdef __cplusplus
extern "C" {
#endif


/* MIP error codes */

#define CPXERR_BOUNDS_BINARY          3002
#define CPXERR_NOT_MIP                3003
#define CPXERR_SOS_BOUNDS             3004
#define CPXERR_BAD_PRIORITY           3006
#define CPXERR_ORDER_BAD_DIRECTION    3007
#define CPXERR_ARRAY_BAD_SOS_TYPE     3009
#define CPXERR_UNIQUE_WEIGHTS         3010
#define CPXERR_BOUNDS_INT             3011
#define CPXERR_BAD_DIRECTION          3012
#define CPXERR_NO_SOS                 3015
#define CPXERR_NO_ORDER               3016
#define CPXERR_NO_INT_SOLN            3017
#define CPXERR_INT_TOO_BIG            3018
#define CPXERR_SUBPROB_SOLVE          3019
#define CPXERR_NO_MIPSTART            3020
#define CPXERR_BAD_CTYPE              3021
#define CPXERR_SEMI_BDS               3022
#define CPXERR_NO_INT_X               3023
       
#define CPXERR_MISS_SOS_TYPE          3301
       
#define CPXERR_TRE_FILE_DATA          3401
#define CPXERR_TRE_FILE_WRITE         3402
#define CPXERR_TRE_FILE_VERSION       3403
#define CPXERR_TRE_FILE_OBJ           3404
#define CPXERR_TRE_FILE_COLS          3405
#define CPXERR_TRE_FILE_ROWS          3406
#define CPXERR_TRE_FILE_INTS          3407
#define CPXERR_TRE_FILE_NONZ          3408
#define CPXERR_TRE_FILE_TYPES         3409
#define CPXERR_TRE_FILE_PRESOLVE      3410
#define CPXERR_NO_TREE                3412
#define CPXERR_TREE_MEMORY_LIMIT      3413
#define CPXERR_TRE_FILE_FORMAT        3414
       
#define CPXERR_NODE_ON_DISK           3504
       
#define CPXERR_PTHREAD_MUTEX_INIT     3601
#define CPXERR_PTHREAD_CREATE         3603

/* MIP emphasis settings */

#define CPX_MIPEMPHASIS_BALANCED     0
#define CPX_MIPEMPHASIS_FEASIBILITY  1
#define CPX_MIPEMPHASIS_OPTIMALITY   2
#define CPX_MIPEMPHASIS_BESTBOUND    3

/* Values for sostype and branch type */

#define CPX_TYPE_VAR                    '0'
#define CPX_TYPE_SOS1                   '1'
#define CPX_TYPE_SOS2                   '2'
#define CPX_TYPE_USER                   'X'

/* Variable selection values */

#define CPX_VARSEL_MININFEAS            -1
#define CPX_VARSEL_DEFAULT               0
#define CPX_VARSEL_MAXINFEAS             1
#define CPX_VARSEL_PSEUDO                2
#define CPX_VARSEL_STRONG                3
#define CPX_VARSEL_PSEUDOREDUCED         4

/* Node selection values */

#define CPX_NODESEL_DFS                  0
#define CPX_NODESEL_BESTBOUND            1
#define CPX_NODESEL_BESTEST              2
#define CPX_NODESEL_BESTEST_ALT          3

/* Values for generated priority order */

#define CPX_MIPORDER_COST                1 
#define CPX_MIPORDER_BOUNDS              2 
#define CPX_MIPORDER_SCALEDCOST          3

/* Values for direction array */

#define CPX_BRANCH_GLOBAL                0
#define CPX_BRANCH_DOWN                 -1
#define CPX_BRANCH_UP                    1

/* Values for CPX_PARAM_BRDIR */

#define CPX_BRDIR_DOWN                  -1
#define CPX_BRDIR_AUTO                   0
#define CPX_BRDIR_UP                     1
 
/* Use of MIP start values */

#define CPX_MIPSTART_NODE0               1

/* MIP Problem status codes */

#define CPXMIP_OPTIMAL                 101
#define CPXMIP_OPTIMAL_TOL             102
#define CPXMIP_INFEASIBLE              103
#define CPXMIP_SOL_LIM                 104
#define CPXMIP_NODE_LIM_FEAS           105
#define CPXMIP_NODE_LIM_INFEAS         106
#define CPXMIP_TIME_LIM_FEAS           107
#define CPXMIP_TIME_LIM_INFEAS         108
#define CPXMIP_FAIL_FEAS               109
#define CPXMIP_FAIL_INFEAS             110
#define CPXMIP_MEM_LIM_FEAS            111
#define CPXMIP_MEM_LIM_INFEAS          112
#define CPXMIP_ABORT_FEAS              113
#define CPXMIP_ABORT_INFEAS            114
#define CPXMIP_OPTIMAL_INFEAS          115
#define CPXMIP_FAIL_FEAS_NO_TREE       116
#define CPXMIP_FAIL_INFEAS_NO_TREE     117
#define CPXMIP_UNBOUNDED               118
#define CPXMIP_INForUNBD               119

/* Algorithm types for MIP node algorithms */

#define CPX_NODEALG_PRIMAL                    1
#define CPX_NODEALG_DUAL                      2
#define CPX_NODEALG_HYBNETOPT                 3
#define CPX_NODEALG_BARRIER                   4
#define CPX_NODEALG_SIFTING                   5

/* Callback values for wherefrom */

#define CPX_CALLBACK_MIP               101
#define CPX_CALLBACK_MIP_BRANCH        102
#define CPX_CALLBACK_MIP_NODE          103
#define CPX_CALLBACK_MIP_HEURISTIC     104
#define CPX_CALLBACK_MIP_SOLVE         105
#define CPX_CALLBACK_MIP_CUT           106
#define CPX_CALLBACK_MIP_PROBE         107
#define CPX_CALLBACK_MIP_FRACCUT       108
#define CPX_CALLBACK_MIP_DISJCUT       109
#define CPX_CALLBACK_MIP_FLOWMIR       110
#define CPX_CALLBACK_MIP_INCUMBENT     111
#define CPX_CALLBACK_MIP_DELETENODE    112
/* Be sure to check the LP values */

/* Values for getcallbackinfo function */

#define CPX_CALLBACK_INFO_BEST_INTEGER        101
#define CPX_CALLBACK_INFO_BEST_REMAINING      102
#define CPX_CALLBACK_INFO_NODE_COUNT          103
#define CPX_CALLBACK_INFO_NODES_LEFT          104
#define CPX_CALLBACK_INFO_MIP_ITERATIONS      105
#define CPX_CALLBACK_INFO_CUTOFF              106
#define CPX_CALLBACK_INFO_CLIQUE_COUNT        107
#define CPX_CALLBACK_INFO_COVER_COUNT         108
#define CPX_CALLBACK_INFO_MIP_FEAS            109
#define CPX_CALLBACK_INFO_FLOWCOVER_COUNT     110
#define CPX_CALLBACK_INFO_GUBCOVER_COUNT      111
#define CPX_CALLBACK_INFO_IMPLBD_COUNT        112
#define CPX_CALLBACK_INFO_PROBE_PHASE         113
#define CPX_CALLBACK_INFO_PROBE_PROGRESS      114
#define CPX_CALLBACK_INFO_FRACCUT_COUNT       115
#define CPX_CALLBACK_INFO_FRACCUT_PROGRESS    116
#define CPX_CALLBACK_INFO_DISJCUT_COUNT       117
#define CPX_CALLBACK_INFO_DISJCUT_PROGRESS    118
#define CPX_CALLBACK_INFO_FLOWPATH_COUNT      119
#define CPX_CALLBACK_INFO_MIRCUT_COUNT        120
#define CPX_CALLBACK_INFO_FLOWMIR_PROGRESS    121
#define CPX_CALLBACK_INFO_MY_THREAD_NUM       122
#define CPX_CALLBACK_INFO_USER_THREADS        123

/* Values for getcallbacknodeinfo function */

#define CPX_CALLBACK_INFO_NODE_SIINF          201
#define CPX_CALLBACK_INFO_NODE_NIINF          202
#define CPX_CALLBACK_INFO_NODE_ESTIMATE       203
#define CPX_CALLBACK_INFO_NODE_DEPTH          204
#define CPX_CALLBACK_INFO_NODE_OBJVAL         205
#define CPX_CALLBACK_INFO_NODE_TYPE           206
#define CPX_CALLBACK_INFO_NODE_VAR            207
#define CPX_CALLBACK_INFO_NODE_SOS            208
#define CPX_CALLBACK_INFO_NODE_SEQNUM         209
#define CPX_CALLBACK_INFO_NODE_USERHANDLE     210
#define CPX_CALLBACK_INFO_NODE_NODENUM        211

/* Values for getcallbacksosinfo function */

#define CPX_CALLBACK_INFO_SOS_TYPE            240
#define CPX_CALLBACK_INFO_SOS_SIZE            241
#define CPX_CALLBACK_INFO_SOS_IS_FEASIBLE     242
#define CPX_CALLBACK_INFO_SOS_PRIORITY        243
#define CPX_CALLBACK_INFO_SOS_MEMBER_INDEX    244
#define CPX_CALLBACK_INFO_SOS_MEMBER_REFVAL   246
#define CPX_CALLBACK_INFO_SOS_NUM             247
/* Be sure to check the LP values */


/* Old MIP node algorithm definitions */

#ifndef CPX_MODERN

#define CPXALG_NONE                      CPX_ALG_NONE
#define CPXALG_PRIMAL                    CPX_NODEALG_PRIMAL
#define CPXALG_DUAL                      CPX_NODEALG_DUAL
#define CPXALG_NETWORK                   CPX_NODEALG_HYBNETOPT
#define CPXALG_BARRIER                   CPX_NODEALG_HYBBAROPT
#define CPXALG_DUAL_BARRIER              CPX_NODEALG_DUAL_HYBBAROPT
#define CPXALG_BARRIER_NO_CROSSOVER      CPX_NODEALG_BARRIER

#endif

/* Callback return codes */

#define CPX_CALLBACK_DEFAULT             0
#define CPX_CALLBACK_SET                 2
#define CPX_CALLBACK_FAIL                1

/* For CPXgetnodeintfeas() */
#define CPX_INTEGER_FEASIBLE             0
#define CPX_INTEGER_INFEASIBLE           1
#define CPX_IMPLIED_INTEGER_FEASIBLE     2

/* MIP Parameter numbers */
#define CPX_PARAM_BRDIR                2001
#define CPX_PARAM_BTTOL                2002
#define CPX_PARAM_CLIQUES              2003
#define CPX_PARAM_COEREDIND            2004
#define CPX_PARAM_COVERS               2005
#define CPX_PARAM_CUTLO                2006
#define CPX_PARAM_CUTUP                2007
#define CPX_PARAM_EPAGAP               2008
#define CPX_PARAM_EPGAP                2009
#define CPX_PARAM_EPINT                2010
#define CPX_PARAM_HEURISTIC            2011
#define CPX_PARAM_MIPDISPLAY           2012
#define CPX_PARAM_MIPINTERVAL          2013
#define CPX_PARAM_MIPTHREADS           2014
#define CPX_PARAM_INTSOLLIM            2015
#define CPX_PARAM_NODEFILEIND          2016
#define CPX_PARAM_NODELIM              2017
#define CPX_PARAM_NODESEL              2018
#define CPX_PARAM_OBJDIF               2019
#define CPX_PARAM_MIPORDIND            2020
#define CPX_PARAM_RELOBJDIF            2022
#define CPX_PARAM_STARTALG             2025
#define CPX_PARAM_SUBALG               2026
#define CPX_PARAM_TRELIM               2027
#define CPX_PARAM_VARSEL               2028
#define CPX_PARAM_BNDSTRENIND          2029
#define CPX_PARAM_HEURFREQ             2031
#define CPX_PARAM_MIPORDTYPE           2032
#define CPX_PARAM_CUTSFACTOR           2033
#define CPX_PARAM_RELAXPREIND          2034
#define CPX_PARAM_MIPSTART             2035
#define CPX_PARAM_PRESLVND             2037
#define CPX_PARAM_BBINTERVAL           2039
#define CPX_PARAM_FLOWCOVERS           2040
#define CPX_PARAM_IMPLBD               2041
#define CPX_PARAM_PROBE                2042
#define CPX_PARAM_GUBCOVERS            2044
#define CPX_PARAM_STRONGCANDLIM        2045
#define CPX_PARAM_STRONGITLIM          2046
#define CPX_PARAM_STRONGTHREADLIM      2047
#define CPX_PARAM_FRACCAND             2048
#define CPX_PARAM_FRACCUTS             2049
#define CPX_PARAM_FRACPASS             2050
#define CPX_PARAM_FLOWPATHS            2051
#define CPX_PARAM_MIRCUTS              2052
#define CPX_PARAM_DISJCUTS             2053
#define CPX_PARAM_AGGCUTLIM            2054
#define CPX_PARAM_MIPCBREDLP           2055    
#define CPX_PARAM_CUTPASS              2056
#define CPX_PARAM_MIPEMPHASIS          2058
#define CPX_PARAM_SYMMETRY             2059
#define CPX_PARAM_DIVETYPE             2060


/* Copying Data */

int CPXPUBLIC
   CPXcopyctype   (CPXCENVptr env, CPXLPptr lp, const char *xctype);
int CPXPUBLIC
   CPXcopyorder    (CPXCENVptr env, CPXLPptr lp, int cnt,
                    const int *indices, const int *priority,
                    const int *direction);
int CPXPUBLIC
   CPXcopysos      (CPXCENVptr env, CPXLPptr lp, int numsos,
                    int numsosnz, const char *sostype,
                    const int *sospri, const int *sosbeg,
                    const int *sosind, const double *soswt);
int CPXPUBLIC
   CPXcopymipstart (CPXCENVptr env, CPXLPptr lp, int cnt,
                    const int *indices, const double *value);


/* Optimizing Problems */

int CPXPUBLIC
   CPXmipopt     (CPXCENVptr env, CPXLPptr lp);


/* Accessing MIP Results */

int CPXPUBLIC
   CPXgetmipx        (CPXCENVptr env, CPXCLPptr lp, double *x,
                      int begin, int end);
int CPXPUBLIC
   CPXgetmipslack    (CPXCENVptr env, CPXCLPptr lp, double *slack,
                      int begin, int end);
int CPXPUBLIC
   CPXgetmipobjval   (CPXCENVptr env, CPXCLPptr lp, 
                      double *objval_p);
int CPXPUBLIC
   CPXgetmipitcnt    (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetbestobjval  (CPXCENVptr env, CPXCLPptr lp, 
                      double *objval_p);
int CPXPUBLIC
   CPXgetcutoff      (CPXCENVptr env, CPXCLPptr lp, 
                      double *cutoff_p);
int CPXPUBLIC
   CPXgetnodecnt     (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetnodeleftcnt (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetnodeint     (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetgenclqcnt   (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetclqcnt      (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetcovcnt      (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetmipstart    (CPXCENVptr env, CPXCLPptr lp, int *cnt_p,
                      int *indices, double *value, int mipstartspace,
                      int *surplus_p);
int CPXPUBLIC
   CPXgetsubstat     (CPXCENVptr env, CPXCLPptr lp);

int CPXPUBLIC
   CPXgetsubmethod   (CPXCENVptr env, CPXCLPptr lp);


/* Problem Modification Routines */

int CPXPUBLIC
   CPXchgctype    (CPXCENVptr env, CPXLPptr lp, int cnt,
                   const int *indices, const char *xctype);
int CPXPUBLIC
   CPXaddsos      (CPXCENVptr env, CPXLPptr lp, int numsos,
                   int numsosnz, const char *sostype,
                   const int *sospri, const int *sosbeg,
                   const int *sosind, const double *soswt);
int CPXPUBLIC
   CPXdelsetsos   (CPXCENVptr env, CPXLPptr lp, int *delset);


/* Routines Accessing MIP Data */

int CPXPUBLIC
   CPXgetctype       (CPXCENVptr env, CPXCLPptr lp, char *xctype,
                      int begin, int end);
int CPXPUBLIC
   CPXgetnumsos      (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetsos         (CPXCENVptr env, CPXCLPptr lp, int *numsosnz_p,
                      char *sostype, int *sospri, int *sosbeg,
                      int *sosind, double *soswt, int sosspace,
                      int *surplus_p, int begin, int end);
int CPXPUBLIC
   CPXgetnumint      (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetnumbin      (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetnumsemicont (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetnumsemiint  (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetorder       (CPXCENVptr env, CPXCLPptr lp, int *cnt_p,
                      int *indices, int *priority, int *direction,
                      int ordspace, int *surplus_p);


/* File Reading and Writing Routines */

int CPXPUBLIC
   CPXreadcopyorder    (CPXCENVptr env, CPXLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXreadcopymipstart (CPXCENVptr env, CPXLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXreadcopysos      (CPXCENVptr env, CPXLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXreadcopytree     (CPXCENVptr env, CPXLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXordwrite         (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXmstwrite         (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXsoswrite         (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXtreewrite        (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);


/* Data Debugging Routines */

int CPXPUBLIC
   CPXcheckcopyctype    (CPXCENVptr env, CPXCLPptr lp, const char *xctype);

int CPXPUBLIC
   CPXcheckcopysos      (CPXCENVptr env, CPXCLPptr lp, int numsos,
                         int numsosnz, const char *sostype,
                         const int *sospri, const int *sosbeg,
                         const int *sosind, const double *soswt);

/* Callback Routines */

int CPXPUBLIC
   CPXsetmipcallbackfunc (CPXENVptr env,
                          int (CPXPUBLIC *callback)(CPXCENVptr,
                          void *, int, void *), void *cbhandle);

int CPXPUBLIC
   CPXgetmipcallbackfunc (CPXCENVptr env,
                          int (CPXPUBLIC **callback_p)(CPXCENVptr,
                          void *, int, void *), void **cbhandle_p);


/* Argument lists for callbacks */

#define CALLBACK_BRANCH_ARGS  CPXCENVptr xenv, void *cbdata,\
   int wherefrom, void *cbhandle, int brtype, int brset,\
   int nodecnt, int bdcnt, const double *nodeest, const int *nodebeg,\
   const int *xindex, const char *lu, const int *bd, int *useraction_p
#define CALLBACK_NODE_ARGS  CPXCENVptr xenv, void *cbdata,\
   int wherefrom, void *cbhandle, int *nodenum, int *useraction
#define CALLBACK_HEURISTIC_ARGS  CPXCENVptr xenv, void *cbdata,\
   int wherefrom, void *cbhandle, double *objval_p, double *x,\
   int *checkfeas_p, int *useraction_p
#define CALLBACK_SOLVE_ARGS  CPXCENVptr xenv, void *cbdata,\
   int wherefrom, void *cbhandle, int *useraction
#define CALLBACK_CUT_ARGS  CPXCENVptr xenv, void *cbdata,\
   int wherefrom, void *cbhandle, int *useraction_p
#define CALLBACK_INCUMBENT_ARGS  CPXCENVptr xenv, void *cbdata,\
   int wherefrom, void *cbhandle, double objval, double *x,\
   int *isfeas_p, int *useraction_p
#define CALLBACK_DELETENODE_ARGS  CPXCENVptr xenv,\
   int wherefrom, void *cbhandle, int seqnum, void *handle


/* Advanced MIP Routines */

int CPXPUBLIC
   CPXsetbranchcallbackfunc    (CPXENVptr env,
                                int (CPXPUBLIC *branchcallback)
                                (CALLBACK_BRANCH_ARGS), void *cbhandle);
int CPXPUBLIC
   CPXsetcutcallbackfunc       (CPXENVptr env,
                                int (CPXPUBLIC *cutcallback)
                                (CALLBACK_CUT_ARGS), void *cbhandle); 

int CPXPUBLIC
   CPXsetnodecallbackfunc      (CPXENVptr env,
                                int (CPXPUBLIC *nodecallback)
                                (CALLBACK_NODE_ARGS), void *cbhandle);
int CPXPUBLIC
   CPXsetheuristiccallbackfunc (CPXENVptr env,
                                int (CPXPUBLIC *heuristiccallback)
                                (CALLBACK_HEURISTIC_ARGS), void *cbhandle);
int CPXPUBLIC
   CPXsetincumbentcallbackfunc (CPXENVptr env,
                                int (CPXPUBLIC *incumbentallback)
                                (CALLBACK_INCUMBENT_ARGS), void *cbhandle);
int CPXPUBLIC
   CPXsetsolvecallbackfunc     (CPXENVptr env,
                                int (CPXPUBLIC *solvecallback)
                                (CALLBACK_SOLVE_ARGS),
                                void *cbhandle);

int CPXPUBLIC
   CPXsetdeletenodecallbackfunc(CPXENVptr env,
                                void (CPXPUBLIC *deletecallback)
                                (CALLBACK_DELETENODE_ARGS),
                                void *cbhandle);
void CPXPUBLIC
   CPXgetbranchcallbackfunc    (CPXCENVptr env,
                                int (CPXPUBLIC **branchcallback_p)
                                (CALLBACK_BRANCH_ARGS), void **cbhandle_p);
void CPXPUBLIC
   CPXgetcutcallbackfunc       (CPXCENVptr env,
                                int (CPXPUBLIC **cutcallback_p)
                                (CALLBACK_CUT_ARGS), void **cbhandle_p);

void CPXPUBLIC
   CPXgetnodecallbackfunc      (CPXCENVptr env,
                                int (CPXPUBLIC **nodecallback_p)
                                (CALLBACK_NODE_ARGS), void **cbhandle_p);
void CPXPUBLIC
   CPXgetheuristiccallbackfunc (CPXCENVptr env,
                                int (CPXPUBLIC **heuristiccallback_p)
                                (CALLBACK_HEURISTIC_ARGS), void **cbhandle_p);
void CPXPUBLIC
   CPXgetincumbentcallbackfunc (CPXCENVptr env,
                                int (CPXPUBLIC **incumbentcallback_p)
                                (CALLBACK_INCUMBENT_ARGS), void **cbhandle_p);
void CPXPUBLIC
   CPXgetsolvecallbackfunc     (CPXCENVptr env,
                                int (CPXPUBLIC **solvecallback_p)
                                (CALLBACK_SOLVE_ARGS), void **cbhandle_p);
void CPXPUBLIC
   CPXgetdeletenodecallbackfunc(CPXCENVptr env,
                                void (CPXPUBLIC **deletecallback_p)
                                (CALLBACK_DELETENODE_ARGS),
                                void **cbhandle_p);

int CPXPUBLIC
   CPXgetcallbacknodelp        (CPXCENVptr env, void *cbdata,
                                int wherefrom,
                                CPXLPptr *nodelp_p);
int CPXPUBLIC
   CPXgetcallbacknodeinfo      (CPXCENVptr env, void *cbdata,
                                int wherefrom, int nodenum,
                                int whichinfo, void *result_p);
int CPXPUBLIC
   CPXgetcallbackseqinfo       (CPXCENVptr env, void *cbdata,
                                int wherefrom, int seqid,
                                int whichinfo, void *result_p);
int CPXPUBLIC
   CPXgetcallbacksosinfo       (CPXCENVptr env, void *cbdata,
                                int wherefrom, int sosindex,
                                int member, int whichinfo,
                                void *result_p);

int CPXPUBLIC
   CPXcutcallbackadd           (CPXCENVptr env, void *cbdata,
                                int wherefrom, int nzcnt,
                                double rhs, int sense,
                                const int *cutind, const double *cutval);
int CPXPUBLIC
   CPXcutcallbackaddlocal      (CPXCENVptr env, void *cbdata,
                                int wherefrom, int nzcnt,
                                double rhs, int sense,
                                const int *cutind, const double *cutval);
int CPXPUBLIC
   CPXbranchcallbackbranchbds  (CPXCENVptr env, void *cbdata,
                                int wherefrom, double nodeest,
                                int cnt, const int *indices,
                                const char *lu, const int *bd,
                                void *userhandle, int *seqnum_p);
int CPXPUBLIC
   CPXbranchcallbackbranchgeneral (CPXCENVptr env, void *cbdata,
                                int wherefrom, double nodeest,
                                int varcnt, const int *varind,
                                const char *varlu, const int *varbd,
                                int rcnt, int nzcnt, const double *rhs,
                                const char *sense, const int *rmatbeg,
                                const int *rmatind, const double *rmatval,
                                void *userhandle, int *seqnum_p);
int CPXPUBLIC
   CPXbranchcallbackbranchconstraints (CPXCENVptr env, void *cbdata,
                                int wherefrom, double nodeest,
                                int rcnt, int nzcnt, const double *rhs,
                                const char *sense, const int *rmatbeg,
                                const int *rmatind, const double *rmatval,
                                void *userhandle, int *seqnum_p);
int CPXPUBLIC
   CPXgetcallbacknodex         (CPXCENVptr env, void *cbdata, 
                                int wherefrom, double *x, 
                                int begin, int end);

int CPXPUBLIC
   CPXgetcallbacknodeobjval   (CPXCENVptr env, void *cbdata, 
                               int wherefrom, double *objval_p);

int CPXPUBLIC
   CPXgetcallbackctype        (CPXCENVptr env, void *cbdata, 
                               int wherefrom, char *xctype, 
                               int begin, int end);

int CPXPUBLIC
   CPXgetcallbackorder        (CPXCENVptr env, void *cbdata, 
                               int wherefrom, int *priority,
                               int *direction, int begin, int end);

int CPXPUBLIC
   CPXgetcallbackpseudocosts  (CPXCENVptr env, void *cbdata, 
                               int wherefrom, double *uppc, 
                               double *downpc, int begin, int end);

int CPXPUBLIC
   CPXgetcallbackincumbent   (CPXCENVptr env, void *cbdata, 
                              int wherefrom, double *x, 
                              int begin, int end);

int CPXPUBLIC
   CPXgetcallbacknodeintfeas (CPXCENVptr env, void *cbdata, 
                              int wherefrom, int *feas, 
                              int begin, int end);

int CPXPUBLIC
   CPXgetcallbackgloballb    (CPXCENVptr env, void *cbdata, 
                              int wherefrom, double *lb, 
                              int begin, int end);

int CPXPUBLIC
   CPXgetcallbackglobalub    (CPXCENVptr env, void *cbdata, 
                              int wherefrom, double *ub, 
                              int begin, int end);

int CPXPUBLIC
   CPXgetcallbacknodelb      (CPXCENVptr env, void *cbdata, 
                              int wherefrom, double *lb, 
                              int begin, int end);

int CPXPUBLIC
   CPXgetcallbacknodeub      (CPXCENVptr env, void *cbdata, 
                              int wherefrom, double *ub, 
                              int begin, int end);

int CPXPUBLIC
   CPXgetcallbacklp          (CPXCENVptr env, void *cbdata,
                              int wherefrom, CPXCLPptr *lp_p);

int CPXPUBLIC
   CPXgetcallbacknodestat    (CPXCENVptr env, void *cbdata,
                              int wherefrom, int *nodestat_p);

int CPXPUBLIC
   CPXaddusercuts            (CPXCENVptr env, CPXLPptr lp, int rcnt,
                              int nzcnt, const double *rhs,
                              const char *sense, const int *rmatbeg,
                              const int *rmatind, const double *rmatval);

int CPXPUBLIC
   CPXaddlazyconstraints     (CPXCENVptr env, CPXLPptr lp, int rcnt,
                              int nzcnt, const double *rhs,
                              const char *sense, const int *rmatbeg,
                              const int *rmatind, const double *rmatval);

int CPXPUBLIC
   CPXfreeusercuts           (CPXCENVptr env, CPXLPptr lp);

int CPXPUBLIC
   CPXfreelazyconstraints    (CPXCENVptr env, CPXLPptr lp);


/* External Interface Routines */
 
int CPXPUBLIC
   CPXEgetusercuts           (CPXCENVptr env, CPXCLPptr lp,
                              int *rcnt_p, int *nzcnt_p,
                              double **zrhs_p, char **zsense_p,
                              int **rmatbeg_p, int **rmatind_p,
                              double **rmatval_p);
 
int CPXPUBLIC
   CPXEgetlazyconstraints    (CPXCENVptr env, CPXCLPptr lp,
                              int *rcnt_p, int *nzcnt_p,
                              double **zrhs_p, char **zsense_p,
                              int **rmatbeg_p, int **rmatind_p,
                              double **rmatval_p);

/* Old-Style File Reading Routines */

int CPXPUBLIC
   CPXordread  (CPXCENVptr env, const char *filename_str, int numcols,
                char **colname, int *cnt_p, int *indices,
                int *priority, int *direction);
int CPXPUBLIC
   CPXsosread  (CPXCENVptr env, const char *filename_str, int numcols,
                char **colname, int *numsos_p, int *numsosnz_p,
                char **sostype_p, int **sospri_p, int **sosbeg_p,
                int **sosind_p, double **soswt_p);

#ifdef __cplusplus
}
#endif

#endif /* __MIPDEFS_H */

/*------------------------------------------------------------------------*/
/*  File: NETDEFS.h                                                       */
/*  Version 8.1                                                           */
/*                                                                        */
/*  Copyright (C) 1997-2002 by ILOG.                                      */
/*  All Rights Reserved.                                                  */
/*                                                                        */
/*  N O T I C E                                                           */
/*                                                                        */
/*  THIS MATERIAL IS CONSIDERED A TRADE SECRET BY ILOG.                   */
/*  UNAUTHORIZED ACCESS, USE, REPRODUCTION OR DISTRIBUTION IS PROHIBITED. */
/*------------------------------------------------------------------------*/
/*  $Revision: 1.1 $                                           */
/*  Last modified on $Date: 2003/08/05 13:58:29 $ by $Author: elf $ */
/*------------------------------------------------------------------------*/


#ifndef __CPXNET_H
#define __CPXNET_H

#ifdef __cplusplus
extern "C" {
#endif


/* Network parameters */

#define CPX_PARAM_NETITLIM             5001
#define CPX_PARAM_NETEPOPT             5002
#define CPX_PARAM_NETEPRHS             5003
#define CPX_PARAM_NETPPRIIND           5004
#define CPX_PARAM_NETDISPLAY           5005


/* NET/MIN files format errors */

#define CPXERR_NET_DATA               1530
#define CPXERR_NOT_MIN_COST_FLOW      1531
#define CPXERR_BAD_ROW_ID             1532
#define CPXERR_BAD_CHAR               1537
#define CPXERR_NET_FILE_SHORT         1538


/* NETOPT display values */

#define CPXNET_NO_DISPLAY_OBJECTIVE     0
#define CPXNET_TRUE_OBJECTIVE           1
#define CPXNET_PENALIZED_OBJECTIVE      2

/* NETOPT pricing parameters */

#define CPXNET_PRICE_AUTO               0
#define CPXNET_PRICE_PARTIAL            1
#define CPXNET_PRICE_MULT_PART          2
#define CPXNET_PRICE_SORT_MULT_PART     3




/* Creating and Deleting Network Problems and Copying Data */

CPXNETptr CPXPUBLIC
   CPXNETcreateprob   (CPXENVptr env, int *status_p, const char *name_str);

int CPXPUBLIC
   CPXNETfreeprob     (CPXENVptr env, CPXNETptr *net_p);

int CPXPUBLIC
   CPXNETcopynet      (CPXCENVptr env, CPXNETptr net, int objsen,
                       int nnodes, const double *supply, char **nnames,
                       int narcs, const int *fromnode, const int *tonode,
                       const double *low, const double *up, const double *obj,
                       char **anames);
int CPXPUBLIC
   CPXNETcopybase     (CPXCENVptr env, CPXNETptr net,
                       const int *astat, const int *nstat);
int CPXPUBLIC
   CPXNETaddnodes     (CPXCENVptr env, CPXNETptr net, int nnodes,
                       const double *supply, char **name);
int CPXPUBLIC
   CPXNETaddarcs      (CPXCENVptr env, CPXNETptr net, int narcs,
                       const int *fromnode, const int *tonode,
                       const double *low, const double *up,
                       const double *obj, char **anames);

int CPXPUBLIC
   CPXNETdelnodes     (CPXCENVptr env, CPXNETptr net, int begin,
                       int end);
int CPXPUBLIC
   CPXNETdelarcs      (CPXCENVptr env, CPXNETptr net, int begin,
                       int end);
int CPXPUBLIC
   CPXNETdelset       (CPXCENVptr env, CPXNETptr net,
                       int *whichnodes, int *whicharcs);



/* Optimizing Network Problems */

int CPXPUBLIC
   CPXNETprimopt      (CPXCENVptr env, CPXNETptr net);


/* Accessing Network Results */

int CPXPUBLIC
   CPXNETgetstat      (CPXCENVptr env, CPXCNETptr net);
int CPXPUBLIC
   CPXNETgetobjval    (CPXCENVptr env, CPXCNETptr net,
                       double *objval_p);
int CPXPUBLIC
   CPXNETgetx         (CPXCENVptr env, CPXCNETptr net, double *x,
                       int begin, int end);
int CPXPUBLIC
   CPXNETgetpi        (CPXCENVptr env, CPXCNETptr net, double *pi,
                       int begin, int end);
int CPXPUBLIC
   CPXNETgetslack     (CPXCENVptr env, CPXCNETptr net, double *slack,
                       int begin, int end);
int CPXPUBLIC
   CPXNETgetdj        (CPXCENVptr env, CPXCNETptr net, double *dj,
                       int begin, int end);
int CPXPUBLIC
   CPXNETgetitcnt     (CPXCENVptr env, CPXCNETptr net);
int CPXPUBLIC
   CPXNETgetphase1cnt (CPXCENVptr env, CPXCNETptr net);
int CPXPUBLIC
   CPXNETgetbase      (CPXCENVptr env, CPXCNETptr net,
                       int *astat, int *nstat);
int CPXPUBLIC
   CPXNETsolution     (CPXCENVptr env, CPXCNETptr net, int *netstat_p,
                       double *objval_p, double *x, double *pi,
                       double *slack, double *dj);
int CPXPUBLIC
   CPXNETsolninfo     (CPXCENVptr env, CPXCNETptr net,
                       int *pfeasind_p, int *dfeasind_p);


/* Modifying Network Problems */

int CPXPUBLIC
   CPXNETchgname      (CPXCENVptr env, CPXNETptr net, int key,
                       int vindex, const char *name_str);
int CPXPUBLIC
   CPXNETchgarcname   (CPXCENVptr env, CPXNETptr net, int cnt,
                       const int *indices, char **newname);
int CPXPUBLIC
   CPXNETchgnodename  (CPXCENVptr env, CPXNETptr net, int cnt,
                       const int *indices, char **newname);
int CPXPUBLIC
   CPXNETchgobjsen    (CPXCENVptr env, CPXNETptr net, int maxormin);
int CPXPUBLIC
   CPXNETchgbds       (CPXCENVptr env, CPXNETptr net,
                       int cnt, const int *indices, const char *lu,
                       const double *bd);
int CPXPUBLIC
   CPXNETchgarcnodes  (CPXCENVptr env, CPXNETptr net,
                       int cnt, const int *indices, const int *fromnode,
                       const int *tonode);
int CPXPUBLIC
   CPXNETchgobj       (CPXCENVptr env, CPXNETptr net,
                       int cnt, const int *indices, const double *obj);
int CPXPUBLIC
   CPXNETchgsupply    (CPXCENVptr env, CPXNETptr net,
                       int cnt, const int *indices, const double *supply);


/* Accessing Network Problem Data */

int CPXPUBLIC
   CPXNETgetobjsen    (CPXCENVptr env, CPXCNETptr net);
int CPXPUBLIC
   CPXNETgetsupply    (CPXCENVptr env, CPXCNETptr net, double *supply,
                       int begin, int end);
int CPXPUBLIC
   CPXNETgetprobname  (CPXCENVptr env, CPXCNETptr net, char *buf_str,
                       int bufspace, int *surplus_p);
int CPXPUBLIC
   CPXNETgetnodename  (CPXCENVptr env, CPXCNETptr net,
                       char **nnames, char *namestore, int namespc,
                       int *surplus_p, int begin, int end);
int CPXPUBLIC
   CPXNETgetarcname   (CPXCENVptr env, CPXCNETptr net,
                       char **nnames, char *namestore, int namespc,
                       int *surplus_p, int begin, int end);
int CPXPUBLIC
   CPXNETgetlb        (CPXCENVptr env, CPXCNETptr net, double *low,
                       int begin, int end);
int CPXPUBLIC
   CPXNETgetub        (CPXCENVptr env, CPXCNETptr net,
                       double *up, int begin, int end);
int CPXPUBLIC
   CPXNETgetobj       (CPXCENVptr env, CPXCNETptr net,
                       double *obj, int begin, int end);
int CPXPUBLIC
   CPXNETgetarcnodes  (CPXCENVptr env, CPXCNETptr net,
                       int* fromnode, int *tonode, int begin, int end);
int CPXPUBLIC
   CPXNETgetnodearcs (CPXCENVptr env, CPXCNETptr net, int *arccnt_p,
                      int* arcbeg, int *arc, int arcspace, int *surplus_p,
                      int begin, int end);
int CPXPUBLIC
   CPXNETgetnumnodes  (CPXCENVptr env, CPXCNETptr net);
int CPXPUBLIC
   CPXNETgetnumarcs   (CPXCENVptr env, CPXCNETptr net);
int CPXPUBLIC
   CPXNETgetnodeindex (CPXCENVptr env, CPXCNETptr net, const char *lname_str,
                       int *index_p);
int CPXPUBLIC
   CPXNETgetarcindex  (CPXCENVptr env, CPXCNETptr net, const char *lname_str,
                       int *index_p);


/* File Reading and Writing Routines */

int CPXPUBLIC
   CPXNETreadcopyprob (CPXCENVptr env, CPXNETptr net, const char *filename_str);
int CPXPUBLIC
   CPXNETreadcopybase (CPXCENVptr env, CPXNETptr net, const char *filename_str);
int CPXPUBLIC
   CPXNETwriteprob    (CPXCENVptr env, CPXCNETptr net, const char *filename_str,
                       const char *format_str);
int CPXPUBLIC
   CPXNETbasewrite    (CPXCENVptr env, CPXCNETptr net, const char *filename_str);


/* Data Debugging Routines */

int CPXPUBLIC
   CPXNETcheckcopynet (CPXCENVptr env, CPXNETptr net, int objsen,
                       int nnodes, const double *supply, char **nnames,
                       int narcs, const int *fromnode, const int *tonode,
                       const double *low, const double *up, const double *obj,
                       char **aname);


#ifdef __cplusplus
}
#endif

#endif /* __CPXNET_H */


/*------------------------------------------------------------------------*/
/*  File: QPDEFS.h                                                        */
/*  Version 8.1                                                           */
/*                                                                        */
/*  Copyright (C) 1997-2002 by ILOG.                                      */
/*  All Rights Reserved.                                                  */
/*                                                                        */
/*  N O T I C E                                                           */
/*                                                                        */
/*  THIS MATERIAL IS CONSIDERED A TRADE SECRET BY ILOG.                   */
/*  UNAUTHORIZED ACCESS, USE, REPRODUCTION OR DISTRIBUTION IS PROHIBITED. */
/*------------------------------------------------------------------------*/
/*  $Revision: 1.1 $                                           */
/*  Last modified on $Date: 2003/08/05 13:58:29 $ by $Author: elf $ */
/*------------------------------------------------------------------------*/


#ifndef __QPDEFS_H
#define __QPDEFS_H

#ifdef __cplusplus
extern "C" {
#endif


/* QP error codes */

#define CPXERR_BAD_Q           5001
#define CPXERR_Q_NOT_POS_DEF   5002
#define CPXERR_NOT_QP          5004
#define CPXERR_Q_DUP_ENTRY     5011
#define CPXERR_Q_NOT_SYMMETRIC 5012
#define CPXERR_Q_NOT_INDEF     5014

/* Copying data */

#define CPX_PARAM_QPNZREADLIM  4001
#define CPX_PARAM_QPNZGROWTH   4002

/* presolve */
#define CPX_PARAM_QPMAKEPSDIND 4010



int CPXPUBLIC
   CPXcopyquad  (CPXCENVptr env, CPXLPptr lp, const int *qmatbeg, 
                 const int *qmatcnt, const int *qmatind,
                 const double *qmatval);
int CPXPUBLIC
   CPXcopyqpsep (CPXCENVptr env, CPXLPptr lp, const double *qsepvec);


/* Problem Modification Routines */
int CPXPUBLIC
   CPXchgqpcoef  (CPXCENVptr env, CPXLPptr lp, int i, int j,
                  double newvalue);

/* Problem Query Routines */

int CPXPUBLIC
   CPXgetnumqpnz (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetnumquad (CPXCENVptr env, CPXCLPptr lp);
int CPXPUBLIC
   CPXgetqpcoef  (CPXCENVptr env, CPXCLPptr lp, int rownum, int colnum,
                  double *coef_p);
int CPXPUBLIC
   CPXgetquad    (CPXCENVptr env, CPXCLPptr lp, int *nzcnt_p,
                  int *qmatbeg, int *qmatind, double *qmatval,
                  int qmatspace, int *surplus_p, int begin, int end);

/* Solution Query Routines */
int CPXPUBLIC
   CPXqpindefcertificate (CPXCENVptr env, CPXCLPptr lp, double *x);

/* Data Debugging Routines */
int CPXPUBLIC
   CPXcheckcopyqpsep    (CPXCENVptr env, CPXCLPptr lp,
                         const double *qsepvec);
int CPXPUBLIC
   CPXcheckcopyquad     (CPXCENVptr env, CPXCLPptr lp, const int *qmatbeg,
                         const int *qmatcnt, const int *qmatind,
                         const double *qmatval);

/* File Reading and Writing Routines */

int CPXPUBLIC
   CPXreadcopyqp (CPXCENVptr env, CPXLPptr lp, const char *filename_str);
int CPXPUBLIC
   CPXqpwrite (CPXCENVptr env, CPXCLPptr lp, const char *filename_str);

/* Optimizing Problems */

int CPXPUBLIC
   CPXqpopt     (CPXCENVptr env, CPXLPptr lp);


/* Old-Style File Reading */

int CPXPUBLIC
   CPXqpread     (CPXCENVptr env, const char *filename_str, int numcols, 
                  int colspace, char **colname, int **qmatbeg_p, 
                  int **qmatcnt_p, int **qmatind_p, double **qmatval_p,
                  int *qnzspace_p);

#ifdef __cplusplus
}
#endif

#endif /* __QPDEFS_H */

