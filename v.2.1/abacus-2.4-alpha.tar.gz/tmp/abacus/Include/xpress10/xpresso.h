#ifndef XPRESSO_H
#define XPRESSO_H

#ifdef DLL16
#define DLL
#endif

#ifdef DLL
#include <windows.h>
#endif
#include <stdio.h>

/*
** Useful constants
*/
#define dplinf  1.0e+30
#define dmninf -1.0e+30
#define DPLINF  1.0e+30
#define DMNINF -1.0e+30
/*
**  
**  string control variables
*/
#define N_RHSNAM  1
#define N_OBJNAM  2
#define N_RNGNAM  3
#define N_BNDNAM  4
#define N_ASCMSK  5
#define N_DATNAM  6
/*
**  
**  double control variables
*/
#define N_ZTOLDA     1
#define N_ZTOLPV     2
#define N_ZTOLZE     3
#define N_ZTOLPZ     4
#define N_ZTOLST     5
#define N_ZTCOST     6
#define N_ZTETA      7
#define N_ZTOLRP     8
#define N_ZTOLIS     9
#define N_PSEUDO    10
#define N_OBJTAR    11
#define N_ADDCUT    12
#define N_CUTOFF    13
#define N_PERCUT    14
#define N_RTOLPS    15
#define N_PENLTY    16
#define N_BIGM      18
#define N_TOLPIV    25
#define N_TOLCOMP   26
#define N_TOLDUAL   27
#define N_TOLPRIMAL 28
#define N_TOLIMP    29
#define N_PETURB    37

/*
**  
**  int control variables
*/
#define N_M_R        1
#define N_M_C        2
#define N_M_M        3
#define N_NRXTRA     4
#define N_NCXTRA     5
#define N_NMXTRA     6
#define N_ITRLIM     7
#define N_IFMSG      8
#define N_ITRLOG     9
#define N_IFSCAL    10
#define N_IFPRES    11
#define N_ICRASH    12
#define N_IPHSF     13
#define N_INVFRQ    14
#define N_INVMIN    15
#define N_NGEMAX    16
#define N_INTMAX    17
#define N_MAXNOD    18
#define N_MXANOD    19
#define N_MAXTIM    20
#define N_MAXSOL    21
#define N_IPKEEP    22
#define N_IALG      23
#define N_IPACTN    24
#define N_KCRITM    25
#define N_NDSEL1    26
#define N_NDSEL2    27
#define N_GPRINT    28
#define N_IGNORE    29
#define N_IFNRW     30
#define N_LENDBL    31
#define N_PRNLVL    32
#define N_IFBSNM    33
#define N_NLINES    34
#define N_PRTMSG    35
#define N_M_S       36
#define N_NEXTRA    37
#define N_MXCPOL    38
#define N_MXCPEL    39
#define N_IFCUTP    40
#define N_IFNDCP    41
#define N_IFMEM     42
#define N_CACHE_SIZE 43
#define N_CROSS     44
#define N_MAXITER   45
#define N_PUSH_CHOLESKY 46
#define N_PRLEV     47
#define N_IFC       50
#define N_NGXTRA    51
#define N_IFNBAS    54
#define N_OMNIMAT   58
#define N_VERNO     61
#define N_M_E       63
#define N_IPSLCT    77
#define N_IFINTP    78
#define N_NBDUAL    81
#define N_MAXNBF    82
#define N_IPETRB    84
#define N_DENSECOL  86
#define N_ITRACE    130
#define N_NIIS      131
/*
**  
**  int problem variables
*/
#define N_NROW   1001 
#define N_NSEQ   1002 
#define N_NGLENT 1003
#define N_NSETS  1004
#define N_NSOSM  1005
#define N_NELEM  1006
#define N_NINF   1007
#define N_NNEGDJ 1008
#define N_ITCNT  1009
#define N_STATUS 1010
#define N_GLSTAT 1011
#define N_NCUTS  1012
#define N_NODNUM 1013
#define N_NDEPTH 1014
#define N_NACTIVE 1015
#define N_NODISL 1016
#define N_NINTSL 1017
#define N_NCOL   1018
#define N_NRSPAR 1019
#define N_NCSPAR 1020
#define N_NMSPAR 1021
#define N_NGSPAR 1022
#define N_ERRNO  1023
#define N_INTINF 1024

#define N_NBITER 3001    /* barrier */
#define N_NBNZAA 3002    
#define N_NBNNZL 3003    
#define N_NBDCOL 3004    
#define N_NBCRSS 3005    

/*
**  
**  double problem variables
*/
#define N_DOBJVL  2001 
#define N_SUMINF  2002
#define N_DINTSL  2003
#define N_DBESTB  2004
#define N_DOBJFX  2005
#define N_DOBJAR  2006
#define N_ZSCALE  2008

#define N_DBPOBJ 4001    /* barrier */
#define N_DBDOBJ 4002    
#define N_DBPFEA 4003    
#define N_DBDFEA 4004    
#define N_DBSTOP 4005    

/*
**  
**  character problem variables
*/
#define N_NAMMAT 3001
#define N_NAMBND 3002
#define N_NAMOBJ 3003
#define N_NAMRHS 3004
#define N_NAMRNG 3005

#ifdef sun
#define UNDERSCORE 1
#endif
#ifdef __alpha
#define UNDERSCORE 1
#endif
#if UNDERSCORE
#define xo_setcme xo_setcme_
#define xo_xpr xo_xpr_
#define xo_ifc xo_ifc_
#endif

/*
**
**  return code and error no.
*/
extern struct
{
  int xo_stat;
  int xo_errno;
} xo_xpr;

#ifdef DLL
#define initlz XPINITLZ
#define freexo XPFREEXO
#define basisin XPBASISIN
#define basisout XPBASISOUT
#define dashin XPDASHIN
#define fprint XPFPRINT
#define frprint XPFRPRINT
#define global XPGLOBAL
#define input XPINPUT
#define maxim XPMAXIM
#define minim XPMINIM
#define range XPRANGE
#define rtoasc XPRTOASC
#define toasc XPTOASC
#define directives XPDIRECTIVES
#define setprob XPSETPROB
#define getprob XPGETPROB
#define seticv XPSETICV
#define setdcv XPSETDCV
#define setccv XPSETCCV
#define geticv XPGETICV
#define getdcv XPGETDCV
#define getccv XPGETCCV
#define getcpv XPGETCPV
#define getipv XPGETIPV
#define getdpv XPGETDPV
#define setoptlog XPSETOPTLOG
#define setilcback XPSETILCBACK
#define setglcback XPSETGLCBACK
#define setblcback XPSETBLCBACK
#define save XPSAVE
#define restore XPRESTORE
#define omniout XPOMNIOUT
#define alter XPALTER

/* Optimiser Level 2 */
#define loadprob XPLOADPROB
#define loadglobal XPLOADGLOBAL
#define addnames XPADDNAMES
#define loaddir XPLOADDIR
#define iloaddir XPILOADDIR
#define loadbasis XPLOADBASIS
#define iloadbasis XPILOADBASIS
#define getbasis XPGETBASIS
#define igetbasis XPIGETBASIS
#define solution XPSOLUTION
#define getobj XPGETOBJ
#define getrowtype XPGETROWTYPE
#define getrhs XPGETRHS
#define getrng XPGETRNG
#define getcoltype XPGETCOLTYPE
#define getbdl XPGETBDL
#define getbdu XPGETBDU
#define getcols XPGETCOLS
#define getrows XPGETROWS
#define igetobj XPIGETOBJ
#define igetrhs XPIGETRHS
#define igetrng XPIGETRNG
#define igetbdl XPIGETBDL
#define igetbdu XPIGETBDU
#define igetcols XPIGETCOLS
#define igetrows XPIGETROWS
#define getnames XPGETNAMES
#define getindex XPGETINDEX
#define getglobal XPGETGLOBAL
#define output XPOUTPUT
#define addrows XPADDROWS
#define delrows XPDELROWS
#define addcols XPADDCOLS
#define delcols XPDELCOLS
#define chgbds XPCHGBDS
#define chgcof XPCHGCOF
#define chgrhs XPCHGRHS
#define chgrng XPCHGRNG
#define chgobj XPCHGOBJ
#define chgrowtype XPCHGROWTYPE
#define chgcoltype XPCHGCOLTYPE
#define savmat XPSAVMAT
#define cpymat XPCPYMAT
#define resmat XPRESMAT
#define delmat XPDELMAT
#define addcuts XPADDCUTS
#define delcuts XPDELCUTS
#define dropcuts XPDROPCUTS
#define getcnlist XPGETCNLIST
#define getcplist XPGETCPLIST
#define getcuts XPGETCUTS
#define loadcuts XPLOADCUTS
#define storecuts XPSTORECUTS
#define storebnds XPSTOREBNDS
#define branchcut XPBRANCHCUT
#define control XPCONTROL
#define optlicence XPOPTLICENCE
#define DefineILEntry XPDEFINEILENTRY
#define DefineGLEntry XPDEFINEGLENTRY
#define DefineBLEntry XPDEFINEBLENTRY
#define DefineCMIEntry XPDEFINECMIENTRY
#define DefineCMEntry XPDEFINECMENTRY
#define DefineTCMEntry XPDEFINETCMENTRY
#define DefineCMSEntry XPDEFINECMSENTRY
#define DefineUSNEntry XPDEFINEUSNENTRY
#define DefineUONEntry XPDEFINEUONENTRY
#define DefineUINEntry XPDEFINEUINENTRY
#define DefineUCNEntry XPDEFINEUCNENTRY
#define DefineUISEntry XPDEFINEUISENTRY
#define DefineUCBEntry XPDEFINEUCBENTRY
#define DefineUBEEntry XPDEFINEUBEENTRY
#define DefineUSEEntry XPDEFINEUSEENTRY
#define DefineUOPEntry XPDEFINEUOPENTRY
#define pivot XPPIVOT
#define getpivots XPGETPIVOTS
#define getinf XPGETINF
#define getunb XPGETUNB
#define getdir XPGETDIR
#define btran XPBTRAN
#define ibtran XPIBTRAN
#define ftran XPFTRAN
#define iftran XPIFTRAN
/* define calling convention */
#define XO_CC __stdcall
#ifdef DLL16
#define int long far
#define char char far
#define double double far
#endif

#ifndef __ANSIC_
#define __ANSIC_
#endif
#else
#define XO_CC
#endif

#ifdef __cplusplus
extern "C" {
#endif
#ifdef __ANSIC_
int XO_CC setoptlog( const char *logname );
int XO_CC seticv( int _index, int _ivalue );
int XO_CC setdcv( int _index, double _dvalue );
int setdcvi( int _index, double *_dvalue );
int XO_CC getprob( char *_svalue );
int XO_CC setprob( const char *_svalue );
int XO_CC setccv( int _index, const char *_svalue );
int XO_CC geticv( int _index, int *_ivalue );
int XO_CC getdcv( int _index, double *_dvalue );
int XO_CC getccv( int _index, char *_svalue );
int XO_CC getipv( int _index, int *_ivalue );
int XO_CC getcpv( int _index, char *_cvalue );
int XO_CC getdpv( int _index, double *_dvalue );
int XO_CC initlz( const char *_sxpath, int _imemory );
int XO_CC freexo( void );
int XO_CC input( const char *_sprobname );
int XO_CC dashin( const char *_sprobname );
int XO_CC loadprob( const char *_sprobname, int _ncols, int _nrows, 
              const char *_srowtypes, double *_drhs, double *_drange, 
	      double *_dobj, int *_mstart, int *_mnel, int *_mrwind, 
	      double *_dmatval, double *_dlb, double *_dub);
int XO_CC loaddir( int _ndir, int *_mcols, int *_mpri, const char *_sbr, 
              double *dupc, double *ddpc);
int XO_CC iloaddir( int _ndir, int *_mcols, int *_mpri, const char *_sbr, 
              double *dupc, double *ddpc);
int XO_CC getdir( int *_ndir, int *_mcols, int *_mpri, char *_sbr, 
              double *dupc, double *ddpc);
int XO_CC loadglobal( const char *_sprobname, int _ncols, int _nrows, 
              const char *_srowtypes, double *_drhs, double *_drange, 
	      double *_dobj, int *_mstart, int *_mnel, int *_mrwind, 
	      double *_dmatval, double *_dlb, double *_dub, int _ngents, 
	      int _nsets, const char *_qgtype, int *_mgcols, int *_mplim, 
	      const char *_stype, int *_msstart, int *_mscols, double *_dref);
int XO_CC addnames( int _itype, const char *_sname, int _ifirst, int _ilast );
int XO_CC directives( const char *_sfilename );
int XO_CC minim( const char *_sflags );
int XO_CC maxim( const char *_sflags );
int XO_CC range( void );
int XO_CC basisin( const char *_sfilename, const char *_sflags );
int XO_CC basisout( const char *_sfilename, const char *_sflags );
int XO_CC global( void );
int XO_CC fprint( void );
int XO_CC omniout( void );
int XO_CC alter( const char *_sfilename );
int XO_CC toasc( const char *_sfilename, const char *_sflags );
int XO_CC frprint( void );
int XO_CC rtoasc( const char *_sfilename, const char *_sflags );
int XO_CC solution( double *_dx, double *_dslack, double *_dual, double *_dj);
int XO_CC getinf( int *npvinf, int *npsinf, int *ndsinf, int *ndvinf, int *mx, 
	    int *mslack, int *mdual, int *mdj );
int XO_CC getunb( int *icol );
int XO_CC btran( double *dwork );
int XO_CC ibtran( double *dwork );
int XO_CC ftran( double *dwork );
int XO_CC iftran( double *dwork );
int XO_CC getobj( double *_dobj, int _ifirst, int _ilast);
int XO_CC getrhs( double *_drhs, int _ifirst, int _ilast);
int XO_CC getrng( double *_drng, int _ifirst, int _ilast);
int XO_CC getbdl( double *_dbdl, int _ifirst, int _ilast);
int XO_CC getbdu( double *_dbdu, int _ifirst, int _ilast);
int XO_CC getcols( int *_mstart, int *_mrwind, double *_dmatval, int _isize, 
	     int *_nels, int _ifirst, int _ilast);
int XO_CC getrows( int *_mstart, int *_mclind, double *_dmatval, int _isize, 
	     int *_nels, int _ifirst, int _ilast);
int XO_CC igetobj( double *__dobj, int _ifirst, int _ilast);
int XO_CC igetrhs( double *__drhs, int _ifirst, int _ilast);
int XO_CC igetrng( double *__drng, int _ifirst, int _ilast);
int XO_CC igetbdl( double *__dbdl, int _ifirst, int _ilast);
int XO_CC igetbdu( double *__dbdu, int _ifirst, int _ilast);
int XO_CC igetcols( int *_mstart, int *_mrwind, double *_dmatval, int _isize, 
	     int *_nels, int _ifirst, int _ilast);
int XO_CC igetrows( int *_mstart, int *_mclind, double *_dmatval, int _isize, 
	     int *_nels, int _ifirst, int _ilast);
int XO_CC igetbasis( int *_mrowstatus, int *_mcolstatus);
int XO_CC iloadbasis( int *_mrowstatus, int *_mcolstatus);
int XO_CC getglobal( int *_ngetns, int *_nsets, char *_sgtype, int *_mgcols, 
	     int *_mplim, char *_sstype, int *_msstart, int *_mscols, 
	     double *_dref);
int XO_CC output( const char *_sfilename );
int XO_CC getnames( int _itype, char *_sbuff, int _ifirst, int _ilast);
int XO_CC getrowtype( char *_srowtype, int _ifirst, int _ilast);
int XO_CC getcoltype( char *_coltype, int _ifirst, int _ilast);
int XO_CC getbasis( int *_mrowstatus, int *_mcolstatus);
int XO_CC loadbasis( int *_mrowstatus, int *_mcolstatus);
int XO_CC getindex( int _itype, char *_sname, int *_iseq );
int XO_CC addrows( int _newrow, int _newnz, const char *_srowtype, 
             double *_drhs, double *_drng, int *_mstart, int *_mclind, 
	     double *_dmatval);
int XO_CC delrows( int _nrows, int *_mindex);
int XO_CC addcols( int _newcol, int _newnz, double *_dobj, int *_mstart, 
	     int *_mrwind, double *_dmatval, double *_dbdl, double *_dbdu);
int XO_CC delcols( int _ncols, int *_mindex);
int XO_CC chgcoltype( int _nels, int *_mindex, const char *_coltype);
int XO_CC chgrowtype( int _nels, int *_mindex, const char *_srowtype);
int XO_CC chgbds( int _nbnds, int *_mindex, const char *_sboundtype, 
                  double *_dbnd);
int XO_CC chgobj( int _nels, int *_mindex, double *_dobj);
int XO_CC chgcof( int _irow, int _icol, double _dval);
int chgcofi( int _irow, int _icol, double *_dval);
int XO_CC chgrhs( int _nels, int *_mindex, double *_drhs);
int XO_CC chgrng( int _nels, int *_mindex, double *_drng);
int XO_CC save( void );
int XO_CC restore( const char * _sprobname );
int XO_CC savmat( int *_imat );
int XO_CC resmat( int _imat );
int XO_CC delmat( int _imat );
int XO_CC cpymat( const char *probname, int *_imat );
int XO_CC pivot( int _in, int _out );
int XO_CC getpivots( int _in, int *_mout, double *_dout, double *_dobjo, int *_npiv,
	       int _maxpiv );
int XO_CC control (void XO_CC (*fip)(const char *, int *));
int XO_CC optlicence( int _i1, const char *_c1 );
int XO_CC DefineILEntry (int XO_CC (*fuil)(void));
int XO_CC DefineGLEntry (int XO_CC (*fugl)(void));
int XO_CC DefineBLEntry (int XO_CC (*fubl)(void));
int XO_CC DefineCMIEntry (int XO_CC (*fcmi)(void)); /* initialize cut manager */
int XO_CC DefineCMEntry (int XO_CC (*fcme)(void));  /* cut manager */
int XO_CC DefineTCMEntry (int XO_CC (*ftcm)(void)); /* top cut manager */
int XO_CC DefineCMSEntry (int XO_CC (*fcms)(void)); /* stop cut manager */
int XO_CC DefineUSNEntry(void XO_CC (*fusn)(int *)); /* select node */
int XO_CC DefineUONEntry(void XO_CC (*fuon)(int *)); /* optimise node */
int XO_CC DefineUINEntry(void XO_CC (*fuin)(void));   /* infeas node */
int XO_CC DefineUCNEntry(void XO_CC (*fucn)(int));   /* cutoff node */
int XO_CC DefineUISEntry(void XO_CC (*fuis)(void));  /* integer solution */
int XO_CC DefineUCBEntry(void XO_CC (*fucb)(int *, int *, double *)); /* choose branch */
int XO_CC DefineUBEEntry (int XO_CC (*fbe)(int *, int *, double *, double *, 
					     double *, int *, int *, double *));
int XO_CC DefineUSEEntry (int XO_CC (*fse)(int, int, int, double));
int XO_CC DefineUOPEntry (void XO_CC (*fop)(const char *, int, int));
int XO_CC addcuts( int __i1, int *__i2, const char *__s1, double *__d1, 
             int *__i3, int *__i4, double *__d2);
int XO_CC delcuts( int __i1, int __i2, int __i3, double __d1, int __i4, 
             int *__i5);
int XO_CC dropcuts( int __i1, int __i2, int __i3, int *__i4);
int XO_CC getcnlist( int __i1, int __i2, int *__i3, int __i4, int *__i5);
int XO_CC getcplist( int __i1, int __i2, double __d1, int *__i3, int __i4, 
               int *__i5, double *__d2);
int XO_CC getcuts( int *__i1, int __i2, int __i3, int *__i4, 
             int *__i5, int *__i6, double *__d1, double *__d2);
int XO_CC loadcuts( int __i1, int __i2, int __i3, int *__i4);
int XO_CC storecuts( int __i1, int __i2, int *__i3, const char *__s1, 
               double *__d1, int *__i4, int *__i5, int *__i6, double *__d2);
int XO_CC storebnds( int nbnds, int *mcols, const char *qbtype, double *dbnd, 
                     int *mindex);
int XO_CC branchcut( int nbnds, int *mindex);
#endif

#ifndef __ANSIC_
int setprob( );
int getprob( );
int seticv( );
int setdcv( );
int setdcvi( );
int setccv( );
int geticv( );
int getdcv( );
int getccv( );
int getcpv( );
int getipv( );
int getdpv( );
int initlz( );
int freexo( );
int input( );
int dashin( );
int loadprob( );
int addnames( );
int directives( );
int minim( );
int maxim( );
int range( );
int basisin( );
int basisout( );
int global( );
int fprint( );
int omniout( );
int alter( );
int toasc( );
int frprint( );
int rtoasc( );
int solution( );
int getinf( );
int getobj( );
int getrhs( );
int getrng( );
int getbdl( );
int getbdu( );
int getcols( );
int getrows( );
int igetobj( );
int igetrhs( );
int igetrng( );
int igetbdl( );
int igetbdu( );
int igetcols( );
int igetrows( );
int getglobal( );
int getnames( );
int getindex( );
int getrowtype( );
int getcoltype( );
int getbasis( );
int loadbasis( );
int loaddir( );
int iloaddir( );
int loadglobal( );
int output( );
int addrows( );
int delrows( );
int addcols( );
int delcols( );
int chgcoltype( );
int chgrowtype( );
int chgbds( );
int chgobj( );
int chgcof( );
int chgcofi( );
int chgrhs( );
int chgrng( );
int save( );
int restore( );
int savmat( );
int resmat( );
int delmat( );
int cpymat( );
int pivot( );
int getpivots( );
int btran( );
int ibtran( );
int ftran( );
int iftran( );
int getdir( );
int getunb( );
int igetbasis( );
int iloadbasis( );
#ifdef DLL
int setoptlog( );
#endif
int control ( );
int optlicence ( );
int DefineILEntry ( );
int DefineGLEntry ( );
int DefineBLEntry ( );
int DefineCMIEntry ( );
int DefineCMEntry ( );
int DefineTCMEntry ( );
int DefineCMSEntry ( );
int DefineUSNEntry ( );
int DefineUONEntry ( );
int DefineUINEntry ( );
int DefineUISEntry ( );
int DefineUCBEntry ( );
int DefineUBEEntry ( );
int DefineUSEEntry  ( );
int DefineUOPEntry  ( );
int addcuts( );
int branchcut( );
int delcuts( );
int dropcuts( );
int getcnlist( );
int getcplist( );
int getcuts( );
int loadcuts( );
int storebnds( );
int storecuts( );
#endif

#ifdef __cplusplus
};
#endif

#ifdef DLL16
#undef int
#undef char
#undef double
#endif

#endif

