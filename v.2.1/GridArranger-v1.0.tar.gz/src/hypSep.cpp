///////////////////////////////// C++ /////////////////////////////////////////
//
//  Module           : hypSep.cpp
//  Description      : Implements a separator for hypermetric inequalities.
//  Author           : Thorsten Bonato
//  Email            : thorsten.bonato@informatik.uni-heidelberg.de
//  Copyright        : University of Heidelberg
//  Created on       : 06.12.2011
//  Last modified by :
//  Last modified on :
//  Update count     :
//
///////////////////////////////////////////////////////////////////////////////
//
//  Date    Name        Changes/Extensions
//  ----    ----        ------------------
//
///////////////////////////////////////////////////////////////////////////////


#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <vector>

#include "MersenneTwister.h"
#include "SparseConstraint.hh"

using namespace std;


//
// g e t E d g e I D
//
/**
 * Given the IDs of the end nodes u and v, the function computes the ID of the
 * edge (u,v). NOTE: all indices start at 0.
 * @param  n  number of nodes
 * @param  u  ID of first end node
 * @param  v  ID of second end node
 *
 * @return  ID of edge (u,v)
 */
static unsigned getEdgeID( unsigned n, unsigned u, unsigned v ) {
    unsigned min = (u <= v) ? u : v;
    unsigned max = (u <= v) ? v : u;

    min++;
    max++;

    return( ( n * (min - 1) ) - ( (min * (min + 1)) / 2 ) + max - 1 );
} // getEdgeID



//
// g e t L P V a l
//
/**
 * This function returns the LP value of a given edge.
 *
 * @param n      Number of nodes.
 * @param i      Index of first end vertex (starting at 0).
 * @param j      Index of second end vertex (starting at 0).
 * @param lpVal  Array storing the LP values of the edges.
 *
 * @return LP value of edge (i,j)
 */
static double getLPVal( int n, int i, int j, double* lpVal ) {

    // If end vertices are identical
    if ( i == j ) {
        // cout << "ERROR in function 'getLPVal'! LP value of edge ("
        //     << i << "," << j << ") undefined!" << endl;

        exit( 1 );
    } // if

    return( lpVal[ getEdgeID( n, i, j ) ] );
} // getLPVal



//
// i s D u p l i c a t e C u t
//
/**
 * This function takes a given inequality and checks whether it is already
 * contained in the buffer or not.
 *
 * @param nNz   Number of nonzero lhs coefficients of the given inequality.
 * @param cs    Checksum of the given inequality.
 * @param idx   Array storing the indices of the lhs coefficients of the
 *              given inequality.
 * @param coef  Array storing the values of the nonzero lhs coefficients
 *              of the given inequality.
 * @param buf   Reference to the vector storing pointers to the previously
                generated inequalities.
 *
 * @return true, if inequality is already part of the buffer. False, otherwise.
 */
static bool isDuplicateCut( int nNz, double cs, int* idx, int* coef,
                            vector< SparseConstraint<int>* >& buf ) {

    // Cycle through all previously generated inequalities
    for ( vector< SparseConstraint<int>* >::iterator it = buf.begin();
          it != buf.end(); it++ ) {

        // If checksums are equal, check number of nonzeros
        if ( cs == (*it)->chk() ) {
            // If numbers of nonzeros are equal, check all entries
            if ( nNz == (*it)->nNz() ) {
                bool isDupl  = true;
                int* bufIdx  = (*it)->idx();
                int* bufCoef = (*it)->coef();

                for ( int j = 0; j < nNz; j++ ) {
                    if ( (idx[j] != bufIdx[j])
                          || (coef[j] != bufCoef[j]) ) {

                        isDupl = false;
                        break;
                    } // if
                } // for

                if ( isDupl ) {
                    return( true );
                } // if
            } // if
        } // if
    } // for

    return( false );
} // isDuplicateCut



//
// h y p e r m e t r i c S e p a r a t o r
//
/**
 * This function tries to generate a violated hypermetric inequality.
 *
 * @param n        Number of nodes in the graph.
 * @param maxgen   Maximum number of inequalities to be generated.
 * @param minViol  Required minimum violation of a separating inequality.
 * @param lpVal    Array storing the LP values of the edges.
 * @param buffer   Reference to vector storing pointers to the generated
 *                 inequalities.
 */
void hypermetricSeparator( int     n,
                           int     maxgen,
                           double  minViol,
                           double* lpVal,
                           vector< SparseConstraint<int>* >& buffer ) {

    //
    // Local variables
    //
    int i;               //
    int j;               // Loop variables.
    int k;               //
    int iter;            //
    int delta;           // Amount by which a b-value is altered in one
                         // iteration.
    int pos1;            // Buffer for random positions.
    int pos2;            //
    int nNz;             // Buffer for number of nonzero entries.
    int bestLocalStep;   // Buffer for the index of the best local step.
    int nFails;          // Counter for failed attempts to generate a new
                         // violated inequality.
    int maxAbsB;         // Maximum absolute value that the entries of b and
                         // bestB are allowed to have.
    int nAdded = 0;      // Counter for successfully added inequalities.

    bool improved;       // Flag indicating whether the violation could be
                         // increased.

    double lhs;          // Value of lhs.
    double bestLhs;      // Value of best lhs.
    double maxLhs;       // Value of maximum lhs value along a search path.
    double posIncr;      // Change of lhs when performing b[pos1] += delta and
                         // b[pos2] -= delta.
    double negIncr;      // Change of lhs when performing b[pos1] -= delta and
                         // b[pos2] += delta.
    double normB;        // Value of squared Euclidean norm of b.
    double normBestB;    // Value of squared Euclidean norm of bestB.
    double normMaxB;     // Value of squared Euclidean norm of maximum b along
                         // local search path.
    double posNorm;      // Value of normB after positive increment.
    double negNorm;      // Value of normB after negative increment.

    double checksum;     // Buffer for checksum of an inequality.
    double tmpDbl;       // Temporary buffer for double values.

    double deltaTimes2;        // Value of 2.0 * delta.
    double deltaSquared;       // Value of delta * delta.
    double deltaSquaredTimes2; // Value of 2.0 * delta * delta.


    //
    // Parameters
    //

#if defined( GLOBAL_BEST_PAIR )

    int    nLocalSteps  = (int) (10 * n);    // Default: 1.25 * n.
    int    maxIter      = 3 * maxgen;        // Default: 150.
    int    maxFails     = 300;               // Default: 30.
    int    nPerturbIter = (int) (5 * n);     // Default: 0.5 * n.
    double minImprove   = 1.0e-3;            // Default: 1.0e-3.

#elif defined( HALF_RANDOM )

    int    nLocalSteps  = (int) (5 * n);
    int    maxIter      = 1000;
    int    maxFails     = 150;
    int    nPerturbIter = (int) (0.5 * n);
    double minImprove   = 1.0e-3;

#else

    int    nLocalSteps  = 5 * n;                    // Default: 5 * n.
    int    maxIter      = maxgen;                   // Default: 10 * maxgen.
    int    maxFails     = (int) ( 0.1 * maxIter );  // Default: 0.1 * maxIter.
    int    nPerturbIter = (int) (0.5 * n);          // Default: 0.5 * n.
    double minImprove   = 1.0e-3;                   // Default: 1.0e-3.

#endif


    // Compute number of edges
    int m = (int) ( (n * (n - 1)) / 2 );


#if defined( GLOBAL_BEST_PAIR )

    int    bestPos1;
    int    bestPos2;
    double bestScaledLhs;
    double bestPosIncr;
    double bestNegIncr;
    double bestPosNorm;
    double bestNegNorm;

    double* posStar = new double[n];

#elif defined( HALF_RANDOM )

    int    bestPos2;
    double bestScaledLhs;
    double bestPosIncr;
    double bestNegIncr;
    double bestPosNorm;
    double bestNegNorm;
    double posStarPos1;

#endif


    //
    // Allocations
    //
    int* b      = new int[n];            // Current b-vector.
    int* bestB  = new int[n];            // Buffer for best b-vector.
    int* idx    = new int[m];            // Buffer for indices of nonzero
                                         // coefficients in inequality.
    int* coef   = new int[m];            // Buffer for nonzero coefficients
                                         // in inequality.
    int* pPlus  = new int[nLocalSteps];  // Array storing the indices of b
                                         // that were increased.
    int* pMinus = new int[nLocalSteps];  // Array storing the indices of b
                                         // that were decreased.


    //
    // Initializations
    //
    MTRand mtrand( 4711 );  // Random number generator.

    nFails             = 0;
    delta              = 1;
    deltaTimes2        = 2.0 * delta;
    deltaSquared       = delta * delta;
    deltaSquaredTimes2 = 2.0 * deltaSquared;
    maxAbsB            = 2;



    //
    // Perform at most maxIter attempts to generate a violated inequality
    //
    for ( iter = 0; iter < maxIter; iter++ ) {
        //
        // Generate initial bestB
        //
        for ( k = 0; k < n; k++ ) {
            bestB[k] = 0;
        } // for

        bestB[ mtrand.randInt( n - 1 ) ] = 1;


        //
        // Perturb initial bestB
        //
        for ( k = 0; k < nPerturbIter; k++ ) {
            // Determine two random positions
            pos1 = mtrand.randInt( n - 1 );

            do {
                pos2 = mtrand.randInt( n - 1 );
            } while ( pos1 == pos2 );

            // Alter bestB
            if ( bestB[pos1] > 0 ) {
                bestB[pos1] -= delta;
                bestB[pos2] += delta;
            } // if

            else {
                bestB[pos1] += delta;
                bestB[pos2] -= delta;
            } // else

            if ( (abs( bestB[pos1] ) >= maxAbsB)
                 || (abs( bestB[pos2] ) >= maxAbsB) ) {

                break;
            } // if
        } // for


        //
        // Compute current bestLhs and norm of bestB
        //
        bestLhs   = 0.0;
        normBestB = 0.0;

        for ( i = 0; i < (n - 1); i++ ) {
            if ( bestB[i] == 0 ) {
                continue;
            } // if

            normBestB += (double) ( bestB[i] * bestB[i] );

            for ( j = i + 1; j < n; j++ ) {
                if ( bestB[j] != 0 ) {
                    bestLhs += bestB[i] * bestB[j]
                               * getLPVal( n, i, j, lpVal );
                } // if
            } // for
        } // for

        if ( bestB[ n-1 ] != 0 ) {
            normBestB += (double) ( bestB[ n-1 ] * bestB[ n-1 ] );
        } // if


        //
        // Perform search along local paths of length nLocalSteps until the
        // first path occurs that yields no possibility of improving the lhs
        // value.
        //
        do {
            // Initializations
            bestLocalStep = -1;
            improved      = false;
            lhs           = bestLhs;
            maxLhs        = -numeric_limits<double>::max();
            normB         = normBestB;
            normMaxB      = 1.0;

            for ( k = 0; k < n; k++ ) {
                b[k] = bestB[k];
            } // for


            // Perform search along local path
            for ( k = 0; k < nLocalSteps; k++ ) {
                //
                // Determine two random positions
                //

            #if defined( GLOBAL_BEST_PAIR )

                bestPos1      = -1;
                bestPos2      = -1;
                bestScaledLhs = -numeric_limits<double>::max();
                bestPosIncr   = -numeric_limits<double>::max();
                bestNegIncr   = -numeric_limits<double>::max();
                bestPosNorm   = -numeric_limits<double>::max();
                bestNegNorm   = -numeric_limits<double>::max();

                // Compute and store positive and negative increments for
                // all stars
                for ( pos1 = 0; pos1 < n; pos1++ ) {
                    posStar[ pos1 ] = 0.0;

                    // Calculate increments in the star of pos1
                    for ( i = 0; i < n; i++ ) {
                        if ( i != pos1 ) {
                            // Positive increment (negative increment is simply
                            // the positive one times -1)
                            posStar[ pos1 ] += delta * b[i] * getLPVal( n, pos1, i, lpVal );
                        } // if
                    } // for
                } // for

                for ( pos1 = 0; pos1 < n - 1; pos1++ ) {
                    for ( pos2 = pos1 + 1; pos2 < n; pos2++ ) {

                        tmpDbl = deltaSquared * getLPVal( n, pos1, pos2, lpVal );

                        // posIncr = change of lhs when performing b[pos1] += delta;
                        //                                         b[pos2] -= delta;
                        // negIncr = change of lhs when performing b[pos1] -= delta;
                        //                                         b[pos2] += delta;
                        posIncr = posStar[ pos1 ] - posStar[ pos2 ] - tmpDbl;
                        negIncr = posStar[ pos2 ] - posStar[ pos1 ] - tmpDbl;

                        posNorm = normB
                                  + ( deltaTimes2 * (b[pos1] - b[pos2]) )
                                  + deltaSquaredTimes2;

                        negNorm = normB
                                  + ( deltaTimes2 * (b[pos2] - b[pos1]) )
                                  + deltaSquaredTimes2;


                        // Update best increments if necessary
                        if ( ((lhs + posIncr) / posNorm) > bestScaledLhs ) {
                            bestScaledLhs = (lhs + posIncr) / posNorm;
                            bestPos1      = pos1;
                            bestPos2      = pos2;
                            bestPosIncr   = posIncr;
                            bestNegIncr   = negIncr;
                            bestPosNorm   = posNorm;
                            bestNegNorm   = negNorm;
                        } // if

                        if ( ((lhs + negIncr) / negNorm) > bestScaledLhs ) {
                            bestScaledLhs = (lhs + negIncr) / negNorm;
                            bestPos1      = pos1;
                            bestPos2      = pos2;
                            bestPosIncr   = posIncr;
                            bestNegIncr   = negIncr;
                            bestPosNorm   = posNorm;
                            bestNegNorm   = negNorm;
                        } // if
                    } // for
                } // for

                pos1    = bestPos1;
                pos2    = bestPos2;
                posIncr = bestPosIncr;
                negIncr = bestNegIncr;
                posNorm = bestPosNorm;
                negNorm = bestNegNorm;

            #elif defined( HALF_RANDOM )

                bestPos2      = -1;
                bestScaledLhs = -numeric_limits<double>::max();
                bestPosIncr   = -numeric_limits<double>::max();
                bestNegIncr   = -numeric_limits<double>::max();
                bestPosNorm   = -numeric_limits<double>::max();
                bestNegNorm   = -numeric_limits<double>::max();

                pos1 = mtrand.randInt( n - 1 );

                // Calculate increments in the star of pos1
                posStarPos1 = 0.0;

                for ( i = 0; i < n; i++ ) {
                    if ( i != pos1 ) {
                        // Positive increment (negative increment is simply
                        // the positive one times -1)
                        posStarPos1 += delta * b[i] * getLPVal( n, pos1, i, lpVal );
                    } // if
                } // for


                for ( pos2 = 0; pos2 < n; pos2++ ) {
                    if ( pos2 == pos1 ) {
                        continue;
                    } // if

                    posIncr = posStarPos1;
                    negIncr = -posStarPos1;


                    //
                    // Calculate increments in the star of pos2
                    //
                    for ( i = 0; i < n; i++ ) {
                        if ( i != pos2 ) {
                            tmpDbl = delta * b[i] * getLPVal( n, pos2, i, lpVal );
                            posIncr -= tmpDbl;
                            negIncr += tmpDbl;
                        } // if
                    } // for


                    //
                    // Correction term for edge (pos1,pos2)
                    //
                    tmpDbl = deltaSquared * getLPVal( n, pos1, pos2, lpVal );
                    posIncr -= tmpDbl;
                    negIncr -= tmpDbl;


                    // posIncr = change of lhs when performing b[pos1] += delta;
                    //                                         b[pos2] -= delta;
                    // negIncr = change of lhs when performing b[pos1] -= delta;
                    //                                         b[pos2] += delta;
                    posNorm = normB
                              + ( deltaTimes2 * (b[pos1] - b[pos2]) )
                              + deltaSquaredTimes2;

                    negNorm = normB
                              + ( deltaTimes2 * (b[pos2] - b[pos1]) )
                              + deltaSquaredTimes2;


                    // Update best increments if necessary
                    if ( ((lhs + posIncr) / posNorm) > bestScaledLhs ) {
                        bestScaledLhs = (lhs + posIncr) / posNorm;
                        bestPos2      = pos2;
                        bestPosIncr   = posIncr;
                        bestNegIncr   = negIncr;
                        bestPosNorm   = posNorm;
                        bestNegNorm   = negNorm;
                    } // if

                    if ( ((lhs + negIncr) / negNorm) > bestScaledLhs ) {
                        bestScaledLhs = (lhs + negIncr) / negNorm;
                        bestPos2      = pos2;
                        bestPosIncr   = posIncr;
                        bestNegIncr   = negIncr;
                        bestPosNorm   = posNorm;
                        bestNegNorm   = negNorm;
                    } // if
                } // for


                pos2    = bestPos2;
                posIncr = bestPosIncr;
                negIncr = bestNegIncr;
                posNorm = bestPosNorm;
                negNorm = bestNegNorm;

            #else

                pos1 = mtrand.randInt( n - 1 );

                do {
                    pos2 = mtrand.randInt( n - 1 );
                } while ( pos1 == pos2 );

                posIncr = 0.0;
                negIncr = 0.0;


                //
                // Calculate the positive and negative increments, i.e. the
                // change in lhs when performing
                //
                //     b[i] += delta, b[j] -= delta;
                //
                // or
                //
                //     b[i] -= delta, b[j] += delta;
                //

                // Calculate increments in the star of pos1
                for ( i = 0; i < n; i++ ) {
                    if ( i != pos1 ) {
                        tmpDbl = delta * b[i] * getLPVal( n, pos1, i, lpVal );
                        posIncr += tmpDbl;
                        negIncr -= tmpDbl;
                    } // if
                } // for

                // Calculate increments in the star of pos2
                for ( i = 0; i < n; i++ ) {
                    if ( i != pos2 ) {
                        tmpDbl = delta * b[i] * getLPVal( n, pos2, i, lpVal );
                        posIncr -= tmpDbl;
                        negIncr += tmpDbl;
                    } // if
                } // for

                //
                // Correction term for edge (pos1,pos2)
                //
                tmpDbl = deltaSquared * getLPVal( n, pos1, pos2, lpVal );
                posIncr -= tmpDbl;
                negIncr -= tmpDbl;


                // posIncr = change of lhs when performing b[pos1] += delta;
                //                                         b[pos2] -= delta;
                // negIncr = change of lhs when performing b[pos1] -= delta;
                //                                         b[pos2] += delta;
                posNorm = normB
                          + ( deltaTimes2 * (b[pos1] - b[pos2]) )
                          + deltaSquaredTimes2;

                negNorm = normB
                          + ( deltaTimes2 * (b[pos2] - b[pos1]) )
                          + deltaSquaredTimes2;

            #endif


                // If normalized lhs after positive increment is better than
                // the one after negative increment
                if ( ((lhs + posIncr) / posNorm)
                     > ((lhs + negIncr) / negNorm) ) {

                    b[pos1]  += delta;
                    b[pos2]  -= delta;
                    lhs      += posIncr;

                    pPlus[k]  = pos1;
                    pMinus[k] = pos2;

                    normB     = posNorm;
                } // if

                else {
                    b[pos1]  -= delta;
                    b[pos2]  += delta;
                    lhs      += negIncr;

                    pMinus[k] = pos1;
                    pPlus[k]  = pos2;

                    normB     = negNorm;
                } // else

                if ( (lhs / normB) > (maxLhs / normMaxB) ) {
                    maxLhs        = lhs;
                    normMaxB      = normB;
                    bestLocalStep = k;

                    if ( (maxLhs / normMaxB) > (bestLhs / normBestB) + minImprove ) {
                        improved = true;
 // -------------------   // break;    
                    } // if
                } // if

                if ( (abs( b[pos1] ) >= maxAbsB)
                     || (abs( b[pos2] ) >= maxAbsB) ) {

                    break;
                } // if
            } // for


            // bestLocalStep has to be >= 0. Otherwise we have a problem.
            if ( bestLocalStep < 0 ) {
                // cout << "Error in hypermetricSeparator(): " << endl
                //     << "  final value of bestLocalStep < 0 !" << endl;
                exit( 5 );
            } // if


            // If normalized bestLhs could be improved
            if ( improved ) {
                bestLhs   = maxLhs;
                normBestB = normMaxB;


                // Update bestB by following the local search path up to
                // length bestLocalStep
                for ( k = 0; k <= bestLocalStep; k++ ) {
                    bestB[ pPlus[k] ]  += delta;
                    bestB[ pMinus[k] ] -= delta;
                } // for


                if ( bestLhs > 1.0 * minViol ) {
                    break;
                } // if
            } // if
        } while ( improved );


        //
        // If violation is larger than minViol, generate the
        // corresponding hypermetric inequality.
        // Note that the violation equals bestLhs since the right hand side
        // is zero.
        //
        if ( bestLhs > minViol ) {
            //
            // Gather information on inequality and compute checksum
            //
            nNz      = 0;
            checksum = 0.0;

            for ( i = 0; i < (n - 1); i++ ) {
                if ( bestB[i] == 0 ) {
                    continue;
                } // if

                checksum += log( fabs( (double) bestB[i] ) );

                for ( j = i + 1; j < n; j++ ) {
                    if ( bestB[j] != 0 ) {
                        idx[ nNz ]  = getEdgeID( n, i, j );
                        coef[ nNz ] = bestB[i] * bestB[j];
                        nNz++;
                    } // if
                } // for
            } // for

            if ( bestB[ n-1 ] != 0 ) {
                checksum += log( fabs( (double) bestB[ n-1 ] ) );
            } // if


            // Check the already generated inequalities
            if ( isDuplicateCut( nNz, checksum, idx, coef, buffer ) ) {
                nFails++;

                if ( nFails >= maxFails ) {
                    goto Terminate;
                } // if

                goto NoInequalityGenerated;
            } // if

            buffer.push_back( new SparseConstraint<int>( nNz, 0, idx, coef, checksum ) );
            nAdded++;

            if ( nAdded >= maxgen ) {
                goto Terminate;
            } // if
            // End of "Allocate Inequality"


            // Goto
            NoInequalityGenerated:;
        } // if

        else {
            nFails++;

            if ( nFails >= maxFails ) {
                goto Terminate;
            } // if
        } // else
    } // for

    // Goto
    Terminate:

    //
    // Free disk space
    //
    delete [] b;
    delete [] bestB;
    delete [] idx;
    delete [] coef;
    delete [] pPlus;
    delete [] pMinus;

#if defined( GLOBAL_BEST_PAIR )
    delete [] posStar;
#endif

    return;
} // hypermetricSeparator
