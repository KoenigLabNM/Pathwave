////////////////////////////////////// c++ /////////////////////////////////////
//
//  Module           : gridSub.hh
//  Description      :
//  Author           : Marcus Oswald
//  Email            : Marcus.Oswald@informatik.uni-heidelberg.de
//  Copyright        : University of Heidelberg
//  Created on       : Tue Jul  2 17:23:19 2002
//  Last modified by : oswald
//  Last modified on : Tue Jul 23 09:42:20 2002
//  Update count     : 8
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date	Name		Changes/Extensions
//  ----	----		------------------
//
////////////////////////////////////////////////////////////////////////////////


#ifndef LAP_SUB_HH
#define LAP_SUB_HH

#include "abacus/sub.h"

class GridMaster;
class GridVariable;

/**
 * This class realizes a Grid-Arrangement-Subproblem derived from ABA_SUB
*/
class GridSub:public ABA_SUB{

public:
  // -----------------------------------------------------
  // ------- M e t h o d s   ( p u b l i c ) -------------
  // -----------------------------------------------------

  /**
   * Constructor.
   *
   * @param master Pointer to the Master-Problem.
   * @param father Pointer to the Father-Problem in the Branch&Cut-Tree.
   * @param branchRule Pointer to the Branchrule.
   */
  GridSub(ABA_MASTER*master,ABA_SUB*father,ABA_BRANCHRULE*branchRule);

  /**
   * Constructor for the first Subproblem.
   *
   * @param master Pointer to the Master-Problem
   */
  GridSub(ABA_MASTER*master);

  /**
   * Destructor.
   */
  virtual~GridSub();

  /**
   * Test if the current LP-Solution is a feasible Linear-Ordering-Solution.
   */
  virtual bool feasible();

  /**
   * Generating the sons of the current Subproblem.
   *
   * @param branchRule Pointer to the Branchrule.
   */
  virtual ABA_SUB*generateSon(ABA_BRANCHRULE*branchRule);
 
  virtual int generateBranchRules(ABA_BUFFER<ABA_BRANCHRULE*>&rules);
    //int branchingOnVarCon(ABA_BUFFER<ABA_BRANCHRULE*>&rules);

  /**
   * Creating the Linear-Ordering-Separation-class LopThreeCycleSeparator, 
   * derived from the ABACUS-class ABA_SEPARATOR.
   */
  virtual int separate();

  /**
   * Starting the improve-heuristing.
   *
   * @param primalValue Value of the current best feasible solution.
   */
  virtual int improve(double &primalValue);

  void createDistConstraintsFromCutList(list<int>& cuts, int type);
  void createConstraintsOnlyDistVariables(list<int> onlyDist);

private:
  // -----------------------------------------------------
  // ------- M e t h o d s   ( p r i v a t ) -------------
  // -----------------------------------------------------

  /**
   * Returns the Pointer to the Linear-Ordering-Masterproblem
   */ 
  GridMaster* gridMaster();


  // -----------------------------------------------------
  // -------- V a r i a b l e s --------------------------
  // -----------------------------------------------------

  int ngen_;

}; // class LopSub

#endif  

