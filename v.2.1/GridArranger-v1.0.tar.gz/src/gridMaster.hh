////////////////////////////////////// c++ /////////////////////////////////////
//
//  Module           : gridMaster.hh
//  Description      :
//  Author           : Marcus Oswald
//  Email            : Marcus.Oswald@informatik.uni-heidelberg.de
//  Copyright        : University of Heidelberg
//  Created on       : Tue Jul  2 14:40:43 2002
//  Last modified by : oswald
//  Last modified on : Tue Jul 23 14:44:52 2002
//  Update count     : 23
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date	Name		Changes/Extensions
//  ----	----		------------------
//
////////////////////////////////////////////////////////////////////////////////



#ifndef LAP_MASTER_HH
#define LAP_MASTER_HH

#include "abacus/master.h"
#include "cplex.h"
#include "FeasibilityTree.hpp"
#include "FeasibilityTest.hpp"

                                                                  
/**
 * This class realizes the Linear-Ordering-Masterproblem derived from ABA_MASTER
*/
class GridMaster:public ABA_MASTER{
public:
  /**
   * Constructor.
   *
   * @param problemName Name of the Problem.
   */
  GridMaster(const char*problemName);

  /**
   * Destructor.
   */
  virtual~GridMaster();


  FeasibilityTest* m_feasyTest;

  /**
   * Returns the pointer of the first Subproblem.
   */
  virtual ABA_SUB* firstSub();


ABA_STANDARDPOOL<ABA_CONSTRAINT,ABA_VARIABLE> *constraintPool()

  {return m_constraintPool;};



private:


    /**
     * The constraint pool.
     */
    
    ABA_STANDARDPOOL<ABA_CONSTRAINT,ABA_VARIABLE> *m_constraintPool; 
    
    
    /**
     *  Reading a -Ordering-Problem.
     *
     * @param fileName Name of the File of the Problem.
     */
    void readGridFile(const char*fileName);
    
    /**
     *  Initialization of the Optimization. 
     *  Generating variables and initial constraints.
     */
    virtual void initializeOptimization();
    virtual void terminateOptimization();
    virtual void initializeParameters();
    
    
    GridMaster(const GridMaster&rhs);
    const GridMaster&operator= (const GridMaster&rhs);
};

#endif 
