////////////////////////////////////// c++ /////////////////////////////////////
//
//  Module           : generalIntConstraint.cpp
//  Description      :
//  Author           : Dino Ahr & Marcus Oswald & Gerhard Reinelt & Klaus Wenger
//  Email            : {Dino.Ahr|Marcus.Oswald|Gerhard.Reinelt|Klaus.Wenger}@informatik.uni-heidelberg.de
//  Copyright        : University of Heidelberg
//  Created on       : Thu Jul  4 17:04:05 2002
//  Last modified by : wiesberg
//  Last modified on : Wed Feb 03 2010
//  Update count     : 2
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date	Name		Changes/Extensions
//  ----	----		------------------
// Feb 3 2010   wiesberg        The sense of the constraint ('<=', '>=' or '=')
//				is now given to the constructor.
////////////////////////////////////////////////////////////////////////////////


#include "generalIntConstraint.hh"


  /**
   * Constructor.
   *
   * @param master Pointer to the master-problem.
   * @param nVars The total number of variables with nonzero coefficient in the constraint.
   * @param rhs The right-hand-side of the constraint.
   * @param vari The indices of the variables with nonzero coefficient in the constraint.
   * @param coef Array of the coefficients.
   */
GeneralIntConstraint::GeneralIntConstraint(ABA_MASTER*master, int nVars, int rhs, int* vari, int* coef, ABA_CSENSE::SENSE sense, bool isDynamic):
  ABA_CONSTRAINT(master,0,sense,(double)rhs,isDynamic,false,false),
  m_nVars(nVars),
  m_rhsInt(rhs)
{
  m_vari = new int[nVars];
  m_coef = new int[nVars];

  int i;
  for(i=0;i<nVars;i++) {
    m_vari[i] = vari[i];
    m_coef[i] = coef[i];
  }
}

GeneralIntConstraint::~GeneralIntConstraint()
{
  delete[] m_vari;
  delete[] m_coef;
}

  /**
   * Returns the name of the constraint.
   *
   */
const char* GeneralIntConstraint::name() {
  return "GeneralIntConstraint";
}

  /**
   * Returns the hashkey of the constraint.
   *
   */
unsigned GeneralIntConstraint::hashKey() {
  return 0;
}

  /**
   * Returns the coefficient of the variable v in the constraint.
   *
   * @param v variable of type EdgeVariable derived from ABA_VARIABLE
   */
double GeneralIntConstraint::coeff(ABA_VARIABLE*v)
{
  return 0.0;
}

  /**
   * Generating the whole row of the constraint in a sparse format.
   *
   * @param row Sparse row to be generated.
   */
int GeneralIntConstraint::genRow(ABA_ACTIVE<ABA_VARIABLE,ABA_CONSTRAINT> *, ABA_ROW &row)
{
  int i;
  for(i=0;i<m_nVars;i++) {
    row.insert(m_vari[i],(double)m_coef[i]);
  }
  row.rhs(rhs());
  row.sense(sense_);
  return row.nnz(); 
}

bool GeneralIntConstraint::equal(ABA_CONVAR *cv) 
{
    return false;
}
