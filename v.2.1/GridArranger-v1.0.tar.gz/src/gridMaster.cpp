////////////////////////////////////// c++ /////////////////////////////////////
//
//  Module           : gridMaster.cpp
//  Description      :
//  Author           : Marcus Oswald
//  Email            : Marcus.Oswald@informatik.uni-heidelberg.de
//  Copyright        : University of Heidelberg
//  Created on       : Tue Jul  2 15:42:51 2002
//  Last modified by : oswald
//  Last modified on : Wed Feb 03 2010
//  Update count     : 51
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date	Name		Changes/Extensions
//  ----	----		------------------
// Feb 03 2010  wiesberg  Changing file for Grid Arrangement Problem
////////////////////////////////////////////////////////////////////////////////

#include <cstdlib>
#include "gridMaster.hh"
#include "gridSub.hh"
//#include "gridVariable.hh"
#include "generalIntConstraint.hh"
#include "abacus/master.h"
#include "abacus/numvar.h"
#include "FeasibilityTree.hpp"
#include "FeasibilityTest.hpp"

extern"C"{
  #include <stdio.h>
  #include <string.h>
}
#ifdef ABACUS_MATH_CPP
#include <math.h>
#else
extern"C"{
  #include <math.h>
}
#endif

  /**
   * Constructor.
   *
   * @param problemName Name of the Problem.
   */
GridMaster::GridMaster(const char*problemName):
  ABA_MASTER(problemName,true,false,ABA_OPTSENSE::Min),m_constraintPool(NULL)
{
                                                                    
  if(problemName==0){
    err()<<"GridMaster::GridMaster(): problem name is missing."<<endl;
    exit(Fatal);
  }

  //cout<< endl << "2D-GRID-ARRANGEMENT-Solver v. 0.9"<<endl;
  //cout<<"Copyright (c) 2009 Universitaet Heidelberg, Germany"<<endl<<endl;

  char* problemName2 = (char*)problemName;
  m_feasyTest = new FeasibilityTest(problemName2);
  if(m_feasyTest->m_isZeroMatrix){ 
    m_feasyTest->m_calculateAndNormalizeSolution();
    m_feasyTest->m_createOutputFiles(-2);
    cout << "Input graph does not contain any edges. Nothing to optimize."; 
    cout << endl;
  }
  
}

void GridMaster::readGridFile(const char*fileName)
{

}

GridMaster::~GridMaster()
{
  //cout << "deleting feasibility test data...";
  delete m_feasyTest;
  //cout << " done" <<endl;

  if ( m_constraintPool ) {
      delete m_constraintPool;
  } // if
}

  /**
   * Returns the pointer of the first Subproblem.
   */
ABA_SUB* GridMaster::firstSub()
{
  return new GridSub(this);
}


  /**
   * Initialization of the Optimization. Generating variables and 
   * initial constraints.
   */
void GridMaster::initializeOptimization()
{
     
//cout << "intialize variables" << endl;
  ABA_BUFFER<ABA_VARIABLE*>variables(this,(m_feasyTest->m_nEdges)
                        *(m_feasyTest->m_maxDistAllowedInModel));

  int i;
  double maxPossibleDistance = (double)m_feasyTest->m_maxDistAllowedInModel;
  // add integral distance variables:
  for (i = 0; i < m_feasyTest->m_nEdges; i++) {
    variables.push(new ABA_NUMVAR(this,0,i, false, false, 
          (m_feasyTest->m_edgeWeights)[i] + (100-(rand()%200))*0.00000001, 1.0, maxPossibleDistance, 
          ABA_VARTYPE::Integer) );
  }
  // add binary monotony variables:
  for (i = m_feasyTest->m_nEdges; i < (m_feasyTest->m_nEdges)
                 *(m_feasyTest->m_maxDistAllowedInModel); i++){
    variables.push(new ABA_NUMVAR(this,0,i, false, false, 0.0, 0.0, 1.0, 
                   ABA_VARTYPE::Binary) );
  }

  ABA_BUFFER<ABA_CONSTRAINT*>constraints(this,2*(m_feasyTest->m_nEdges)
                                *(m_feasyTest->m_maxDistAllowedInModel));

//cout << "intialize constraints" << endl;
  // adding constraints which connect the 
  // integral distance- and the binary monotony-variables:
  int nNonZeros = m_feasyTest->m_maxDistAllowedInModel;
  int counterDistVar = 0;
  int counterMonVar = m_feasyTest->m_nEdges;

  int* coef = new int[nNonZeros];
  int* vari = new int[nNonZeros];
  coef[0] = 1;
  for(int j = 1; j < nNonZeros; j++){coef[j] = -1;}

  for(i = 0; i < m_feasyTest->m_nEdges; i++){
    vari[0] = i;
    for(int j = 1; j < nNonZeros; j++){
 	vari[j] = counterMonVar;
  	counterMonVar++;
    }
    GeneralIntConstraint* conny = new GeneralIntConstraint(
                      this, nNonZeros, 1, vari, coef, ABA_CSENSE::Equal, false);
    constraints.push(conny);
    counterDistVar++;
  }
  delete [] vari;
  delete [] coef;
  
  // adding constraints for the (binary) monotony-variables:
  nNonZeros = 2;
  vari = new int[nNonZeros];
  coef = new int[nNonZeros];
  coef[0] = 1;
  coef[1] = -1;
  for(i = m_feasyTest->m_nEdges; 
         i < m_feasyTest->m_nEdges * m_feasyTest->m_maxDistAllowedInModel; i++){
     if(   (i - m_feasyTest->m_nEdges) 
         % (m_feasyTest->m_maxDistAllowedInModel - 1) != 0 ){
        vari[0] = i;
        vari[1] = i-1;
        GeneralIntConstraint* conny = new GeneralIntConstraint(
                       this, nNonZeros, 0, vari, coef, ABA_CSENSE::Less, false);
        constraints.push(conny);
     }
  }
  delete [] vari;
  delete [] coef;
//cout << "intialize pools" << endl;
  initializePools(constraints,variables,
     10*(m_feasyTest->m_nEdges)*(m_feasyTest->m_maxDistAllowedInModel)-1,
      2*(m_feasyTest->m_nEdges)*(m_feasyTest->m_maxDistAllowedInModel),true);
  // 0: genIntConstraint-pool
  m_constraintPool = new ABA_STANDARDPOOL<ABA_CONSTRAINT,ABA_VARIABLE>(
   this, 2*(m_feasyTest->m_nEdges)*(m_feasyTest->m_maxDistAllowedInModel),true); 
 // cout<<"End initialize optimization"<<endl;
}

void GridMaster::terminateOptimization()
{
  m_feasyTest->m_calculateAndNormalizeSolution();
  cout << "| Best solution value: " << primalBound() << endl; 
  m_feasyTest->m_createOutputFiles( lowerBound() );
  m_feasyTest->m_printFinalStatistics();
}

void GridMaster::initializeParameters() {
}
