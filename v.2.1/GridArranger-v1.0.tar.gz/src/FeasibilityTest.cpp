////////////////////////////////////// c++ /////////////////////////////////////
//
//  Module           : FeasibilityTest.cpp
//  Description      : The methods of his class is able to test whether a given 
//                     distance matrix D (partially given) is embeddable on a 
//                     2-dimensional grid. If possible, the absolute coordinates
//                     are returned. If there is no such embedding, problematic
//                     submatrices of minimum size are determined and returned,
//                     enabling the construction of cutting planes in a branch-
//                     and-cut algorithm.
//  Author           : Stefan Wiesberg
//  Email            : stefan.wiesberg@gmx.de
//  Copyright        : University of Heidelberg, Germany
//  Created on       : Wed Feb 03 2010
//  Last modified by : 
//  Last modified on : 
//  Update count     : 0
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date	Name		Changes/Extensions
//  ----	----		------------------
//
////////////////////////////////////////////////////////////////////////////////


#include <algorithm>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "FeasibilityTest.hpp"
#include "gridSub.hh"
#include "SparseConstraint.hh"
#include "hypSep.hh"
#include "generalIntConstraint.hh"
using namespace std;

// ---------------------------------------------------------------------------
// -----------  PARAMETERS  --------------------------------------------------
// ---------------------------------------------------------------------------


/* Specify the format of the input data file. 
1: DKFZ format:
	line 1: number of nodes n
	line 2: suggestion for maxdist, or 0 (estimate maxdist) or -1 ( n-2 is maxdist )
	line 3 to n-3: adjacency matrix of G
2: Grid Breaking Tree format:
	line 1: number of nodes n
	line 2: number of edges m
	line 3 to m-3: edge list
*/
int inputFormat = 1;

/* If true, the main depth-first-search trees are stored in a compact way.
This leads to an increase in running time as the minimization of conflict sets
cannot make use of the search tree information anymore. 
Default value: false */
bool runInMinMemoryMode = false;
/* If true, among the several embedding possibilties the most aesthetic one is
returned. You have to define the aesthetic value function first. Leads to an 
increase in running time. Recommended for small instances only.
Default value: false */
bool findMostAestheticSolution = true;
/* If true, the conflict sets are not only minimized with respect to vertices,
but also with respect to edges afterwards. Improves the cutting plane's quality,
increases the running time. 
Default value: true */
bool useEdgeMinimization = false;
/* If true, the output files are not only created after the optimization process
is finished, but after every quality improval. Recommended for long time
calculations: The files with the currently best solutions are saved even if the
calculations are unexpectedly interrupted. 
Default value: true */
bool createOutputFileAfterEveryImproval = true;
/* If true, only a single cutting plane for each component is calculated by each
call of the feasibilty test. If false, several cutting planes are calculated
and returned.
Default value: false */
bool returnSingleCuttingPlane = false;
/* If true, the initial vertex fixations for the embeddability test are tried 
to be adopted from the last tests. Saves time, but might constrain the variety
of the cutting planes to be found.
Default value: false */
bool useInfoFromFormerTests = false;
/* There are two strategys for the order of fixation of the vertices during the
embeddability test:
  1: Random ordering
  2: Include information on vertex degree and distances to keep the tree small
Default value: 2 */
int vertexOrderingStrategy = 2;
/* The separation of clique graphs might be time consuming. The parameter
specifies the size of the maximum clique to be separated. Note that the right-
hand side of the corresponding inequality must be known. Current max possible
value: 9.
Default value: 9 */
int maxCliqueSizeToBeSeparated = 9;
/* If true, then additional information on the embeddability tests is printed
to screen. 
Default value: true
*/
bool highOutputLevel = false;



// ----------------------------------------------------------------------------
// -------- PROGRAM SOURCE CODE -----------------------------------------------
// ----------------------------------------------------------------------------

void FeasibilityTest::m_printError(int errorID){
  cout << "FeasibilityTest: ";
  if(errorID < 0) {cout << "Fatal error ";}
  else {cout << "Warning ";}
  cout << "during ";

  if(errorID == -1){
             cout << "initialization: Input file (containing the ";
             cout << "graph) could not be found or opened."; 
  }
  if(errorID == -2){
             cout << "initialization: Problem with input file (containing the ";
             cout << "graph). Check the syntax: Line 1: Number of vertices n. ";
             cout << "Line 2: Max. possible distance value allowed by the IP-";
             cout << "model. Line 3 to 3+n-1: ";
             cout << "Binary adjacency matrix (n x n) of the graph.";
  }
  if(errorID == -4){
             cout << "initialization: Problem with input file (containing the ";
             cout << "graph). The adjacency matrix is not symmetrical (i.e. ";
             cout << "the graph is not undirected)! Only symmetrical matrices ";
             cout << "are allowed.";
  }
  if(errorID == -6){
             cout << "reading of cplex solution: The user given array of ";
             cout << "distance values is too short. Needed length: ";
             cout << m_nEdges << " entries. Exit.";             
             }
  if(errorID == -10){
             cout << "determination of the next vertex to fix: The list of ";
             cout << "already fixed vertices is empty. Any call of private ";
             cout << "member method 'int determineNextVertex(int)' requires ";
             cout << "at least one vertex to be fixed already."; 
  }
  if(errorID == -11){
             cout << "ERROR_NOT_ENOUGH_MEMORY"; 
  }  
  if(errorID == -12){
	     cout << "main depth first search. Exit.";
  }
  if(errorID == 1){
             cout << "initialization: Problem with input file (containing the ";
             cout << "graph). The given adjacency matrix contains a non-zero ";
             cout << "entry on the main diagonal. Entry ignored. ";
  }
  
  cout << endl;   
}

struct distSol{
  int var;
  float val;
};

bool operator<(const distSol& left, const distSol& right){
   if(left.val < right.val) {return true;}
   else {return false;}
}

bool FeasibilityTest::m_readInputFile(const char* graphFile){
//cout << "reading input matrix... ";
  ifstream source;
  try{
      source.open(graphFile, ios::in);
      }
  catch(...){m_printError(-1); return false;}
  
  try{
      source >> m_nVertices;
      if(m_nVertices <= 0 || m_nVertices > 100000){
                     m_printError(-2); 
                     return false;
      }
	  
	  if( inputFormat == 1 ) source >> m_maxDistAllowedInModel;               
	  if( inputFormat == 2 ){ 
		source >> m_nEdges;
			if( m_nEdges == 0 ) m_isZeroMatrix = true;
			else m_isZeroMatrix = false;
	  }

	 if( inputFormat == 1 ){
      vector<int> column;
      list<int> adjList;
      m_nEdges = 0;
      m_edgeWeights.clear();
	  int help = -1;
      double helpDouble;
      m_isZeroMatrix = true;
      for(int v1=0; v1<m_nVertices; v1++) {
              for(int v2=0; v2<m_nVertices; v2++) {
	         source >> helpDouble;
	         if( helpDouble < 0.001 ) help = 0;
             else{ 
                help = 1; // ((int)(helpDouble + 0.00001)); 
				if( v1 < v2 ) m_edgeWeights.push_back( helpDouble );
            }
	         column.push_back(help);
	         if(help == 0){ } 
	         if(help == 1 && v1 != v2){
                   m_isZeroMatrix = false;
                   adjList.push_back(v2);
                       m_nEdges++;
                  }
                  if(help != 1){ 
                    if(help != 0) {
                      m_printError(-2);
                      return false;
                    }
                 }
              }
              m_adjMatrix.push_back(column);
              m_adjList.push_back(adjList);
              column.clear();
              adjList.clear();
      }
      m_nEdges = m_nEdges / 2;

   }
   
   if( inputFormat == 2 ){
		m_adjList.clear();
		vector<int> column( m_nVertices, 0 );
		list<int> emptyList;
		for( int i=0; i<m_nVertices; i++){ 
			m_adjMatrix.push_back( column );
			m_adjList.push_back( emptyList );
		}
		int head, tail;
		for( int i=0; i < m_nEdges; i++ ){
			m_edgeWeights.push_back( 1.0 );
			source >> tail;
			source >> head;
			if( tail >= m_nVertices || tail <= -1 || head >= m_nVertices || head <= -1 ){
				cout << "Error! Problematic edge (" << tail << "," << head << "). Vertex numbers must lie in range 0.." << m_nVertices << endl; 
				return false;
			}
			if( m_adjMatrix[tail][head] != 1){
				m_adjMatrix[tail][head] = 1;
				m_adjMatrix[head][tail] = 1;
				m_adjList[tail].push_back( head );
				m_adjList[head].push_back( tail );
			}
			else{ 
				cout << "Error: Edge (" << tail << "," << head << ") is twice in edge list." << endl;
				return false;
			}
		}
		
		
		
	} // if inputFormat == 2
	} // try
	
    catch(...){
       m_printError(-2); 
       return false;
    }  
	
   //cout << "done" << endl;   
   //cout << "#Vertices = " << m_nVertices << ", #Edges = " << m_nEdges << endl;
   if(m_isZeroMatrix){return false;}
   m_isTestForMaxDistance = false;
   m_heuristicIsCurrentlyActive = false;
   //cout << "analyzing graph... " << endl;
   // edgeNumberMatrix:
   vector<int> zeroColumn;
   for(int i=0; i<m_nVertices; i++) zeroColumn.push_back(0);
   for(int i=0; i<m_nVertices; i++) m_edgeNumberMatrix.push_back(zeroColumn);
   int edgeCounter = 0;
   for(int i=0; i<m_nVertices-1; i++){
     for(int j=i+1; j<m_nVertices; j++){
	if(m_adjMatrix[i][j] == 1){
	   m_edgeNumberMatrix[i][j] = edgeCounter;
	   m_edgeNumberMatrix[j][i] = edgeCounter;
	   edgeCounter++;
	}
     }
   }

   // Initializing sets
   m_bestApproximationValue = -1;
   m_aestheticModeActivated = false;
   m_conflictSets.clear();
   m_conflictSetsEdges.clear();
   vector<int> distColumn;
   for(int i=0; i<m_nVertices; i++){ 
        distColumn.push_back(0);
   } 
   for(int i=0; i<m_nVertices; i++){ 
        m_distMatrix.push_back(distColumn);
   }
   m_nCplexSolutionTests = 0; 
   m_nCutsTotal = 0;
   m_createOutputFileAfterEveryImproval = createOutputFileAfterEveryImproval;
   m_bestLowerBound = 0;

   // right-hand sides of clique constraints:
   int rhsClique[10] = {0,0,1,4,8,16,25,38,54,72};
   for(int i=0; i<10; i++){m_rhsClique.push_back(rhsClique[i]);}
   if(maxCliqueSizeToBeSeparated <= 9){ 
	m_maxCliqueSizeToBeSeparated = maxCliqueSizeToBeSeparated;
   }
   else{
        m_maxCliqueSizeToBeSeparated = 9;
   }

   // determine connected components of the graph:
   //cout << "  determining connected components...";
   list<int>::iterator iter;
   bool isAlreadySet[m_nVertices+1];
   for(int i=0;i<m_nVertices+1;i++){isAlreadySet[i] = false;}
   int nextComponentStartVertex = 0;

   do{
     int components[m_nVertices+1];
     for(int i=0;i<m_nVertices+1;i++){components[i] = -1;}
     components[0] = nextComponentStartVertex;
     isAlreadySet[nextComponentStartVertex] = true;

     int writePos = 1;
     int componentSize = 1;
     for(int readPos = 0; readPos<m_nVertices; readPos++){
       for(iter = m_adjList[components[readPos]].begin(); 
                          iter != m_adjList[components[readPos]].end(); ++iter){
           if(!isAlreadySet[*iter] ){
               components[writePos] = *iter;
               writePos++;
               componentSize++;
               isAlreadySet[*iter] = true;
           }     
       }
       if(components[readPos+1] == -1){break;}    
     }

   // create component:
     Component compy;
     compy.nVertices = componentSize;
     if(componentSize > 3) compy.isStillActive = true;
     else{compy.isStillActive = false;}
     vector<bool> isForbidden;
     vector<bool> isSymPartnerAlreadyCreated;
     vector<int> xPos, yPos;
     for(int i=0; i<m_nVertices; i++){
        xPos.push_back(2*m_nVertices +1); //largeNumber
        yPos.push_back(2*m_nVertices +1);
        isSymPartnerAlreadyCreated.push_back(false);
        isSymPartnerAlreadyCreated.push_back(false);
        isForbidden.push_back(true);   
     }
     if(runInMinMemoryMode){
      for(int i=0; i<2*(compy.nVertices); i++){
         (compy.bestPosInMinMemMode).push_back(2*m_nVertices+2);         
      }
     }  
     isSymPartnerAlreadyCreated.push_back(false);
     isSymPartnerAlreadyCreated.push_back(false);
     int nEdges = 0;
     for(int i=0; i<componentSize; i++){
        isForbidden[components[i]] = false;
	compy.vertexList.push_back(components[i]);
	nEdges += m_adjList[components[i]].size();
     }
     compy.vertexList.sort();
     compy.nEdges = nEdges / 2;
     for(int i=0; i<m_nVertices; i++ ){
          compy.isTemporarilyForbiddenVertex.push_back(isForbidden[i]);
     }
     compy.bestObjVal 
        = compy.nVertices * compy.nVertices * compy.nVertices; //big M
     if(componentSize <= 2){
       xPos[components[0]] = 0;
       yPos[components[0]] = 0;   
       if(componentSize == 2){
           xPos[components[1]] = 1;
           yPos[components[1]] = 0;
		   compy.bestObjVal = m_edgeWeights[m_edgeNumberMatrix[components[0]][components[1]]];
       }              
       else{ compy.bestObjVal = 0.0;}
     }

    if(componentSize == 3){
          list<int>::iterator iter3;
	  iter3 = compy.vertexList.begin();
	  int v1 = *iter3;
	  iter3++;
	  int v2 = *iter3;
	  iter3++;
	  int centerVertex = v1;
	  if(m_adjMatrix[v1][v2] == 0) centerVertex = *iter3;
	  if(m_adjMatrix[v1][*iter3] == 0) centerVertex = v2;
	  if(m_adjMatrix[v2][*iter3] == 0) centerVertex = v1;
	  
	  double largestEdgeVal = 0.0;
	  double smallestEdgeVal = 1.0;
	  if( m_adjMatrix[v1][v2] == 1 ){
		if( m_edgeWeights[m_edgeNumberMatrix[v1][v2]] > largestEdgeVal ){
			largestEdgeVal = m_edgeWeights[m_edgeNumberMatrix[v1][v2]];
			centerVertex = v1;
		}
		if( m_edgeWeights[m_edgeNumberMatrix[v1][v2]] < smallestEdgeVal ){
			smallestEdgeVal = m_edgeWeights[m_edgeNumberMatrix[v1][v2]];
		}
	  }
	  if( m_adjMatrix[v1][*iter3] == 1 ){
		if( m_edgeWeights[m_edgeNumberMatrix[v1][*iter3]] < largestEdgeVal ){
			largestEdgeVal = m_edgeWeights[m_edgeNumberMatrix[v1][*iter3]];
			centerVertex = v1;
		}
		if( m_edgeWeights[m_edgeNumberMatrix[v1][*iter3]] < smallestEdgeVal ){
			smallestEdgeVal = m_edgeWeights[m_edgeNumberMatrix[v1][*iter3]];
		}
	  }
	  if( m_adjMatrix[*iter3][v2] == 1 ){
		if( m_edgeWeights[m_edgeNumberMatrix[*iter3][v2]] < largestEdgeVal ){
			largestEdgeVal = m_edgeWeights[m_edgeNumberMatrix[*iter3][v2]];
			centerVertex = *iter;
		}
		if( m_edgeWeights[m_edgeNumberMatrix[*iter3][v2]] < smallestEdgeVal ){
			smallestEdgeVal = m_edgeWeights[m_edgeNumberMatrix[*iter3][v2]];
		}
	  }
	  
	  compy.bestObjVal = smallestEdgeVal;
	  if(m_adjMatrix[v1][v2] == 1) compy.bestObjVal += m_edgeWeights[m_edgeNumberMatrix[v1][v2]];
	  if(m_adjMatrix[v1][*iter3] == 1) compy.bestObjVal += m_edgeWeights[m_edgeNumberMatrix[v1][*iter3]];
	  if(m_adjMatrix[v2][*iter3] == 1) compy.bestObjVal += m_edgeWeights[m_edgeNumberMatrix[v2][*iter3]];	  
	  
      yPos[v1] = m_nVertices;
      yPos[v2] = m_nVertices;
      yPos[*iter3] = m_nVertices;
	  int diff = 1;
	  if(v1 != centerVertex) 
           { xPos[v1] = m_nVertices+diff; diff = -1; }
	  else{ xPos[v1] = m_nVertices; }
	  if(v2 != centerVertex) 
           { xPos[v2] = m_nVertices+diff; diff = -1; }
	  else{ xPos[v2] = m_nVertices; }
	  if(*iter3 != centerVertex) 
           { xPos[*iter3] = m_nVertices+diff; }
	  else{ xPos[*iter3] = m_nVertices; }
          int right = -1;
          if(xPos[v1] == m_nVertices+1) right = v1;
          if(xPos[v2] == m_nVertices+1) right = v2;
          if(xPos[*iter3] == m_nVertices+1) right = *iter3;

          compy.xPos = xPos;
          compy.yPos = yPos;
          if(componentSize == 3 && findMostAestheticSolution){
            double aestheticValue1 = m_calcAestheticValue(compy);
            compy.xPos[right]--;
            compy.yPos[right]++;
            double aestheticValue2 = m_calcAestheticValue(compy);
            if(aestheticValue2 > aestheticValue1){
		xPos[right]--;
		yPos[right]++;
            }
          }
      }
     compy.xPos = xPos;
     compy.xPosBest = xPos;
     compy.yPos = yPos;
     compy.yPosBest = yPos;
     compy.isSymPartnerAlreadyCreated = isSymPartnerAlreadyCreated;
     compy.oldStartVertices.clear();
     compy.startVertices.clear();

     m_graphComponents.push_back(compy);
	 //cout << "(" << compy.nVertices << ")";
     nextComponentStartVertex = -1;
     for(int i=0; i<m_nVertices; i++){
       if(!isAlreadySet[i]){
         nextComponentStartVertex = i;
         break;           
       }        
     }
     // if(nextComponentStartVertex == -1){break;}
  }
  while(nextComponentStartVertex != -1);
  // end: determine connected components of the graph 
  // cout << m_graphComponents.size() << " components" << endl;

  //calculate right-hand sides for Star Inequalities: 
     int currentDist = 1;
     int counterLimit = 4;
     int currentRhs = 0;
     m_rhsStarInequalities.push_back(0);
     for(int i=1; i<m_nVertices; i++){
	if(i > counterLimit){
		currentDist++;
		counterLimit += 4*currentDist;
	}
	currentRhs += currentDist;
	m_rhsStarInequalities.push_back(currentRhs);
     }

  m_minMemoryMode = runInMinMemoryMode;
  return true;
}     

void FeasibilityTest::m_calcMaxDistAllowed(){
  if(m_maxDistAllowedInModel == -1){
	m_maxDistAllowedInModel = (int)( 2*(((m_nVertices+1) / 2) -1)   );
	return;
  }
  if( inputFormat == 2 ) m_maxDistAllowedInModel = 4;
  if(m_maxDistAllowedInModel == 0){
  
    // perform greedy heuristic to get feasible solution
	m_isTestForMaxDistance = true;
	m_maxDistAllowedInModel = m_nVertices;
	bool aestheticOriginal = findMostAestheticSolution;
	findMostAestheticSolution = false;
    int onesArray[m_nEdges];
    for(int i=0;i<m_nEdges;i++) onesArray[i] = 1;
    double currentBestObjValue = m_nVertices * m_nVertices * m_nVertices;
    
	for( int i=0; i<100; i++){
	   double solutionValue = m_constructFeasibleSolution(onesArray, currentBestObjValue, false); 
	   if( !(solutionValue >= -1.1 && solutionValue <= -0.9) && solutionValue < currentBestObjValue){
         currentBestObjValue = solutionValue;
       } 
	}
	
	findMostAestheticSolution = aestheticOriginal;
	
    // cout << "Estimate maximum distance for adjacent vertices:"<<endl;
    m_isTestForMaxDistance = true;
    // (a) Look-up maximum sizes of components, cliques and stars:
    int maxCompSize = 0;
    int maxCliqueSize = 0;
    int maxStarSize = 0;
    list<Component>::iterator comp;
    list<int>::iterator iter;
    for(int i=0; i<m_nVertices; i++){
      if((int)m_adjList[i].size() > maxStarSize)
        { maxStarSize = (int)m_adjList[i].size(); }
    }
    for(comp=m_graphComponents.begin(); comp!=m_graphComponents.end();++comp){
      if((*comp).nVertices > maxCompSize) maxCompSize = (*comp).nVertices;
      for(iter = (*comp).maxCliquesInGraph.begin(); 
                             iter != (*comp).maxCliquesInGraph.end(); ++iter){
        int currentSize = *iter;
        if(currentSize > maxCliqueSize) maxCliqueSize = currentSize;
        for(int i=0; i<currentSize; i++) iter++;
      }
    }

    // (b) Calc. initial max dist from these values:
    int newDistAllowed = 0;
     // 2*sqrt(n) - 1:
     newDistAllowed = (2* (int)(sqrt((double)maxCompSize)+0.001)) -1;
     // sqrt(maxCliqueSize) + 2: 
    if(((int)(sqrt((double)maxCliqueSize)-0.001)) +2 > newDistAllowed)
     { newDistAllowed = ((int)(sqrt((double)maxCliqueSize)-0.001)) +2; }
    // star inequality value + 2:
    if( (int)(sqrt((double)maxStarSize/2 +0.25) -0.5001) + 2 > newDistAllowed)
       {newDistAllowed = (int)(sqrt((double)maxStarSize/2 +0.25) -0.5001) + 2;}

    // (c) Further increase of this distance? Let tests decide:
   for(int i=0;i<m_nEdges;i++) onesArray[i] = 1;
   currentBestObjValue = m_nVertices * m_nVertices * m_nVertices;

   for(int testDist = newDistAllowed; testDist <= 2*m_nVertices-2; testDist++){
     //cout << "  --> testing distance " << testDist << endl;
     int countMaxDistErrors = 0;
     m_maxDistAllowedInModel = testDist;
     for(int i=0; i<100; i++){
       double solutionValue 
            = m_constructFeasibleSolution(onesArray, currentBestObjValue, false);
       if( solutionValue >= -1.1 && solutionValue <= -0.9 ){
          countMaxDistErrors++;
       }
       else{ if(solutionValue < currentBestObjValue){
                 currentBestObjValue = solutionValue;
             } 
       }
     }
     // cout << "errors: " << countMaxDistErrors << " of 100" << endl;
     if(countMaxDistErrors <= 20){/*cout << "  accepted: ";*/ break;}
  }
  // cout << "MaxDist = " << m_maxDistAllowedInModel << " + 1 = ";
  // cout << m_maxDistAllowedInModel + 1 << endl;
  m_maxDistAllowedInModel++;
 }
 else{ // if maxDist was given by user
    m_isTestForMaxDistance = true;
	bool aestheticOriginal = findMostAestheticSolution;
	findMostAestheticSolution = false;
    int onesArray[m_nEdges];
    for(int i=0;i<m_nEdges;i++) onesArray[i] = 1;
    double currentBestObjValue = m_nVertices * m_nVertices * m_nVertices;    
	for( int i=0; i<100; i++){
	   double solutionValue = m_constructFeasibleSolution(onesArray, currentBestObjValue, false); 
	   if( !(solutionValue >= -1.1 && solutionValue <= -0.9) && solutionValue < currentBestObjValue){
         currentBestObjValue = solutionValue;
       } 
	}
	findMostAestheticSolution = aestheticOriginal;
 }
 m_isTestForMaxDistance = false;
}


double FeasibilityTest::m_currentObjVal(Component& comp){
    list<int>::iterator iter1, iter2;
    double returnVal = 0.0;
    for(iter1 = comp.vertexList.begin(); 
                                       iter1 != comp.vertexList.end(); ++iter1){
      for(iter2 = m_adjList[*iter1].begin(); 
                                     iter2 != m_adjList[*iter1].end(); ++iter2){
	 if(*iter2 < *iter1){
		returnVal += m_distMatrix[*iter1][*iter2] * m_edgeWeights[m_edgeNumberMatrix[*iter1][*iter2]];
	 }
	 else{break;}
      }
    }
    return returnVal;
}

bool FeasibilityTest
     ::m_compareGridPositionsWithDistMatrixEntries(Component& comp){
  list<int>::iterator iter1, iter2;
  for(iter1 = comp.vertexList.begin(); iter1 != comp.vertexList.end(); ++iter1){
      for(iter2 = m_adjList[*iter1].begin(); 
                                     iter2 != m_adjList[*iter1].end(); ++iter2){
	 if(*iter2 < *iter1){
		int xDiff = comp.xPos[*iter1] - comp.xPos[*iter2];
		if(xDiff < 0) {xDiff = -xDiff;}
		int yDiff = comp.yPos[*iter1] - comp.yPos[*iter2];
		if(yDiff < 0) {yDiff = -yDiff;}
		if(xDiff + yDiff != m_distMatrix[*iter1][*iter2]) {
		  cout << "node " << *iter1 << ": (" << comp.xPos[*iter1];
                  cout << "," << comp.yPos[*iter1] << ")" << endl;
		  cout << "node " << *iter2 << ": (" << comp.xPos[*iter2];
                  cout << "," << comp.yPos[*iter2] << ")" << endl;
		  cout << "needed distance: " << m_distMatrix[*iter1][*iter2];
		  cout << " instead of " << xDiff+yDiff << endl;	
		  return false;
		}
	}
      }
  }
  return true;
}

bool FeasibilityTest::m_isInputMatrixSymmetrical(){
  for(int i=0; i<m_nVertices-1; i++){
    for(int j=i+1; j<m_nVertices; j++){ 
       if(m_adjMatrix[i][j] != m_adjMatrix[j][i]){
           m_printError(-4);
           return false;
       }
    }
  }
  for(int i=0; i<m_nVertices; i++){
      if(m_adjMatrix[i][i] != 0){
          m_printError(1);
          break;
      }
  }
  return true;
}

bool FeasibilityTest::m_findTrianglesAnd4CliquesInGraph(int maxNumberToFind){
  // find triangles:
   int counter = 0;
   list<int>::iterator iter, iter2;
   for(int v=0; v<m_nVertices; v++){
     if(m_adjList[v].size() > 1){
       for(iter=m_adjList[v].begin(); iter != m_adjList[v].end(); ++iter){ 
         if(*iter > v){
           for(iter2=iter; iter2 != m_adjList[v].end(); ++iter2){
             if( (*iter < *iter2) && (m_adjMatrix[*iter][*iter2] == 1) ){
                    //determine component
                    list<Component>::iterator compIter;
                    for(compIter = m_graphComponents.begin(); 
                                 compIter!=m_graphComponents.end(); ++compIter){
                      if( !(*compIter).isTemporarilyForbiddenVertex[v]){
                         (*compIter).trianglesInGraph.push_back(v);
                         (*compIter).trianglesInGraph.push_back(*iter);
                         (*compIter).trianglesInGraph.push_back(*iter2);
			 counter++;
			 if(counter >= maxNumberToFind) {
			   // cout << "aborted (more than " << maxNumberToFind << " 3-cliques): ";
                           goto fourcliques;
			 }
                         break;
                      }
                    }
             }
           }
         }
       }  
     }
   }
  // cout << "#3 = " << counter << " ";
   // find 4-cliques:
   fourcliques:
   list<Component>::iterator compIter;
   counter = 0;
   for(compIter = m_graphComponents.begin(); 
                                 compIter!=m_graphComponents.end(); ++compIter){
   
    for(iter=(*compIter).trianglesInGraph.begin(); 
                              iter!=(*compIter).trianglesInGraph.end(); ++iter){
     int v1 = *iter;
     iter++;
     int v2 = *iter;
     iter++;
     int v3 = *iter;
     for(iter2=m_adjList[v3].begin();iter2!=m_adjList[v3].end();++iter2){
       if(   *iter2 > v3 
          && m_adjMatrix[*iter2][v1] == 1 
          && m_adjMatrix[*iter2][v2] == 1){
            (*compIter).fourCliquesInGraph.push_back(v1);
            (*compIter).fourCliquesInGraph.push_back(v2);
            (*compIter).fourCliquesInGraph.push_back(v3);
            (*compIter).fourCliquesInGraph.push_back(*iter2);
	    counter++;
	    if(counter >= maxNumberToFind) {
		// cout << "aborted (more than " << maxNumberToFind << " 4-cliques): ";
	        return true;
	    }
       }
     }
    }
   }
   // cout << "#4 = " << counter << " ";
   return true;
}

bool FeasibilityTest::m_findMaxCliquesInGraph(int maxNumberToFind){
  int nCurrentlyStoredCliques = 0;
  int nCliquesFound = 0;
  int largestCliqueSize = 0;
  list<Component>::iterator compIter;
  for(compIter = m_graphComponents.begin(); 
                                 compIter!=m_graphComponents.end(); ++compIter){
    list<int> oldCliques = (*compIter).fourCliquesInGraph;
    list<int> newCliques;
    int currentCliqueSize = 4;
    if(currentCliqueSize > largestCliqueSize) largestCliqueSize = currentCliqueSize;
	list<int>::iterator iter;
    while( ! oldCliques.empty() ){
	newCliques.clear();
	for(iter = oldCliques.begin(); iter != oldCliques.end(); ++iter){
	  bool wasCliqueExtended = false;
	  int maxCliqueMember = -1;
	  for(int i=0; i<currentCliqueSize; i++){
	      if(*iter > maxCliqueMember) maxCliqueMember = *iter;
	      iter++;
	  }
	  for(int i=0; i<currentCliqueSize; i++){iter--;}
	  for(int v=0; v<m_nVertices; v++){
	      int counter = 1;
	      while( true ){
	      if(m_adjMatrix[v][*iter] == 1) {
		if(counter == currentCliqueSize){
		  if(v > maxCliqueMember){
		  // new clique was found:
            nCurrentlyStoredCliques++;
            if(nCurrentlyStoredCliques >= maxNumberToFind){goto copyCliques;}
		    for(int i=0; i<currentCliqueSize-1; i++){iter--;}
		    for(int i=0; i<currentCliqueSize; i++){
		        newCliques.push_back(*iter);
		        iter++;
		    }
		    iter--;
		    newCliques.push_back(v);
		  }
		  wasCliqueExtended = true;
		  for(int i=0; i<currentCliqueSize-1; i++){iter--;}
		  break;
	        }
	        else{
		  // new clique still possible:
		  iter++;
		  counter++;
	        }
	      }
	      else{ 
		for(int i=0; i<counter-1; i++){iter--;}
		break; 
	      }
	      }
	  }
	  if(!wasCliqueExtended){
         nCliquesFound++;
		(*compIter).maxCliquesInGraph.push_back(currentCliqueSize);
		//m_maxCliquesInGraph.push_back(currentCliqueSize);
		for(int i=0; i<currentCliqueSize; i++){
		  (*compIter).maxCliquesInGraph.push_back(*iter);
		  //m_maxCliquesInGraph.push_back(*iter);
		  iter++;
		}
		iter--; 
		if(nCliquesFound >= maxNumberToFind){ 
			// cout << "abort (too many cliques) ";	
			return true;
		}
	  }
	  else{
		for(int i=0; i<currentCliqueSize-1; i++){iter++;}
	  }
	}
	copyCliques:
        oldCliques = newCliques;
        nCurrentlyStoredCliques = 0;
	    currentCliqueSize++;
		if(currentCliqueSize > largestCliqueSize) largestCliqueSize = currentCliqueSize;
	    if(currentCliqueSize >= m_maxCliqueSizeToBeSeparated){break;}
   }
  }
  // cout << "largest clique size = " << largestCliqueSize-1 << ": ";
  return true;
}

bool FeasibilityTest::m_findFiveCyclesInGraph(int maxNumberToFind){

  list<int> current5cycle;
  int n5cycles = 0;
  int all5Cycles[maxNumberToFind][5];
  list<int>::iterator iter1,iter2, iter3, iter4, iter5;
  for(int u1 = 0; u1 <m_nVertices; u1++){
   if(!m_adjList[u1].empty()){
    iter1 = m_adjList[u1].begin();
    for(unsigned u2 = 0; u2 < m_adjList[u1].size()-1; u2++){
     if(*iter1 > u1){
       iter2 = m_adjList[u1].begin();
       for(unsigned i=0; i<u2+1; i++){iter2++;}
         for(unsigned u3 = u2+1; u3 < m_adjList[u1].size();u3++){
	    if(*iter2 > u1){
	      iter3 = m_adjList[*iter1].begin();
	        for(unsigned u4=0; u4<m_adjList[*iter1].size(); u4++){
	          iter4 = m_adjList[*iter2].begin();
	          for(unsigned u5=0; u5<m_adjList[*iter2].size();u5++){
		    if(    *iter3 != u1 
             && *iter3 != *iter2 
             && *iter4 != u1 
             && *iter4 != *iter1 
             && *iter4 > *iter3 
             && m_adjMatrix[*iter4][*iter3] > 0.9){
			current5cycle.clear();
			current5cycle.push_back(u1);
			current5cycle.push_back(*iter1);
			current5cycle.push_back(*iter2);
			current5cycle.push_back(*iter3);
			current5cycle.push_back(*iter4);
			current5cycle.sort();
			bool identical = false;
			for(int i=0; i<n5cycles; i++){   
			  identical = false;
			  int j=0;
 			  for(iter5=current5cycle.begin(); 
                                         iter5 != current5cycle.end(); ++iter5){
			     if(*iter5 == all5Cycles[i][j]) {
                                  identical = true; 
                                  j++;
                             }	
			     else{identical = false; break;}
			  }
			if(identical){break;}
			}
			if(!identical){
			    int i=0;
 			    for(iter5=current5cycle.begin(); 
                                         iter5 != current5cycle.end(); ++iter5){
				 all5Cycles[n5cycles][i] = *iter5;  
				 i++;
			    }
			n5cycles++;
			if(n5cycles >= maxNumberToFind){  
			   // cout << "aborted (more than " << maxNumberToFind << "): ";
			   return true;
			}
			// determine component:
			list<Component>::iterator compIter;
			compIter = m_graphComponents.begin();
			while( compIter != m_graphComponents.end()){
			  if( !(*compIter).isTemporarilyForbiddenVertex[u1] ){
				(*compIter).fiveCyclesInGraph.push_back(u1);
				(*compIter).fiveCyclesInGraph.push_back(*iter1);
				(*compIter).fiveCyclesInGraph.push_back(*iter3);
				(*compIter).fiveCyclesInGraph.push_back(*iter4);
				(*compIter).fiveCyclesInGraph.push_back(*iter2);
				
 
			        break;
			}
			compIter++;
			}
			}
		    }
		    iter4++;
	          }
	         iter3++;
	        }
	     }
	  iter2++;
         }
        }
     iter1++;
    }
  }
  }
  // cout << "# = " << n5cycles << " ";
return true;
}

bool FeasibilityTest::read(int* cplexSolution){
 if(!m_errorOccured){
   m_conflictSets.clear();
   m_conflictSetsEdges.clear();
   m_maxDistInInput = 0;
  // fill distance matrix:
  list<int>::iterator iter;
  int arrayMarker = 0;
  for(int i=0; i<m_nVertices; i++){
    for(iter = m_adjList[i].begin(); iter != m_adjList[i].end(); ++iter){
       if(i < *iter){
            if(   cplexSolution[arrayMarker] > 10000 
               || cplexSolution[arrayMarker] < -10000){
                  m_printError(-6);
                  return false;                                
            }
            m_distMatrix[i][*iter] = cplexSolution[arrayMarker];
            if(m_maxDistInInput < cplexSolution[arrayMarker]){
               m_maxDistInInput = cplexSolution[arrayMarker];
            }
            arrayMarker++;
       }
       if(i > *iter) m_distMatrix[i][*iter] = m_distMatrix[*iter][i]; 
    }       
  }
 }
 return true;
}

void FeasibilityTest::m_calculateAndNormalizeSolution(){
  list<Component>::iterator compIter;
  list<int>::iterator iter;
  m_approximationFound = true;
  m_bestApproximationValue = 0.0;
  for(compIter=m_graphComponents.begin(); 
                                  compIter!=m_graphComponents.end();++compIter){
    // Special case: <= 3 vertices:
    if( (*compIter).nVertices <= 3) {
	  (*compIter).xPosBest = (*compIter).xPos;
	  (*compIter).yPosBest = (*compIter).yPos;
    }
    
    // Was approximation found?
    (*compIter).approximationFound = true;
    for(iter = (*compIter).vertexList.begin(); 
                                  iter != (*compIter).vertexList.end(); ++iter){
      if((*compIter).xPosBest[*iter] >= 2*m_nVertices+1){
          (*compIter).approximationFound = false;
          m_approximationFound = false;
          break;
      }
    }
    if((*compIter).approximationFound){
      m_bestApproximationValue += (*compIter).bestObjVal;
     // Normalize solution:
     int minXValue = 2*m_nVertices+1;
     int minYValue = 2*m_nVertices+1;
     for(int i=0; i<m_nVertices; i++){    
       if((*compIter).xPosBest[i] < minXValue ) 
           { minXValue = (*compIter).xPosBest[i]; }
       if((*compIter).yPosBest[i] < minYValue ) 
           { minYValue = (*compIter).yPosBest[i]; }
     }    
     for(int i=0; i<m_nVertices; i++){
        if((*compIter).xPosBest[i] < 2*m_nVertices+1){     
          (*compIter).xPosBest[i] = (*compIter).xPosBest[i] - minXValue;
          (*compIter).yPosBest[i] = (*compIter).yPosBest[i] - minYValue;   
          (*compIter).solution.push_back((*compIter).xPosBest[i]);
          (*compIter).solution.push_back((*compIter).yPosBest[i]);
        }
     } 
    }   
   }
}

void FeasibilityTest::m_printFinalStatistics(){
 // m_calculateAndNormalizeSolution();

 cout << "|----------------------------------------------" <<endl;
 cout << "|---- 2D-Grid-Arrangement-Solver: Results -----" <<endl;
 cout << "|----------------------------------------------" <<endl;  
 cout << "| Graph properties: "<<endl;
// cout << "|    File:\t" << m_graphFileName << endl;
 cout << "|   # vertices:    "<< m_nVertices << endl;    
 cout << "|   # edges:       "<< m_nEdges << endl;  
 float density = (float)m_nEdges /((float)m_nVertices*((float)m_nVertices-1)/2);
 cout.precision(3);
 cout << "|   edge density:  "<< density*100 << " %" << endl;  
 cout << "|   # components:  "<< m_graphComponents.size() << endl;
 cout << "|----------------------------------------------" <<endl;
 cout << "| Program statistics: "<<endl;
 cout << "|   # feasibility tests:\t" << m_nCplexSolutionTests <<endl;
 cout << "|   # calculated cuts (total):\t" << m_nCutsTotal << endl; 
 cout << "|----------------------------------------------" <<endl; 

// draw solution grid onto output screen:   
 list<Component>::iterator compIter;
 int componentCounter = 1;
 for(compIter=m_graphComponents.begin();
                                  compIter!=m_graphComponents.end();++compIter){
  if((*compIter).nVertices <= 100){
   cout << "| Best grid arrangement of component " <<componentCounter;
   if( !(*compIter).approximationFound )
     { cout << ": UNSOLVED" << endl << "No approximation found!" << endl; }
   else{
   int maxXValue = 0;
   int maxYValue = 0;
   for(int i=0; i<m_nVertices; i++){
    if(    (*compIter).xPosBest[i] > maxXValue 
        && (*compIter).xPosBest[i] < 2*m_nVertices+1) 
      {maxXValue = (*compIter).xPosBest[i];}
    if(    (*compIter).yPosBest[i] > maxYValue 
        && (*compIter).yPosBest[i] < 2*m_nVertices+1) 
      {maxYValue = (*compIter).yPosBest[i];}
   }
   cout.precision(5);
   cout <<" (val=" <<(*compIter).bestObjVal<<"):" <<endl << "|" <<endl;


// cout distance vector
/*
   for(int i=0; i<m_nVertices-1; i++){
    for(int j=i+1; j<m_nVertices;j++){ 
	int x1 = (*compIter).xPosBest[i];
	int x2 = (*compIter).xPosBest[j];
	int y1 = (*compIter).yPosBest[i];
	int y2 = (*compIter).yPosBest[j];
       if( x1 < (2*m_nVertices+1)
            && x2 < (2*m_nVertices+1) 
            && m_adjMatrix[i][j] == 1){
		 int xdiff = x1-x2;
		 if( xdiff < 0) xdiff = -xdiff;
		 int ydiff = y1-y2;
		 if( ydiff < 0) ydiff = -ydiff;		 
	        cout << "," << xdiff+ydiff;
       }
     }
   }
   cout << endl;
*/
// end: cout distance vector



   if(maxXValue > 27)
     { cout << "...arrangement to large to visualize here..." << endl;}
   else{
   int isOccupied[maxXValue+1][maxYValue+1];
   for(int i=0; i<=maxXValue; i++){
    for(int j=0; j<=maxYValue; j++){
       isOccupied[i][j] = -1;
    }
   }         
   for(int i=0; i<m_nVertices; i++){
     if(! (*compIter).isTemporarilyForbiddenVertex[i]){
          isOccupied[(*compIter).xPosBest[i]][(*compIter).yPosBest[i]] = i;
     }
   }

   for(int i=0; i<=maxYValue; i++){
    cout << "| ";
    for(int j=0; j<=maxXValue; j++){cout << "---";}
    cout << "-" << endl << "| ";
    for(int j=0; j<=maxXValue; j++){
       if(isOccupied[j][i] == -1) {cout << "|  ";} 
       else{
           if(isOccupied[j][i] < 10) cout << "| " << isOccupied[j][i];
           else{cout << "|" << isOccupied[j][i];}     
       }    
    }
    cout << "|" <<endl;  
  } 
  cout << "| ";
  for(int j=0; j<=maxXValue; j++){cout << "---";}
  cout << "-" << endl << "|" <<endl; 
  cout << "|----------------------------------------------" <<endl;
 }  
 }
 cout << "|----------------------------------------------" <<endl;
 componentCounter++;
 }
 }
}

void FeasibilityTest
     ::m_determineCloseVertexAlreadyFixed(int vertexID, FeasibilityTree* tree){
  list<int>::iterator iter;
  int minDist = 2 * m_nVertices;
  int minDistVertex = -1;
  for(iter=m_adjList[vertexID].begin();iter!=m_adjList[vertexID].end();++iter){
    if( tree->m_positionOfVertexInOrdering[*iter] != -1){
       if(m_distMatrix[vertexID][*iter] == 1){
          minDistVertex = *iter;
          break;
       } 
       if(minDist > m_distMatrix[vertexID][*iter]){ 
          minDist = m_distMatrix[vertexID][*iter];
          minDistVertex = *iter;
       }
    }
  }
  tree->m_closeVertexAlreadyFixed[vertexID] = minDistVertex; 
}

double FeasibilityTest::m_calcAestheticValue(Component& component){
  // Data structures you might want to use:
  // component.xPos[i] : The x-coordinate of vertex i (between 0 and 2*|V|+2)
  // m_distMatrix[i][j] : Distance between vertex i and j
  // component.vertexList : List (int) of the vertices in the component
  // m_nVertices : Total number of vertices
  // component.nVertices : Number of vertices in the component

 // Example: aesthetic is "as quadratic as possible"
  int maxX = 0; // max x-coordinate in component
  int maxY = 0;
  int minX = 2*m_nVertices+2;
  int minY = 2*m_nVertices+2;
  list<int>::iterator vertex;
  for(vertex = component.vertexList.begin(); 
                                vertex != component.vertexList.end(); ++vertex){
    if(component.xPos[*vertex] > maxX) maxX = component.xPos[*vertex];
    if(component.xPos[*vertex] < minX) minX = component.xPos[*vertex];
    if(component.yPos[*vertex] > maxY) maxY = component.yPos[*vertex];
    if(component.yPos[*vertex] < minY) minY = component.yPos[*vertex];
  }
  int difference = (maxX - minX) - (maxY - minY);
   // difference between vertical and horizontal expansion

  if(difference < 0) difference = -difference;
  double aestheticValue = 1 / ((double)difference + 1); //the larger the better
  
  return aestheticValue;  // must be >= 0 !!!
}

void FeasibilityTest::m_findMostAestheticSolution(Component& comp){
  m_aestheticModeActivated = true;
  if(comp.nVertices >= 4){
     int returnMaxConflictSetSize = -1;
     m_startMainSearch(returnMaxConflictSetSize, comp, true);
  }
  m_aestheticModeActivated = false;
}


bool FeasibilityTest::m_separateMonotonyInequalities(
                                  list<int>& cuts, double* sol, int maxNOfCuts){
  int cutCounter = 0;
  srand( time(NULL) );
  int edge = rand() % m_nEdges;
  for(int i=0; i<m_nEdges; i++){
   for(int mono=0; mono<m_maxDistAllowedInModel-2; mono++){
     if(   sol[m_nEdges + (m_maxDistAllowedInModel-1) * edge + mono] 
         < sol[m_nEdges + (m_maxDistAllowedInModel-1) * edge + mono + 1] 
           - 0.01){
	cuts.push_back(2);
	cuts.push_back(m_nEdges +(m_maxDistAllowedInModel-1) * edge + mono);
	cuts.push_back(m_nEdges +(m_maxDistAllowedInModel-1) * edge + mono + 1);
	cutCounter++;
	if( maxNOfCuts != 0 && 
	    cutCounter >= maxNOfCuts){ return true; }
     }
   }
   edge++;
   if(edge == m_nEdges) edge = 0;
  }

  if(cuts.empty()){ return false;}
  else { return true; }
}

bool FeasibilityTest::m_separateTriangleInequalities(
				  list<int>& cuts, double* sol, int maxNOfCuts){
  int cutCounter = 0;
  cuts.clear();
  srand( time(NULL) );
  list<Component>::iterator compIter;

    compIter = m_graphComponents.begin();
    int startComponent = rand() % m_graphComponents.size();
    for(int i=0; i<startComponent; i++){compIter++;}
    for(unsigned i=0; i<m_graphComponents.size(); i++){
     if((*compIter).isStillActive && !(*compIter).trianglesInGraph.empty() ){
       int startTriangle = rand() % ((*compIter).trianglesInGraph.size() / 3);
       list<int>::iterator iter;
       iter=(*compIter).trianglesInGraph.begin();
       for(int i=0; i<3*startTriangle; i++){iter++;}
       for(unsigned i=0; i<((*compIter).trianglesInGraph.size() /3); i++){
	   int v1 = *iter;
	   iter++;
	   int v2 = *iter;
	   iter++;
	   int v3 = *iter;
	   int e1 = m_edgeNumberMatrix[v1][v2];
	   int e2 = m_edgeNumberMatrix[v1][v3];
	   int e3 = m_edgeNumberMatrix[v2][v3];
	   if( sol[e1] + sol[e2] < sol[e3] - 0.001){
		cuts.push_back(3);
                cuts.push_back(e1);
                cuts.push_back(e2);
                cuts.push_back(e3);
		cutCounter++;
	   }
	   if( sol[e1] + sol[e3] < sol[e2] - 0.001){
		cuts.push_back(3);
                cuts.push_back(e1);
                cuts.push_back(e3);
                cuts.push_back(e2);
		cutCounter++;
	   }
	   if( sol[e2] + sol[e3] < sol[e1] - 0.001){
		cuts.push_back(3);
                cuts.push_back(e2);
                cuts.push_back(e3);
                cuts.push_back(e1);
		cutCounter++;
	   }
	   if(maxNOfCuts != 0 && cutCounter >= maxNOfCuts){ return true; }
	   iter++;
	   if(iter == (*compIter).trianglesInGraph.end()) 
                { iter = (*compIter).trianglesInGraph.begin(); }
	}
    }
    compIter++;
    if(compIter == m_graphComponents.end())compIter = m_graphComponents.begin();
  }
  if(cuts.empty()){ return false;}
  else { return true; }
}

bool FeasibilityTest::m_separateStarInequalities(
				  list<int>& cuts, double* sol, int maxNOfCuts){

  int cutCounter = 0;
  cuts.clear();
  srand( time(NULL) );
  vector<int> currentCuts;
  list<Component>::iterator compIter;
  compIter = m_graphComponents.begin();
  int startComponent = rand() % m_graphComponents.size();
  for(int i=0; i<startComponent; i++){compIter++;}
  for(unsigned i=0; i<m_graphComponents.size(); i++){
   if((*compIter).isStillActive){
     list<int>::iterator iter, neighIter;
       int startVertex = rand() % (*compIter).vertexList.size();
       iter = (*compIter).vertexList.begin();
       for(int i=0; i<startVertex; i++){iter++;}
       for(unsigned i=0; i<(*compIter).vertexList.size(); i++){

	if(m_adjList[*iter].size() > 4){
	  vector<distSol> v;
	  make_heap(v.begin(),v.end());
	  distSol currentSol;
	  for(neighIter = m_adjList[*iter].begin(); 
			      neighIter != m_adjList[*iter].end(); ++neighIter){
		currentSol.var = m_edgeNumberMatrix[*iter][*neighIter];
		currentSol.val = sol[ m_edgeNumberMatrix[*iter][*neighIter] ];
		v.push_back(currentSol); 
		push_heap(v.begin(),v.end());
	  }
	  double lhs = 0;
	  int counter = 1;
	  while(!v.empty()){
	     lhs += v.front().val;
	     currentCuts.push_back(v.front().var);
	     if( lhs < m_rhsStarInequalities[counter] - 0.0001 ){
		cutCounter++;
		cuts.push_back(currentCuts.size());
		for(unsigned j=0; j<currentCuts.size(); j++){
			cuts.push_back(currentCuts[j]);
		}
		if(maxNOfCuts != 0 && cutCounter >= maxNOfCuts){return true;}
		currentCuts.pop_back();
		lhs -= v.front().val;
		counter--;
	     }
	     pop_heap(v.begin(),v.end()); 
	     v.pop_back();
	     counter++;
	  }
	  currentCuts.clear();
	}
	iter++;
	if(iter == (*compIter).vertexList.end()) 
           { iter = (*compIter).vertexList.begin(); }
     }
   }
   compIter++;
   if(compIter == m_graphComponents.end()) compIter = m_graphComponents.begin();
  }
  if(cuts.empty()){ return false;}
  else { return true; }
}

bool FeasibilityTest::m_separateFiveCycleInequalities(
                                  list<int>& cuts, double* sol, int maxNOfCuts){
  int cutCounter = 0;
  srand( time(NULL) );
  list<Component>::iterator compIter;
  compIter = m_graphComponents.begin();
  int startComponent = rand() % m_graphComponents.size();
  for(int i=0; i<startComponent; i++){compIter++;}
  for(unsigned i=0; i<m_graphComponents.size(); i++){
   if((*compIter).isStillActive && !(*compIter).fiveCyclesInGraph.empty() ){
     list<int>::iterator iter;
     int vertices[5];
     int edges[5];
     int startCycle = rand() % ((*compIter).fiveCyclesInGraph.size() / 5);
     iter = (*compIter).fiveCyclesInGraph.begin();
     for(int i=0; i<5*startCycle; i++){iter++;}
     for(unsigned i=0; i<((*compIter).fiveCyclesInGraph.size()/5); i++){
	for(int j=0; j<5; j++){
            vertices[j] = *iter;
	    iter++;
	}
	iter--;
	double lhs = 0;
	for(int j=0; j<4; j++){
	    edges[j] = m_edgeNumberMatrix[vertices[j]][vertices[j+1]];
	    lhs += sol[ edges[j] ];
	}
	edges[4] = m_edgeNumberMatrix[vertices[0]][vertices[4]];
	lhs += sol[ edges[4] ];
	if(lhs < 5.999){
	    list<int> currentCut;
	    for(int j=0; j<5; j++){currentCut.push_back(edges[j]);}
	    currentCut.sort();
	    cuts.push_back(5);
	    list<int>::iterator cutIter = currentCut.begin();
	    for(int j=0; j<5; j++){ 
		cuts.push_back(*cutIter);
		cutIter++;
	    }	    
	}
	cutCounter++;
	if(maxNOfCuts != 0 && cutCounter >= maxNOfCuts){ return true; }
	iter++;
	if(iter == (*compIter).fiveCyclesInGraph.end()) 
           { iter = (*compIter).fiveCyclesInGraph.begin(); }
     }
   }
  compIter++;
  if(compIter == m_graphComponents.end()) compIter = m_graphComponents.begin();
  }
  if(cuts.empty()){ return false;}
  else { return true; }
}



int FeasibilityTest::m_separateHypermetricInequalities(ABA_BUFFER<ABA_CONSTRAINT*>* newConstraint, 
                            ABA_MASTER* master, ABA_SUB* sub, double* LPsol){

  // Determine first graph component to be searched for violated
  // inequalities
  srand( time(NULL) );
  list<Component>::iterator compIter;
  compIter = m_graphComponents.begin();
  int startComponent = rand() % m_graphComponents.size();
  for(int i=0; i<startComponent; i++){compIter++;}
  for(unsigned compCount=0; compCount<m_graphComponents.size(); compCount++){
  
	// traverse list of maximum cliques in current component
    if( !(*compIter).maxCliquesInGraph.empty() ){
        list<int>::iterator iter = (*compIter).maxCliquesInGraph.begin();

        while(iter != (*compIter).maxCliquesInGraph.end() ){
	        
			// get current clique size
			int cliqueSize = *iter;
//cout << "--------------------------------" <<endl;
//cout <<  cliqueSize << "-Clique: "; 
	        iter++;
			// get current clique
		    int currentClique[cliqueSize];
            for(int i=0; i<cliqueSize; i++){
	           currentClique[i] = *iter;
//cout << *iter << " ";
	           iter++;
	        }
//cout << endl;
//cout << "--------------------------------" <<endl;

			// get current LP values on the clique's edges
			double LPvalClique[ (cliqueSize * (cliqueSize-1)) / 2 ];
			int translationTableEdgeNumbers[ (cliqueSize * (cliqueSize-1)) / 2 ];
			int currEdge = 0;
			for(int i = 0; i < cliqueSize - 1; i++){
			    for(int j = i + 1; j < cliqueSize; j++){
					int edgeNumber = m_edgeNumberMatrix[ currentClique[i] ][ currentClique[j] ];
					translationTableEdgeNumbers[ currEdge ] = edgeNumber;
					LPvalClique[ currEdge ] = LPsol[ edgeNumber ];
					currEdge++;
				}
			}
    
			// -------------------
			// ThorstensSeparator
			// -------------------
			double  minViol = 1.0e-3;  // Minium violation.
			vector< SparseConstraint<int>* > buf;  // Buffer for generated inequalities.
			hypermetricSeparator( cliqueSize, newConstraint->size(), minViol, &LPvalClique[0], buf );		
		    // Copy inequalities from buffer to ABA_Constraints
            if ( !buf.empty() ) { 			
				SparseConstraint<int>* con;
				GeneralIntConstraint*  mc;				
				for ( vector< SparseConstraint<int>* >::iterator it = buf.begin();
										it != buf.end(); it++ ) {

					// Get constraint
					con = *it;						
										
					int coef[ con->nNz() ];
					int vari[ con->nNz() ];										
					for( int i=0; i<con->nNz(); i++){
						coef[i] = con->coef( i );
						vari[i] = translationTableEdgeNumbers[ con->idx( i ) ];	
										

					if( !newConstraint->full() ){
						// Generate general int constraint
						mc = new GeneralIntConstraint(
							(GridMaster*)master, con->nNz(), con->rhs(), vari, coef, 
                                                   ABA_CSENSE::Less, false);
												   
						newConstraint->push( mc );	
					} //if
				
                    delete con;					
				} // for
				
				if ( newConstraint->full() ) {
				    return 1;
				} // if
				} // for
			} // if
//cout << "--------------------------------" <<endl;
		  

    compIter++;
    if(compIter == m_graphComponents.end()) compIter = m_graphComponents.begin();
	} // while
	} // if
  } // for
   
  return 0;
  
}


bool FeasibilityTest::m_separateCliqueInequalities(
                                  list<int>& cuts, double* sol, int maxNOfCuts){
  cuts.clear();
  int cutCounter = 0;
  srand( time(NULL) );
  list<Component>::iterator compIter;
  compIter = m_graphComponents.begin();
  int startComponent = rand() % m_graphComponents.size();
  for(int i=0; i<startComponent; i++){compIter++;}
  for(unsigned compCount=0; compCount<m_graphComponents.size(); compCount++){
    if( !(*compIter).maxCliquesInGraph.empty() ){
       list<int>::iterator iter = (*compIter).maxCliquesInGraph.begin();

       while(iter != (*compIter).maxCliquesInGraph.end() ){
	 int cliqueSize = *iter;
	 iter++;
	 int currentMaxClique[cliqueSize];
         double currentVertexValues[cliqueSize];
	 int start = rand() % cliqueSize;
	 for(int i=start; i<cliqueSize; i++){
	   currentMaxClique[i] = *iter;
	   iter++;
	 }
	 for(int i=0; i<start; i++){
	   currentMaxClique[i] = *iter;
	   iter++;
	 }
         int maxVertexPos = 0;
	 double totalWeight = 0.0;
	 for(int i=0; i<cliqueSize; i++){
           currentVertexValues[i] = 0;
	   for(int j=0; j<cliqueSize; j++){
	      if(i!=j) {
                 currentVertexValues[i] 
                 += sol[m_edgeNumberMatrix
                         [currentMaxClique[i]][currentMaxClique[j]]
                       ];
              }
           }
           totalWeight += currentVertexValues[i];
	   if(currentVertexValues[i] > currentVertexValues[maxVertexPos])
               { maxVertexPos = i; }
         }
	 totalWeight = totalWeight / 2;
         if(totalWeight < m_rhsClique[cliqueSize] - 0.01){
// cout << "1totalWeight " << totalWeight << " for clique size " << cliqueSize << endl;
	     cuts.push_back(cliqueSize * (cliqueSize-1) / 2);
	     for(int i=0; i<cliqueSize-1; i++){
	      for(int j=i+1; j<cliqueSize; j++){
	        cuts.push_back(
                  m_edgeNumberMatrix[currentMaxClique[i]][currentMaxClique[j]]
                );
              }
	     }
	     cuts.push_back(m_rhsClique[cliqueSize]);
	     cutCounter++;
	     if(cutCounter >= maxNOfCuts) return true;
          }
	int maxVertex;
	for(int currentSize = cliqueSize-1; currentSize >= 3; currentSize--){
	    maxVertex = currentMaxClique[maxVertexPos];
	    currentMaxClique[maxVertexPos] = currentMaxClique[currentSize];
	    maxVertexPos = 0;
	    for(int i=0; i<currentSize; i++){
		currentVertexValues[i] 
                  -= sol[m_edgeNumberMatrix[currentMaxClique[i]][maxVertex]];
		totalWeight 
                  -= sol[m_edgeNumberMatrix[currentMaxClique[i]][maxVertex]];
		if(currentVertexValues[i] > currentVertexValues[maxVertexPos]) 
                   { maxVertexPos = i; }
	    }
	    if(totalWeight < m_rhsClique[currentSize] - 0.01){
//cout.precision(3);
//cout << "2totalWeight " << totalWeight << " for clique size " << currentSize << endl;
//cout << "Single weights: ";
	       cuts.push_back(currentSize * (currentSize-1) / 2);
	       for(int i=0; i<currentSize-1; i++){
	         for(int j=i+1; j<currentSize; j++){
//cout << sol[m_edgeNumberMatrix[currentMaxClique[i]][currentMaxClique[j]]] << " ";
	           cuts.push_back(
                     m_edgeNumberMatrix
                       [currentMaxClique[i]][currentMaxClique[j]]
                   );
                 }
	       }
//cout << endl;
	       cuts.push_back(m_rhsClique[currentSize]);
	       cutCounter++;
	       if(cutCounter >= maxNOfCuts) return true;
	    }	
	}
   }
  }
  compIter++;
  if(compIter == m_graphComponents.end()) compIter = m_graphComponents.begin();
  }
  if(cuts.empty()){ return false;}
  else { return true; }
}










bool FeasibilityTest::m_separateOddTriangles(){
  // check whether triangle side sum is even  
  list<int>::iterator iter;
  list<Component>::iterator compIter;
  for(compIter=m_graphComponents.begin();
                                  compIter!=m_graphComponents.end();++compIter){
   if((*compIter).isStillActive){
    for(iter=(*compIter).trianglesInGraph.begin();
                               iter!=(*compIter).trianglesInGraph.end();++iter){
       int v1 = *iter;
       iter++;
       int v2 = *iter;
       iter++;
       int v3 = *iter;
       if( (m_distMatrix[v1][v2] + m_distMatrix[v2][v3] + m_distMatrix[v1][v3])
          % 2 == 1){
              // odd triangle was found
              m_conflictSets.push_back(3);
              m_conflictSets.push_back(v1);
              m_conflictSets.push_back(v2);
              m_conflictSets.push_back(v3);               
              if(returnSingleCuttingPlane) return true;
       }
    }
   }
  }
  if(m_conflictSets.empty()) {
	return false;
  }
  else {return true;}
}

int FeasibilityTest::m_determineNextVertex(int position, FeasibilityTree* tree){
 if(position >= m_nVertices){ return -1;}
 if(tree->m_vertexOrder.empty()){
      m_printError(-10); 
      return -1;
 }
 // lookup next vertex:
 if (position < tree->m_nVerticesAlreadyDetermined){
     return tree->m_vertexOrder[position];
 }
 else{
   // calculate next vertex:
   int nVerticesToCalculate = position - tree->m_nVerticesAlreadyDetermined + 1;
   if(vertexOrderingStrategy > 2 || vertexOrderingStrategy < 1){return -1;}
   switch (vertexOrderingStrategy){
   case 1: //Strategy 1: Random ordering, but:
           // New vertex has to be adjacent to at least one fixed vertex
    {
      // calculate set of candidates:
      list<int>::iterator returnVertex;
      for(int nVertCalculated=0;
                     nVertCalculated < nVerticesToCalculate; nVertCalculated++){   
        tree->m_candidatesForNextVertexList.clear();
        for(int i=0; i<(int)tree->m_vertexOrder.size(); i++){ 
         list<int>::iterator iter;
         for(iter=m_adjList[tree->m_vertexOrder[i]].begin(); 
                       iter != m_adjList[tree->m_vertexOrder[i]].end(); ++iter){ 
           if( tree->m_positionOfVertexInOrdering[*iter] == -1
               && (tree->m_isTemporarilyForbiddenVertex[*iter] == false) ){
                    tree->m_candidatesForNextVertexList.push_back(*iter); 
           } 
         }  
        }

         // choose randomly from set of candidates:
        srand( time(NULL) );
        if(tree->m_candidatesForNextVertexList.empty()) {return -1;}
        else{
          tree->m_candidatesForNextVertexList.sort();
	      tree->m_candidatesForNextVertexList.unique();
          int randomChoice 
               = rand() % (tree->m_candidatesForNextVertexList.size()); 
          returnVertex = tree->m_candidatesForNextVertexList.begin();
          for(int i=0; i<randomChoice; i++){returnVertex++;}
          tree->m_vertexOrder.push_back(*returnVertex);
          tree->m_nVerticesAlreadyDetermined++;  
          tree->m_positionOfVertexInOrdering[*returnVertex] 
            = position + nVertCalculated;
          m_determineCloseVertexAlreadyFixed(*returnVertex, tree);
        }
      }
      return *returnVertex;
   }  //end: case 1
    
   case 2: //Strategy 2: New vertex has distance 1 to a fixed vertex. Among
           // these, the new vertex is adjacent to a maximum number of fixed
           // vertices. Among these, the new vertex has highest degree.
    {
   int returnVertex;
   list<int>::iterator iter, iter2;
   //if(tree->m_candidatesForNextVertexList.empty()) 
   //  { tree->m_collectNewInfoForFastOrdering = true; }
   int counter = 0;   
  for(int nVertCalculated=0; 
                       nVertCalculated<nVerticesToCalculate; nVertCalculated++){   
     //clear old data:
     tree->m_candidatesForNextVertexList.clear();
     for(int i=0; i<m_nVertices; i++){tree->m_nNeighboursAlreadyFixed[i] = -1;} 
     
     //update candidates list: All unfixed vertices with distance 1 to a fixed
     // vertex. If no such candidate exists: All unfixed vertices with distance
     // 2 to a fixed vertex... etc.
     int dist = 1;
     while( true ){
      for(int i=0; i<(int)tree->m_vertexOrder.size(); i++){ 
       for(iter2=m_adjList[tree->m_vertexOrder[i]].begin(); 
                     iter2 != m_adjList[tree->m_vertexOrder[i]].end(); ++iter2){
           if( m_distMatrix[tree->m_vertexOrder[i]][*iter2] == dist 
               && tree->m_positionOfVertexInOrdering[*iter2] == -1
               && (tree->m_isTemporarilyForbiddenVertex[*iter2] == false) ){
                    tree->m_candidatesForNextVertexList.push_back(*iter2);
                    // new candidate found (= *iter2)
           } 
       }  
      }
      dist++;
      if(dist > m_maxDistAllowedInModel+1){ /*cout << "m_determineNextVertex: dist too large" <<endl;*/ return -1; }
      if( !tree->m_candidatesForNextVertexList.empty() ){break;}       
     }
     // if(dist == 2) tree->m_collectNewInfoForFastOrdering = false;
      // for fixed vertex v: How many already fixed vertices are adj. to v? :
     for(int j=0; j<(int)tree->m_vertexOrder.size(); j++){ 
         for(iter=m_adjList[tree->m_vertexOrder[j]].begin(); 
                          iter!=m_adjList[tree->m_vertexOrder[j]].end();++iter){
           if(tree->m_nNeighboursAlreadyFixed[*iter] == -1){
             tree->m_nNeighboursAlreadyFixed[*iter] = 0;
           }
           if(tree->m_nNeighboursAlreadyFixed[*iter] != -1){
             tree->m_nNeighboursAlreadyFixed[*iter]++;
           }
         }
     } 

   // determine vertex with highest nNeighboursAlreadyFixed-value from
   //  candidate list and delete multiple members from candidate list:   
   tree->m_candidatesForNextVertexList.sort();
   tree->m_candidatesForNextVertexList.unique();
   list<int> help = tree->m_candidatesForNextVertexList;
   tree->m_candidatesForNextVertexList.clear();
   for(iter=help.begin();iter!=help.end();++iter){
         if(!tree->m_isTemporarilyForbiddenVertex[*iter]){
           tree->m_candidatesForNextVertexList.push_back(*iter);} 
  }
   
   if(tree->m_candidatesForNextVertexList.size() == 0){ return -1;}
   if(tree->m_candidatesForNextVertexList.size() == 1) {
      returnVertex = tree->m_candidatesForNextVertexList.front();
   }
   else{
     tree->m_candidatesPhase2.clear();
     int bestValue = 0;
     for(iter=tree->m_candidatesForNextVertexList.begin(); 
                        iter!=tree->m_candidatesForNextVertexList.end();++iter){
             if( tree->m_nNeighboursAlreadyFixed[*iter] > bestValue ){
               bestValue = tree->m_nNeighboursAlreadyFixed[*iter];
               tree->m_candidatesPhase2.clear();
               tree->m_candidatesPhase2.push_back(*iter);   
             }                                
             if( tree->m_nNeighboursAlreadyFixed[*iter] == bestValue ){
               tree->m_candidatesPhase2.push_back(*iter);   
             }    
     }

   // determine candidates with highest degree:
    tree->m_candidatesPhase2.sort();
    tree->m_candidatesPhase2.unique();    
     if(tree->m_candidatesPhase2.size() == 1){
        returnVertex = tree->m_candidatesPhase2.front();
     }
     else{
       int highestDegree = 0;
       for(iter=tree->m_candidatesPhase2.begin(); 
                                   iter!=tree->m_candidatesPhase2.end();++iter){
           if((int)m_adjList[*iter].size() > highestDegree){
               highestDegree = m_adjList[*iter].size(); 
               returnVertex = *iter;                               
           }                                    
       }         
   
     }
   }
   tree->m_vertexOrder.push_back(returnVertex);
   tree->m_nVerticesAlreadyDetermined++;  
   tree->m_positionOfVertexInOrdering[returnVertex] = position + counter;
   m_determineCloseVertexAlreadyFixed(returnVertex, tree);
   for(iter = m_adjList[returnVertex].begin(); 
                                 iter != m_adjList[returnVertex].end(); ++iter){
     tree->m_nNeighboursAlreadyFixed[*iter]++; 
      
     if(tree->m_nNeighboursAlreadyFixed[*iter] == 0) 
         { tree->m_nNeighboursAlreadyFixed[*iter]++;}
     if(m_distMatrix[returnVertex][*iter] == 1 
        && tree->m_positionOfVertexInOrdering[*iter] == -1){
        tree->m_candidatesForNextVertexList.push_back(*iter);
     }
   } 
   tree->m_candidatesForNextVertexList.remove(returnVertex);
   counter++;
   // tree->m_collectNewInfoForFastOrdering = false;
  }
   return returnVertex;  
  }
  } 
 }
 return -1;
}                   
 
int FeasibilityTest::m_isRectangle(int* fourNodes){
  int maxDist = 0;
  int nMaxDistPairs = 0;
  int maxDistPairs[4];
  
  for(int i=0; i<3; i++){
    for(int j=i+1;j<4;j++){
      if(m_distMatrix[fourNodes[i]][fourNodes[j]] == maxDist){
         maxDistPairs[2] = fourNodes[i];
         maxDistPairs[3] = fourNodes[j];
         nMaxDistPairs++;                                            
      }
      if(m_distMatrix[fourNodes[i]][fourNodes[j]] > maxDist){
         maxDist = m_distMatrix[fourNodes[i]][fourNodes[j]];
         nMaxDistPairs = 1;
         maxDistPairs[0] = fourNodes[i];
         maxDistPairs[1] = fourNodes[j];
      }
    }   
  }
  if(nMaxDistPairs != 2) {return 0;}

  for(int i=0; i<3; i++){
    for(int j=i+1;j<4;j++){  
        if(maxDistPairs[i] == maxDistPairs[j]){return 0;}
    }
  }
  int shortDist1;
  int shortDist2;
  if( m_distMatrix[maxDistPairs[0]][maxDistPairs[2]] 
      != m_distMatrix[maxDistPairs[1]][maxDistPairs[3]] ){return 0;}
  else{shortDist1 = m_distMatrix[maxDistPairs[0]][maxDistPairs[2]];} 
  if( m_distMatrix[maxDistPairs[0]][maxDistPairs[3]] 
      != m_distMatrix[maxDistPairs[1]][maxDistPairs[2]] ){return 0;}
  else{shortDist2 = m_distMatrix[maxDistPairs[0]][maxDistPairs[3]];}
  if(shortDist1 + shortDist2 != maxDist){return 0;}

  fourNodes[0] = maxDistPairs[0];
  fourNodes[1] = maxDistPairs[2];
  fourNodes[2] = maxDistPairs[1];
  fourNodes[3] = maxDistPairs[3];
  return maxDist;                  
} 
 
void FeasibilityTest::m_initializeSearchTree(Component& component){
  list<int>::iterator iter, iter2;
  component.startVertices.clear();
  //check former start vertices:
  if(useInfoFromFormerTests){
    if(component.oldStartVertices.size() == 2){
       iter = component.oldStartVertices.begin();
       int v1 = *iter;
       iter++;
       if(m_distMatrix[v1][*iter] != 1) component.oldStartVertices.clear();
    }
    if(component.oldStartVertices.size() == 4){
       int fourNodes[4];
       iter = component.oldStartVertices.begin();
       fourNodes[0] = *iter;
       iter++;
       fourNodes[1] = *iter;
       iter++;
       fourNodes[2] = *iter;
       iter++;
       fourNodes[3] = *iter;
       if( m_isRectangle(fourNodes) == 0) component.oldStartVertices.clear();
    }                           
  } 
  else{component.oldStartVertices.clear();}
   component.startVertices = component.oldStartVertices;
   component.oldStartVertices.clear();
  //determine new start vertices  
  srand( time(NULL) );
  if(component.startVertices.empty() && !component.fourCliquesInGraph.empty() ){
    // 4-clique
    int fourClique[4];
    int maxDiagonal = 0;
    int startFourClique = rand() % (component.fourCliquesInGraph.size() / 4);
    iter = component.fourCliquesInGraph.begin();
    for(int i=0; i<4*startFourClique; i++) {iter++;}
    for(unsigned i=0; i < (component.fourCliquesInGraph.size() / 4); i++){
       fourClique[0]=*iter;
       iter++;
       fourClique[1]=*iter;
       iter++;
       fourClique[2]=*iter;
       iter++;
       fourClique[3]=*iter;
       iter++;
       int diag = m_isRectangle(fourClique);
       if( diag > maxDiagonal ){
          maxDiagonal = diag;  
          component.startVertices.clear();
          component.startVertices.push_back(fourClique[0]);  
          component.startVertices.push_back(fourClique[1]); 
          component.startVertices.push_back(fourClique[2]); 
          component.startVertices.push_back(fourClique[3]); 
       }
       if(iter == (component.fourCliquesInGraph).end()) 
          { iter = (component.fourCliquesInGraph).begin(); }
    }
  }
  
  // find pair with distance 1:
  if(component.startVertices.empty()){
    int startVertexA = rand() % component.nVertices;
    iter = component.vertexList.begin();
    for(int i=0; i<startVertexA; i++){iter++;}
    for(int i=0; i<component.nVertices; i++){
	int startVertexB = rand() % m_adjList[*iter].size();
	iter2 = m_adjList[*iter].begin();
	for(int j=0; j<startVertexB; j++){iter2++;}
	for(unsigned j=0; j<m_adjList[*iter].size(); j++){
	  if(    !component.isTemporarilyForbiddenVertex[*iter]
              && !component.isTemporarilyForbiddenVertex[*iter2]
               && m_distMatrix[*iter][*iter2] == 1){
                  component.startVertices.push_back(*iter);
                  component.startVertices.push_back(*iter2);
		  break;
	  }
	  iter2++;
	  if(iter2 == m_adjList[*iter].end()) iter2 = m_adjList[*iter].begin();
	}
	if(!component.startVertices.empty()) {break;}
	iter++;
	if(iter == component.vertexList.end()) 
	  { iter=component.vertexList.begin(); }
    }
  }
  if(component.startVertices.empty()){ 
    // choose any single start vertex 
    int startVertex = rand() % component.nVertices;
    iter = component.vertexList.begin();
    for(int i=0; i<startVertex; i++){iter++;}                                   
    component.startVertices.push_back(*iter);                                   
  }
   
  // initialize tree:
     iter = component.startVertices.begin();
     int s1 = *iter;
     int s2;
     if(component.startVertices.size() > 1){
       iter++;
       s2 = *iter;
     }
     int s3,s4;
     if(component.startVertices.size() == 4){
       iter++;
       s3 = *iter;
       iter++;
       s4 = *iter;                          
     }

     Node root;
     root.ID = 0;
     root.xCoordinate = m_nVertices;
     root.yCoordinate = m_nVertices;
     if(component.startVertices.size() > 1) root.isSymmetryCheckNeeded = true;
     else root.isSymmetryCheckNeeded = false;
     component.mainTree 
       = new FeasibilityTree(root, component.nVertices , m_nVertices);   
     for(int i=0; i< m_nVertices; i++) {
       component.mainTree->m_isTemporarilyForbiddenVertex[i] 
         = component.isTemporarilyForbiddenVertex[i];
     }
     if(component.startVertices.size() > 1){
       for(int i=0; i<(int)component.startVertices.size()-1; i++){
         Node newNode;
         newNode.ID = 1;
         if(i==0){newNode.isSymmetryCheckNeeded = true;}
         else{newNode.isSymmetryCheckNeeded = false;}
         newNode.xCoordinate = m_nVertices;
         if(i==0 || i==1) newNode.xCoordinate += m_distMatrix[s1][s2];
         newNode.yCoordinate = m_nVertices;
         if(i==1 || i==2) newNode.yCoordinate += m_distMatrix[s2][s3];
         newNode.pParent = &(component.mainTree->m_nodesOfTree)[i].front();
         (component.mainTree->m_nodesOfTree)[i+1].push_back(newNode);
         ((component.mainTree->m_nodesOfTree)[i].front()).pLeftChild 
           = &(component.mainTree->m_nodesOfTree[i+1].front());
         ((component.mainTree->m_nodesOfTree)[i+1].front()).pRightBrother 
           = &(component.mainTree->m_nil);    
       }
     }
     // initialize vertex order:
     component.mainTree->m_vertexOrder.clear();
     for(int i=0; i<m_nVertices; i++){
             component.mainTree->m_positionOfVertexInOrdering[i] = -1;
             component.mainTree->m_closeVertexAlreadyFixed[i] = -1;
     }
     component.mainTree->m_nVerticesAlreadyDetermined 
       = component.startVertices.size();
     component.mainTree->m_vertexOrder.push_back(s1);
     component.mainTree->m_positionOfVertexInOrdering[s1] = 0;
     if(component.startVertices.size() > 1){
       component.mainTree->m_vertexOrder.push_back(s2);
       component.mainTree->m_positionOfVertexInOrdering[s2] = 1;
       m_determineCloseVertexAlreadyFixed(s2, component.mainTree);
     }  
     if(component.startVertices.size() == 4){
       component.mainTree->m_vertexOrder.push_back(s3);
       component.mainTree->m_vertexOrder.push_back(s4);
       component.mainTree->m_positionOfVertexInOrdering[s3] = 2;
       component.mainTree->m_positionOfVertexInOrdering[s4] = 3;
       m_determineCloseVertexAlreadyFixed(s3, component.mainTree);
       m_determineCloseVertexAlreadyFixed(s4, component.mainTree);       
     } 
    
}      
              
int FeasibilityTest::m_performDepthFirstSearch(
      Component& component, FeasibilityTree* tree, vector<intVector>& distMatrix, 
      Node* startNode, int levelStartNode, int stopLevel, int vertexToAdd){

// Initialize information about current state of the search:            
  Node* currentNode = startNode;
  int currentLevel = levelStartNode;
  bool isOccupied[2*m_nVertices+2][2*m_nVertices+2]; // true if grid point is 
                                                     // currently occupied
  for(int i=0; i<2*m_nVertices; i++){
    for(int j=0; j<2*m_nVertices; j++){
       isOccupied[i][j] = false;          
    }
  }
  if(m_minMemoryMode){
    for(int i=0; i<= 2 * component.nVertices - 1; i++){  
      component.bestPosInMinMemMode[i] = 2 * m_nVertices + 2;}
  }
  
  double thisSolutionsBestAestheticValue = -1;
      
// Get information from start node up to the root node:     
  while(currentLevel != -1){  
     component.xPos[m_determineNextVertex(currentLevel, tree)] 
	= currentNode->xCoordinate;
     component.yPos[m_determineNextVertex(currentLevel,tree)] 
	= currentNode->yCoordinate; 
     isOccupied[currentNode->xCoordinate][currentNode->yCoordinate] = true;
     if(currentLevel != 0) {currentNode = currentNode->pParent;}
     currentLevel--;                    
  } 
  currentLevel = levelStartNode;
  currentNode = startNode;
  
  if(m_minMemoryMode){
      component.bestPosInMinMemMode[2*currentLevel] = m_nVertices + 1;
      component.bestPosInMinMemMode[2*currentLevel+1] = m_nVertices + 1;   
  } 

  if(levelStartNode == 0){
     if(stopLevel == 1){return 0;}
     Node root;
     root.ID = 0;
     root.pParent = &tree->m_nil;
     root.pRightBrother = &tree->m_nil;
     root.pLeftChild = &tree->m_nil;
     root.xCoordinate = m_nVertices + 1;
     root.yCoordinate = m_nVertices + 1;
     root.isSymmetryCheckNeeded = true;
     tree->m_root = root;
     tree->m_nodesOfTree[0].empty();
     tree->m_nodesOfTree[0].push_back(root);
     startNode = &tree->m_nodesOfTree[0].front();
     currentNode = startNode;
     m_determineNextVertex(0,tree);
  }
  
// Start Depth-First-Search: 
   list<int>::iterator iter, pos, del;
   int fourPositions[8];
   fourPositions[0] = 1;
   fourPositions[1] = 0;
   fourPositions[2] = 0;
   fourPositions[3] = 1;
   fourPositions[4] = -1;
   fourPositions[5] = 0;
   fourPositions[6] = 0;
   fourPositions[7] = -1;
   
   int whileLoopCounter = 0;
   while(true){
     whileLoopCounter++;
     if(m_isTestForMaxDistance || m_heuristicIsCurrentlyActive){
        if(whileLoopCounter > 1000000){ return (tree->m_currentTreeDepth + 2); }                         
     } 
     int nextVertex;
     if(vertexToAdd == -1) 
       { nextVertex = m_determineNextVertex(currentLevel+1,tree); }
     else nextVertex = vertexToAdd;
     if(nextVertex == -1) { return -1;}
//	 cout << nextVertex << ":" << endl;
     int nChildren = 0;
     // create children:
     int center = tree->m_closeVertexAlreadyFixed[nextVertex];
     if(center == -1) center = m_determineNextVertex(currentLevel,tree);
     // Special case: New vertex has distance 1
     if(distMatrix[center][nextVertex] == 1){
     // a) calculate possible positions
         bool check[4];
         if(!isOccupied[component.xPos[center]+1][component.yPos[center]]){
            check[0] = true;
            nChildren++;
         }
         else check[0] = false; 
         if(!isOccupied[component.xPos[center]][component.yPos[center]+1]){
            check[1] = true;
            nChildren++;
         } 
         else check[1] = false; 
         if(!isOccupied[component.xPos[center]-1][component.yPos[center]]){
            check[2] = true;
            nChildren++;
         } 
         else check[2] = false; 
         if(!isOccupied[component.xPos[center]][component.yPos[center]-1]){
            check[3] = true;
            nChildren++;
         } 
         else check[3] = false; 
         // b) check possible positions
         if(nChildren != 0){
         int vDiff; //vertical difference
         int hDiff; //horizontal difference
           for(iter=m_adjList[nextVertex].begin(); 
                                     iter!=m_adjList[nextVertex].end(); ++iter){
            if( *iter != center
                && tree->m_positionOfVertexInOrdering[*iter] <= currentLevel
                && tree->m_positionOfVertexInOrdering[*iter] != -1){
                for(int i=0; i<4; i++){
                  if(check[i]){
                    hDiff = component.xPos[*iter] 
                      - component.xPos[center] -fourPositions[2*i];
                    if(hDiff < 0) hDiff = (-1)*hDiff;
                    vDiff = component.yPos[*iter] 
                      - component.yPos[center] -fourPositions[2*i+1];
                    if(vDiff < 0) vDiff = (-1)*vDiff;
                    int diff = hDiff + vDiff - distMatrix[*iter][nextVertex];
                    if(diff != 0){
                        nChildren--;
                        check[i] = false;  
                        if(diff < -2 || diff > 2){
                           nChildren = 0;
                           break; 
                        }
                    }
                   }
                }
                if(nChildren == 0) break;
            }
           } 
         }
       // c) create new children nodes
      if(nChildren != 0){
        list<Node>::iterator nodeIter;
        bool isFirstChild = true;
        if(currentNode->isSymmetryCheckNeeded){
          if(check[1] && check[3]){
              check[3] = false;
              nChildren--;
          }                                       
        }
        for(int i=0; i<4; i++){
          if(check[i]){
            Node newNode;
            if((currentNode->isSymmetryCheckNeeded) && (i==0 || i==2))
                   {newNode.isSymmetryCheckNeeded = true;}
            else{newNode.isSymmetryCheckNeeded = false;}
            newNode.xCoordinate = component.xPos[center]+fourPositions[2*i];
            newNode.yCoordinate = component.yPos[center]+fourPositions[2*i+1];
            newNode.pParent = currentNode;
            newNode.pLeftChild = &(tree->m_nil);
            newNode.ID = 1;
//cout << "new node " << i << endl;
            
            try{
                   tree->m_nodesOfTree[currentLevel+1].push_back(newNode);
            }
            catch(bad_alloc){
               m_printError(-11);
               return -2;
            }
            
            if(isFirstChild){
              currentNode->pLeftChild 
                                 = &tree->m_nodesOfTree[currentLevel+1].back();
            }
            else{
              nodeIter = tree->m_nodesOfTree[currentLevel+1].end();
              nodeIter--;
              nodeIter--;
              (*nodeIter).pRightBrother 
                               = &(tree->m_nodesOfTree[currentLevel+1]).back();
            }
            isFirstChild = false;
          }    
        }
      (tree->m_nodesOfTree[currentLevel+1].back()).pRightBrother = &tree->m_nil;
      
      }
      if(nChildren == 0){
        currentNode->pLeftChild = &tree->m_nil;
      }                  
     }
     // General case: New vertex has distance > 1
     else{
       int dist = distMatrix[center][nextVertex];
       list<int> positions;
       positions.clear();
       int xCenter = component.xPos[center];
       int yCenter = component.yPos[center]; 
     // a) calculate possible positions
       //  calculate 4 extreme points: left, right, up, down
       if(xCenter-dist>=0 && !isOccupied[xCenter-dist][yCenter]){
          positions.push_back(xCenter-dist);
          positions.push_back(yCenter);
       }
       if(xCenter+dist<=2*m_nVertices+1 && !isOccupied[xCenter+dist][yCenter]){
          positions.push_back(xCenter+dist);
          positions.push_back(yCenter);
       }
       if(yCenter-dist>=0 && !isOccupied[xCenter][yCenter-dist]){
          positions.push_back(xCenter);
          positions.push_back(yCenter-dist);
       }
       if(yCenter+dist<=2*m_nVertices+1 && !isOccupied[xCenter][yCenter+dist]){
          positions.push_back(xCenter);
          positions.push_back(yCenter+dist);
       }
      // calculate all non-extreme points 
       for(int i=1; i<dist; i++){
          int j = dist - i;
          if(xCenter+i <= 2*m_nVertices+1){
            if(   yCenter+j <= 2*m_nVertices+1 
               && !isOccupied[xCenter+i][yCenter+j]){
                     positions.push_back(xCenter+i);
                     positions.push_back(yCenter+j);
              } 
              if(yCenter-j >= 0 && !isOccupied[xCenter+i][yCenter-j]){
                positions.push_back(xCenter+i);
                positions.push_back(yCenter-j);
              }
            }
          if(xCenter-i >= 0){
              if(    yCenter+j <= 2*m_nVertices+1 
                  && !isOccupied[xCenter-i][yCenter+j]){
                        positions.push_back(xCenter-i);
                        positions.push_back(yCenter+j);
              } 
              if(yCenter-j >= 0 && !isOccupied[xCenter-i][yCenter-j]){
                positions.push_back(xCenter-i);
                positions.push_back(yCenter-j);
              }
            }
          }            
         // b) check possible positions
       if(!positions.empty()){
         int vDist;
         int hDist;         
         for(iter=m_adjList[nextVertex].begin(); 
                                     iter!=m_adjList[nextVertex].end(); ++iter){
           if(   *iter != center 
              && tree->m_positionOfVertexInOrdering[*iter] <= currentLevel
              && tree->m_positionOfVertexInOrdering[*iter] != -1){  
              pos = positions.begin();  
              while(pos!=positions.end()){
                  hDist = *pos - component.xPos[*iter];
                  if(hDist<0) hDist = -hDist;
                  pos++;
                  vDist = *pos - component.yPos[*iter];
                  if(vDist<0) vDist = -vDist;
                  pos++;
                  if(hDist+vDist != distMatrix[*iter][nextVertex]){
                     //delete position
                     del = pos;
                     del--;
                     positions.erase(del);
                     del = pos;
                     del--;
                     positions.erase(del);  
                    if(positions.empty()) break;       
                  }
              }     
           }
           if(positions.empty()) break;            
         }
       }
       nChildren = positions.size() / 2;
     
     // c) create new children nodes
      if(nChildren != 0){
        list<Node>::iterator nodeIter;
        bool isFirstChild = true;
        pos = positions.begin();
        if(currentNode->isSymmetryCheckNeeded){
          for(int i=0; i<2*m_nVertices+2;i++){
            component.isSymPartnerAlreadyCreated[i]= false;
          }
        }
          while(!positions.empty()){
            Node newNode;
            newNode.xCoordinate = positions.front();
            positions.pop_front();
            newNode.yCoordinate = positions.front();
            positions.pop_front();
            if(   !currentNode->isSymmetryCheckNeeded
               || !component.isSymPartnerAlreadyCreated[newNode.xCoordinate]){
            component.isSymPartnerAlreadyCreated[newNode.xCoordinate] = true;
            if(   newNode.yCoordinate == m_nVertices 
               && currentNode->isSymmetryCheckNeeded){
                      newNode.isSymmetryCheckNeeded = true;
            }
            else{newNode.isSymmetryCheckNeeded = false;}
            newNode.pParent = currentNode;
            newNode.pLeftChild = &(tree->m_nil);
            newNode.ID = 1;
            try{
                tree->m_nodesOfTree[currentLevel+1].push_back(newNode);
            }
            catch(bad_alloc){
               m_printError(-11);
               return -1;
            }
            if(isFirstChild){
              currentNode->pLeftChild 
                                 = &tree->m_nodesOfTree[currentLevel+1].back();
            }
            else{
              nodeIter = tree->m_nodesOfTree[currentLevel+1].end();
              nodeIter--;
              nodeIter--;
              (*nodeIter).pRightBrother 
                               = &(tree->m_nodesOfTree[currentLevel+1]).back();
            }
            isFirstChild = false;
           (tree->m_nodesOfTree[currentLevel+1].back()).pRightBrother 
                                                                = &tree->m_nil;
           }
           else{nChildren--;}
         }
        }
        if(nChildren == 0){
           currentNode->pLeftChild = &tree->m_nil;
        }  
     }    
     // END: Create Children
     
     // Go to next vertex and update position arrays
     if(nChildren > 0){
     if(vertexToAdd != -1) {return 0;}
       currentLevel++;
       if(currentLevel == stopLevel){ //solution found! 
//cout << "stop level reached, solution found" << endl;
          currentNode = currentNode->pLeftChild; 
          component.xPos[nextVertex] = currentNode->xCoordinate;
          component.yPos[nextVertex] = currentNode->yCoordinate;
          if(m_minMemoryMode){     
              Node* currentNode2 = currentNode;
              for(int i=currentLevel; i>=0; i--){
                component.bestPosInMinMemMode[2*i] = currentNode2->xCoordinate;
                component.bestPosInMinMemMode[2*i+1] = currentNode2->yCoordinate;    
                currentNode2 = currentNode2->pParent;      
              }
          }
          if(!m_aestheticModeActivated) {return 0;}
          double aestheticValue = m_calcAestheticValue(component);
          if(aestheticValue > thisSolutionsBestAestheticValue +0.001){
		component.xPosBest = component.xPos;
		component.yPosBest = component.yPos;
          }
//cout <<	"walkback" << endl;
          goto walkback;
	  

       }
       currentNode = currentNode->pLeftChild; 
       component.xPos[nextVertex] = currentNode->xCoordinate;
       component.yPos[nextVertex] = currentNode->yCoordinate;
       isOccupied[currentNode->xCoordinate][currentNode->yCoordinate] = true;
     }
     if(nChildren == 0){
        if(tree->m_currentTreeDepth < currentLevel){
           tree->m_currentTreeDepth = currentLevel;          
           if(m_minMemoryMode){     
              Node* currentNode2 = currentNode;
              for(int i=currentLevel; i>=0; i--){
                component.bestPosInMinMemMode[2*i] = currentNode2->xCoordinate;
                component.bestPosInMinMemMode[2*i+1] = currentNode2->yCoordinate; 
                currentNode2 = currentNode2->pParent;      
              }
           }
        } 
        // start walkback:
        walkback:
        while(true){
            if( (currentNode->pRightBrother)->ID != -1){
                // goto right brother node:
                isOccupied[currentNode->xCoordinate][currentNode->yCoordinate] 
                  = false;
                currentNode = currentNode->pRightBrother;
                isOccupied[currentNode->xCoordinate][currentNode->yCoordinate] 
                  = true;
                component.xPos[tree->m_vertexOrder[currentLevel]] 
                  = currentNode->xCoordinate;
                component.yPos[tree->m_vertexOrder[currentLevel]] 
                  = currentNode->yCoordinate;
                if(m_minMemoryMode)
                   {tree->m_nodesOfTree[currentLevel].pop_front();}
                if( (currentNode->pLeftChild)->ID == -1){
                  if(currentLevel >= levelStartNode){  
                     break;
                  } 
                }
                else{
                // goto child node at the very left:
                 currentNode = currentNode->pLeftChild;
                 currentLevel++;
                 isOccupied[currentNode->xCoordinate][currentNode->yCoordinate] 
                   = true;
                 component.xPos[tree->m_vertexOrder[currentLevel]] 
                   = currentNode->xCoordinate;
                 component.yPos[tree->m_vertexOrder[currentLevel]] 
                   = currentNode->yCoordinate;
                }
            }
            else{
                // goto parental node or exit:
                if( (currentLevel-1) > 0){
                    // goto parental node:
                  component.xPos[tree->m_vertexOrder[currentLevel]] 
                    = 2*m_nVertices+1;
                  component.yPos[tree->m_vertexOrder[currentLevel]] 
                    = 2*m_nVertices+1;
                  isOccupied[currentNode->xCoordinate][currentNode->yCoordinate]
                    = false; 
                  currentNode = currentNode->pParent;
                  if(m_minMemoryMode) 
                    { tree->m_nodesOfTree[currentLevel].pop_front(); }
                  currentLevel--;   
                }
                else{
                    // exit:
                    return (tree->m_currentTreeDepth + 2);
                }
            }                  
        }
     }     
   } // END while
}
 
FeasibilityTest::FeasibilityTest(char* graphFile){
     m_errorOccured = false;
     m_graphFile = graphFile;
     if( m_readInputFile(graphFile) ){
	 // cout << "  checking symmetry of matrix... ";
       if( m_isInputMatrixSymmetrical() ){
         // cout << "done." << endl; 
		 // cout << "  searching for stars... # = ";
		 int starCounter = 0;
		 for(int i=0; i<m_nVertices; i++){
			if( m_adjList[i].size() >= 5)
				starCounter++;
		 }
		 // cout << starCounter << " done." << endl;
         // cout << "  searching for 3- and 4-cliques... ";
         if( m_findTrianglesAnd4CliquesInGraph(1000000) ){
		   // cout << "done." << endl;
		   // cout << "  searching for 5-cycles... ";
		   if( m_findFiveCyclesInGraph(100000) ){
             // cout << "done." << endl;
		    // cout << "  searching for maximum cliques... ";
	         if( m_findMaxCliquesInGraph(1000000) ){
		       // cout << "done." <<endl << "done." <<endl <<endl;
                       m_calcMaxDistAllowed();
		     }
             else{m_errorOccured = true; }   
		   }
           else{m_errorOccured = true; }   
         }
   
         else{m_errorOccured = true; }   
       }
       else{m_errorOccured = true; }   
     }
     else{m_errorOccured = true; } 
}

int FeasibilityTest
     ::m_isConnectedComponentEmbeddable(list<int> componentsVertices){
  if(componentsVertices.size() < 3) {return 1;}
  list<int>::iterator iter;
  int component[componentsVertices.size()];
  int counter = 0;
  for(iter=componentsVertices.begin(); iter!=componentsVertices.end(); ++iter){
      component[counter] = *iter;
      counter++;                                   
  }
  if(componentsVertices.size() == 3){
     // special case: triangle
     if(   m_adjMatrix[component[0]][component[1]]==1
             && m_adjMatrix[component[0]][component[2]]==1
             && m_adjMatrix[component[1]][component[2]]==1){
             if((m_distMatrix[component[0]][component[1]]
                 + m_distMatrix[component[0]][component[2]]
                 + m_distMatrix[component[1]][component[2]])
                 % 2 == 1){
                 return 0; // unembeddable
                 }
	      else{return 1;}
          }
      else{return 1;}
      }
  else{
   // general case: > 3 vertices
            Node root; 
            root.ID = 0;
            root.isSymmetryCheckNeeded = true;
            root.xCoordinate = m_nVertices;
            root.yCoordinate = m_nVertices;
            Component compy;
	    compy.isStillActive = true;
	    for(int i=0; i<m_nVertices; i++){
                (compy.xPos).push_back(-1); 
                (compy.yPos).push_back(-1);
        }
	    for(int i=0; i<2*m_nVertices+2; i++)
            { (compy.isSymPartnerAlreadyCreated).push_back(false); }
        compy.mainTree 
          = new FeasibilityTree(root,componentsVertices.size()+1, m_nVertices);
        ((compy.mainTree->m_nodesOfTree[0]).front()).pRightBrother 
          = &(compy.mainTree->m_nil); 
        ((compy.mainTree->m_nodesOfTree[0]).front()).pParent 
          = &(compy.mainTree->m_nil); 
        ((compy.mainTree->m_nodesOfTree[0]).front()).pLeftChild 
          = &(compy.mainTree->m_nil);  
        compy.mainTree->m_vertexOrder.push_back(component[0]);
        compy.mainTree->m_positionOfVertexInOrdering[component[0]] = 0;
	    compy.xPos[component[0]] = m_nVertices;
	    compy.yPos[component[0]] = m_nVertices;
        for(int j=0;j<m_nVertices;j++){
          compy.mainTree->m_isTemporarilyForbiddenVertex[j] = true;
          compy.isTemporarilyForbiddenVertex.push_back(true);
        }
        for(int j=0;j<(int)componentsVertices.size();j++){
          compy.mainTree->m_isTemporarilyForbiddenVertex[component[j]] = false;
          compy.isTemporarilyForbiddenVertex[component[j]] = false;
        }
        // start depth-first search:
        int dfs = m_performDepthFirstSearch(compy, 
                    compy.mainTree, 
                     m_distMatrix,
                      &(((compy.mainTree)->m_nodesOfTree[0]).front()),
                        0, 
                          componentsVertices.size()-1, 
                            -1);                              
        delete compy.mainTree;
        if(dfs == 0) {return 1;}
		if(dfs == -2) {return -2;}
        if(dfs == -1 || dfs >= 1 ){ return 0; }
        }
	return 0;
}

int FeasibilityTest::m_reduceConflictSet(
       int nConflictSets, int maxSetSize, Component& component){
  //construct conflict matrix: 
  int conflictMatrix[nConflictSets][maxSetSize+1];  
  int newSetSize[nConflictSets]; 
  bool mustThisRowBeChecked[nConflictSets];
  for(int i=0;i<nConflictSets;i++){mustThisRowBeChecked[i] = true;}  
  list<int>::iterator iter = component.currentConflictSets.begin();
  int counter = 0;
  while(iter!=component.currentConflictSets.end()){
    int limit = *iter;
    newSetSize[counter] = limit;
    for(int i=0; i<= limit; i++){
      conflictMatrix[counter][i] = *iter;
      iter++;
    }
    for(int i=limit+1; i<maxSetSize+1; i++){
      conflictMatrix[counter][i] = -1;        
    } 
    counter++;
  } 
  component.currentConflictSets.clear();

  // Set-reducing loop:
  list<int> isolatedFromMainTree;
  for(int i=maxSetSize-1; i>=1; i--){ //i: column of vertex to be left out

    for(int j=nConflictSets-1; j >= 0; j--){ // j: ID of set to be reduced
      if(i > conflictMatrix[j][0] - 1){break;}    
      if(mustThisRowBeChecked[j]){
    
      //(a) Forbidden vertices and vertex order update: 
      while((int)component.mainTree->m_vertexOrder.size() > i-1){
         component.mainTree->m_positionOfVertexInOrdering
           [component.mainTree->m_vertexOrder.back()] = -1;
         component.mainTree->m_vertexOrder.pop_back();            
         component.mainTree->m_nVerticesAlreadyDetermined--;                  
      }
      
      for(int k=0; k< m_nVertices; k++)
         { component.mainTree->m_isTemporarilyForbiddenVertex[k] = true; }
      isolatedFromMainTree.clear();                 
      int nVerticesToAdd = 0;
      for(int k=i+1; k <= conflictMatrix[j][0]; k++){
         if(conflictMatrix[j][k] != -1){
            component.mainTree
              ->m_isTemporarilyForbiddenVertex[conflictMatrix[j][k]] = false; 
            isolatedFromMainTree.push_back(conflictMatrix[j][k]); 
              //vertex might(!) be isolated, check below
            nVerticesToAdd++;                   
         }        
      }
      
      //(b) prepare tree:
      if(i!=1){
      for(int k=i-1;k<m_nVertices;k++){
         if(!component.mainTree->m_nodesOfTree[k].empty()){
             component.mainTree->m_nodesOfTree[k].clear();
         }
         else{break;}        
      }
      list<Node>::iterator nodeIt;
      for(nodeIt=component.mainTree->m_nodesOfTree[i-2].begin();
          nodeIt!=component.mainTree->m_nodesOfTree[i-2].end(); ++nodeIt){  
             nodeIt->pLeftChild = &component.mainTree->m_nil;
      }
      // (c) determine next vertices to fix 
      // component.mainTree->m_collectNewInfoForFastOrdering = true;
      for(int k=0; k<nVerticesToAdd; k++){    
         int next = m_determineNextVertex(
           component.mainTree->m_vertexOrder.size(), component.mainTree
         );        
         if(next != -1){isolatedFromMainTree.remove(next);}
         if(next == -1){
                 nVerticesToAdd = k;
                 break;
         }
      }
      }

      //(d) check vertices isolated from the main tree  
      bool isUnembeddableComponentFound = false;
      if(!isolatedFromMainTree.empty()){
        //detect next connected component
        int components[m_nVertices];
        for(int i2=0; i2<m_nVertices;i2++){components[i2]=-1;}
        components[0] = isolatedFromMainTree.front();
        int counter = 0;
        
        for(int i2=0; i2<(int)isolatedFromMainTree.size(); i2++){
          if(components[i2] == -1){break;}
          for(iter=isolatedFromMainTree.begin();
                                       iter!=isolatedFromMainTree.end();++iter){
            if(m_adjMatrix[components[i2]][*iter] == 1){
               bool isAlreadySet = false;
               for(int j=0; j<counter+1; j++){
                 if(components[j] == *iter){isAlreadySet = true; break;}
               }
               if(!isAlreadySet){
                 components[counter+1] = *iter;
                 counter++;
               }
            }
          } 
        }

        // check component
        list<int> componentToCheck;
        for(int k=0; k<counter+1;k++)
          { componentToCheck.push_back(components[k]); }
          int compTestEmb = m_isConnectedComponentEmbeddable(componentToCheck);
		if( compTestEmb == 0 ) isUnembeddableComponentFound = true;
		if( compTestEmb == 1 ) isUnembeddableComponentFound = false;
        if( compTestEmb == -2 ) return -2;		
        if(isUnembeddableComponentFound){
           mustThisRowBeChecked[j] = false; 
           m_conflictSets.push_back(counter+1);
           list<int> currentConflictSet;
           for(int j=0; j<counter+1;j++){
               currentConflictSet.push_back(components[j]);
           }
           currentConflictSet.sort();
           iter = currentConflictSet.begin();
           for(int j=0; j<counter+1;j++){
              m_conflictSets.push_back(*iter);
              iter++; 
           }
           break;
        }
        // delete component
        for(int j=0; j<counter+1; j++){
            isolatedFromMainTree.remove(components[j]);
        }

      }

      //(e) perform depth first search
      if(i!=1 && mustThisRowBeChecked[j]){
      bool isEmbeddingPossible = false;
      if(nVerticesToAdd == 0){
        isEmbeddingPossible = true;
      }
      else{
        int dfs = m_performDepthFirstSearch
         (component, 
           component.mainTree, 
            m_distMatrix,
            &(component.mainTree->m_nodesOfTree[i-2].front()), 
              i - 2,
               i - 2 + nVerticesToAdd,
                 -1);     
        if(dfs == 0){isEmbeddingPossible = true;}
        if(dfs > 0){isEmbeddingPossible = false; }
        if(dfs < 0){cout << "error during minimization-dfs" <<endl;} 
		if( dfs == -2 ) return -2;
      }
     if(isUnembeddableComponentFound) isEmbeddingPossible = false;

      //(e) delete vertex if it is not needed in conflict set:
       if( !isEmbeddingPossible && mustThisRowBeChecked[j]){
         conflictMatrix[j][i] = -1;
         newSetSize[j]--;
       }
       }
      }     
    }     
  }
     
  // store minimized sets
  list<int> currentConflictSet;
  for(int i=0; i<nConflictSets; i++){
    if(mustThisRowBeChecked[i]){
    newSetSize[i] = 0;
    for(int j=1; j<maxSetSize+1; j++){
      if(conflictMatrix[i][j] != -1){newSetSize[i]++;}	
    }
    m_conflictSets.push_back(newSetSize[i]);
    for(int j=1; j<maxSetSize+1; j++){
      if(conflictMatrix[i][j] != -1){
         currentConflictSet.push_back(conflictMatrix[i][j]);
      }     
    }
    currentConflictSet.sort();
    for(iter=currentConflictSet.begin();iter!=currentConflictSet.end();++iter){
      m_conflictSets.push_back(*iter);
    }
    currentConflictSet.clear();
   }
  } 

  return 0;  
}

bool FeasibilityTest::m_isComponentConnected(Component& comp){
  list<int>::iterator iter, iter2;
  bool reached[m_nVertices];
  for(int i=0; i<m_nVertices; i++) reached[i] = false;
  int vertices[comp.nVertices];
  int reachedVertices[comp.nVertices];
  iter = comp.vertexList.begin();
  for(int i=0; i<comp.nVertices; i++) {
    reachedVertices[i] = -1;
    vertices[i] = *iter; 
    iter++;
  }

  reached[vertices[0]] = true;
  reachedVertices[0] = vertices[0];
  int counterReached = 1;
  for(int i=0; i<comp.nVertices-1; i++){
   if(reachedVertices[i] == -1) return false;
   for(int j=0; j<comp.nVertices; j++){
    if(     m_adjMatrix[reachedVertices[i]][vertices[j]] == 1 
        && !reached[vertices[j]]){
       reached[vertices[j]] = true;
       reachedVertices[counterReached] = vertices[j];
       counterReached++;
       if(counterReached == comp.nVertices) return true;
    }
   }
  }
  return false;
}



  struct Edge{
    int v1;
    int v2;
    int edgeNumber;
  };

void FeasibilityTest::m_edgeReduceVertexConflictSet(Component& component){

  //cout << "Edge reduce vertex conflict set" << endl;
  vector<intVector> copyDistMatrix = m_distMatrix;
  vector<intVector> copyAdjMatrix = m_adjMatrix;
  vectorOfLists copyAdjList = m_adjList;

  list<int>::iterator iter;
  list<int> newVertexConflictList;
  for(iter = m_conflictSets.begin(); iter != m_conflictSets.end(); ++iter){
    int nVertices = *iter;
   if(nVertices <= 3){
     newVertexConflictList.push_back(*iter);
     for(int i=0; i<nVertices; i++) { 
       iter++;
       newVertexConflictList.push_back(*iter);               
     }
   }
   else{
    int vertexArray[nVertices];
    for(int i=0; i<nVertices; i++) {
      iter++;
      vertexArray[i] = *iter;
    }

    list<Edge> edgesToCheck;
    for(int i=0; i<nVertices-1; i++){
      for(int j=i+1; j<nVertices; j++){
	if(m_adjMatrix[vertexArray[i]][vertexArray[j]] == 1){
	    Edge edge;
	    edge.v1 = vertexArray[i];
	    edge.v2 = vertexArray[j];
	    edge.edgeNumber = m_edgeNumberMatrix[vertexArray[i]][vertexArray[j]];
	    edgesToCheck.push_back(edge);
        }
      }
    }
    int nEdges = edgesToCheck.size();

    list<int> neededEdges;
    list<Edge>::iterator edgeIter;
    srand( time(NULL) );
    while(! edgesToCheck.empty() ){
      int nextEdgeNumber = rand() % edgesToCheck.size();
      edgeIter = edgesToCheck.begin();
      for(int i=0; i<nextEdgeNumber; i++) edgeIter++;
      Edge nextEdge = *edgeIter;

      m_adjMatrix[nextEdge.v1][nextEdge.v2] = 0;
      m_adjMatrix[nextEdge.v2][nextEdge.v1] = 0;
      int copyDist = m_distMatrix[nextEdge.v1][nextEdge.v2];
      m_distMatrix[nextEdge.v1][nextEdge.v2] = 0;
      m_distMatrix[nextEdge.v2][nextEdge.v1] = 0;
      m_adjList[nextEdge.v1].remove(nextEdge.v2);
      m_adjList[nextEdge.v2].remove(nextEdge.v1);
      nEdges--;

     //create new component:
    Component compy;
    compy.nVertices = nVertices;
    compy.nEdges = nEdges;
    for(int i=0; i<m_nVertices; i++){
       compy.isTemporarilyForbiddenVertex.push_back(true);
       compy.xPos.push_back(2*nVertices+2);
       compy.yPos.push_back(2*nVertices+2);
       compy.xPosBest.push_back(2*nVertices+2);
       compy.yPosBest.push_back(2*nVertices+2);
       compy.isSymPartnerAlreadyCreated.push_back(false);
       compy.isSymPartnerAlreadyCreated.push_back(false);
    }
    compy.isSymPartnerAlreadyCreated.push_back(false);
    compy.isSymPartnerAlreadyCreated.push_back(false);
    for(int i=0; i<nVertices; i++){ 
      compy.vertexList.push_back(vertexArray[i]);
      compy.isTemporarilyForbiddenVertex[vertexArray[i]] = false;
    }
     // TEST is component connected?
     bool embeddable;
     int result = -1;
     if( ! m_isComponentConnected(compy) ){ embeddable = true; }
     else{
       try{
        //performing depth-first-search:
         int returnMaxConflictSetSize;
         result = m_startMainSearch(returnMaxConflictSetSize, compy, true);
      }
       catch(...){result = -1;}
      if(result == 0 || result == -1) { embeddable = true; }
      else{ embeddable = false; }
      if(result != -1) { delete compy.mainTree; }
     } 

      if(embeddable){
        // Don't delete edge:
        neededEdges.push_back(nextEdge.v1);
        neededEdges.push_back(nextEdge.v2);
        m_adjMatrix[nextEdge.v1][nextEdge.v2] = 1;
        m_adjMatrix[nextEdge.v2][nextEdge.v1] = 1;
        m_distMatrix[nextEdge.v1][nextEdge.v2] = copyDist;
        m_distMatrix[nextEdge.v2][nextEdge.v1] = copyDist;
        m_adjList[nextEdge.v1].push_back(nextEdge.v2);
        m_adjList[nextEdge.v2].push_back(nextEdge.v1);
        nEdges++;
      }
      else{
	   // delete edge
      }
     edgesToCheck.erase(edgeIter);
    }

    // recopy adjacency information
    m_adjMatrix = copyAdjMatrix;
    m_adjList = copyAdjList;
    m_distMatrix = copyDistMatrix;

   // Construct problematic set: m_conflictSetsEdges
    m_conflictSetsEdges.push_back(neededEdges.size() / 2);
    list<int>::iterator iter2;
    for(iter2 = neededEdges.begin(); iter2 != neededEdges.end(); ++iter2)
     { m_conflictSetsEdges.push_back(*iter2); }
  }
  }
  m_conflictSets = newVertexConflictList;
}

void FeasibilityTest::m_calcOutputInequalitiesFromConflictSets(
         list<int>& nNonZeros, list<int>& nonZeroCoeff, 
         list<int>& nonZeroVariables, list<int>& rhs){
  

  list<int>::iterator iter;
  int setArray[m_nVertices];
  m_nCuts = 0;
  for(iter=m_conflictSets.begin();iter!=m_conflictSets.end();++iter){
    int setSize = *iter;
    m_nCuts++;
    m_nCutsTotal++;
    int currentRhs = 0;
    int nonZerosCounter = 0;
//cout << "(" << setSize << ") ";
    for(int i=0;i<setSize;i++){
      iter++; 
      setArray[i] = *iter;   
//cout << setArray[i] << " ";  
    }
//cout << ". d = ";
    for(int i=0; i<setSize-1; i++){
      for(int j=i+1; j<setSize; j++){
          if(m_distMatrix[setArray[i]][setArray[j]] != 0){
//cout << m_distMatrix[setArray[i]][setArray[j]] << " ";
               int newID = m_nEdges;
               newID +=   (m_maxDistAllowedInModel-1) 
                        * m_edgeNumberMatrix[setArray[i]][setArray[j]];
               newID += m_distMatrix[setArray[i]][setArray[j]]-2; 
			   
//cout << "newID=" << m_nEdges-1 << "+" << (m_maxDistAllowedInModel) << "*" <<m_edgeNumberMatrix[setArray[i]][setArray[j]]
//	 << "+" << m_distMatrix[setArray[i]][setArray[j]] << " = " << newID << endl;

             if(m_distMatrix[setArray[i]][setArray[j]] != m_maxDistAllowedInModel
			   && m_distMatrix[setArray[i]][setArray[j]] != 1){ 
			    currentRhs++;
		        nonZerosCounter++; 
                nonZeroCoeff.push_back(1);
                nonZeroVariables.push_back(newID);
		        nonZerosCounter++;
             	nonZeroCoeff.push_back(-1); 
             	nonZeroVariables.push_back(newID+1);                
	         }
             if(m_distMatrix[setArray[i]][setArray[j]] == m_maxDistAllowedInModel){ 
			    currentRhs++;
		        nonZerosCounter++; 
                nonZeroCoeff.push_back(1);
                nonZeroVariables.push_back(newID);               
	         }			 
             if(m_distMatrix[setArray[i]][setArray[j]] == 1){ 
		        nonZerosCounter++; 
                nonZeroCoeff.push_back(-1);
                nonZeroVariables.push_back(newID+1);               
	         }				 
			 
          }          
      }
    }
//cout << endl;

	currentRhs--;
    rhs.push_back(currentRhs);
    nNonZeros.push_back(nonZerosCounter);

  }


}

void FeasibilityTest::m_calcOutputInequalitiesFromEdgeConflictSets(
         list<int>& nNonZeros, list<int>& nonZeroCoeff, 
         list<int>& nonZeroVariables, list<int>& rhs){
  
  list<int>::iterator iter;
  for(iter=m_conflictSetsEdges.begin();iter!=m_conflictSetsEdges.end();++iter){
    int setSize = *iter;
    m_nCuts++;
    m_nCutsTotal++;
    int currentRhs = 0;
    int nonZerosCounter = 0;

    for(int i=0; i<setSize; i++){
      iter++;
      int v1 = *iter;
      iter++;
      int v2 = *iter;
//cout << "v1: " << v1 << ", v2: " << v2 << " , ID: ";
      int newID = m_nEdges;
      newID +=   (m_maxDistAllowedInModel-1) 
                 * m_edgeNumberMatrix[v1][v2];
      newID += m_distMatrix[v1][v2] - 1;
      if(m_distMatrix[v1][v2] != 1){
		nonZerosCounter++;
                currentRhs++;  
                nonZeroCoeff.push_back(1);
                nonZeroVariables.push_back(newID-1);
      }
      if(   m_distMatrix[v1][v2] 
                != m_maxDistAllowedInModel){
                nonZerosCounter++;
   	            nonZeroCoeff.push_back(-1); 
   	            nonZeroVariables.push_back(newID);                
      }
    }          
    currentRhs--;
    rhs.push_back(currentRhs);
    nNonZeros.push_back(nonZerosCounter);
  }
}

int FeasibilityTest::m_startMainSearch(
   int& returnMaxConflictSetSize, Component& component, bool singleConflictSet){
  m_initializeSearchTree(component);
  int sizeConflictSet = -1;
  int maxConflictSetSize = 0;
  int nNewConflictSets = 0;
  component.currentConflictSets.clear();
  if( ! component.startVertices.empty() ){
   while(true){

     sizeConflictSet = m_performDepthFirstSearch
         (component,
          component.mainTree,
          m_distMatrix, 
          &(component.mainTree->m_nodesOfTree
              [component.mainTree->m_nVerticesAlreadyDetermined-1].front()), 
           component.mainTree->m_nVerticesAlreadyDetermined-1,
            component.nVertices-1,
             -1);

	if(sizeConflictSet == -2 ) return -2;
    if(sizeConflictSet == 0 || sizeConflictSet == -1){break;}
    component.currentConflictSets.push_back(
       component.mainTree->m_nVerticesAlreadyDetermined
    );
    if(maxConflictSetSize < component.mainTree->m_nVerticesAlreadyDetermined){
        maxConflictSetSize = component.mainTree->m_nVerticesAlreadyDetermined;
    }
    for(int i=0; i<component.mainTree->m_nVerticesAlreadyDetermined; i++){  
       component.currentConflictSets.push_back(
         component.mainTree->m_vertexOrder[i]
       );     
    }
    nNewConflictSets++;
    if(singleConflictSet){break;}
    if(m_minMemoryMode){break;}

    // remove last vertex in conflict set
    component.mainTree->m_isTemporarilyForbiddenVertex[
      component.mainTree->m_vertexOrder[
        component.mainTree->m_nVerticesAlreadyDetermined-1
      ]
    ] = true;
    component.mainTree->m_positionOfVertexInOrdering[
      component.mainTree->m_vertexOrder[
        component.mainTree->m_nVerticesAlreadyDetermined-1
      ]
    ] = -1;
    component.mainTree->m_vertexOrder.pop_back();
    component.mainTree->m_nVerticesAlreadyDetermined--;
  }
  }
  else{return -1;}
  returnMaxConflictSetSize = maxConflictSetSize;
  if(singleConflictSet){
    if(sizeConflictSet == 0) return 0;
    if(sizeConflictSet == -1) return -1;
    else{return 1;}
  }
  return nNewConflictSets;  
}

int FeasibilityTest::m_solveComponentWithAtMost3Vertices(Component& compIter){
      // check triangle:
       list<int>::iterator triangleIter;
       if(!(compIter).trianglesInGraph.empty()){
         triangleIter = (compIter).trianglesInGraph.begin();
         int v1 = *triangleIter;
         triangleIter++;
         int v2 = *triangleIter;
         triangleIter++;
         int v3 = *triangleIter;
         if(m_distMatrix[v1][v2] + m_distMatrix[v2][v3] + m_distMatrix[v1][v3]
            == 4){
                  (compIter).xPos[v1] = m_nVertices;  
                  (compIter).yPos[v1] = m_nVertices;
                  (compIter).yPos[v2] = m_nVertices;
                  (compIter).yPos[v3] = m_nVertices;
                  if(m_distMatrix[v1][v2] == 2){
                     (compIter).xPos[v2] = m_nVertices + 2;  
                     (compIter).xPos[v3] = m_nVertices + 1;
                  }  
                  else{
                     (compIter).xPos[v2] = m_nVertices + 1;  
                     (compIter).xPos[v3] = m_nVertices + 2;
                  }
                  return 0; 
       }
       else{
           m_conflictSets.push_back(3);
           m_conflictSets.push_back(v1);
           m_conflictSets.push_back(v2);
           m_conflictSets.push_back(v3); 
           return 1;
       } 
      }
      else{
        int v1 = -1;
        for(int i=0; i<m_nVertices; i++){
            if(    !(compIter).isTemporarilyForbiddenVertex[i] 
                && m_adjList[i].size() == 2){
                   v1 = i;
                   break;
            }
        }
        (compIter).xPos[v1] = m_nVertices;
        (compIter).yPos[v1] = m_nVertices;
        list<int>::iterator iter;
        iter=m_adjList[v1].begin();
        (compIter).xPos[*iter] = m_nVertices+1;
        (compIter).yPos[*iter] = m_nVertices;
        iter++;
        (compIter).xPos[*iter] = m_nVertices-1;
        (compIter).yPos[*iter] = m_nVertices;  
        return 0;
      }
}

double FeasibilityTest
    ::m_constructFeasibleSolution(int* distArray, double currentBestObjValue, bool useTreeSearch){
      
  srand ( time(NULL) );

  
  // construct solution according to distArray, then fill up grid with
  // the remaining vertices in a locally optimal way
  
  m_heuristicIsCurrentlyActive = true;
  srand( time(NULL) );
  list<int>::iterator iter, iter2;
  // (a) copy the dist-array:
  int counter = 0;
  int maxDistInInput = 0;
  for(int v=0; v<m_nVertices; v++){
    for(iter = m_adjList[v].begin(); iter != m_adjList[v].end(); iter++){
	if(*iter > v){
        m_distMatrix[v][*iter] = distArray[counter];
	    m_distMatrix[*iter][v] = distArray[counter];
	    if(maxDistInInput < distArray[counter]) 
           {maxDistInInput = distArray[counter];}
	    counter++;
        }
    }
  }
  m_maxDistInInput = maxDistInInput;

  list<Component>::iterator compIter;
  list<Node>::iterator nodeIter;

  int xPos[m_nVertices];
  int yPos[m_nVertices];
  for(int i=0; i<m_nVertices; i++){
      xPos[i] = 2*m_nVertices+2;
      yPos[i] = 2*m_nVertices+2;
  }
  double bestObjValOfComp[m_graphComponents.size()];
  int compNo = -1;
  for(compIter = m_graphComponents.begin(); compIter != m_graphComponents.end();
                                                                    compIter++){
    compNo++;
    if((*compIter).nVertices == 1){
	(*compIter).bestObjVal = 0.0;
        bestObjValOfComp[compNo] = 0.0;
    }
    // case: 2-vertex-component:
    if((*compIter).nVertices == 2){
	iter = (*compIter).vertexList.begin();
	int v1 = *iter;
        (*compIter).xPosBest[v1] = m_nVertices;
        (*compIter).yPosBest[v1] = m_nVertices;
	iter++;
        (*compIter).xPosBest[*iter] = m_nVertices + 1;
        (*compIter).yPosBest[*iter] = m_nVertices;
	distArray[m_edgeNumberMatrix[v1][*iter]] = 1;
        bestObjValOfComp[compNo] = m_edgeWeights[m_edgeNumberMatrix[v1][*iter]];
    }
    // case: 3-vertex-component:
    if((*compIter).nVertices == 3){
	  iter = (*compIter).vertexList.begin();
	  int v1 = *iter;
	  iter++;
	  int v2 = *iter;
	  iter++;
	  int centerVertex = v1;
	  double largestEdgeVal = 0.0;
	  double smallestEdgeVal = 1.0;
	  double totalEdgeWeight = 0.0;
	  if( m_adjMatrix[v1][v2] == 1 ){
	    totalEdgeWeight += m_edgeWeights[m_edgeNumberMatrix[v1][v2]];
		if( m_edgeWeights[m_edgeNumberMatrix[v1][v2]] > largestEdgeVal ){
			largestEdgeVal = m_edgeWeights[m_edgeNumberMatrix[v1][v2]];
			centerVertex = v1;
		}
		if( m_edgeWeights[m_edgeNumberMatrix[v1][v2]] < smallestEdgeVal ){
			smallestEdgeVal = m_edgeWeights[m_edgeNumberMatrix[v1][v2]];
		}
	  }
	  if( m_adjMatrix[v1][*iter] == 1 ){
	    totalEdgeWeight += m_edgeWeights[m_edgeNumberMatrix[v1][*iter]];
		if( m_edgeWeights[m_edgeNumberMatrix[v1][*iter]] > largestEdgeVal ){
			largestEdgeVal = m_edgeWeights[m_edgeNumberMatrix[v1][*iter]];
			centerVertex = v1;
		}
		if( m_edgeWeights[m_edgeNumberMatrix[v1][*iter]] < smallestEdgeVal ){
			smallestEdgeVal = m_edgeWeights[m_edgeNumberMatrix[v1][*iter]];
		}
	  }
	  if( m_adjMatrix[*iter][v2] == 1 ){
	    totalEdgeWeight += m_edgeWeights[m_edgeNumberMatrix[*iter][v2]];
		if( m_edgeWeights[m_edgeNumberMatrix[*iter][v2]] > largestEdgeVal ){
			largestEdgeVal = m_edgeWeights[m_edgeNumberMatrix[*iter][v2]];
			centerVertex = *iter;
		}
		if( m_edgeWeights[m_edgeNumberMatrix[*iter][v2]] < smallestEdgeVal ){
			smallestEdgeVal = m_edgeWeights[m_edgeNumberMatrix[*iter][v2]];
		}
	  }

	  if(m_adjMatrix[v1][v2] == 1) distArray[m_edgeNumberMatrix[v1][v2]] =1;
	  else centerVertex = *iter;
	  if(m_adjMatrix[v1][*iter] == 1) 
        { distArray[m_edgeNumberMatrix[v1][*iter]] = 1; }
	  else centerVertex = v2;
	  if(m_adjMatrix[v2][*iter] == 1) 
        { distArray[m_edgeNumberMatrix[v2][*iter]] = 1; }
	  else centerVertex = v1;
        bestObjValOfComp[compNo] = totalEdgeWeight;
	  if((*compIter).nEdges == 3) {
		distArray[m_edgeNumberMatrix[v1][v2]] = 2; 
		bestObjValOfComp[compNo] = totalEdgeWeight + smallestEdgeVal;
  	  }
/*
        (*compIter).yPosBest[v1] = m_nVertices;
        (*compIter).yPosBest[v2] = m_nVertices;
        (*compIter).yPosBest[*iter] = m_nVertices;
	  int diff = 1;
	  if(v1 != centerVertex) 
        { (*compIter).xPosBest[v1] = m_nVertices+diff; diff = -1; }
          else{ (*compIter).xPosBest[v1] = m_nVertices; }
	  if(v2 != centerVertex) 
        { (*compIter).xPosBest[v2] = m_nVertices+diff; diff = -1; }
          else{ (*compIter).xPosBest[v2] = m_nVertices; }
	  if(*iter != centerVertex) 
        { (*compIter).xPosBest[*iter] = m_nVertices+diff; }
          else{ (*compIter).xPosBest[*iter] = m_nVertices; }
*/
      }
	  
	  
    // case: component with > 3 vertices
    if((*compIter).nVertices >= 4){
    // (b) construct solution as far as possible:
    	int returnMaxDepth;
	   int result = 1;
       if( useTreeSearch ){
          result = m_startMainSearch(returnMaxDepth, *compIter, true);
		  if( result == -2 ) return -2;
	   }
	   else{
	      m_initializeSearchTree( *compIter );
	   }
	// (c) choose basis construction randomly:
       if(result != 0){
 	     int grid[2*(*compIter).nVertices+2][2*(*compIter).nVertices+2];
	     for(int i=0; i<2*(*compIter).nVertices+2; i++){
	       for(int j=0; j<2*(*compIter).nVertices+2; j++){
		     grid[i][j] = -1;
	       }
	     }                                 
        if(m_minMemoryMode){
           for(int i=0; i <= ((*compIter).mainTree)->m_nVerticesAlreadyDetermined-2; i++){
             int currentVertex = ((*compIter).mainTree)->m_vertexOrder[i];
             if((*compIter).bestPosInMinMemMode[2*i] != 2*m_nVertices +2 ){
               xPos[currentVertex] = (*compIter).bestPosInMinMemMode[2*i];
               yPos[currentVertex] = (*compIter).bestPosInMinMemMode[2*i+1];
		       grid[xPos[currentVertex]][yPos[currentVertex]] = currentVertex;
             }      
           }                
        
        }
        else{
	    int nPotStartNodes = (*compIter).mainTree->m_nodesOfTree[
          (*compIter).mainTree->m_nVerticesAlreadyDetermined -2
        ].size();
	    if(nPotStartNodes == 0) {return -1;}
	    int startNodeNumber = rand() % nPotStartNodes;
	    nodeIter = (*compIter).mainTree->m_nodesOfTree[
          (*compIter).mainTree->m_nVerticesAlreadyDetermined -2
        ].begin();
	    for(int i=0; i<startNodeNumber; i++) nodeIter++;
	    Node* currentNode = &(*nodeIter);
        
	// (d) initialize grid and basis construction:
	     for(int level=(*compIter).mainTree->m_nVerticesAlreadyDetermined-2; 
                                                           level >= 0; level--){
		  int currentVertex = (*compIter).mainTree->m_vertexOrder[level];
		  xPos[currentVertex] = currentNode->xCoordinate +(*compIter).nVertices - m_nVertices;
		  yPos[currentVertex] = currentNode->yCoordinate +(*compIter).nVertices - m_nVertices;
		  grid[xPos[currentVertex]][yPos[currentVertex]] = currentVertex;
		  currentNode = currentNode->pParent;
	     }
        }
        
	// (e) fix remaining vertices:
        (*compIter).mainTree->m_isTemporarilyForbiddenVertex 
          = (*compIter).isTemporarilyForbiddenVertex;
		int nextVertex = m_determineNextVertex(
          (*compIter).mainTree->m_nVerticesAlreadyDetermined-1, 
          (*compIter).mainTree
        );
	    for(unsigned i=(*compIter).mainTree->m_nVerticesAlreadyDetermined-1; 
                                          i<(*compIter).vertexList.size(); i++){
		nextVertex = m_determineNextVertex(i, (*compIter).mainTree);
		if(nextVertex == -1) {
		  return -1;
		}
       
		  double bestWeight = m_nVertices * m_maxDistAllowedInModel;
		  vector<int> bestXPos;
		  vector<int> bestYPos;
		  
		  list<int>::iterator iter;
		  for(int x = 0; x < 2*(*compIter).nVertices+2; x++){
		    for(int y = 0; y < 2*(*compIter).nVertices+2; y++){
				if(grid[x][y] == -1){
				    double currentWeight = 0.0;
				    for(iter = m_adjList[nextVertex].begin(); iter != m_adjList[nextVertex].end(); ++iter){
					   if( xPos[*iter] < (2 * m_nVertices + 2) ){
					     int diff = xPos[*iter] - x; 
						 if(diff < 0) diff = - diff;
						 int diff2 = yPos[*iter] - y;
						 if(diff2 < 0) diff2 = -diff2;
						 diff += diff2;
					     currentWeight += (m_edgeWeights[m_edgeNumberMatrix[nextVertex][*iter]] * (double)diff);
						 cout.precision(5);
					   }
					}
					double improval = currentWeight - bestWeight;
					if( improval < 0.0) improval = -improval;
					if( improval < 0.5){
					  bestXPos.push_back(x);
					  bestYPos.push_back(y);
					}
					else{
					  if( currentWeight < bestWeight - 0.1 ){
					    bestWeight = currentWeight;  
					    bestXPos.clear(); 
					    bestYPos.clear();
						bestXPos.push_back(x);
						bestYPos.push_back(y);
					  }
					}
		  
		    }
		  }
         }
		 int randNumber = rand() % (int)bestXPos.size();
		 int chosenX = bestXPos[randNumber]; 
		 int chosenY = bestYPos[randNumber];
		 grid[chosenX][chosenY] = nextVertex;
		 xPos[nextVertex] = chosenX; 
		 yPos[nextVertex] = chosenY; 
	   }
	  }
       else{ // embeddable
	    for(iter = (*compIter).vertexList.begin(); 
                                  iter != (*compIter).vertexList.end(); ++iter){
	      xPos[*iter] = (*compIter).xPos[*iter];
	      yPos[*iter] = (*compIter).yPos[*iter];
	    }
	   }
	// (f) update distance vector:
  	bestObjValOfComp[compNo] = 0;
	   for(iter = (*compIter).vertexList.begin(); 
                                  iter != (*compIter).vertexList.end(); iter++){
	     for(iter2 = m_adjList[*iter].begin(); 
                                      iter2 != m_adjList[*iter].end(); iter2++){
	       if(*iter < *iter2){
		     int dist = xPos[*iter] - xPos[*iter2];
		     if(dist < 0) dist = -dist;
		     int yDist = yPos[*iter] - yPos[*iter2];
		     if(yDist < 0) yDist = -yDist;
		     dist += yDist;
		     distArray[m_edgeNumberMatrix[*iter][*iter2]] = dist;
		     bestObjValOfComp[compNo] += (m_edgeWeights[m_edgeNumberMatrix[*iter][*iter2]] * dist);
		     if(dist > m_maxDistAllowedInModel) {
                    // Dist too large				
	               delete (*compIter).mainTree;
	                   m_heuristicIsCurrentlyActive = false;
                       return -1;
                     }
	       }
	     }
	   }
	   (*compIter).approximationFound = true;
	// (g) clean up:
	   delete (*compIter).mainTree;
    }
  }

  int totalDist = 0;
  double totalWeight = 0.0;
  if(    m_isTestForMaxDistance 
      && ( currentBestObjValue < -1 
           || currentBestObjValue 
            > m_maxDistAllowedInModel * m_nVertices * m_nVertices) ){
     currentBestObjValue = m_maxDistAllowedInModel * m_nVertices * m_nVertices;
   }
   for(int i=0; i<m_nEdges; i++) { totalDist += distArray[i]; totalWeight += (m_edgeWeights[i] * distArray[i]); }
   if (totalWeight < currentBestObjValue -0.001){
     compNo = -1;
     for(compIter = m_graphComponents.begin(); 
                               compIter != m_graphComponents.end(); compIter++){
       compNo++;
       (*compIter).bestObjVal = bestObjValOfComp[compNo];
       if((*compIter).nVertices >= 4){
         if(findMostAestheticSolution && createOutputFileAfterEveryImproval){
              m_findMostAestheticSolution(*compIter);

         }
         else{
           for(iter = (*compIter).vertexList.begin(); 
                                  iter != (*compIter).vertexList.end(); iter++){
	       (*compIter).xPosBest[*iter] = xPos[*iter];
	       (*compIter).yPosBest[*iter] = yPos[*iter];
//cout << *iter << ": " << xPos[*iter] << " " << yPos[*iter] << endl;
           }
         }
        } 
     }

     if(m_isTestForMaxDistance && createOutputFileAfterEveryImproval){
       m_calculateAndNormalizeSolution();
       m_createOutputFiles(-1.0);
     }

   //}
  }



//cout best dist vector
/*
  int coutSum = distArray[0];
  cout << "{" << distArray[0];
  for(int e=1; e<m_nEdges; e++){
	cout << "," << distArray[e];
	coutSum += distArray[e];
   }
  cout << "}" << coutSum << ":"<< endl;
  
*/
//end: cout best dist vector


  m_heuristicIsCurrentlyActive = false;
  return totalWeight;
}




double FeasibilityTest::m_dist( int u, int v, Component* comp, bool& error ){
 
  double result = 0.0;

  int x1 = comp->xPosBest[u];
  int x2 = comp->xPosBest[v];
  int y1 = comp->yPosBest[u];
  int y2 = comp->yPosBest[v];
  
  if(    x1 >= 2*m_nVertices+1 || x2 >= 2*m_nVertices+1 
      || y1 >= 2*m_nVertices+1 || y2 >= 2*m_nVertices+1 ){
	   error = true;
  }
  
  if( x1 >= x2 ) result += ( x1 - x2 );
  else result += ( x2 - x1 );
  if( y1 >= y2 ) result += ( y1 - y2 );
  else result += ( y2 - y1 );

  return m_edgeWeights[ m_edgeNumberMatrix[u][v] ] * result;  
}

double FeasibilityTest::m_improve( bool& abort ){

  list<Component>::iterator compIter;
  list<int>::iterator it, it2;	
  
  for(compIter = m_graphComponents.begin(); compIter != m_graphComponents.end();
                                                                    compIter++){   

																	
	double bestIncrease = -1;
    int bestU = -1;
    int bestV = -1;
    bool improvementFound = false;
	if ( (*compIter).nVertices >= 4 && (*compIter).approximationFound ){
	  vector<int> nodes;
	  for( it = (*compIter).vertexList.begin(); it != (*compIter).vertexList.end(); ++it ){
	     nodes.push_back(*it);	 
	  }  
	  bool error = false;
	  for( int i=0; i<(int)nodes.size()-1; i++){
	    for( int j=i+1; j<(int)nodes.size(); j++ ){
		   int u = nodes[i];
		   int v = nodes[j];
	       double valBeforeSwitch = 0.0;
		   for( it2 = m_adjList[u].begin(); it2 != m_adjList[u].end(); ++it2 ){
		     if ( *it2 != v ){
			    valBeforeSwitch += m_dist( u, *it2, &(*compIter), error );
			 }
		   }
		   for( it2 = m_adjList[v].begin(); it2 != m_adjList[v].end(); ++it2 ){
		     if ( *it2 != u ){
			    valBeforeSwitch += m_dist( v, *it2, &(*compIter), error );
			 }
		   }
	       double valAfterSwitch = 0.0;
		   for( it2 = m_adjList[u].begin(); it2 != m_adjList[u].end(); ++it2 ){
		     if ( *it2 != v ){
			    valAfterSwitch += m_dist( v, *it2, &(*compIter), error );
			 }
		   }
		   for( it2 = m_adjList[v].begin(); it2 != m_adjList[v].end(); ++it2 ){
		     if ( *it2 != u ){
			    valAfterSwitch += m_dist( u, *it2, &(*compIter), error );
			 }
		   }
			    if( error ){
				  abort = true;
				  return -1;
				}		   
		   if( valAfterSwitch < valBeforeSwitch - 0.001 ){
		      if( bestIncrease < ( valBeforeSwitch - valAfterSwitch ) - 0.001 ){
			     bestU = u;
				 bestV = v;
				 improvementFound = true;
				 bestIncrease = valBeforeSwitch - valAfterSwitch;
			  }
		   }
		   
		} // for j
	  } // for i 

	  if( improvementFound ){
	     int helpX = (*compIter).xPosBest[ bestU ];
	     int helpY = (*compIter).yPosBest[ bestU ];	  
		 (*compIter).xPosBest[ bestU ] = (*compIter).xPosBest[ bestV ];
		 (*compIter).yPosBest[ bestU ] = (*compIter).yPosBest[ bestV ];	
		 (*compIter).xPosBest[ bestV ] = helpX;
		 (*compIter).yPosBest[ bestV ] = helpY;
         (*compIter).bestObjVal -= bestIncrease;
		 compIter--;
	  }
	
	} // if approximation found

   } // component loop	


  double returnVal = 0.0;
  for(compIter = m_graphComponents.begin(); compIter != m_graphComponents.end();
                                                                    compIter++){   
     returnVal += (*compIter).bestObjVal;
  }
  
  return returnVal;
}







bool FeasibilityTest::m_createOutputFiles(double lowerBound){
  bool abort = false;
  m_improve( abort );

  if( lowerBound > -1.1 && lowerBound < -0.9 ){
     lowerBound = 0.0;
	 for( int i=0; i<m_nVertices-1; i++ ){
	    for( int j=i+1; j<m_nVertices; j++ ){
           if( m_adjMatrix[i][j] == 1 ) lowerBound += m_edgeWeights[ m_edgeNumberMatrix[i][j] ];
        }
	 }
  }  
  
  list<Component>::iterator comp;   
  
  int compNumber = 0;
  if(lowerBound > m_bestLowerBound + 0.001){m_bestLowerBound = lowerBound;}
  double guarantee;
  if(    m_bestLowerBound > 0.001 
      && m_bestApproximationValue != -1){
         guarantee = 100 * (m_bestApproximationValue - m_bestLowerBound) / m_bestLowerBound;
  }
  else{guarantee = -1.0;}
  if(lowerBound > -2.1 && lowerBound < -1.9){  // if matrix is zero matrix
      guarantee = 0.0;          
  }
  
  for(comp = m_graphComponents.begin(); comp!=m_graphComponents.end(); ++comp){
    compNumber++;
    char compNumberChar[10];
    sprintf(compNumberChar, "%d", compNumber);

    // Compose file name:
    char outSuffix[25] = "";
    if(m_graphComponents.size() > 1) { 
	strcat(outSuffix, ".component"); 
	strcat(outSuffix, compNumberChar);
    }
    strcat(outSuffix, ".out");
    const char* outSuffixConst = outSuffix;
    char outputFileName[500] = "";
    strcat(outputFileName, m_graphFile);
    strcat(outputFileName, outSuffixConst);

    // Compose file content:
    string out;
    out = out += "2D Grid Arrangement Solver v.1.0, ";
    out = out += "(c) 2009 University of Heidelberg\nSolution value: ";
    if(m_graphComponents.size() > 1){
      out = out += "Component ";
      out = out += compNumberChar;
      out = out += ": ";
    }
    if(! (*comp).approximationFound ){
      out = out+= "none";
    }
    else{
      char optChar[10];
      sprintf(optChar, "%e", (*comp).bestObjVal);
      out = out += optChar;
      if(m_approximationFound){
        out = out += ", Total: ";
        char totalOptChar[10];
        sprintf(totalOptChar, "%e", m_bestApproximationValue);
        out = out += totalOptChar;
      }
    }
    
    out = out += "\nMax. allowed distance between adjacent vertices: ";
    char maxDist[10];
    sprintf(maxDist, "%d", m_maxDistAllowedInModel);
    out = out += maxDist;
  
    out = out += "\n";
    if(guarantee > 0.001 && guarantee < 98.999){
    char guaranteeChar[10];
    sprintf(guaranteeChar, "%d", (int)guarantee+1);
    out = out += guaranteeChar;
    out = out += " % (0 % = opt)";
    }
    else{
      if( ( guarantee >= -0.001 && guarantee <= 0.001 ) ){
        out = out += "optimum";
      }
      else{
        out = out += "none";
      }
    }
    out = out += " is the solution guarantee";	
    if(m_graphComponents.size() > 1){
      out = out += " (all components)";
    }

	
	
    out = out += "\nSyntax: Vertex-ID x-coordinate y-coordinate\n";
    if((*comp).approximationFound){
      list<int>::iterator iter;
      for(iter=(*comp).vertexList.begin(); 
                                       iter!=(*comp).vertexList.end(); ++iter){
          char numbers[20];
          sprintf(numbers, "%d %d %d", 
                      *iter, (*comp).xPosBest[*iter], (*comp).yPosBest[*iter]);
	  out = out += numbers;
          out = out += "\n";
      }
    }
    else{
      out = out += "-1\n";
    }
    
    // Create file:
  ofstream outfile;
  outfile.open(outputFileName,ios::out);
  if(!outfile.fail()){
    outfile << out << endl;
    outfile.close();
  }
  else{cout << "Error during creation of solution output files!";}
  
   
  // Create Grid Breaking Tree Info Output File
/*	
		int q = (int)m_bestApproximationValue - m_nEdges;
		// cout << "q = " << (int)m_bestApproximationValue << " - " << m_nEdges << " = " << q << endl;
		if( q != 0 ){
			//compose output file name
		    char treeSuffix[25] = "";
			strcat(treeSuffix, ".tree"); 
			const char* treeSuffixConst = treeSuffix;
			char qChar[10];
			sprintf(qChar, "%d", q);
			const char* qCharConst = qChar;
			
			char treeFileName[500] = "";		
			strcat(treeFileName, m_graphFile);
			strcat(treeFileName, "_");
			strcat(treeFileName, qCharConst);	
			strcat(treeFileName, treeSuffixConst);
					
			// explore structure of 4-grid-breaking tree
			list<int>::iterator iter, iter2;
			int nNeighDeg2 = 0;
			int root = 0;
			for(iter = m_adjList[0].begin(); iter != m_adjList[0].end(); ++iter){
				if( m_adjList[*iter].size() >= 2 ) nNeighDeg2++; 
			}
			if( nNeighDeg2 == 1 && m_adjList[0].size() == 1 ){
				iter = m_adjList[0].begin();
				root = *iter;
// cout << "new root: " << *iter << endl;
			}
			if( nNeighDeg2 == 1){
				int newRoot = -1;
				for( iter2 = m_adjList[root].begin(); iter2 != m_adjList[root].end(); ++iter2){
// cout << "in the loop of " << root << ": " << *iter2 << endl;
					if( m_adjList[*iter2].size() >= 2 ) newRoot = *iter2;
				}
				if( newRoot != -1 ) root = newRoot;
 			}
			// cout << "root = " << root << endl;
			
			list<int> neighDegrees;
			for( iter = m_adjList[root].begin(); iter != m_adjList[root].end(); ++iter ){
				neighDegrees.push_back( m_adjList[ *iter ].size() );
			}
			neighDegrees.sort();
			
			
			// Create file:
			ofstream treefile;
			treefile.open(treeFileName,ios::out);
			if(!treefile.fail()){
				treefile << m_adjList[ root ].size() << " ";
				for( iter = neighDegrees.begin(); iter != neighDegrees.end(); ++iter ){
					treefile << *iter << " ";
				}
				treefile << endl;
				treefile.close();
			}

					
			// explore structure of 5-grid-breaking tree
			list<int>::iterator iter, iter2;
			list<int> neighDegrees;
			list<int> tree5Degrees;
			int tree5root = 0;
			
			for(iter = m_adjList[0].begin(); iter != m_adjList[0].end(); ++iter){
				neighDegrees.push_back( m_adjList[*iter].size() );
				if( tree5root < *iter ) tree5root = *iter;
			}
			for(iter = m_adjList[ tree5root ].begin(); iter != m_adjList[ tree5root ].end(); ++iter){
				if( *iter != 0 ) tree5Degrees.push_back( m_adjList[ *iter ].size() );
			}			
			tree5Degrees.sort();
			
			
			
			// Create file:
			ofstream treefile;
			treefile.open(treeFileName,ios::out);
			if(!treefile.fail()){
				//treefile << m_adjList[ root ].size() << " ";
				for( iter = neighDegrees.begin(); iter != neighDegrees.end(); ++iter ){
					treefile << *iter << " ";
				}
				treefile << " - ";
				for( iter = tree5Degrees.begin(); iter != tree5Degrees.end(); ++iter ){
					treefile << *iter << " ";
				}				
				treefile << endl;
				treefile.close();
			}					
		}
 */	
  
  } // next component
  return true;
}

int FeasibilityTest::solve(list<int>& nNonZeros, list<int>& nonZeroCoeff, 
                list<int>& nonZeroVariables, list<int>& rhs, double lowerBound){

  if(m_errorOccured){return -1;}
  if(m_nVertices == 0){return 0;}
  bool wasSolutionImproved = false;
  if(lowerBound > m_bestLowerBound + 0.001){ 
                wasSolutionImproved = true; 
                m_bestLowerBound = lowerBound;
  }
  if(highOutputLevel){
    cout << "|------------- Feasibility Test ---------------" << endl;
    cout << "| Test no. " << m_nCplexSolutionTests << endl;
    cout << "| Performing Triangle Check... "; 
  }

  // bool wasSetFound = m_separateOddTriangles();
  bool wasSetFound = false;

   if(highOutputLevel){cout << "done" << endl;}
  if(wasSetFound){ 
    m_calcOutputInequalitiesFromConflictSets(
       nNonZeros,nonZeroCoeff,nonZeroVariables,rhs
    );
    if(highOutputLevel){ 
      cout << "| # calculated cuts:\t" << m_nCuts << endl; 
      cout << "|----------------------------------------------" << endl <<endl;
    }
    return 1;
  }
  else{
    int nComponentsStillActive = 0;
    list<Component>::iterator compIter;
    for(compIter = m_graphComponents.begin(); 
                               compIter != m_graphComponents.end(); ++compIter){
       if((*compIter).isStillActive){    
           nComponentsStillActive++;
      }
    }
    int componentCounter = 0;
    for(compIter = m_graphComponents.begin(); 
                               compIter != m_graphComponents.end(); ++compIter){
      componentCounter++;
      if(componentCounter==1){
		if(highOutputLevel){
			cout<<"| Performing Main Embeddability Test... \n";
		}
	  }
      if((*compIter).isStillActive){
        int returnMaxConflictSetSize;
        int nNewConflictSets;
          if((*compIter).nVertices > 3){
            if(highOutputLevel){
              cout << "|   --> component " << componentCounter;
              cout << " (" << (*compIter).nVertices << ")...\t ";
            }
            nNewConflictSets = m_startMainSearch(
                   returnMaxConflictSetSize,*compIter,returnSingleCuttingPlane);
          }
          else{
            if(highOutputLevel){
              cout << "|   --> component " << componentCounter << " (";
              cout << (*compIter).nVertices << ")...\t ";
            }
            nNewConflictSets = m_solveComponentWithAtMost3Vertices(*compIter);
          }
          if( nNewConflictSets == -2 ) return -2;
          if(nNewConflictSets == 0){
	    bool check = true; 
                 //= m_compareGridPositionsWithDistMatrixEntries(*compIter);
	    if(!check)
              {cout << "Internal Error! Calculated positions are incorrect!\n";}
            if(highOutputLevel) cout << "feasible." << endl;
            if(m_currentObjVal(*compIter) < (*compIter).bestObjVal){
                 wasSolutionImproved = true;
	         (*compIter).bestObjVal = m_currentObjVal(*compIter);
                 if(findMostAestheticSolution){m_findMostAestheticSolution(*compIter);}
                 else{
	           for(int i=0; i<m_nVertices;i++){
                    (*compIter).xPosBest[i] = (*compIter).xPos[i];
	            (*compIter).yPosBest[i] = (*compIter).yPos[i];
	           }
	         }
	        }
	        nComponentsStillActive--;
          }
          else{
            if(highOutputLevel) cout << "infeasible." << endl;
            if((*compIter).nVertices > 3){
              if(highOutputLevel) cout << "|        --> reduction... ";
              int maxConflictSetSize = returnMaxConflictSetSize;
              if(!m_minMemoryMode) {
                int resultReduceConflictSet = m_reduceConflictSet(
                  nNewConflictSets,maxConflictSetSize,*compIter
                );
				if( resultReduceConflictSet == -2 ) return -2;
                if(useEdgeMinimization){
                  m_edgeReduceVertexConflictSet(*compIter);
                }
              }
              if(highOutputLevel) cout << "done." << endl;  
            } 
          }
          if((*compIter).nVertices > 3){
              (*compIter).oldStartVertices = (*compIter).startVertices;
              delete (*compIter).mainTree;   
          }
      }
    }

    if(wasSolutionImproved && createOutputFileAfterEveryImproval){
       m_calculateAndNormalizeSolution();
       m_createOutputFiles(lowerBound);
    }
   
    if(nComponentsStillActive == 0){
       if(highOutputLevel) cout << "|----------------------------------------------" << endl <<endl;
       return 0;
    }
    else{
	// calculate output inequalities
	   nNonZeros.clear();
	   nonZeroCoeff.clear();
	   nonZeroVariables.clear();
	   rhs.clear();
       m_calcOutputInequalitiesFromConflictSets(
         nNonZeros,nonZeroCoeff,nonZeroVariables,rhs
       );  
       if(useEdgeMinimization){
         m_calcOutputInequalitiesFromEdgeConflictSets(
           nNonZeros,nonZeroCoeff,nonZeroVariables,rhs
       );                                 
       }
       if(highOutputLevel) cout << "|----------------------------------------------" << endl <<endl;
       return 1;   
    }
  }
}
