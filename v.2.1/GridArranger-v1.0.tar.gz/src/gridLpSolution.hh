////////////////////////////////////// c++ /////////////////////////////////////
//
//  Module           : gridLpSolution.hh
//  Description      :
//  Author           : Marcus Oswald
//  Email            : Marcus.Oswald@informatik.uni-heidelberg.de
//  Copyright        : University of Heidelberg
//  Created on       : Wed Jul  3 14:39:38 2002
//  Last modified by : oswald
//  Last modified on : Wed Jul  3 14:51:55 2002
//  Update count     : 5
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date	Name		Changes/Extensions
//  ----	----		------------------
//
////////////////////////////////////////////////////////////////////////////////

#ifndef LAP_LP_SOLUTION_HH
#define LAP_LP_SOLUTION_HH

#include "abacus/lpsolution.h"
#include "gridMaster.hh"

class ABA_VARIABLE;
class ABA_CONSTRAINT;

/**
 * This class stores an LP-Solution.
*/
class GridLpSolution:public  ABA_LPSOLUTION<ABA_VARIABLE,ABA_CONSTRAINT>{

public:
    GridLpSolution(ABA_MASTER *master,int nVar, double *xVal); 
    ~GridLpSolution();
    
    friend ostream&operator<<(ostream &os, const GridLpSolution &rhs);
    
    GridMaster *gridMaster() const {return (GridMaster*)master_;};
    
    void print(ostream&out);

private:
    //int m_nNodes;
    //int m_nEdges;

    
};
#endif

