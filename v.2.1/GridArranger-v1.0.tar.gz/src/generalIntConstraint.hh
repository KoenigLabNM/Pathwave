////////////////////////////////////// c++ /////////////////////////////////////
//
//  Module           : generalIntConstraint.hh
//  Description      :
//  Author           : Dino Ahr & Marcus Oswald & Gerhard Reinelt & Klaus Wenger
//  Email            : {Dino.Ahr|Marcus.Oswald|Gerhard.Reinelt|Klaus.Wenger}@informatik.uni-heidelberg.de
//  Copyright        : University of Heidelberg
//  Created on       : Thu Jul  4 17:00:40 2002
//  Last modified by : wiesberg
//  Last modified on : Wed Feb 03 2010
//  Update count     : 2
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date	Name		Changes/Extensions
//  ----	----		------------------
// Feb 3 2010   wiesberg        The sense of the constraint ('<=', '>=' or '=')
//				is now given to the constructor.
////////////////////////////////////////////////////////////////////////////////



#ifndef GENERAL_INT_CONSTRAINT_HH
#define GENERAL_INT_CONSTRAINT_HH

#include "abacus/constraint.h"
#include "abacus/row.h"

/**
 * This class realizes a genaeral constraint-class, derived from
 * ABA_CONSTRAINT. The constraint is determinated by an array of variables
 * and an array of coefficients and a right-hand-side.
*/
class GeneralIntConstraint:public ABA_CONSTRAINT{
public:

  /**
   * Constructor.
   *
   * @param master Pointer to the master-problem.
   * @param nVars The total number of variables with nonzero coefficient in the constraint.
   * @param rhs The right-hand-side of the constraint.
   * @param vari The indices of the variables with nonzero coefficient in the constraint.
   * @param coef Array of the coefficients.
   */
  GeneralIntConstraint(ABA_MASTER*master, int nVars, int rhs, int* vari, int* coef, ABA_CSENSE::SENSE, bool isDynamic);
  ~GeneralIntConstraint();

  /**
   * Returns the coefficient of the variable v in the constraint.
   *
   * @param v variable of type EdgeVariable derived from ABA_VARIABLE.
   */
  virtual double coeff(ABA_VARIABLE*v);

  /**
   * Generating the whole row of the constraint in a sparse format.
   *
   * @param row Sparse row to be generated.
   */
  virtual int genRow(ABA_ACTIVE<ABA_VARIABLE,ABA_CONSTRAINT> *, ABA_ROW &row);

  virtual const char *name();
  virtual unsigned hashKey();
    virtual bool equal(ABA_CONVAR *cv);

    int nVars(){return m_nVars;};
    int vari(int i){return m_vari[i];};
    int coef(int i){return m_coef[i];};
    int rhsInt(){return m_rhsInt;};

private:
  int  m_nVars;
  int* m_vari;
  int* m_coef;
  int  m_rhsInt;

GeneralIntConstraint(const GeneralIntConstraint&rhs);
const GeneralIntConstraint&operator= (const GeneralIntConstraint&rhs);
};

#endif  

