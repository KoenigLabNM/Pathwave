////////////////////////////////////// c++ /////////////////////////////////////
//
//  Module           : FeasibilityTree.cpp
//  Description      : This class represents a tree structure which will contain
//                     the set possible grid embeddings of a set of vertices V
//                     with distance matrix D.
//  Author           : Stefan Wiesberg
//  Email            : stefan.wiesberg@gmx.de
//  Copyright        : University of Heidelberg, Germany
//  Created on       : Wed Feb 03 2010
//  Last modified by : 
//  Last modified on : 
//  Update count     : 0
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date	Name		Changes/Extensions
//  ----	----		------------------
//
////////////////////////////////////////////////////////////////////////////////

#include "FeasibilityTree.hpp"
using namespace std;

// Constructor:
FeasibilityTree::FeasibilityTree(Node root, int maxDepth, int nVertices) {
  m_root = root;
  m_nil.ID = -1;
  m_currentTreeDepth = 0; //edges
  //m_collectNewInfoForFastOrdering = true;
  m_nVerticesAlreadyDetermined = 1;
  list<Node> list1;
  list1.push_back(root);
  m_nodesOfTree.push_back(list1);
  list<Node> emptyList;
  for(int i=1; i<maxDepth; i++){
     m_nodesOfTree.push_back(emptyList);
  }
  for(int i=0; i<nVertices; i++){
     m_positionOfVertexInOrdering.push_back(-1);
     m_closeVertexAlreadyFixed.push_back(-1);
     m_nNeighboursAlreadyFixed.push_back(-1);
     m_isTemporarilyForbiddenVertex.push_back(false);
  } 
}
