////////////////////////////////////// c++ /////////////////////////////////////
//
//  Module           : FeasibilityTree.hpp
//  Description      : This class represents a tree structure which will contain
//                     the set possible grid embeddings of a set of vertices V
//                     with distance matrix D.
//  Author           : Stefan Wiesberg
//  Email            : stefan.wiesberg@gmx.de
//  Copyright        : University of Heidelberg, Germany
//  Created on       : Wed Feb 03 2010
//  Last modified by : 
//  Last modified on : 
//  Update count     : 0
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date	Name		Changes/Extensions
//  ----	----		------------------
//
////////////////////////////////////////////////////////////////////////////////

using namespace std;
#include<list>
#include<vector>
#ifndef TREE_HH_
#define TREE_HH_

/**
* A node within the search tree of the feasibility test. The information stored
* in this structure covers position of the node, coordinates of the represented
* graph vertex, and information on the symmetry. The node ID is set to -1 iff
* the node represents the nil node and values greater than 0 otherwise.
*/
struct Node {
       int ID;
/**
* Pointer to parental node
*/
       Node* pParent; 
/**
* Pointer to left child node or NIL
*/
       Node* pLeftChild;
/**
* Pointer to right brother node or NIL
*/
       Node* pRightBrother;
/**
* Horizontal grid coordinate of the represented vertex 
*/       
       int xCoordinate;
/**
* Vertical grid coordinate of the represented vertex 
*/          
       int yCoordinate;
/**
* If "true", the fixation represented by the node allows for symmetrical 
* extensions. In this case, from the set of symmetrical extensions only a single
* representative is created. If no symmetrical extensions are possible anymore,
* the variable is set to "false". 
*/ 
       bool isSymmetryCheckNeeded;     
};

typedef list<Node> nodeList;

/**
 * This class represents a tree structure which will contain the set possible 
 * grid embeddings of a set of vertices V with distance matrix D. Its methods 
 * are able to test whether an embedding of V on g exists.
 * Every node of the tree contains a pointer to (1) its parental node, (2) its
 * left child and (3) its right brother (the number of children is not limited). 
*/
class FeasibilityTree {

// ------------------------------
// -------- public --------------
// ------------------------------
  public:


/**
 * Constructor
 */ 
   FeasibilityTree(Node root, int maxDepth, int nVertices);
/**
* The root node of the tree.
*/
   Node m_root;
/**
* A nil node, i.e. a node which is not contained in the tree and to which 
* pointers can be set if no pointer target exists. 
*/
   Node m_nil;
/**
* The ID counter can be incremented every time a new node is added to the tree.
* This way, every node gets a new and unique ID.
*/  
   int m_IDCounter;
/**
* This vector contains node lists and thus the "tree" itself. The list at 
* position i contains the nodes of height i in the tree, read from left to 
* right. Thus, m_nodesOfTree[0] exclusively contains the root node.
*/             
   vector<nodeList> m_nodesOfTree;
/**
* The height (or depth) of the tree measured in the number of edges. That is,
* a tree consisting exclusively of the root node gets height 0, a tree
* consisting of the root and its children gets height 1...
*/
   int m_currentTreeDepth;
/**
* The order in which the graph vertices are fixed in the tree. If
* m_vertexOrder[i] = j, then graph vertex j is the i-th vertex to be fixed.
* Thus the nodes of height i in the tree represent the positions of vertex
* m_vertexOrder[i].
*/
  vector<int> m_vertexOrder;
/**
* Inverse function to m_vertexOrder. If m_positionOfVertexInOrdering[i] = j,
* then graph vertex i is the j-th vertex to be fixed in the tree.
*/
  vector<int> m_positionOfVertexInOrdering;
/**
* The successive fixation of the graph vertices on the grid requires an ordering
* of the vertices. This integer gives the size of the current ordering.
*/
  int m_nVerticesAlreadyDetermined;
/**
* m_closeVertexAlreadyFixed[i] contains a vertex which was already fixed on the
* grid during the feasibility test and which has a small distance to i in the
* distance matrix.
*/
  vector<int> m_closeVertexAlreadyFixed;
/**
* A help variable. In the method FeasibilityTest::m_determineNextVertex, 
* vertices with a greater number of graph neighbours already fixed are 
* preferred. m_nNeighboursAlreadyFixed[i] contains the number for vertex i.
*/
  vector<int> m_nNeighboursAlreadyFixed;
/**
* A help variable. In the method FeasibilityTest::m_determineNextVertex, 
* the next vertex to be fixed is chosen from this list of candidates.
*/
  list<int> m_candidatesForNextVertexList;
/**
* A help variable. In the method FeasibilityTest::m_determineNextVertex, 
* the next vertex to be fixed is chosen from this list of candidates.
*/
  list<int> m_candidatesPhase2;
/**
* If m_isTemporarilyForbiddenVertex[i] == true, then vertex i is forbidden. That
* is, it cannot be fixed on the grid. Possible reason: i is in another graph
* component. In the method FeasibilityTest::m_determineNextVertex, only 
* un-forbidden vertices are considered.
*/
  vector<bool> m_isTemporarilyForbiddenVertex;


// ------------------------------
// -------- private--------------
// ------------------------------
  private:
          
};

#endif /*TREE_HH_*/
