///////////////////////////////// C++ /////////////////////////////////////////
//
//  Module           : hypSep.hh
//  Description      : Defines a separator for hypermetric inequalities.
//  Author           : Thorsten Bonato
//  Email            : thorsten.bonato@informatik.uni-heidelberg.de
//  Copyright        : University of Heidelberg
//  Created on       : 06.12.2011
//  Last modified by :
//  Last modified on :
//  Update count     :
//
///////////////////////////////////////////////////////////////////////////////
//
//  Date    Name        Changes/Extensions
//  ----    ----        ------------------
//
///////////////////////////////////////////////////////////////////////////////


#ifndef HYP_SEP_HH
#define HYP_SEP_HH

#include <vector>
#include "SparseConstraint.hh"


using namespace std;


//
// h y p e r m e t r i c S e p a r a t o r
//
/**
 * This function tries to generate a violated hypermetric inequality.
 *
 * @param n        Number of nodes in the graph.
 * @param maxgen   Maximum number of inequalities to be generated.
 * @param minViol  Required minimum violation of a separating inequality.
 * @param lpVal    Array storing the LP values of the edges.
 * @param buffer   Reference to vector storing pointers to the generated
 *                 inequalities.
 */
void hypermetricSeparator( int     n,
                           int     maxgen,
                           double  minViol,
                           double* lpVal,
                           vector< SparseConstraint<int>* >& buffer );

#endif // HYP_SEP_HH
