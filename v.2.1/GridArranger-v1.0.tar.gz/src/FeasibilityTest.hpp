////////////////////////////////////// c++ /////////////////////////////////////
//
//  Module           : FeasibilityTest.hpp
//  Description      : The methods of his class is able to test whether a given 
//                     distance matrix D (partially given) is embeddable on a 
//                     2-dimensional grid. If possible, the absolute coordinates
//                     are returned. If there is no such embedding, problematic
//                     submatrices of minimum size are determined and returned,
//                     enabling the construction of cutting planes in a branch-
//                     and-cut algorithm.
//  Author           : Stefan Wiesberg
//  Email            : stefan.wiesberg@gmx.de
//  Copyright        : University of Heidelberg, Germany
//  Created on       : Wed Feb 03 2010
//  Last modified by : 
//  Last modified on : 
//  Update count     : 0
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date	Name		Changes/Extensions
//  ----	----		------------------
//
////////////////////////////////////////////////////////////////////////////////

#include"iostream"
#include "FeasibilityTree.hpp"
#include "gridMaster.hh"
#include<vector>
#include<list>
#include <algorithm>
#include <fstream>
#include <cstring>
#include <string>
using namespace std;

#ifndef FEASIBILITYTEST_HH_
#define FEASIBILITYTEST_HH_

typedef vector<int> intVector;
typedef list<int> intList;
typedef vector<intList> vectorOfLists;

/**
* This structure represents a (maximally chosen) connectivity component 
* of the given graph. 
*/
struct Component {
/**
* If "false", the component isn't handled anymore by the feasibility test.
*/
   bool isStillActive;
/**
* Was a solution found (not necessarily optimal) during the calculations?
* The value is set at the very end of the optimization in the method
* m_calculateAndNormalizeSolution .
*/
   bool approximationFound;

/**
* Number of vertices in this graph component.
*/
   int nVertices; 
/**
* Number of edges in this graph component.
*/
   int nEdges;
/**
* List of the vertex ID numbers. Its size equals nVertices.
*/
   list<int> vertexList;
/**
* If isTemporarilyForbiddenVertex[i] == true, then vertex i is forbidden. That
* is, it cannot be fixed on the grid. Possible reason: i is in another graph
* component. In the method FeasibilityTest::m_determineNextVertex, only 
* un-forbidden vertices are considered.
*/
   vector<bool> isTemporarilyForbiddenVertex;
/**
* The main search tree of the feasibility test.
*/   
   FeasibilityTree* mainTree; 
/**
* The current x-coordinates at the current position within the main tree.
*/
   vector<int> xPos;
/**
* The current y-coordinates at the current position within the main tree.
*/
   vector<int> yPos;
/**
* The x-coordinates of the best solution found so far.
*/
   vector<int> xPosBest;
/**
* The y-coordinates of the best solution found so far.
*/
   vector<int> yPosBest;

/**
* When the Feasibility Test runs in Min-Memory-Mode, subtrees of the
* depth-first-search tree are deleted as soon as possible. In this case,
* the best vertex positions are stored in the following vector. Entries 2i and
* 2i+1 give the positions of the i-th vertex' x- and y-coordinate in the order
* of fixation.
*/   
   vector<int> bestPosInMinMemMode;
   
/**
* The best objective function value that was found so far for this component.
*/
   double bestObjVal;
/**
* The 2 or 4 vertices to be fixed first. 
*/
   list<int> startVertices;
/**
* Copy of the startVertices.
*/ 
   list<int> oldStartVertices;
/**
* A list of the triangles in this graph component. Entry i, i+1 and i+2 give
* the triangles' vertices for i=0,3,6,...,3*k. 
*/
   list<int> trianglesInGraph;
/**
* A list of the 4-cliques (complete subgraphs with 4 vertices) in this graph 
* component. Entry i, i+1, i+2 and i+3 give the cliques' vertices for 
* i=0,4,8,...,4*k. 
*/   
   list<int> fourCliquesInGraph;
/**
* A list of the 5-cycles in this graph component. Entry i, i+1, ..., i+4
* give the cycles' vertices for i=0,5,10,...,5*k. 
*/      
   list<int> fiveCyclesInGraph;
/**
* A list of the maximum cliques in this graph component, i.e. cliques which 
* are not included in larger cliques (except of themselves). The number of
* vertices of the clique is followed by its vertices. For example, the list
* "3 1 4 5 4 3 2 4 1" encodes two cliques of size 3 (vertices 1, 4, 5) and 4.
*/
   list<int> maxCliquesInGraph;
   // vector<int> oldVertexOrder;                                               !!!
   // vector<int> oldPositionOfVertexInOrdering;

/**
* Helps during the construction of the main search tree. If entry i is "true", 
* then a node with coordinates (i, f(i)) has already been created, so a node
* with coordinates (i, -f(i)) does not have to be created for symmetry reasons.
*/   
   vector<bool> isSymPartnerAlreadyCreated;
/**
* A list of the current conflict sets (unembeddable submatrices of the distance
* matrix). The number of vertices in the problematic subset is followed by the 
* vertex IDs. 
*/
   list<int> currentConflictSets;
/**
* If an embedding of the graph component was found, this list contains the 
* coordinates of the components' vertices. The coordinates are ordered by
* increasing vertex ID-number, alternating x- and y-coordinates: For example
* x(0), y(0), x(1), y(1), x(3), y(3), ...
*/
   list<int> solution;
};


/**
* The methods of the test are able to test whether a given distance matrix
* is embeddable on a 2-dimensional grid. 
*/
class FeasibilityTest {

  public:

// -----------------------------------------------------------------------
// Constructor -----------------------------------------------------------
// -----------------------------------------------------------------------

/**
* The constructor reads and checks the graph file specified by the user,
* initializes the basic data for the feasibility tests, scans the graph for
* triangles, 4-cliques, 5-cycles and maximum cliques, calculates the maximum
* distance for adjacent nodes. 
* \param graphFile  The path and name of the text file containing the graph to
* be embedded, e.g.  "/home/user/graphs/matrix1.txt" 
*/
 FeasibilityTest(char* graphFile);
 

// -----------------------------------------------------------------------
// Data Members ----------------------------------------------------------
// -----------------------------------------------------------------------

// -----------------------------
// General Data ----------------
// -----------------------------
/**
* Is set to "true" if an error occures during the initialization.
*/
          bool m_errorOccured;
/**
* Total number of calls of the "solve" method.
*/
          long int m_nCplexSolutionTests;
/**
* Number of cuts calculated in the current test.
*/          
          long int m_nCuts;
/**
* Total number of cuts calculated in all feasibility tests.
*/    
          long int m_nCutsTotal;
/**
* The maximum distance two adjacent vertices are allowed to have on the grid.
*/    
          int m_maxDistAllowedInModel;

/**
* If true, the depth-first-search immediately deletes all nodes which are not
* needed anymore. This will slow down the minimization process afterwards.
*/
         bool m_minMemoryMode;

/**
* If true, the heuristic is currently applied to determine the maximum distance
* allowed for adjacent vertices. 
*/
         bool m_isTestForMaxDistance;
         
/**
* If true, the heuristic is currently running.
*/         
         bool m_heuristicIsCurrentlyActive;

// -----------------------------
// Separation ------------------
// -----------------------------

/**
* Separates star inequalities.
* \param cuts In this list the calculated cutting planes are encoded. The number
* of non-zero coefficients is followed by the non-zero variables. The right-
* hand sides are calculated externally by ABACUS. The list is cleared at the
* beginning of every separation.
* \param sol The fractional lp-solution to be separated. Entry sol[i] stores the
* value of the i-th edge in the standard enumeration.
* \param maxNOfCuts The separation is aborted if maxNOfCuts cutting planes were
* found. 
* \return True if cutting planes were found, false otherwise.
*/
	  bool m_separateStarInequalities(
        list<int>& cuts, double* sol, int maxNOfCuts);
          //bool m_separateIntStarInequalities();
		  
		  
		  
		  
	int m_separateHypermetricInequalities( ABA_BUFFER<ABA_CONSTRAINT*>* newConstraint, ABA_MASTER* master, ABA_SUB* gridSub, double* LPsol);	  
		  
		  
		  
		  
/**
* Separates triangle inequalities. Parameters and return value are analogous
* to m_separateStarInequalities.
*/
	  bool m_separateTriangleInequalities(
        list<int>& cuts, double* sol, int maxNOfCuts);
/**
* Separates monotony inequalities. Parameters and return value are analogous
* to m_separateStarInequalities.
*/
	  bool m_separateMonotonyInequalities(
        list<int>& cuts, double* sol, int maxNOfCuts);
/**
* Separates 5-cycle inequalities. Parameters and return value are analogous
* to m_separateStarInequalities.
*/
	  bool m_separateFiveCycleInequalities(
        list<int>& cuts, double* sol, int maxNOfCuts);
/**
* Separates clique inequalities. Parameters and return value are analogous
* to m_separateStarInequalities.
*/
	  bool m_separateCliqueInequalities(
        list<int>& cuts, double* sol, int maxNOfCuts);
/**
* Searches for odd triangles in the integral distance matrix m_distMatrix
* and adds them to m_conflictSets. 
*/
      bool m_separateOddTriangles();

/**
* A heuristic which tries to construct a feasible solution from a given 
* (possible unembeddable) distance matrix. The matrix is embedded as far as 
* possible, the remaining vertices are then filled up in a locally optimum way.
* \param distArray The distance matrix given as a line-by-line array.
* \param currentBestObjValue The best feasible solutions objective function 
* value found so far. 
* \param useTreeSearch Use embeddability test to construct the solution.
* \return The objective function value of the constructed feasible solution or
* "-1" if an error occured.
*/
	  double m_constructFeasibleSolution(int* distArray, 
                                           double currentBestObjValue,
                                           bool useTreeSearch);

/**
* Tries to improve the current solution stored in the components. Performs simple
* exchange moves among node pairs.
* \return Objective value of improved solution.
*/
        double m_improve( bool& abort );


// -----------------------------
// Feasibile Solutions ---------
// -----------------------------
/**
* True if a feasible solution (giving an upper bound) has been found. It is
* set once at the very end of the optimization.
*/
           bool m_approximationFound;
/**
* Objective function value of the best feasible solution found so far.
*/
            double m_bestApproximationValue;
/**
* The best (greatest) lower bound which was found.
*/
           double m_bestLowerBound;

// -----------------------------
// The Graph -------------------
// -----------------------------
/**
* The number of vertices of the whole graph.
*/
          int m_nVertices;
/**
* The number of edges of the whole graph.
*/
          int m_nEdges;
/**
* The adjacency matrix of the whole graph. Entrx [i][j] is 1 if vertices i and j
* are adjacent and 0 otherwise.
*/
          vector<intVector> m_adjMatrix;
/**
* The distance matrix contains the current solution to be checked for 
* embeddability. Entry [i][j] gives the desired distance of vertices i and j.
*/
          vector<intVector> m_distMatrix;

/**
* The weights of the (non-zero) edges. The weight of the edge with number i
* is stored in m_edgeWeights[i]. 
*/		  
		  vector<double> m_edgeWeights;
/**
* The maximum entry in the current distance matrix.
*/
          int m_maxDistInInput;

/**
* Element m_adjList[i] gives the adjacency list of vertex i, i.e. a list of
* the vertices adjacent to i.
*/ 
          vectorOfLists m_adjList;
/**
* Entry [i][j] of the edge number matrix gives the ID-number of edge (i,j)
* ranging from 0 to m_nEdges-1. 
*/ 
          vector<intVector> m_edgeNumberMatrix;
/**
* The connectivity components of the graph. 
*/
          list<Component> m_graphComponents;
          
/**
* True if the input adjacency matrix contains no "1", i.e. the input graph
* does not contain any edge.
*/
          bool m_isZeroMatrix;
// -----------------------------
// Separation ------------------
// -----------------------------

/**
* The maximum number k such that the right-hand side of a clique-inequality
* for k vertices is known and shall be separated.
*/
         int m_maxCliqueSizeToBeSeparated;
/**
* The right-hand sides of the clique-inequalities. m_rhsClique[i] is the 
* right-hand side for the cliques with i vertices. 
*/
         vector<int> m_rhsClique;
/**
* The right-hand sides of the star-inequalities. m_rhsStarInequalities[i] is
* the right-hand side for the stars with i+1 vertices, i.e. one center vertex 
* and i neighbours. 
*/
	     vector<int> m_rhsStarInequalities;

// -----------------------------
// Cutting planes --------------
// -----------------------------

/**
* The list contains unembeddable vertex subsets of the given distance matrix
* the cutting planes will be calculated from. The size of the unembeddable 
* subset is followed by its member vertices. E.g. 
* 4 1 4 2 5 3 1 6 7 
* encodes two unembeddable vertex subsets: {1,2,4,5} and {1,6,7}.
*/
         list<int> m_conflictSets;
/**
* The list contains unembeddable edge subsets of the given distance matrix.
* Its syntax is similar to m_conflictSets which is vertex-based. E.g.
* 4 12 43 2 99 3 102 16 7 
* encodes two unembeddable subsets consisting of the edges {2,12,43,99} and
* {7,16,102}.
*/
         list<int> m_conflictSetsEdges;


// -----------------------------------------------------------------------
// Public Methods --------------------------------------------------------
// -----------------------------------------------------------------------

// -----------------------------
// Input and Output ------------
// -----------------------------

/**
* Prints an error message on the screen.
* \param errorID The ID-number of the error. Positive IDs for warnings,
* negative IDs for fatal errors.
*/         
         void m_printError(int errorID);



// -----------------------------
// Input and Output ------------
// -----------------------------
/**
* Reads in the new integral distance matrix in vector form (line-by-line).
* \param cplexSolution The integral distance vector to be checked for 
* embeddability
* \return False if an error occured, true otherwise.
*/
         bool read(int* cplexSolution);

/**
* Reads the input file containing the graph and initializes the graph related
* data structures.
* \param graphFile The path and name of the text file containing the graph. See
* the manual for syntax issues.
* \return False if an error occured, true otherwise.
*/
          bool m_readInputFile(const char* graphFile);

/**
* Checks if solutions were found. If so, the coordinates of the vertices are
* minimized while staying non-negative.
*/
         void m_calculateAndNormalizeSolution();

/**
* Prints final statistics on the graph, the optimization results and a 
* visualization of the best grid arrangements to the screen. Is usually called
* after the optimization process is finished.
*/
          void m_printFinalStatistics();

/**
* Method which creates the solution output files in the folder of the input
* file. See manual for syntax.
* \param guarantee The guarantee the branch-and-cut system gives for the best
* solution found. This value will be printed into the output files.
* \return False if an error occured, true otherwise.
*/
         bool m_createOutputFiles(double guarantee);

 /**
 * The path and name of the input file in which the graph to be embedded is 
 * described.
 */
             char* m_graphFile;

/**
* If true, the output files are updated each time the objective gets
* better or the lower bound is improved. Otherwise at the end of optimization.
*/
            bool m_createOutputFileAfterEveryImproval;

/**
* If true, the depth-first-search won't stop when a feasible solution is found
* but continues the search for the "most aesthetic solution" as defined in
* m_calcAestheticValue(Component&).
*/
	    bool m_aestheticModeActivated;

// -----------------------------
// Checking Embeddability ------
// -----------------------------

/**
* Checks whether the read-in solution is embeddable. If not, cutting planes in
* form of inequalities are determined and returned by lists. Their sense is 
* always ">=" (greater or equal).
* \param nNonZeros The number of non-zero coefficients in each inequality. The
* length of the list gives the number of inequalities found.
* \param nonZeroCoeff The non-zero coefficients of each inequality. 
* \param nonZeroVariables The IDs of the variables with non-zero coefficients.
* \param rhs The right-hand sides of the inequalities.
* \param guarantee If you have the global lower bound, you can hand it over here
*  and the corresponding global guarantee be printed into the output files.
*/ 
         int solve(list<int>& nNonZeros, 
            list<int>& nonZeroCoeff, list<int>& nonZeroVariables, 
              list<int>& rhs, double lowerBound);

/**
* Determines start vertices and initializes the main search tree for an 
* embeddability check.
* \param component The component for which the tree is initialized.
*/ 
          void m_initializeSearchTree(Component& component);
/**
* Checks the embeddability of a component the matrix m_distMatrix after having
* called m_initalizeSearchTree. Controls the calls of the depth-first-search-
* method in order to generate several cutting planes intelligently. 
* \param returnMaxConlictSetSize The method writes the number of vertices in
* the maximum unembeddable vertex subset into this variable.
* \param component The component to be searched.
* \param If true, the algorithm stops when a single conflict set (cutting plane)
* was found. If false, several conflict sets are searched for.
* \return The number of conflict sets found or "-1" if an error occured.
*/
          int m_startMainSearch(int& returnMaxConflictSetSize, 
            Component& component, bool singleConflictSet);
/**
* This depth-first-search algorithm checks whether, given a possible set of grid
* arrangements for k nodes u_1,...,u_k, m additional vertices v_k+1,...,v_k+m 
* of the same component can be placed on the grid according to a distance
* matrix. The m additional vertices are chosen from the unfixed vertices of 
* the component. Use the m_isTemporarilyForbiddenVertex vector of the tree to 
* exclude certain vertices from being chosen.
* \param component The component of u_1,...,u_k+m.
* \param tree The search tree containing the possibilities for u_1,...,u_k and
* will be extended for the placement of the remaining vertices u_k+1,...,u_k+m.
* \param distMatrix The matrix containing the adjacent vertices' distances.
* \param startNode A node of the tree "tree" from which the depth-first-search
* starts. If the expandation of the start node isn't successful, the algorithm
* will also try to expand from every leaf which is right of the start node, but
* not from leaves left of the start node.
* \param The level of the start node in the tree. Root has level 0, its children
* level 1... If u_1,...,u_k are already fixed, the value is usually k-1.
* \param stopLevel If this tree level is reached, the algorithm stops and 
* returns "embeddable". In the example above, set stopLevel to k+m-1.
* \param vertexToAdd If you just want to add one single vertex, set this value
* to the vertex' ID. Otherwise, set the value to "-1". 
* \return Returns "0" if the stop level was reached successfully, "n" (>0) if
* the stop level wasn't reached and the total number of vertices that could be
* fixed is n-1, and "-1" if an error occured.
*/
          int m_performDepthFirstSearch(Component& component, 
            FeasibilityTree* tree, vector<intVector>& distMatrix, 
             Node* startNode, int levelStartNode, int stopLevel, 
              int vertexToAdd);
              
/**
* Checks if a connected component is embeddable on a 2D-grid.
* \param componentsVertices List of the vertices which form the component.
* \return 1 if it is embeddable, 0 if unembeddable, -2 if disk space error.
*/              
          int m_isConnectedComponentEmbeddable(list<int> componentsVertices);
/**
* For a given search tree and a vertex v which is already fixed, a vertex which
* isn't fixed yet and which has a minimum distance to v according to 
* m_distMatrix is determined and stored in m_closeVertexAlreadyFixed of the tree
* \param vertexID The vertex v.
* \param tree The search tree.
*/
          void m_determineCloseVertexAlreadyFixed(
            int vertexID, FeasibilityTree* tree); 
/**
* For a given search tree and a position i, this method returns the i-th 
* vertex to be fixed on the grid. If it is not already fixed, the vertex is
* determined. Possible candidates are all vertices which are adjacent to at
* least one fixed vertex and which are not temporarily forbidden.
* \param position The position i.
* \param tree The search tree.
* \return Returns the vertex at position i or "-1" if an error occured.
*/
          int m_determineNextVertex(int position, FeasibilityTree* tree);

/**
* Check the embeddability of a component with at most 3 vertices and store the
* coordinates of the embedding. 
* \param compIter The component to be checked.
* \return "0" if component is embeddable, "1" otherwise.
*/
          int m_solveComponentWithAtMost3Vertices(Component& compIter);

/**
* The vertex-based conflict sets of a component are minimized, i.e. an
* unembeddable vertex subset whose subsets are embeddable is searched for and
* stored in m_conflictSets.
* \param nConflictSets The number of conflict sets that were found for the
* component.
* \param maxConflictSetSize The number of vertices in the maximum vertex
* conflict set to be minimized.
* \param component The component whose vertex conflict sets will be minimized.
* \return 0 if everything is okay, -2 if disk space error
*/
          int m_reduceConflictSet(
            int nConflictSets, int maxConflictSetSize, Component& component);

/**
* Similarily to m_reduceConflictSet, this method minimizes the vertex conflict
* sets of a component. For every edge in the set, the tests decides whether 
* the conflict still remains if the edge is left out. 
* \param component The component whose conflict sets will be minimized.
*/
	      void m_edgeReduceVertexConflictSet(Component& component);

/**
* Searches for the most aesthetic embedding (according to m_calcAestheticValue)
* of the current distance matrix. by performing an extended depth-first search.
* \param component The component for which the most aesthetic solution is 
* to be found. 
*/
           void m_findMostAestheticSolution(Component& component);

/**
* For the current embedding of a component whose coordinates are stored in 
* component.xPos[] and component.yPos[], an aesthetic value is calculated
* and returned. The larger the value, the more aesthetic is the embedding.
* The value must be non-negative!
* \param component The component for which the aesthetic value is returned.
* \return The aesthetic value. Must be non-negative (>= 0) !!
*/
double m_calcAestheticValue(Component& component);

/**
* Translates the vertex-based conflict sets in m_conflictSets into 
* cutting-plane-inequalities. The parameter lists are used as in the method
* "int solve(...)".
*/
          void m_calcOutputInequalitiesFromConflictSets(
            list<int>& nNonZeros, list<int>& nonZeroCoeff, 
              list<int>& nonZeroVariables, list<int>& rhs);

/**
* Translates the edge-based conflict sets in m_conflictSetsEdges into 
* cutting-plane-inequalities. The parameter lists are used as in the method
* "int solve(...)".
*/
          void m_calcOutputInequalitiesFromEdgeConflictSets(
            list<int>& nNonZeros, list<int>& nonZeroCoeff, 
              list<int>& nonZeroVariables, list<int>& rhs);
			  
			  
// -------------------------------
// Analyzing the Graph / Distances
// -------------------------------

/**
* Calculates the weighted distance between nodes u and v in component comp
* in the embedding (xPosBest, yPosBest). If an error occurs, error is
* set to "true".
*/
         double m_dist( int u, int v, Component* comp, bool& error );

/**
* Checks if the input matrix is symmetrical and if there are zeros on the main
* diagonal, i.e. if the graph is undirected.
* \return True if the matrix is symmetrical, false otherwise.
*/
          bool m_isInputMatrixSymmetrical();
/**
* Checks if a given component is connected.
* \param comp The component to be checked.
* \return True if the component is connected, false otherwise.
*/
          bool m_isComponentConnected(Component& comp);
//       bool m_isInputGraphConnected();

/**
* Searches the graph for triangles (3-cliques) and 4-cliques and stores them.
* \param maxNumberToFind The maximum number of triangles and the maximum number
* of 4-cliques to be found, the search is aborted when this limit is reached.
* \return True if no error occured.
*/
          bool m_findTrianglesAnd4CliquesInGraph(int maxNumberToFind);
/**
* Searches the graph for maximum cliques, i.e. cliques which are not contained
* in larger cliques (except of themselves), and stores them.
* \param maxNumberToFind The maximum number of cliques to be found. The search 
* is aborted when this limit is reached.
* \return True if no error occured.
*/
    	  bool m_findMaxCliquesInGraph(int maxNumberToFind);
	  
/**
* Searches the graph for 5-cycles and stores them.
* \param maxNumberToFind The maximum number of 5-cycles to find, the search is 
* aborted when this limit is reached.
* \return True if no error occured.
*/	  
	      bool m_findFiveCyclesInGraph(int maxNumberToFind);

/**
* Checks whether the given four nodes form a rectangle considering the pairwise
* distances in the main distance matrix m_distMatrix. 
* \param fourNodes The four vertices to be checked. They need to form a 4-clique.
* Note that the order of the four nodes might be changed: If they form a 
* rectangle, they are rearranged such that no two diagonal vertices succeed each
* other. 
* \return "0" if it is not a rectangle, "n>0" if it is a rectangle and its 
* diagonal length is n.
*/  
         int m_isRectangle(int* fourNodes);
  
/**
* Calculates a maximum distance any two adjacent vertices are allowed to have
* on the grid by an estimation heuristic. The result is stored in
* m_maxDistAllowedInModel.
*/  
          void m_calcMaxDistAllowed();

/**
* Calculates the current objective function value of a component according to 
* the entries of the main distance matrix m_distMatrix.
* \param component The component whose objective value is calculated.
* \return The current objective function value of the component.
*/
	  double m_currentObjVal(Component& component);

/**
* This method checks whether the calculated embedding really corresponds to the
* given distance matrix m_distMatrix. Prints detailed error messages to screen. 
* Might be useful during a change of the program.
* \param component The component to be checked.
* \return False if the embedding does not correspond to the distance matrix, 
* true otherwise.
*/
         bool m_compareGridPositionsWithDistMatrixEntries(Component& component);

  private:



};

#endif /*FEASIBILITYTEST_HH_*/
