////////////////////////////////////// c++ /////////////////////////////////////
//
//  Module           : gridMain.cpp
//  Description      :
//  Author           : Marcus Oswald 
//  Email            : Marcus.Oswald@informatik.uni-heidelberg.de
//  Copyright        : University of Heidelberg
//  Created on       : Wed Jul  3 14:06:42 2002
//  Last modified by : oswald
//  Last modified on : Wed Feb 03 2010
//  Update count     : 4
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date	       Name		Changes/Extensions
//  ----      	----		------------------
//  Feb 3 2010 	wiesberg	Changed from Linear Arrangement Problem to
//					2D-Grid Arrangement Problem
////////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include "gridMaster.hh"

int main(int argc,char**argv)
{
    char*inputFileName;

    if(argc!=2){
     cerr<<"usage: "<<argv[0]<<" <file>"<<endl;
     return 1;
    }

    inputFileName= argv[1];
    GridMaster*grid= new GridMaster(inputFileName);
    ABA_MASTER::STATUS status= grid->optimize();

    delete grid;

    if(status )return 1;
    else return 0;
}
