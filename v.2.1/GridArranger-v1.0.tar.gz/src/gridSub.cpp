////////////////////////////////////// c++ /////////////////////////////////////
//
//  Module           : gridSub.cpp
//  Description      :
//  Author           : Marcus Oswald
//  Email            : Marcus.Oswald@informatik.uni-heidelberg.de
//  Copyright        : University of Heidelberg
//  Created on       : Wed Jul  3 13:55:04 2002
//  Last modified by : wiesberg
//  Last modified on : Wed Feb 03 2010
//  Update count     : 371
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date	Name		Changes/Extensions
//  ----	----		------------------
// Feb 03 2010  wiesberg  Adjusted for 2D-Grid-Arrangement-Problem
////////////////////////////////////////////////////////////////////////////////

#include "list"
#include "gridSub.hh"
#include "gridMaster.hh"
#include "abacus/lpsub.h"
#include "abacus/lpsolution.h"
#include "gridLpSolution.hh"
#include "generalIntConstraint.hh"
#include "FeasibilityTree.hpp"
#include "FeasibilityTest.hpp"
#include "SparseConstraint.hh"
#include "hypSep.hh"

   /**
   * Constructor for the first Subproblem.
   *
   * @param master Pointer to the Master-Problem
   */
GridSub::GridSub(ABA_MASTER*master):
ABA_SUB(master,10,0,50)
{
}

  /**
   * Constructor.
   *
   * @param master Pointer to the Master-Problem.
   * @param father Pointer to the Father-Problem in the Branch&Cut-Tree.
   * @param branchRule Pointer to the Branchrule.
   */
GridSub::GridSub(ABA_MASTER*master,
ABA_SUB*father,
ABA_BRANCHRULE*branchRule):
ABA_SUB(master,father,branchRule)
{ 
 
}

GridSub::~GridSub()
{

}

  /**
   * Generating the sons of the current Subproblem.
   *
   * @param branchRule Pointer to the Branchrule.
   */
ABA_SUB*GridSub::generateSon(ABA_BRANCHRULE*rule)
{
  return new GridSub(master_,this,rule);
}

int GridSub::generateBranchRules(ABA_BUFFER<ABA_BRANCHRULE*>&rules)
{
  return branchingOnVariable(rules);
  //return branchingOnVarCon(rules);

}

void GridSub::createDistConstraintsFromCutList(list<int>& cuts, int type){
     ngen_ = 0;
     list<int>::iterator iter;
     iter = cuts.begin();
	ABA_BUFFER<ABA_CONSTRAINT*>* newConstraint;

	 
    while(iter != cuts.end()){
		newConstraint = new ABA_BUFFER<ABA_CONSTRAINT*>((ABA_GLOBAL*)((GridMaster*)master_),1);


	int nNonZeros = *iter;
		int vari[nNonZeros];
		int coef[nNonZeros];
		for(int i=0; i<nNonZeros; i++){
			if(type == 2 || type == 3 || type == 4) coef[i] = 1;
				iter++;
				vari[i] = *iter;
				// cout << "+ x_" << vari[i] << " "; 
		}	
		if(type == 0){
			coef[0] = 1;
			coef[1] = -1;
		}
		if(type == 1){
			coef[0] = 1;
			coef[1] = 1;
			coef[2] = -1;
		}
		int rhs = -1;
		if(type == 0 || type == 1) rhs = 0;
		if(type == 2) rhs = (((GridMaster*)master_)->m_feasyTest)
                         ->m_rhsStarInequalities[nNonZeros];
		if(type == 3) rhs = 6;
		if(type == 4){
			iter++;
            rhs = *iter;
			//cout << ">= " << *iter << endl;
        }

		GeneralIntConstraint* genIntCon = new GeneralIntConstraint(
						(GridMaster*)master_, nNonZeros, rhs, vari, coef, 
                        ABA_CSENSE::Greater, false);
		newConstraint->push( genIntCon );
		(ngen_)++;
		iter++;
		//addCons(*newConstraint,gridMaster()->constraintPool());
		addCons( *newConstraint );
		delete newConstraint;
    } //while     
}


  /**
   * Test if the current LP-Solution is a feasible Grid-Arrangement-Solution.
   */
bool GridSub::feasible()
{

  if(integerFeasible()) {
     // read integral solution into Feasibility Test
     double lowerBound = ((GridMaster*)master_)->lowerBound();
     int nEdges = ((GridMaster*)master_)->m_feasyTest->m_nEdges;
     int solToBeCheckedByFeasibilityTest[nEdges];
     int totalEdgeLength = 0;
     for(int i=0; i<nEdges; i++){
        double currentDist = xVal_[i] + 0.1;
	solToBeCheckedByFeasibilityTest[i] = (int) currentDist;
	totalEdgeLength += (int) currentDist;
     } 
     ((GridMaster*)master_)->m_feasyTest->read(solToBeCheckedByFeasibilityTest);

     // start Feasibility Test
     ((GridMaster*)master_)->m_feasyTest->m_nCplexSolutionTests++;
     list<int> nNonZeros, nonZeroCoeff, nonZeroVariables, rhs;
     int testResult = -1;
     testResult = ((GridMaster*)master_)->m_feasyTest->solve(nNonZeros, 
                              nonZeroCoeff, nonZeroVariables, rhs, lowerBound);
     if(testResult == -1) { return true;}
	 if( testResult == -2 ){ return true; } // disk space error
     if(testResult == 0) {
	    if(lowerBound > ((GridMaster*)master_)->m_feasyTest->m_bestLowerBound + 0.001){ 
            ((GridMaster*)master_)->m_feasyTest->m_bestLowerBound = lowerBound;
        }
        ((GridMaster*)master_)->m_feasyTest->m_calculateAndNormalizeSolution();
        ((GridMaster*)master_)->m_feasyTest->m_createOutputFiles(lowerBound); 
        return true;  
}
     if(testResult == 1) {

	ngen_ = nNonZeros.size();
	list<int>::iterator iter, rhsIter, variIter, coefIter;
	rhsIter = rhs.begin();
	variIter = nonZeroVariables.begin();
	coefIter=nonZeroCoeff.begin();
	for(iter = nNonZeros.begin(); iter != nNonZeros.end(); ++iter){
	    ABA_BUFFER<ABA_CONSTRAINT*> newConstraint((ABA_GLOBAL*) 
                                                  ((GridMaster*)master_),1000);

//cout << "variables and coefficients for ABACUS: "; 
	    int vari[*iter];
	    int coef[*iter];
	    for(int i=0; i<*iter; i++){
		  vari[i] = *variIter;
//cout << vari[i] << " ";
		  variIter++;
	    }
//cout << endl;
	    for(int i=0; i<*iter; i++){
		coef[i] = *coefIter; 
//cout << coef[i] << " ";
		coefIter++;
	    }
//cout << "<= " << *rhsIter << endl;
	    newConstraint.push(new GeneralIntConstraint( 
          (GridMaster*)master_, *iter, *rhsIter, vari, coef, 
                                                      ABA_CSENSE::Less, false));
	    rhsIter++;
	    addCons(newConstraint);
           // addCons(newConstraint,gridMaster()->constraintPool());
	}
        return false;
     }
     else {return false;}
   }
  else{ return false; }
}

int GridSub::improve(double &primalValue)
{
  double lowerBound = ((GridMaster*)master_)->lowerBound();  
    
  if((((GridMaster*)master_)->m_feasyTest)->m_createOutputFileAfterEveryImproval 
      && lowerBound > (((GridMaster*)master_)
                                     ->m_feasyTest)->m_bestLowerBound + 0.001 ){
      (((GridMaster*)master_)->m_feasyTest)->m_calculateAndNormalizeSolution();
      (((GridMaster*)master_)->m_feasyTest)->m_createOutputFiles( lowerBound );
  }

  int distArray[(((GridMaster*)master_)->m_feasyTest)->m_nEdges];
  for(int i=0; i<(((GridMaster*)master_)->m_feasyTest)->m_nEdges; i++) 
     distArray[i] = (int)(xVal_[i] + 0.01);
  bool error = (((GridMaster*)master_)->m_feasyTest)->read(distArray) ;
  if(!error) { return 0; }
  double objVal = (((GridMaster*)master_)->m_feasyTest)
       ->m_constructFeasibleSolution(distArray, (master_)->primalBound(), true);
  if(objVal < -0.001){return 0;} 
  double objValBest = objVal;
  if (objVal < (master_)->primalBound() -0.01) {
     for(int i=0; i<100; i++){
       objVal = (((GridMaster*)master_)->m_feasyTest)
         ->m_constructFeasibleSolution(distArray, master_->primalBound(), true);	
       if(objVal < -0.001){return 0;} 
       if(objVal < objValBest -0.01) objValBest = objVal;
     }
     primalValue= objVal;

     // cout << "Rounding Heuristic improved solution to " << primalValue << endl;
     if(   (((GridMaster*)master_)->m_feasyTest)
            ->m_createOutputFileAfterEveryImproval ){
	   bool abort = false; 
	   double newPrimalValue = (((GridMaster*)master_)->m_feasyTest)->m_improve( abort );	
       if( !abort ) primalValue = newPrimalValue;	   
       (((GridMaster*)master_)->m_feasyTest)->m_calculateAndNormalizeSolution();
       (((GridMaster*)master_)->m_feasyTest)->m_createOutputFiles(lowerBound);
     }
       return 1;
   }
  return 0;
}

  /**
   * Creating the Linear-Ordering-Separation-class LopThreeCycleSeparator, 
   * derived from the ABACUS-class ABA_SEPARATOR.
   */
int GridSub::separate()
{



// if(ngen_ > 0) return 0;
  list<int> cuts;
  bool cutsFound = false;


 // SEPARATE MONOTONY INEQUALITIES
  //cout << "Separating monotony inequalities" << endl;
  cutsFound = (((GridMaster*)master_)->m_feasyTest)
     ->m_separateMonotonyInequalities(cuts, xVal_, 0);
  if(cutsFound){
      // cout << "Violated Monotony Inequalities Found" << endl;
      createDistConstraintsFromCutList(cuts, 0);
      cuts.clear();
      return ngen_;
  }




 // SEPARATE TRIANGLE INEQUALITIES
  //cout << "Separating triangle inequalities" << endl;
  cutsFound = (((GridMaster*)master_)->m_feasyTest)
    ->m_separateTriangleInequalities(cuts, xVal_, 10);
  if(cutsFound){
      //cout << "Violated Triangle Inequalities Found" << endl;
      createDistConstraintsFromCutList(cuts, 1);
      cuts.clear();
      return ngen_;
  }



  // SEPARATE STAR INEQUALITIES
  //cout << "Separating star inequalities" << endl;
  cutsFound = (((GridMaster*)master_)->m_feasyTest)
    ->m_separateStarInequalities(cuts, xVal_, 10);
  if(cutsFound){
      //cout << "Violated Star Inequalities Found" << endl;
      createDistConstraintsFromCutList(cuts, 2);
      cuts.clear();
      return ngen_;
  }


  // SEPARATE CLIQUE INEQUALITIES
  //cout << "Separating clique inequalities" << endl;
  cutsFound = (((GridMaster*)master_)->m_feasyTest)
    ->m_separateCliqueInequalities(cuts, xVal_, 10);
  if(cutsFound){
//      cout << "Violated Clique Inequalities Found !" << endl;
      createDistConstraintsFromCutList(cuts, 4);
      cuts.clear();
      return ngen_;
  }


  
  // SEPARATE FIVE CYCLE INEQUALITIES 
   //cout << "Separating 5-cycle inequalities" << endl;
  cutsFound = (((GridMaster*)master_)->m_feasyTest)
    ->m_separateFiveCycleInequalities(cuts, xVal_, 10);
  if(cutsFound){
      //cout << "Violated 5-cycle Inequalities Found" << endl;
      createDistConstraintsFromCutList(cuts, 3);
      cuts.clear();
      return ngen_;
  }

 
    // SEPARATE HYPERMETRIC INEQUALITIES
   ABA_BUFFER<ABA_CONSTRAINT*> newConstraint( master_, 300 );
   (((GridMaster*)master_)->m_feasyTest)
    ->m_separateHypermetricInequalities( &newConstraint, master_, this, xVal_ );
   int nHyp = newConstraint.number();
   addCons( newConstraint );
   if ( nHyp > 0 ) return nHyp;

    return 0;    
}

GridMaster*GridSub::gridMaster()
{
return(GridMaster*)master_;

}
