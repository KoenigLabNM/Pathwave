///////////////////////////////// C++ //////////////////////////////////////////
//
//  Module           : SparseConstraint.hh
//  Description      : Defines a template class to store constraints in sparse
//                     format. Template parameter can be used to specifiy data
//                     of left hand side coefficients.
//  Author           : Thorsten Bonato
//  Email            : thorsten.bonato@informatik.uni-heidelberg.de
//  Copyright        : University of Heidelberg
//  Created on       : 01.03.2010
//  Last modified by :
//  Last modified on :
//  Update count     :
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date    Name        Changes/Extensions
//  ----    ----        ------------------
//
////////////////////////////////////////////////////////////////////////////////


#ifndef SPARSE_CONSTRAINT_HH
#define SPARSE_CONSTRAINT_HH


#include <cstdlib>


using namespace std;


//
// c l a s s   S p a r s e C o n s t r a i n t
//
template <class T>
class SparseConstraint {

    //--------------------------------------------------------------------------
    //                               public
    //--------------------------------------------------------------------------
    public:

        /**
         * Constructor.
         *
         * @param nNz   Number of nonzero left hand side coefficients.
         * @param rhs   Value of right hand side.
         * @param idx   Array storing the edge indices of the nonzero
         *              coefficients.
         * @param coef  Array storing the values of the nonzero coefficients.
         * @param chk   Checksum.
         */
        SparseConstraint( int nNz, T rhs, int* idx, T* coef, double chk )
            : nNz_( nNz ), rhs_( rhs ), idx_( NULL ), coef_( NULL ),
              chk_( chk ) {

            idx_  = new int[ nNz ];
            coef_ = new T  [ nNz ];

            for ( int i = 0; i < nNz; i++ ) {
                idx_[i]  = idx[i];
                coef_[i] = coef[i];
            } // for
        } // Constructor


        /**
         * Copy constructor.
         *
         * @param src  Reference to constraint to be copied.
         */
        SparseConstraint( const SparseConstraint<T>& src )
            : nNz_( src.nNz() ), rhs_( src.rhs() ), idx_( NULL ), coef_( NULL ),
              chk_( src.chk() ) {

            idx_  = new int[ nNz_ ];
            coef_ = new T  [ nNz_ ];

            for ( int i = 0; i < nNz_; i++ ) {
                idx_[i]  = src.idx(i);
                coef_[i] = src.coef(i);
            } // for
        } // Copy constructor.


        /**
         * Destructor.
         */
        ~SparseConstraint() {
            // Delete idx_
            if ( idx_ ) {
                delete [] idx_;
            } // if

            // Delete coef_
            if ( coef_ ) {
                delete [] coef_;
            } // if
        } // Destructor


        /**
         * Get number of nonzero coefficients.
         *
         * @return Number of nonzero coefficients in the constraint.
         */
        int nNz() const {
            return nNz_;
        } // nNz


        /**
         * Get right hand side.
         *
         * @return Right hand side of the constraint.
         */
        T rhs() const {
            return rhs_;
        } // rhs


        /**
         * Get edge index of i-th nonzero coefficient.
         *
         * @return Edge index of i-th nonzero coefficient.
         */
        int idx( int i ) const {
            if ( (i >= 0) && (i < nNz_) ) {
                return idx_[i];
            } // if

            cout << "SparseConstraint.hh : Out of boundary error on idx array." << endl;
            exit( 1 );
        } // idx


        /**
         * Get edge index array.
         *
         * @return Pointer to edge index array.
         */
        int* idx() {
            return idx_;
        } // idx


        /**
         * Get value of i-th nonzero coefficient.
         *
         * @return Value of i-th nonzero coefficient.
         */
        T coef( int i ) const {
            if ( (i >= 0) && (i < nNz_) ) {
                return coef_[i];
            } // if

            cout << "SparseConstraint.hh : Out of boundary error on coef array." << endl;
            exit( 2 );
        } // coef


        /**
         * Get coefficient value array.
         *
         * @return Pointer to coefficient value array.
         */
        T* coef() {
            return coef_;
        } // coef


        /**
         * Get checksum of constraint.
         *
         * @return Checksum of constraint.
         */
        double chk() const {
            return chk_;
        } // chk


        /**
         * Assignment operator.
         *
         * @param src  Reference to constraint to be assigned.
         */
        SparseConstraint& operator=( const SparseConstraint& src ) {
            // Protect against invalid self-assignment
            if ( this != &src ) {
                // Free old disk space
                if ( idx_ ) {
                    delete [] idx_;
                } // if

                if ( coef_ ) {
                    delete [] coef_;
                } // if

                idx_  = NULL;
                coef_ = NULL;


                // Allocate new memory and copy the elements
                nNz_ = src.nNz();
                rhs_ = src.rhs();
                chk_ = src.chk();

                idx_  = new int[ nNz_ ];
                coef_ = new T  [ nNz_ ];

                for ( int i = 0; i < nNz_; i++ ) {
                    idx_[i]  = src.idx(i);
                    coef_[i] = src.coef(i);
                } // for
            } // if

            // By convention, always return *this
            return( *this );
        } // operator=



    //--------------------------------------------------------------------------
    //                               private
    //--------------------------------------------------------------------------
    private:

        int  nNz_;    // Number of nonzero coefficients.
        T    rhs_;    // Right hand side.
        int* idx_;    // Array storing edge indices of the nonzero coefficients.
        T*   coef_;   // Array storing values of the nonzero coefficients.
        double chk_;  // Checksum.

}; // SparseConstraint

#endif // SPARSE_CONSTRAINT_HH
