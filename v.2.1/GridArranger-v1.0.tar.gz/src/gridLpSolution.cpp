////////////////////////////////////// c++ /////////////////////////////////////
//
//  Module           : gridLpSolution.cpp
//  Description      :
//  Author           : Marcus Oswald
//  Email            : Marcus.Oswald@informatik.uni-heidelberg.de
//  Copyright        : University of Heidelberg
//  Created on       : Wed Jul  3 14:40:12 2002
//  Last modified by : oswald
//  Last modified on : Wed Feb 03 2010
//  Update count     : 6
//
////////////////////////////////////////////////////////////////////////////////
//
//  Date	Name		Changes/Extensions
//  ----	----		------------------
//  Feb 3 2010 wiesberg  Modifications for Grid Arrangement Problem
////////////////////////////////////////////////////////////////////////////////

#include "gridLpSolution.hh"

GridLpSolution::GridLpSolution(ABA_MASTER *master, int nVar, double *xVal):
  ABA_LPSOLUTION<ABA_VARIABLE,ABA_CONSTRAINT>(master)
{
    int i; //,j,k;
    nVarCon_=nVar;
    // Copy lp-solution from xVal to zVal
    zVal_.realloc(nVar);
    for(i=0;i<nVar;i++) zVal_[i] = xVal[i];
}

GridLpSolution::~GridLpSolution() 
{
                                  
}

void GridLpSolution::print(ostream&os)
{

}

ostream &operator<<(ostream &os, const GridLpSolution &rhs)  {
    os << *(ABA_LPSOLUTION<ABA_VARIABLE,ABA_CONSTRAINT>*)(&rhs);
    return os;
}
