`pathWave.run` <-
function(configfile="pathwave.run.conf", preprocessed.tag=NULL, input.exprdata=NULL,
					 input.sampleclasses=NULL, param.kegg.only_metabolism=NULL,
					 param.ztransform=NULL,
					 param.numperm = NULL, param.pvalue.correction.method=NULL,
					 param.pvalue.threshold=NULL, param.filter.size=NULL, 
					 output.file.prefix=NULL,
					 verbose=TRUE) {

   ### SOME DEFAULTS:
   DO_ZTRANSF = TRUE
   NUM_PERM = 1000
   DEF_THRES = 0.05
   DEF_FIL_SIZE = 3
   DEF_METHOD = "Bonferroni"

   DEF_KEGG_METABOLIC_PWAY_THRES = 2000

   ### CONFIGURATION FILE?

   config = pw.readConf(configfile, verbose)


   ### GET PARAMETERS and FILE NAMES:

   if (is.null(preprocessed.tag)) {
      if (!is.null(config["preprocessed.tag"]) && !is.na(config["preprocessed.tag"])) {
         preprocessed.tag <- config["preprocessed.tag"]
      } else {
         cat("Error: preprocessed.tag neither specified in function call nor in the configuration file!\n") 
         return(NULL)
      }
   }
   if (verbose) {
      cat(paste("Using preprocessed pathway data: ",preprocessed.tag,"\n",sep=""))
   }


   if (length(grep("^KEGG", preprocessed.tag)) == 0) {
      # if we don't use KEGG pathways, always use all pathways!
      
      param.kegg.only_metabolism = FALSE;

   } else {
      # we use KEGG pathways; check if metabolic pathways only; complain if something wrong specified 

      if (is.null(param.kegg.only_metabolism)) {

      	 if (!is.null(config["param.kegg.only_metabolism"]) && !is.na(config["param.kegg.only_metabolism"])) {
	    param.kegg.only_metabolism <- as.logical(config["param.kegg.only_metabolism"])
      	 } else {      	 
	    # set the default: only metabolic pathways

      	    param.kegg.only_metabolism = TRUE
	 }
      }

      if (!is.na(param.kegg.only_metabolism) && is.logical(param.kegg.only_metabolism)) {
      	 cat(paste("Using metabolic KEGG pathways only: ",param.kegg.only_metabolism,"\n",sep=""))
      } else {
         cat("Error: param.kegg.only_metabolism must be boolean (TRUE or FALSE)!\n") 
         return(NULL)
      }
   }


   if (is.null(input.exprdata)) {
      if (!is.null(config["input.exprdata"]) && !is.na(config["input.exprdata"])) {
         input.exprdata <- config["input.exprdata"]
      } else {
         cat("Error: input.exprdata neither specified in function call nor in the configuration file!\n") 
         return(NULL)
      }
   } else {
      if (!is.data.frame(input.exprdata) && !is.character(input.exprdata)) {
         cat("Error: input.exprdata must be either a filename (character string) or a data.frame!\n") 
         return(NULL)
      }
   }
   if (verbose && is.character(input.exprdata)) {
      cat(paste("Using expression data file: ",input.exprdata,"\n",sep=""))
   }
   if (verbose && is.data.frame(input.exprdata)) {
      cat(paste("Using expression data from data frame passed to function","\n",sep=""))
   }


   if (is.null(input.sampleclasses)) {
      if (!is.null(config["input.sampleclasses"]) && !is.na(config["input.sampleclasses"])) {
         input.sampleclasses <- config["input.sampleclasses"]
      } else {
         cat("Error: input.sampleclasses neither specified in function call nor in the configuration file!\n") 
         return(NULL)
      }
   } else {
      if (!is.data.frame(input.sampleclasses) && !is.character(input.sampleclasses) && !is.factor(input.sampleclasses)) {
         cat("Error: input.sampleclasses must be either a filename (character string), a data.frame or a factor!\n") 
         return(NULL)
      }
   }
   if (verbose && is.character(input.sampleclasses)) {
      cat(paste("Using file for sample class definition: ",input.sampleclasses,"\n",sep=""))
   }
   if (verbose && is.data.frame(input.sampleclasses)) {
      cat(paste("Using sample class definition from data frame passed to function","\n",sep=""))
   }
   if (verbose && is.factor(input.sampleclasses)) {
      cat(paste("Using sample class definition from factor passed to function","\n",sep=""))
   }


   if (is.null(output.file.prefix)) {
      if (!is.null(config["output.file.prefix"]) && !is.na(config["output.file.prefix"])) {
         output.file.prefix <- config["output.file.prefix"]
      }
   }
   if (verbose) {
      cat(paste("Using prefix for output files: ",output.file.prefix,"\n",sep=""))
   }


   if (class(param.pvalue.threshold) == "NULL") {
      # need to check configuration file
      if (!is.null(config["param.pvalue.threshold"]) && !is.na(config["param.pvalue.threshold"])) {
         param.pvalue.threshold = as.numeric(config["param.pvalue.threshold"])
      }
   }
   # if we still have no meaningful result, set default
   if (!is.numeric(param.pvalue.threshold) || is.na(param.pvalue.threshold) || param.pvalue.threshold==0) {
      param.pvalue.threshold = DEF_THRES

      cat(paste("Warning: no meaningful numeric value for param.pvalue.threshold; using default: ",param.pvalue.threshold,"\n",sep=""))
   }
   if (verbose) {
      cat(paste("Using p-value threshold: ",param.pvalue.threshold,"\n",sep=""))
   }


   if (class(param.filter.size) == "NULL") {
      # need to check configuration file
      if (!is.null(config["param.filter.size"]) && !is.na(config["param.filter.size"])) {
         param.filter.size = as.numeric(config["param.filter.size"])
      }
   }
   # if we still have no meaningful result, set default
   if (!is.numeric(param.filter.size) || is.na(param.filter.size) || param.filter.size==0) {
      param.filter.size = DEF_FIL_SIZE

      cat(paste("Warning: no meaningful numeric value for param.filter.size; using default: ",param.filter.size,"\n",sep=""))
   }
   if (verbose) {
      cat(paste("Using gene filter size: ",param.filter.size,"\n",sep=""))
   }


   if (is.null(param.pvalue.correction.method)) {
      if (!is.null(config["param.pvalue.correction.method"]) && !is.na(config["param.pvalue.correction.method"])) {
         param.pvalue.correction.method <- config["param.pvalue.correction.method"]
      } else {
         param.pvalue.correction.method = DEF_METHOD

         cat(paste("Warning: no meaningful correction method for param.pvalue.correction.method; using default: ",param.pvalue.correction.method,"\n",sep=""))
      }
   }
   if (verbose) {
      cat(paste("Using correction method for multiple testing: ",param.pvalue.correction.method,"\n",sep=""))
   }


   if (class(param.ztransform) == "NULL") {
      # need to check configuration file
      if (!is.null(config["param.ztransform"]) && !is.na(config["param.ztransform"])) {
         param.ztransform = as.logical(config["param.ztransform"])
      }
   }
   # if we still have no meaningful result, set default
   if (!is.logical(param.ztransform) || is.na(param.ztransform)) {
      param.ztransform = DO_ZTRANSF

      cat(paste("Warning: no logical (TRUE/FALSE) value for param.ztransform; using default: ",param.ztransform,"\n",sep=""))
   }
   if (verbose) {
      cat(paste("Applying z-transformation to expression data: ",param.ztransform,"\n",sep=""))
   }


   if (class(param.numperm) == "NULL") {
      # need to check configuration file
      if (!is.null(config["param.numperm"]) && !is.na(config["param.numperm"])) {
         param.numperm = as.numeric(config["param.numperm"])
      }
   }
   # if we still have no meaningful result, set default
   if (!is.numeric(param.numperm) || is.na(param.numperm) || param.numperm==0) {
      param.numperm = NUM_PERM

      cat(paste("Warning: no meaningful numeric value for param.numperm; using default: ",NUM_PERM,"\n",sep=""))
   }
   if (verbose) {
      cat(paste("Number of permutations to perform: ",param.numperm,"\n",sep=""))
   }


   ### SET PREPROCESSED PATHWAY DATA:

   pwdataFromPackage = FALSE

   # try to load preprocessed data from the package?
   if (!exists(paste("pwdata.reac.genes.",preprocessed.tag,sep=""))
       || !exists(paste("pwdata.optimalGrid.",preprocessed.tag,sep=""))
       || !exists(paste("pwdata.pid2pname.",preprocessed.tag,sep=""))) {

      if(verbose) {
         cat(paste("Trying to load preprocessed pathway and opt. grid data from package for: ",preprocessed.tag,"\n",sep=""))
      }

      eval(parse(text=paste("data(pwdata.pathways.",preprocessed.tag,")",sep="")))
      eval(parse(text=paste("data(pwdata.optgrids.",preprocessed.tag,")",sep="")))

      pwdataFromPackage = TRUE
   }

   # check the tag for preprocessed pathway data (either from package or loaded otherwise):
   if (!exists(paste("pwdata.reac.genes.",preprocessed.tag,sep=""))
       || !exists(paste("pwdata.optimalGrid.",preprocessed.tag,sep=""))
       || !exists(paste("pwdata.pid2pname.",preprocessed.tag,sep=""))) {

       cat(paste("Error: no preprocessed pathway data for name tag: ",preprocessed.tag,"\n",sep=""))
       return(NULL)
   } else {
      if(verbose) {
         cat(paste("Found preprocessed pathway and opt. grid data from package for: ",preprocessed.tag,"\n",sep=""))
      }
   }

   pid2pname <- get(paste("pwdata.pid2pname.",preprocessed.tag,sep=""))

   # optimal grid arrangements
   optimalGrid <- get(paste("pwdata.optimalGrid.",preprocessed.tag,sep=""))

   # reaction to entrez mapping:
   reac.genes = get(paste("pwdata.reac.genes.",preprocessed.tag,sep=""))




   ## if we need to limit the analysis to metabolic KEGG pathways, immediately remove everything else from the (copied) pathway data!

   if (param.kegg.only_metabolism) {
       # reac.genes
       reac.genes = reac.genes[as.numeric(gsub("^[a-z]{2,3}","",gsub(":.*$","",reac.genes[,1]))) < DEF_KEGG_METABOLIC_PWAY_THRES,]

       # optimalGrid
       pways_optgrids = names(optimalGrid$data)
       names(pways_optgrids) = pways_optgrids
       pways_to_remove = names(pways_optgrids)[ ! ( as.numeric(gsub("^[a-z]{2,3}","",pways_optgrids)) < DEF_KEGG_METABOLIC_PWAY_THRES ) ]
       for (pw2r in pways_to_remove) {
       	   optimalGrid$data[[pw2r]] <- NULL
       }
   }



   ### GENE EXPRESSION AND CLASSES FOR COMPARISON

   # Gene expression data - numeric matrix with columns: samples, rows: genes (entrez gene ids as row.names)

   x.org = NULL
   if (is.data.frame(input.exprdata)) {
      x.org = input.exprdata
   } else {
      # must be a file name!
      if (verbose) {
         cat("Loading expression data\n")
      }

      x.org <- read.table(input.exprdata, check.names=FALSE, sep="\t", row.names=1, header=TRUE)
   }

   if(verbose) {
      cat(paste("Got an expresssion matrix with ",nrow(x.org)," rows(genes) and ",ncol(x.org)," columns(samples)\n",sep=""))
   }

   # do we have expression profiles without any variance (would make optim return an error)?
   varzero = row.names(x.org)[apply(x.org, 1, var) == 0]
   if (length(varzero) > 0) {
      cat("Warning: Excluding the following expression profiles with zero variance:\n --> ")
      cat(varzero)
      cat("\n")

      x.org = x.org[apply(x.org, 1, var) != 0,]
   }


   # Generate factor with class labels from class file
   y = NULL
   cl = NULL

   if (is.factor(input.sampleclasses)) {

      y = input.sampleclasses

   } else {

      # not a factor, must be a data frame or file name from which to build the factor

      cl = NULL

      if (is.data.frame(input.sampleclasses)) {
      	 cl = input.sampleclasses
      } else {
         # must be a file name!
         if (verbose) {
            cat("Loading information about sample classes\n")
         }

	 cl <- read.table(input.sampleclasses, sep="\t")

	 if (ncol(cl) != 2) {
	    stop("Error: the sample class file needs to have exactly two columns!")
	 }

      }

      # build factor
      #names = colnames(x.org)[colnames(x.org)!="row.names"]
      for(i in colnames(x.org)){
      	 y = c(y,as.vector(cl[,2])[i==cl[,1]])
      }
      y = as.factor(y)
   }

   if(verbose) {
      cat(paste("Having a class factor with ",length(levels(y))," classes for ",length(y)," samples: ",paste(levels(y),collapse=" "),"\n",sep=""))
   }

   if(length(levels(y)) != 2) {
      stop(paste("Error: exactly two sample classes required! Having: ",length(levels(y)),". Quitting!\n",sep=""))
   }
   


   # make sure we use only the subset of expression data that we have defined in the factor:
   # but do this only, if we had to build the factor ourselves!
   if (!is.factor(input.sampleclasses)) {
      if (verbose) {
      	 cat("Extracting relevant samples from expression data\n")
      }

      x.org <- x.org[,colnames(x.org) %in% cl[,1]]

      if(verbose) {
        cat(paste("Extracted an expresssion matrix with ",nrow(x.org)," rows(genes) and ",ncol(x.org)," columns(samples)\n",sep=""))
      }
   }

   ### COMPUTE EXPRESSION LEVELS FOR REACTIONS:
   # x will contain expression levels for reactions; x.org for genes


   if (verbose) {
      cat(paste("Computing expression levels for reactions for ",preprocessed.tag,"\n",sep=""))
   }


   x <- NULL
   x.names <- NULL
   for(i in 1:nrow(reac.genes)){
      reac.geneIDs <- unlist(strsplit(reac.genes[i,2],"~~~"))

      reac.chip <- NULL
      #rows <- grep(paste("^",j,"$",sep=""),rownames(x.org),perl=TRUE)
      rows <- match(reac.geneIDs,rownames(x.org))

      rows <- rows[!is.na(rows)]

      if(length(rows)>0){

	 help <- as.matrix(x.org[rows,1:ncol(x.org)])

	 if(dim(help)[1]>1) {
	    # more than one gene for this reaction; comute average!

	    helporg <- help
	    help <- as.matrix(apply(help,2,as.numeric))
	    help <- apply(help,2,mean,na.rm=TRUE)
	 }
	 else {
	    help <- as.numeric(help)
	 }

	 x <- rbind(x,help)
	 x.names <- c(x.names,reac.genes[i,1])
      }
   }

   rownames(x) <- x.names


   if (is.null(x)) {
      stop(paste("Error: cannot match expression data to metabolic reactions for ",preprocessed.tag,"! Wrong organism or gene IDs?",sep=""))
   }


   if(verbose) {
      cat(paste("Having an expresssion matrix with ",nrow(x)," rows(reactions) and ",ncol(x)," columns(samples)\n",sep=""))
   }


   if(nrow(x)<1 || ncol(x)<1) {
      stop(paste("Error: expression matrix for reactions with at least 2 rows and 2 columns required! Having: ",nrow(x)," rows; ",ncol(x)," columns. Quitting!\n",sep=""))
   }


   # z-transform gene expression data
   if (param.ztransform) {
      if (verbose) {
         cat("Performing z-transformation of reaction expression levels\n")
      }

      x <- t(apply(x,1,function(entry){(entry-mean(entry))/sd(entry)}))
   }


   ### NOW RUN THE CORE PATHWAY ANALYSIS!

   if (verbose) {
      cat("Running the core PathWave procedure\n")
   }

   pw <- pw.pathWave(x,y,optimalGrid, nperm = param.numperm, verbose = verbose)


   if (pwdataFromPackage == TRUE) {

      # if we used the pathway data from the package, remove it from the object list after using it

      remove(list=paste("pwdata.reac.genes.",preprocessed.tag,sep=""), pos=".GlobalEnv")
      remove(list=paste("pwdata.optimalGrid.",preprocessed.tag,sep=""), pos=".GlobalEnv")
      remove(list=paste("pwdata.pid2pname.",preprocessed.tag,sep=""), pos=".GlobalEnv")
   }

   ### POST-PROCESSING AND SAVING OF RESULTS:

   # save the complete results in an R data object!

   # saving compete results in one file, below
   #if (!is.null(output.file.prefix)) {
   #   outfile = paste(output.file.prefix,"-pw-results_all.rda",sep="")
   #   if (verbose) {
   #   	 cat(paste("Saving the complete results (object pw) to: ",outfile,"\n",sep=""))
   #   }
   #   save(file=outfile, pw)
   #}

   # filter the complete results:

   if (verbose) {
      cat("Performing statistical filtering of the results\n")
   }

   pw.r = NULL
   restable = NULL

   pw.r <-pw.result(pw, pvalCutoff = param.pvalue.threshold, genes = NULL,
   		    filter = TRUE, filter.size = param.filter.size,
		    multtest = param.pvalue.correction.method, verbose = verbose)

   if (!is.null(pw.r) && !is.null(pw.r$p.values)) {

      # saving compete results in one file, below
      #if (!is.null(output.file.prefix)) {
      #   outfile = paste(output.file.prefix,"-pw.r-results_filtered.rda",sep="")
      #   if (verbose) {
      #      cat(paste("Saving the filtered results (object pw.r) to: ",outfile,"\n",sep=""))
      #   }
      #   save(file=outfile, pw.r)
      #}

      restable <- pw.result.humanreadableTable.R(pw.r, pid2pname)

      if (!is.null(restable)) {

         if (!is.null(output.file.prefix)) {
            outfile = paste(output.file.prefix,"-pw-results_table.tsv",sep="")
            if (verbose) {
      	       cat(paste("Saving the filtered results as a human readable table to: ",outfile,"\n",sep=""))
            }
            write.table(restable, file=outfile, append=FALSE, quote=FALSE, sep="\t")
         }
      }
   } else {
     cat("No significant pathways that respect the filter options.\n")
   }


   # finally group the results and save them

   pwres <- list(results.all=pw, results.filtered=pw.r, results.table=restable)


   if (!is.null(output.file.prefix)) {
      outfile = paste(output.file.prefix,"-pw-results.rda",sep="")
      if (verbose) {
      	 cat(paste("Saving the complete results (object pwres) to: ",outfile,"\n",sep=""))
      }
      save(file=outfile, pwres)
   }


   # print summary results?
   if (verbose) {
      cat("\nSummary for results before filtering and correction for multiple testing:\n")
      pathWave.resultSummary(pw, digits=4)

      if(!is.null(pw.r)) {
         cat("Summary of significant and filtered results:\n")
         pathWave.resultSummary(pw.r, digits=4)
	 cat("\n")
      }
   }

   return(pwres)
}
