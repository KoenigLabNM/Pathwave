`pathWave.preprocessPathways` <-
function(preprocessed.tag=NULL, configfile="pathwave.preprocess.conf", input.file.pathwaydir=NULL,
				input.file.pathwayid2name=NULL, output.file.matrixdir=NULL,
				verbose=TRUE) {

   ### CONFIGURATION FILE?

   config = pw.readConf(configfile, verbose)


   ### GET PARAMETERS and FILE NAMES:

   if (is.null(preprocessed.tag)) {
      if (!is.null(config["preprocessed.tag"]) && !is.na(config["preprocessed.tag"])) {
         preprocessed.tag <- config["preprocessed.tag"]
      } else {
         cat("Error: preprocessed.tag neither specified in function call nor in the configuration file!\n") 
         return(NULL)
      }
   }
   if (verbose) {
      cat(paste("Using tag for preprocessed pathway data: ",preprocessed.tag,"\n",sep=""))
   }

   # location of KEGG pathways

   keggXMLpath = input.file.pathwaydir
   if (is.null(keggXMLpath)) {
      if (!is.null(config["input.file.pathwaydir"]) && !is.na(config["input.file.pathwaydir"])) {
         keggXMLpath <- config["input.file.pathwaydir"]
      } else {
         cat("Error: input.file.pathwaydir neither specified in function call nor in the configuration file!\n") 
         return(NULL)
      }
   }
   if (verbose) {
      cat(paste("Using path for XML files: ",keggXMLpath,"\n",sep=""))
   }

   # this is optional
   pwid2nameFile = input.file.pathwayid2name
   if (is.null(pwid2nameFile)) {
      if (!is.null(config["input.file.pathwayid2name"]) && !is.na(config["input.file.pathwayid2name"])) {
      	pwid2nameFile <- config["input.file.pathwayid2name"]
      }
   }

   if (verbose) {
      cat(paste("Using pathway ID to name mapping from: ",pwid2nameFile,"\n",sep=""))
   }


   # this is optional
   if (is.null(output.file.matrixdir)) {
      if (!is.null(config["output.file.matrixdir"]) && !is.na(config["output.file.matrixdir"])) {
      	output.file.matrixdir <- config["output.file.matrixdir"]
      }
   }

   if (verbose) {
      cat(paste("Writing produced matrices as files to the directory: ",output.file.matrixdir,"\n",sep=""))
   }

  

   ### LOAD AND PREPROCESS INPUT DATA:

   ## PATHWAYS:

   pwdata.pid2pname = NULL
   if (!is.null(pwid2nameFile)) {
      pwdata.pid2pname <- read.delim(pwid2nameFile, header=FALSE)
   }

   # load KEGG pathways
   if (verbose) {
      cat("Loading XML pathway files\n")
   }
   keggXML <- pw.KEGG(url=keggXMLpath, verbose=verbose)


   # compute adjacency matrices:

   if (is.null(output.file.matrixdir)) {
      if (verbose) {
      	 cat("Computing adjacency matrices for pathway networks\n")
      }

      adjMat <- pw.adjM(keggXML, printMatrices=FALSE, matrixType="adjacency")

   } else {
      # we have a directory for writing files! use it!
      if (verbose) {
      	 cat("Computing adjacency matrices for pathway networks and writing them as files\n")
      }

      adjMat <- pw.adjM(keggXML, printMatrices=TRUE, printDir=output.file.matrixdir, matrixType="adjacency",
      	     			 printSizeRequirement=FALSE)

   }


   # convert entries of kegg variable in a readable format
   #for(maps in names(keggXML$genes)){
   #   #names(keggXML$genes[[maps]])=gsub(";| |-|,|\\)|\\(","",names(keggXML$genes[[maps]]))
   #   names(keggXML$genes[[maps]])=gsub(" |-|\\)|\\(|\\[|\\]|\\*|\\+|\\?","",names(keggXML$genes[[maps]]))
   #}
   kegg <- keggXML$genes


   ### MAP ENTREZ GENE IDS TO REACTIONS:

   if (verbose) {
      cat("Mapping reactions to Entrez gene IDs\n")
   }

   pwdata.reac.genes <- NULL
   for(maps in names(kegg)){
      toDel <- NULL   
      duplicate.reactions <- unique(names(kegg[[maps]])[duplicated(names(kegg[[maps]]))])

      for(i in duplicate.reactions) {
         pwdata.reac.genes <- rbind(pwdata.reac.genes,c(i,paste(unique((kegg[[maps]])[grep(paste("^",i,"$",sep=""),names(kegg[[maps]]))]),collapse="~~~")))        
	 toDel <- c(toDel,grep(paste("^",i,"$",sep=""),names(kegg[[maps]])))
      } 

      if(is.null(toDel)){
      	 rest.reactions <- names(kegg[[maps]])
      } else {
         rest.reactions <- names(kegg[[maps]])[-toDel]
      }

      for(i in rest.reactions) {
	 pwdata.reac.genes <- rbind(pwdata.reac.genes,c(i,(kegg[[maps]])[grep(paste("^",i,"$",sep=""),names(kegg[[maps]]))]))
      }
   }

   colnames(pwdata.reac.genes) = c("pw:reac", "gene_list")


   index <- order(pwdata.reac.genes[,1])
   pwdata.reac.genes <- pwdata.reac.genes[index,]


   # now save only those objects that we need to run PathWave (but do it for this particular tag!):
   # pwdata.reac.genes, pwdata.pid2pname

   assign(paste("pwdata.reac.genes.",preprocessed.tag,sep=""), pwdata.reac.genes)
   assign(paste("pwdata.pid2pname.",preprocessed.tag,sep=""), pwdata.pid2pname)

   saveobjects = c(paste("pwdata.reac.genes.",preprocessed.tag,sep=""),
		   paste("pwdata.pid2pname.",preprocessed.tag,sep=""))

   pwdataFileName = paste("pwdata.pathways.",preprocessed.tag,".rda",sep="")
   if (verbose) {
      cat(paste("Saving preprocessed pathway data to: ",pwdataFileName,"\n",sep=""))
      cat(paste("Containing object: ",saveobjects,"\n",sep=""))
   }

   save(file=pwdataFileName, list=saveobjects)

}
