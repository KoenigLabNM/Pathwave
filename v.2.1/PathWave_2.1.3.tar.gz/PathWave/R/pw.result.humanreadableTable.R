`pw.result.humanreadableTable.R` <-
function(x, pid2pname=NULL) {

	    pw.r.table <- NULL
	    pathlist <- NULL

	    for (idx in seq(x$p.values)) {

	    	path <- names(x$p.values)[idx]

		if (!is.null(pid2pname)) {
		   pathname <- as.character(pid2pname[pid2pname[,1]==path,2])
		}
		else {
		   pathname <- path
		}

	    	p.val <- x$p.values[idx]

		num_upreg <- length(x$pathway[[path]]$reaction.regulation[x$pathway[[path]]$reaction.regulation == 1])

		num_nochange <- length(x$pathway[[path]]$reaction.regulation[x$pathway[[path]]$reaction.regulation == 0])

		num_downreg <- length(x$pathway[[path]]$reaction.regulation[x$pathway[[path]]$reaction.regulation == -1])

		regdir <- x$r.reg.direction


		pw.r.table <- rbind(pw.r.table, c(pathname,p.val,num_upreg,num_nochange,num_downreg,regdir))
		pathlist <- c(pathlist, path)
	    }

	    if (!is.null(pw.r.table)) {
	       colnames(pw.r.table) <- c("pathway.name","p.value","reactions.up","reactions.nochange","reactions.down","regulation.direction")
	       rownames(pw.r.table) <- pathlist
	    }

	    return(pw.r.table)
}
