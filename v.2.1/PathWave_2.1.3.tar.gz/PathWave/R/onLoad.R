.onLoad <- function(libname, pkgname){

     packageStartupMessage( "" )
     packageStartupMessage( "Welcome to PathWave" )
     packageStartupMessage( "-------------------" )
     packageStartupMessage( "" )
     packageStartupMessage( "Tags for available preprocessed pathways are:")
     packageStartupMessage( "BiGG.hsa - Human (H.sapiens) pathways from recon 1/BiGG")
     packageStartupMessage( "KEGG.hsa - Human (H.sapiens) pathways from KEGG")
     packageStartupMessage( "KEGG.mmu - Mouse (M.musculus) pathways from KEGG")
     packageStartupMessage( "KEGG.dme - Fly (D.melanogaster) pathways from KEGG")
     packageStartupMessage( "KEGG.dre - Zebrafish (D.rerio) pathways from KEGG")
     packageStartupMessage( "KEGG.cel - Worm (C.elegans) pathways from KEGG")
     packageStartupMessage( "KEGG.eco - Bacterial (E.coli) pathways from KEGG")
     packageStartupMessage( "" )
     packageStartupMessage( "See ?PathWave for a list of available functions." )
     packageStartupMessage( "" )

}
