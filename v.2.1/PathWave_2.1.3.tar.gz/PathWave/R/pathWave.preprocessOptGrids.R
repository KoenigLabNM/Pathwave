`pathWave.preprocessOptGrids` <-
function(preprocessed.tag=NULL, configfile="pathwave.preprocess.conf", input.file.pathwaydir=NULL,
				input.file.optgriddir=NULL, verbose=TRUE) {


   ### CONFIGURATION FILE?

   config = pw.readConf(configfile, verbose)


   ### GET PARAMETERS and FILE NAMES:

   if (is.null(preprocessed.tag)) {
      if (!is.null(config["preprocessed.tag"]) && !is.na(config["preprocessed.tag"])) {
         preprocessed.tag <- config["preprocessed.tag"]
      } else {
         cat("Error: preprocessed.tag neither specified in function call nor in the configuration file!\n") 
         return(NULL)
      }
   }
   if (verbose) {
      cat(paste("Using tag for preprocessed pathway data: ",preprocessed.tag,"\n",sep=""))
   }

   # location of KEGG pathways and optimized grids

   keggXMLpath = input.file.pathwaydir
   if (is.null(keggXMLpath)) {
      if (!is.null(config["input.file.pathwaydir"]) && !is.na(config["input.file.pathwaydir"])) {
         keggXMLpath <- config["input.file.pathwaydir"]
      } else {
         cat("Error: input.file.pathwaydir neither specified in function call nor in the configuration file!\n") 
         return(NULL)
      }
   }
   if (verbose) {
      cat(paste("Using path for XML files: ",keggXMLpath,"\n",sep=""))
   }

   optGridPath = input.file.optgriddir
   if (is.null(optGridPath)) {
      if (!is.null(config["input.file.optgriddir"]) && !is.na(config["input.file.optgriddir"])) {
      	 optGridPath <- config["input.file.optgriddir"]
      } else {
         cat("Error: input.file.optgriddir neither specified in function call nor in the configuration file!\n") 
         return(NULL)
      }
   }

   if (verbose) {
      cat(paste("Using path for optimized grid files: ",optGridPath,"\n",sep=""))
   }


   ### LOAD AND PREPROCESS INPUT DATA:

   ## PATHWAYS:

   # load KEGG pathways and optimal grid arrangements
   if (verbose) {
      cat("Loading XML pathway files\n")
   }
   keggXML <- pw.KEGG(url=keggXMLpath, verbose=verbose)

   if (verbose) {
      cat("Computing adjacency matrices for pathway networks\n")
   }
   adjMat <- pw.adjM(keggXML, printMatrices=FALSE, matrixType="adjacency")

   if (verbose) {
      cat("Loading optimal grid representations of pathways\n")
   }
   pwdata.optimalGrid <- pw.optGrid(optGridPath, adjMat, pattern="out$", verbose=verbose)


   # now save only those objects that we need to run PathWave (but do it for this particular tag!):
   # pwdata.optimalGrid

   assign(paste("pwdata.optimalGrid.",preprocessed.tag,sep=""), pwdata.optimalGrid)

   saveobjects = c(paste("pwdata.optimalGrid.",preprocessed.tag,sep=""))

   pwdataFileName = paste("pwdata.optgrids.",preprocessed.tag,".rda",sep="")
   if (verbose) {
      cat(paste("Saving preprocessed pathway data to: ",pwdataFileName,"\n",sep=""))
      cat(paste("Containing object: ",saveobjects,"\n",sep=""))
   }

   save(file=pwdataFileName, list=saveobjects)

}
