`pathWave.getColorKEGGMapURLs` <-
function(results.filtered, configfile="pathwave.run.conf", preprocessed.tag=NULL, col=c("green","grey","red"),col.sign.pattern=c("red","red","green"),verbose=FALSE){
	
   #require(KEGGSOAP)

   # need to use HTML "%23" instead of "#" if colors are specified as hexdecimal codes (e.g. "#004B00")
   col = gsub("#","%23",col)
   col.sign.pattern = gsub("#","%23",col.sign.pattern)

   config = pw.readConf(configfile, verbose)


   if (is.null(preprocessed.tag)) {
      if (!is.null(config["preprocessed.tag"]) && !is.na(config["preprocessed.tag"])) {
         preprocessed.tag <- config["preprocessed.tag"]
      } else {
         cat("Error: preprocessed.tag neither specified in function call nor in the configuration file!\n") 
         return(NULL)
      }
   }
   if (verbose) {
      cat(paste("Using preprocessed pathway data: ",preprocessed.tag,"\n",sep=""))
   }


   pwdataFromPackage = FALSE

   # try to load preprocessed data from the package?
   if (!exists(paste("pwdata.reac.genes.",preprocessed.tag,sep=""))) {

      if(verbose) {
         cat(paste("Trying to load preprocessed pathway data from package for: ",preprocessed.tag,"\n",sep=""))
      }

      eval(parse(text=paste("data(pwdata.pathways.",preprocessed.tag,")",sep="")))

      pwdataFromPackage = TRUE
   }

   # check the tag for preprocessed pathway data (either from package or loaded otherwise):
   if (!exists(paste("pwdata.reac.genes.",preprocessed.tag,sep=""))) {

       stop(paste("Error: no preprocessed pathway data for name tag: ",preprocessed.tag,sep=""))

   } else {
      if(verbose) {
         cat(paste("Found preprocessed pathway data from package for: ",preprocessed.tag,"\n",sep=""))
      }
   }

   # reaction to entrez mapping:
   reac.genes = get(paste("pwdata.reac.genes.",preprocessed.tag,sep=""))



   url <- list()
   path <- NULL

   for(p in seq(along=results.filtered$pathway)){

      obj_list <- results.filtered$pathway[[p]]$reaction

      #e.g. "hsa00280"
      path <- path.orig <- names(results.filtered$pathway)[p]


      # keep track what reactions are part of the pathway for this species, whether we have expression data or not:

      allPwReactions = gsub("^.[a-z]{2,3}\\d+:","rn:",reac.genes[grep(path,reac.genes[,1]),1])
      useReactions = FALSE


      for (idx in 1:length(obj_list)) {

         if (length(grep("^[a-z]{2,3}\\d+:R\\d+$", obj_list[idx]))!=0) {

            # this has the form "hsa00280:R0223334"; it's a reaction; we need to mark it as such with "rn:"

	    obj_list[idx] = gsub("^[a-z]{2,3}\\d+","rn", obj_list[idx])

	    useReactions = TRUE


         } else {

            # it's not a reaction; interpret it as a gene; 

	    #if (verbose) {
	    #   cat(paste(obj_list[idx]," is not a reaction; interpreting as gene: ", sep=""))
	    #}

	    if (length(reac.genes[grep(obj_list[idx],reac.genes[,1]),2][1]) != 1) {
	       cat(paste("ERROR: ", obj_list[idx], " -> ", reac.genes[grep(obj_list[idx],reac.genes[,1]),2][1] , "\n", sep=""))
	    }

	    obj_list[idx] = reac.genes[grep(obj_list[idx],reac.genes[,1]),2][1]

	    obj_list[idx] = gsub("~~~.*$","", obj_list[idx])


	    #if (verbose) {
	    #   cat(paste(obj_list[idx],"\n", sep=""))
	    #}
         }

      }

      reactionsWithoutExprdata = NULL

      if (useReactions) {

         # we ask KEGG for reactions, this can be done only on generic pathways, but we then need to re-annotate what reactions are present in the species
	 # even if we don't have expression data for it!
	 reactionsWithoutExprdata = allPwReactions[!(allPwReactions %in% obj_list)]

      	 # we can paint reactions only on generic pathway maps, so we need "map00280" instead of "hsa00280"
      	 path <- gsub("[a-z]{3}", "map", path)

      }


#		obj_list <- gsub("^[a-z]{2,3}\\d+","rn",results.filtered$pathway[[p]]$reaction)
#
#		# some of these objects may have been genes instead of reactions (R[0-9]+)
#		# (usually for non-metabolic pathways); remove the trailing "rn:" from these!
#
#		for (idx in 1:length(obj_list)) {
#		   if (length(grep("^rn:R\\d+$", obj_list[idx]))==0) {
#		      obj_list[idx] = gsub("^rn:","", obj_list[idx])
#		   }
#		}


      # set node colors:
      bg_list  <- col[results.filtered$pathway[[p]]$reaction.regulation+2]

      # set font colors:
      sigpattern = names(results.filtered$pathway[[p]]$reaction.regulation) %in% results.filtered$most.sign.pattern[[path.orig]]
      fg_list  <- rep("black",length(obj_list))
      fg_list[sigpattern] = col.sign.pattern[results.filtered$pathway[[p]]$reaction.regulation[sigpattern]+2]


      ##path <- paste("path:",names(results.filtered$pathway)[p],sep="")


      if (verbose) {
      	 cat(paste("Building URL for color map of pathway: ",path,"\n",sep=""))
      	 cat("with objects: ")
      	 cat(list=obj_list)
      	 cat("\n")
      	 cat("with foreground colors: ")
      	 cat(fg_list)
      	 cat("\n")
      	 cat("with background colors: ")
      	 cat(bg_list)
      	 cat("\n")

	 if (useReactions) {
	    cat("species-specific reactions without expression data: ")
	    cat(reactionsWithoutExprdata)
	    if (length(reactionsWithoutExprdata) == 0) {
	       cat("(none)")
	    }
	    cat("\n")
	 }
      }

      # we exclude KEGG pathways 01100 (e.g. hsa01100); these
      # correspond the the entire metabolism and take bloody ages
      #if (grepl("^path:[a-z]+01100$",path) == FALSE) {
      if (grepl("^[a-z]+01100$",path) == FALSE) {

         #url[[p]] <- color.pathway.by.objects(pathway.id=path,object.id.list=obj_list,fg.color.list=fg_list,bg.color.list=bg_list)


      	 restRequestUrl = paste("http://www.kegg.jp/kegg-bin/show_pathway?",path,sep="")

	 for (idx in 1:length(obj_list)) {
	     restRequestUrl = paste(restRequestUrl, "/", obj_list[idx], "%09", bg_list[idx], ",", fg_list[idx], sep="")
	 }

	 for (rWOE in reactionsWithoutExprdata) {
	     restRequestUrl = paste(restRequestUrl, "/", rWOE, "%09", "%23bfffbf", ",", "black", sep="")
	 }


	 url[[path.orig]] <- restRequestUrl



      } else {
      	 #url[[p]] <- "[ignoring pathway hsa01100 (entire metabolism)]"
	 cat(paste("Warning: ignoring ",path.orig,", \"Metabolic pathways\" (too complex).\n",sep=""))
      }

      if (verbose) {
         cat("\n")
      }
   }



   if (pwdataFromPackage == TRUE) {

      # if we used the pathway data from the package, remove it from the object list after using it

      remove(list=paste("pwdata.reac.genes.",preprocessed.tag,sep=""), pos=".GlobalEnv")
      remove(list=paste("pwdata.pid2pname.",preprocessed.tag,sep=""), pos=".GlobalEnv")
   }


   return(unlist(url))
}
