`pw.haarWT` <-
function(x,coord,size,count){

	ll <- matrix(0,nrow=sqrt(size),ncol=sqrt(size)/2)
	lh <- matrix(0,nrow=sqrt(size),ncol=sqrt(size)/2)

	for(i in seq(along=ll[1,])){
		ll[2*i-1,i] <- 0.5 
		ll[2*i,i] <- 0.5
		
		lh[2*i-1,i] <- -0.5
		lh[2*i,i] <- 0.5
	}
	hl <- rbind(-1*ll,ll)
	hh <- rbind(-1*lh,lh)
	ll <- rbind(ll,ll)
	lh <- rbind(lh,lh)

	LL <- matrix(0,nrow=size,ncol=size/4)
	LH <- matrix(0,nrow=size,ncol=size/4)
	HL <- matrix(0,nrow=size,ncol=size/4)
	HH <- matrix(0,nrow=size,ncol=size/4)
	for(i in 1:(ncol(LL)/ncol(ll))){
		LL[(1+(i-1)*(nrow(ll))):(i*nrow(ll)),(1+(i-1)*ncol(ll)):(i*ncol(ll))] <- ll
		LH[(1+(i-1)*(nrow(lh))):(i*nrow(lh)),(1+(i-1)*ncol(lh)):(i*ncol(lh))] <- lh
		HL[(1+(i-1)*(nrow(hl))):(i*nrow(hl)),(1+(i-1)*ncol(hl)):(i*ncol(hl))] <- hl
		HH[(1+(i-1)*(nrow(hh))):(i*nrow(hh)),(1+(i-1)*ncol(hh)):(i*ncol(hh))] <- hh
	}
	helpLL <- matrix(0,nrow=ncol(x),ncol=ncol(LL))
	helpLH <- matrix(0,nrow=ncol(x),ncol=ncol(LH))
	helpHL <- matrix(0,nrow=ncol(x),ncol=ncol(HL))
	helpHH <- matrix(0,nrow=ncol(x),ncol=ncol(HH))

	feat <- list()

	for(i in 1:ncol(x)){
		v <- x[,i]
		if(is.null(coord)){
			co <- which(v!=0)
			v <- v[co]
		} else {
			co <- coord
		}
		if(length(co)>1){
			helpLL[i,] <- v%*%LL[co,]
			helpLH[i,] <- v%*%LH[co,]
			helpHL[i,] <- v%*%HL[co,]
			helpHH[i,] <- v%*%HH[co,]
		} else {
			if(length(co)==1){
				helpLL[i,] <- v%*%t(LL[co,])
				helpLH[i,] <- v%*%t(LH[co,])
				helpHL[i,] <- v%*%t(HL[co,])
				helpHH[i,] <- v%*%t(HH[co,])
			}
		}
	}

	# find out which reactions are involved in the 2x2 subgrids:
	reac_involved <- as.vector(sapply(1:ncol(LL),function(ii){paste(names(v)[LL[co,ii] != 0],collapse="|")}))

	# for those without involved reactions, set the subgrid count as name:
	#reac_involved[which(reac_involved == "")] = which(reac_involved == "")


	names <- as.vector(sapply(c("LL","LH","HL","HH"),function(e){paste(e,count,1:ncol(helpLL),sep="_")}))


	# keep track of which reactions are involved in the single features:

	#names <- as.vector(sapply(c("LL","LH","HL","HH"),function(e){paste(e,count,reac_involved,sep="_")}))
	feature_reaction_list = rep(reac_involved, 4)



	# set the information on involved reactions as names ... needed to pass them to the next iteration of haarWT
	colnames(helpLL) = reac_involved
	colnames(helpLH) = reac_involved
	colnames(helpHL) = reac_involved
	colnames(helpHH) = reac_involved

	feat <- list(ll=t(helpLL),lh=t(helpLH),hl=t(helpHL),hh=t(helpHH),names=names, feature_reaction_list=feature_reaction_list)

	return(feat)
}

