# 2011-04; R.M. Piro changed: added debug messages

`pw.adjM` <-
function(x,printMatrices=FALSE,printDir=NULL,matrixType="adjacency",
	 printSizeRequirement=FALSE, debug=FALSE){

	require(e1071)
 
	if(is.null(x) || class(x)!="PathWave"){
		stop("x must be the result of pw.KEGG() and of class 'PathWave'!")
	} else {
		kegg.maps.names <- names(x$reactions)
		kegg.maps.matrices <- list()
		
		for(map in kegg.maps.names){

			reactions <- x$reactions[[map]]
			compList <- x$compounds[[map]]
			relations <- x$relations[[map]]

			if(debug) {
					cat(paste("Debug message: processing KEGG map", map),sep="\n")
					cat("Debug message: having reactions:",sep="\n")
					str(reactions)
					cat("Debug message: having compounds:",sep="\n")
					str(compList)
					cat("Debug message: having relations:",sep="\n")
					str(relations)
			}

			if(length(reactions)>1){ 
				reaction.connect <- list()
				for(i in reactions){
					reaction1 <- compList[[i]]

					if (debug) {
					   cat (paste("Debug message: compounds for reaction", i),sep="\n")
					   str(reaction1)
					}

					if(!is.null(reaction1)){
						reaction.value <- NULL
						for(j in reactions){
							if(i!=j){
								reaction2 <- compList[[j]]
								if(!is.null(reaction2)){
									if(length(reaction1[!is.na(match(reaction1,reaction2))])>0){
										reaction.value <- c(reaction.value,j)

										if (debug) {
										   cat (paste("Debug message: Found link: reaction", i,"<--> reaction",j),sep="\n")
										}
									}
								}
							}
						}
						reaction.connect[[i]] <- reaction.value
					}
				}
				M <- matrix(0,nrow=length(reactions),ncol=length(reactions))
				rownames(M) <- reactions
				colnames(M) <- reactions

				for(i in names(reaction.connect)){
					M[match(i,colnames(M)),match(reaction.connect[[i]],colnames(M))] <- 1
					M[match(reaction.connect[[i]],colnames(M)),match(i,colnames(M))] <- 1

					if (debug) {
				   	   cat (paste("Debug message: Searching matches for reaction", i),sep="\n")
					}

				}
				M.elements <- names(x$relations[[match(map,names(x$relations))]])
	
				for(i in M.elements){
					connected.elements <- x$relations[[map]][[match(i,names(x$relations[[map]]))]]
					for(j in connected.elements){
						M[match(i,rownames(M)),match(j,colnames(M))] <- 1
						M[match(j,rownames(M)),match(i,colnames(M))] <- 1
					}
				}	
				diag(M) <- 0	
		
				if(max(M)>0){

					if (debug) {
				   	   cat ("Debug message: Having non-empty matrix",sep="\n")
					}

					M.org <- M
					M[M==0] <- Inf
	
					dist.matrix <- allShortestPaths(M)$length
					rownames(dist.matrix) <- reactions
					colnames(dist.matrix) <- reactions
					dist.max <- max(na.omit(as.vector(dist.matrix)))  
	
					dist.matrix[is.na(dist.matrix)] <- Inf
	  
					if((dist.max^2) < length(unique(rownames(M)))){
						dist.max  <-  (round(sqrt(length(unique(rownames(M)))),digits=0)+1)
					}
	  	   	  
					diag(dist.matrix) <- 0
			
					if(printMatrices){

						if (debug) {
						   cat ("Debug message: Writing matrix to file",sep="\n")
						}

						if(matrixType=="distance"){
							cat(paste(dim(M)[1],"\n",sep=""),file=paste(printDir,"/",map,".dist",".matrix",sep=""))

							if (printSizeRequirement==TRUE) {
							   cat(paste(dist.max,"\n",sep=""),file=paste(printDir,"/",map,".dist",".matrix",sep=""),append=TRUE)
							} else {
							   cat(paste("0","\n",sep=""),file=paste(printDir,"/",map,".dist",".matrix",sep=""),append=TRUE)
							}

							write.table(dist.matrix,file=paste(printDir,"/",map,".dist",".matrix",sep=""),col.names=FALSE,row.names=FALSE,append=TRUE)
						} else {
							cat(paste(dim(M)[1],"\n",sep=""),file=paste(printDir,"/",map,".matrix",sep=""))

							if (printSizeRequirement==TRUE) {
							   cat(paste(dist.max,"\n",sep=""),file=paste(printDir,"/",map,".matrix",sep=""),append=TRUE)
							} else {
							   cat(paste("0","\n",sep=""),file=paste(printDir,"/",map,".matrix",sep=""),append=TRUE)
							}

							write.table(M.org,file=paste(printDir,"/",map,".matrix",sep=""),col.names=FALSE,row.names=FALSE,append=TRUE)
						}
					}	
					kegg.maps.matrices[[map]] <- list(nNodes=dim(M)[1],iMax=dist.max,M=M.org,dist=dist.matrix)
				}
				else {
				     if (debug) {
				     	cat ("Debug message: Warning: matrix is empty or has no non-zero values!",sep="\n")
				     }
				}
			}
			else {
			     if (debug) {
			     	cat ("Debug message: warning: less than 2 reactions!",sep="\n")
			     }
			}
		}
		xname <- deparse(substitute(x))
		fcall <- call("pw.adjM",x=xname,printMatrices=printMatrices,printDir=printDir,matrixType=matrixType)
		res <- list(call=fcall,version=x$version,url=x$url,data=kegg.maps.matrices)
		class(res)="PathWave"
    
		return(res)
	}
}

