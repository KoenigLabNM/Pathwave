`pw.readConf` <-
function(configfile=NULL, verbose=FALSE){

   confTable = NULL
   config = NULL

   if (!is.null(configfile) && file_test("-f", configfile)) {

      # first read the configuration file into a table:
      confTable = read.csv(file=configfile, quote = "", header=FALSE, sep="=")

      # remove initial and trailing spaces of value:
      confTable = gsub("^[[:space:]]*","",gsub("[[:space:]]*$","",gsub("\"","",as.matrix(confTable))))

      # remove commented lines:
      confTable <- confTable[grep("^#", confTable[,1], invert=TRUE),]


      # make sure this is a matrix with two columns!
      if (is.null(dim(confTable))) {
         confTable <- matrix(confTable,ncol=2)
      }

      # convert the configuration table into a named vector for easy accessability
      config = NULL
      for (cfi in 1:dim(confTable)[1]) {
      	 config = c(config, confTable[cfi,2])
         names(config)[cfi] = confTable[cfi,1]
      }

      # print configuration
      if (verbose) {
         cat(paste("Loaded configuration from file: ",configfile,"\n",sep=""))
         print(config)
      }

   } else {
      if (verbose) {
         cat(paste("No configuration file: ",configfile,"\n",sep=""))
      }
   }

   return(config)
}