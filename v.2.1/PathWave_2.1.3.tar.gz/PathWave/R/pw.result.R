'pw.result'<-
function(x,pvalCutoff=0.01,genes=NULL,filter=TRUE,filter.size=3,multtest="Bonferroni",verbose=TRUE){
	require(multtest)

	FILTER_NOT_PASSED=-111

	if(class(x)=="PathWave"){
		optimalM <- x$oM$data
		if(is.null(optimalM)){
			stop("ERROR: no list element 'oM' found!")
		} else {
			feat.pval.sig <- x$feat.p.value[x$feat.p.value<=pvalCutoff]
			r.reg <- x$r.reg
			r.pval <- x$r.p.value
			r.reg[r.pval>pvalCutoff] <- 0

			pval <- x$p.value
			if(!is.null(multtest)){
				mTest.proc <- c("Bonferroni","Holm","Hochberg","SidakSS","SidakSD","BH","BY")
				proc <- mTest.proc[match(multtest,mTest.proc)]
				if(is.na(proc)){
					warning("Multitesting correction was set to 'Bonferroni'")
					proc <- "Bonferroni"
				}
				c.pval <- mt.rawp2adjp(pval,proc)
				pval.adj <- c.pval$adjp[order(c.pval$index),]
				if(is.matrix(pval.adj)){
					pval <- pval.adj[,2]
				} else {
					pval <- pval.adj[2]
				}
			}
			names(pval) <- names(x$p.value)
			pval.sig <- pval[pval<=pvalCutoff]

			if(length(pval.sig)==0){
				warning("WARNING: For the chosen p.value cutoff and filter options, PathWave could not detect any pathway with a significant pattern!")
				return(NULL)
			} else {
				pval.filter.sig <- NULL
				reac.res <- list()

				most.sign.pattern <- list()

				for(p in seq(along=pval.sig)){
					map <- names(pval.sig)[p]
					map.features <- feat.pval.sig[grep(paste("^",map,"\\:",sep=""),names(feat.pval.sig))]

					reac <- NULL
					for(i in seq(along=map.features)){
# 						wt <- unlist(strsplit(names(map.features)[i],split="_"))
# 						wt.type <- unlist(strsplit(wt[1],split=":"))[2]
						
						wt <- unlist(strsplit(names(map.features)[i],split=":"))
						wt.type <- unlist(strsplit(wt[2],split="_"))[1]
						wt <- unlist(strsplit(wt[2],split="_"))

						M <- optimalM[[map]][[wt.type]]

						if(is.null(ncol(M)) || ncol(M)<=1){
							M.size <- 2
						} else {
							M.size <- 2^(ceiling(log(ncol(M),base=2)))
						}

						h <- as.numeric(wt[length(wt)])
						for(j in as.numeric(wt[length(wt)-1]):1){
							Ms <- M.size/(2^(j-1))
							h <- c((2*h-1)+floor((h-0.1)/(Ms/2))*Ms,(2*h)+floor((h-0.1)/(Ms/2))*Ms)
							h <- c(h,h+Ms)
						}
						h <- sort(h)

						m <- nrow(as.matrix(M))
						n <- M.size-m
						if(ncol(M)%%2==0){
							if(wt[2]=="org"){
								r <- as.vector(M) 
								hr <- which(r!="0")
								r <- r[hr]
								hr <- hr+floor((hr-0.1)/m)*n
							}
							if(wt[2]=="row"){
								r <- as.vector(M[-c(1,nrow(M)),]) 
								hr <- which(r!="0")
								r <- r[hr]
								hr <- hr+floor((hr-0.1)/(m-2))*(n+2)
							}
							if(wt[2]=="col"){
								r <- as.vector(M[,-c(1,ncol(M))]) 
								hr <- which(r!="0")
								r <- r[hr]
								hr <- hr+floor((hr-0.1)/m)*n
							}
							if(wt[2]=="total"){
								r <- as.vector(M[-c(1,nrow(M)),-c(1,ncol(M))])
								hr <- which(r!="0")
								r <- r[hr]
								hr <- hr+floor((hr-0.1)/(m-2))*(n+2) 
							}
						} else {
							if(wt[2]=="org"){
								r <- as.vector(M[-nrow(M),-ncol(M)])
								hr <- which(r!="0")
								r <- r[hr]
								hr <- hr+floor((hr-0.1)/(m-1))*(n+1)
							}
							if(wt[2]=="row"){
								r <- as.vector(M[-1,])
								hr <- which(r!="0")
								r <- r[hr]
								hr <- hr+floor((hr-0.1)/(m-1))*(n+1)
							}
							if(wt[2]=="col"){
								r <- as.vector(M[,-1])
								hr <- which(r!="0")
								r <- r[hr]
								hr <- hr+floor((hr-0.1)/m)*n
							}
							if(wt[2]=="total"){
								r <- as.vector(M[-1,-1])
								hr <- which(r!="0")
								r <- r[hr]
								hr <- hr+floor((hr-0.1)/(m-1))*(n+1)
							}
						}
						r <- r[match(h,hr)]
						r <- r[!is.na(r)]
						reac <- c(reac,r)
					}
					reac <- unique(reac)

					if(filter){
						map.r.reg <- r.reg[na.omit(match(reac,names(r.reg)))]
						help <- pw.filter(map.r.reg,genes[[map]],filter.size)
						if(help[1] != FILTER_NOT_PASSED){
							pval.filter.sig <- c(pval.filter.sig,pval.sig[p])
							map.r.pval <- r.pval[match(names(map.r.reg),names(r.pval))]
							reac.res[[map]] <- list(reaction=names(map.r.reg),reaction.p.value=map.r.pval,reaction.regulation=map.r.reg)

							# get the reactions/genes involved in the most significant pattern (that gave the p-value):

							#featname = names(sort(x$feat.p.value[grep(paste("^",map,"\\:",sep=""),names(x$feat.p.value))])[1])
							#most.sign.pattern[[map]] = unlist(strsplit(x$feat.reaction_list[names(x$feat.reaction_list)==featname],"\\|"), use.names=FALSE)

							this.pw.feat = x$feat.p.value[grep(paste("^",map,"\\:",sep=""),names(x$feat.p.value))]
							min.feat.p.val = sort(this.pw.feat)[1]
							sigfeatnames = names(this.pw.feat[this.pw.feat==min.feat.p.val])
							most.sign.pattern[[map]] = unique(unlist(strsplit(x$feat.reaction_list[names(x$feat.reaction_list) %in% sigfeatnames],"\\|"),use.names=FALSE))

						}
					} else {
						pval.filter.sig <- c(pval.filter.sig,pval.sig[p])
						map.r.reg <- r.reg[na.omit(match(reac,names(r.reg)))]
						map.r.pval <- r.pval[match(names(map.r.reg),names(r.pval))]
						reac.res[[map]] <- list(reaction=names(map.r.reg),reaction.p.value=map.r.pval,reaction.regulation=map.r.reg)

						# get the reactions/genes involved in the most significant pattern (that gave the p-value):

						#featname = names(sort(x$feat.p.value[grep(paste("^",map,"\\:",sep=""),names(x$feat.p.value))])[1])
						#most.sign.pattern[[map]] = unlist(strsplit(x$feat.reaction_list[names(x$feat.reaction_list)==featname],"\\|"), use.names=FALSE)

						this.pw.feat = x$feat.p.value[grep(paste("^",map,"\\:",sep=""),names(x$feat.p.value))]
						min.feat.p.val = sort(this.pw.feat)[1]
						sigfeatnames = names(this.pw.feat[this.pw.feat==min.feat.p.val])
						most.sign.pattern[[map]] = unique(unlist(strsplit(x$feat.reaction_list[names(x$feat.reaction_list) %in% sigfeatnames],"\\|"),use.names=FALSE))

					}

					
				}
			}
		}
		dname <- deparse(substitute(x))
		if(!is.null(genes)){
			gname <- deparse(substitute(genes))
		} else {
			gname=NULL
		}



		fcall <- call("pw.result",x = dname,pvalCutoff=pvalCutoff,genes=gname,filter=filter,filter.size=filter.size,multtest=multtest,verbose=verbose)
		res <- list(call=fcall,version=x$oM$version,url=x$oM$url,pvalCutoff=pvalCutoff,filter=filter,filter.size=filter.size,multtest=multtest,p.values=pval.filter.sig,r.reg.direction=x$r.reg.direction,pathway=reac.res,most.sign.pattern=most.sign.pattern)
		class(res) <- "PathWave"
		return(res)
	} else {
		stop("ERROR: input is not of class 'PathWave'!")
	}
}
