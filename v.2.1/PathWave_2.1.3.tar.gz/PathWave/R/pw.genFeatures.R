`pw.genFeatures` <-
function(x,optimalM,verbose){

	feat.all <- NULL

	feat.all.reaction_list <- NULL

	no <- 1
	for(map in names(optimalM)){
		if(verbose){
			cat(paste("PathWave:",paste("Generate features for pathway: ",map,", (",no," of ",length(optimalM),")!",sep=""),sep="\t"),sep="\n")
			no <- no + 1
		}
		#generate features for all optimal arranged maps (pathway maps + components)
		for(component in names(optimalM[[map]])){
			count <- 1

			M <- optimalM[[map]][[component]]
		
			#set size of matrix -> must be 2^n
			if(is.null(ncol(M)) || ncol(M)<=1){
				M.size <- 2
			} else {
				M.size <- 2^(ceiling(log(ncol(M),base=2)))
			}
			sizes <- 4 * (4^((log2(M.size)-1):0))

			feat <- matrix(0,nrow=4*sum(sizes),ncol=ncol(x))
			rownames(feat) <- paste("dummy",1:nrow(feat),sep="_")

			# for keeping a mapping from feature names to involved reactions
			feat.r_list <- rep("", 4*sum(sizes))


			#get the reactions of the pathway analysed. 
			#For this is is important, that the reaction names are named according to pathway_ID:Reaction_ID!!
			reac <- grep(paste("^",map,":",sep=""),rownames(x),value=TRUE)
		
			m <- nrow(as.matrix(M))
			n <- M.size - m
			if(ncol(M) %% 2 == 0){
				help <- match(reac,as.vector(M))
				help <- help + floor((help - 0.1)/m) * n

				help.row <- match(reac,as.vector(M[-c(1,nrow(M)),]))
				help.row <- help.row + floor((help.row - 0.1)/(m - 2)) * (n + 2)

				help.col <- match(reac,as.vector(M[,-c(1,ncol(M))]))
				help.col <- help.col + floor((help.col - 0.1)/m) * n
				
				help.total <- match(reac,as.vector(M[-c(1,nrow(M)),-c(1,ncol(M))]))
				help.total <- help.total + floor((help.total - 0.1)/(m - 2)) * (n + 2) 
			} else{
				help <- match(reac,as.vector(M[-nrow(M),-ncol(M)]))
				help <- help + floor((help - 0.1)/(m - 1)) * (n + 1)

				help.row <- match(reac,as.vector(M[-1,]))
				help.row <- help.row + floor((help.row - 0.1)/(m - 1)) * (n + 1)

				help.col <- match(reac,as.vector(M[,-1]))
				help.col <- help.col + floor((help.col - 0.1)/m) * n
				
				help.total <- match(reac,as.vector(M[-1,-1]))
				help.total <- help.total + floor((help.total - 0.1)/(m - 1)) * (n + 1)
			}
			t <- which(!is.na(help))
			t.row <- which(!is.na(help.row))
			t.col <- which(!is.na(help.col))
			t.total <- which(!is.na(help.total))

			v <- x[grep(map,rownames(x)),,drop=FALSE]

			feat.org <- pw.haarWT(v[t,,drop=FALSE],help[t],M.size^2,count)
			feat.row <- pw.haarWT(v[t.row,,drop=FALSE],help.row[t.row],M.size^2,count)
			feat.col <- pw.haarWT(v[t.col,,drop=FALSE],help.col[t.col],M.size^2,count)
			feat.total <- pw.haarWT(v[t.total,,drop=FALSE],help.total[t.total],M.size^2,count)

			s <- sizes[count]
			feat[1:s,] <- rbind(feat.org$ll,feat.org$lh,feat.org$hl,feat.org$hh)
			feat[(s+1):(2*s),] <- rbind(feat.row$ll,feat.row$lh,feat.row$hl,feat.row$hh)
			feat[(2*s+1):(3*s),] <- rbind(feat.col$ll,feat.col$lh,feat.col$hl,feat.col$hh)
			feat[(3*s+1):(4*s),] <- rbind(feat.total$ll,feat.total$lh,feat.total$hl,feat.total$hh)

			rownames(feat)[1:(4*s)] <- c(paste(paste(map,component,sep=":"),"org",feat.org$names,sep="_"),
											paste(paste(map,component,sep=":"),"row",feat.row$names,sep="_"),
											paste(paste(map,component,sep=":"),"col",feat.col$names,sep="_"),
											paste(paste(map,component,sep=":"),"total",feat.total$names,sep="_"))

			# keep mapping of feature names to associated, involved reactions:
			feat.r_list[1:s] <- feat.org$feature_reaction_list
			feat.r_list[(s+1):(2*s)] <- feat.row$feature_reaction_list
			feat.r_list[(2*s+1):(3*s)] <- feat.col$feature_reaction_list
			feat.r_list[(3*s+1):(4*s)] <- feat.total$feature_reaction_list
			names(feat.r_list)[1:(4*s)] <- rownames(feat)[1:(4*s)]


			while(nrow(feat.org$ll)>1){
				count <- count+1
				feat.org <- pw.haarWT(feat.org$ll,NULL,nrow(feat.org$ll),count)
				feat.row <- pw.haarWT(feat.row$ll,NULL,nrow(feat.row$ll),count)
				feat.col <- pw.haarWT(feat.col$ll,NULL,nrow(feat.col$ll),count)
				feat.total <- pw.haarWT(feat.total$ll,NULL,nrow(feat.total$ll),count)
			
				s <- sizes[count]
				ss <- 4*sum(sizes[1:(count-1)])
				feat[ss+(1:s),] <- rbind(feat.org$ll,feat.org$lh,feat.org$hl,feat.org$hh)
				feat[ss+((s+1):(2*sizes[count])),] <- rbind(feat.row$ll,feat.row$lh,feat.row$hl,feat.row$hh)
				feat[ss+((2*s+1):(3*sizes[count])),] <- rbind(feat.col$ll,feat.col$lh,feat.col$hl,feat.col$hh)
				feat[ss+((3*s+1):(4*sizes[count])),] <- rbind(feat.total$ll,feat.total$lh,feat.total$hl,feat.total$hh)
	
				rownames(feat)[ss+(1:(4*s))] <- c(paste(paste(map,component,sep=":"),"org",feat.org$names,sep="_"),
													paste(paste(map,component,sep=":"),"row",feat.row$names,sep="_"),
													paste(paste(map,component,sep=":"),"col",feat.col$names,sep="_"),
													paste(paste(map,component,sep=":"),"total",feat.total$names,sep="_"))

				# keep mapping of feature names to associated, involved reactions:
				feat.r_list[ss+(1:s)] <- feat.org$feature_reaction_list
				feat.r_list[ss+((s+1):(2*sizes[count]))] <- feat.row$feature_reaction_list
				feat.r_list[ss+((2*s+1):(3*sizes[count]))] <- feat.col$feature_reaction_list
				feat.r_list[ss+((3*s+1):(4*sizes[count]))] <- feat.total$feature_reaction_list
				names(feat.r_list)[ss+(1:(4*s))] <- rownames(feat)[ss+(1:(4*s))]

			}
			z <- sapply(apply(feat,1,sd),all.equal,0)
			todel <- which(z==TRUE)
			feat <- feat[-todel,,drop=FALSE]
			feat.all <- rbind(feat.all,feat)

			# keep mapping of feature names to associated, involved reactions:
			feat.r_list <- feat.r_list[-todel]
			feat.all.reaction_list = c(feat.all.reaction_list, feat.r_list)
		}
	}

	return(list(feat=feat.all,feat_reaction_list=feat.all.reaction_list))
}



