# 2011-04; R.M. Piro changed: added debug messages

`pw.KEGG` <-
function(url="ftp://ftp.genome.jp/pub/kegg/xml/kgml/metabolic/organisms/hsa/",verbose=TRUE, debug=FALSE){
	require(RCurl)
	require(XML)
  
	all.list <- list()
	id.list <- list()
	gene.list <- list()
	reaction.list <- list()
	compound.list <- list()
	relation.list <- list()
  
	url.error <- FALSE
  
	url <- sub("/$","",url)
	url <- paste(url,"/",sep="")
    
	if(length(grep("^ftp",url))){
		fileNames <- getURL(url, .opts=list(customrequest=paste("NLST","*.xml",sep=" ")))
		fileNames <- unlist(strsplit(fileNames,"\\\n"))
		fileNames <- unlist(strsplit(fileNames,"\\\r"))
	} else {
		if(length(grep("^http",url))){
			helpFiles <- getURL(url)
			helpFiles <- grep("\\.xml",unlist(strsplit(helpFiles,"</a>")),value=TRUE)
			help <- gregexpr("<a href=.*\\.xml\">",helpFiles)
			fileNames <- NULL
			for(i in seq(along=help)){
				fileNames <- c(fileNames,gsub("<a href=|\"|>","",substr(helpFiles[i],help[[i]][1],attributes(help[[i]])$match.length[1]+help[[i]][1]-1)))
			}
			fileNames <- unique(fileNames)
		} else {
			fileNames <- dir(url)
		}
	}   
	fileNames <- grep("xml$",fileNames,value=TRUE)
	if(length(fileNames)==0){
		stop(paste("There are no xml files in",url,"!",sep=" ")) 
	}
  
	for(files in fileNames){
		if(verbose){
			cat(paste("Processing:",files,sep="\t"),sep="\n")
		}
		help.ids.list <- list()   
		help.group.list <- list()
		help.ids <- NULL
		help.ids.reactions <- NULL  
		help.genes.reactions <- NULL
		help.genes <- NULL
    
		kegg.map <- sub(".xml$","",files)

		# 2012-05; R.M.Piro added:

		# need to remove or convert special characters of regular expressions
		kegg.map <- gsub("-|\\)|\\(|\\[|\\]|:|\\*|\\?","_",kegg.map)
		kegg.map <- gsub("\\+","plus",kegg.map)

		# 2012-05; end R.M.Piro added


		xml <- xmlTreeParse(paste(url,files,sep=""),isURL=TRUE,fullNamespaceInfo=TRUE,asTree=TRUE)
		var.names <- names(xmlChildren(xml$doc$children[["pathway"]]))
  
		entry.tag <- grep("entry",var.names)
		relation.tag <- grep("relation",var.names)
		reaction.tag <- grep("reaction",var.names)
  
		for(entry in entry.tag){

			type <- xmlGetAttr(xml$doc$children[["pathway"]][[entry]], "type")
			ids <- xmlGetAttr(xml$doc$children[["pathway"]][[entry]], "id")
			genes <- xmlGetAttr(xml$doc$children[["pathway"]][[entry]], "name")
			reactions <- xmlGetAttr(xml$doc$children[["pathway"]][[entry]], "reaction")

			if (debug) {
			   cat("Debug message: processing entry:",sep="\n")
			   str(entry)
			   cat(paste("Debug message: having type:",type),sep="\n")
			   cat(paste("Debug message: having ids:",ids),sep="\n")
			   cat(paste("Debug message: having name:",genes),sep="\n")
			   cat(paste("Debug message: having reactions:",reactions),sep="\n")
			}


			if(type=="gene"){
				genes <- gsub(paste("\\w+:",sep=""),"",genes)
				genes <- unlist(strsplit(genes," "))

				if (debug) {
				   cat(paste("Debug message: Gene entry! Having gene(s)",genes),sep="\n")
				}

				if(is.null(reactions)){	  

					# 2011-04 to 2012-05; R.M. Piro changed: to cope with KGML_v0.7.1 (KEGG XML files v.0.7.1)
					# reactions <- xmlGetAttr(xml$doc$children[["pathway"]][[entry]]$children[[1]],"name")
					
					reactions <- gsub(" ","",xmlGetAttr(xml$doc$children[["pathway"]][[entry]]$children[[1]],"name"))

					#need to remove or convert special characters of regular expressions
					reactions <- gsub("-|\\)|\\(|\\[|\\]|:|\\*|\\?","_",reactions)
					reactions <- gsub("\\+","plus",reactions)
					
					# 2011-04; end R.M. Piro changed
					
					reactions <- gsub("\\.\\.\\.","",reactions)


					if (debug) {
					   cat(paste("Debug message: no reactions for this entry, using gene IDs: ", reactions), sep="\n")
					}

				} else{	  
					reactions <- unlist(strsplit(reactions," "))	  
					reactions <- gsub("^\\w+:","",reactions)

					# 2012-05; R.M. Piro added:

					#need to remove or convert special characters of regular expressions
					reactions <- gsub("-|\\)|\\(|\\[|\\]|:|\\*|\\?","_",reactions)
					reactions <- gsub("\\+","plus",reactions)

					# 2012-05; end R.M. Piro added

					if (debug) {
					   cat(paste("Debug message: got reactions from entry's attribute: ", reactions), sep="\n")
					}

				}
				reactions <- paste(kegg.map,reactions,sep=":")

				if (debug) {
					   cat(paste("Debug message: kegg_map:reactions =", reactions), sep="\n")
				}

				if(is.na(match(kegg.map,names(reaction.list)))){   
					reaction.list[[kegg.map]] <- unique(reactions)
				} else{
					reaction.list[[match(kegg.map,names(reaction.list))]] <- unique(c(reaction.list[[match(kegg.map,names(reaction.list))]],reactions))
				}
	  
				for(reac in reactions){
					help.ids <- c(help.ids,ids)
					help.ids.reactions <- c(help.ids.reactions,reac)
					help.genes <- c(help.genes,genes)
					help.genes.reactions <- c(help.genes.reactions,rep(reac,length(genes)))
				}
			}
			if(type=="group"){  
				comp.no <- grep("component",names(xml$doc$children[["pathway"]][[entry]]$children))
	
				components <- NULL
				for(i in comp.no){
					components <- c(components,xmlGetAttr(xml$doc$children[["pathway"]][[entry]]$children[[i]],"id"))
				}
				if(is.na(match(ids,names(help.group.list)))){
					help.group.list[[ids]] <- components	
				} else{
					help.group.list[[match(ids,names(help.group.list))]] <- unique(c(help.group.list[[match(ids,names(help.group.list))]],components))
				}
			}
		}
		names(help.ids) <- help.ids.reactions
		names(help.genes) <- help.genes.reactions

		if(length(help.ids) == length(help.ids.reactions)){
			for(i in seq(along=help.ids)){
				if(is.na(match(help.ids[i],names(help.ids.list)))){
					help.ids.list[[help.ids[i]]] <- help.ids.reactions[i]
				} else{
					help.ids.list[[match(help.ids[i],names(help.ids.list))]] <- c(help.ids.list[[match(help.ids[i],names(help.ids.list))]],help.ids.reactions[i])
				}
			}
		}

		for(i in names(help.group.list)){
			comp <- help.group.list[[match(i,names(help.group.list))]]
			components <- NULL
			for(j in comp){
				components <- c(components,help.ids.list[[match(j,names(help.ids.list))]])
			}
			if(is.na(match(i,names(help.ids.list)))){
				help.ids.list[[i]] <- components
			} else{
				help.ids.list[[match(i,names(help.ids.list))]] <- c(help.ids.list[[match(i,names(help.ids.list))]],components)
			}
		}
    
		if(is.na(match(kegg.map,names(id.list)))){    
			id.list[[kegg.map]] <- help.ids
			gene.list[[kegg.map]] <- help.genes
		} else{
			id.list[[match(kegg.map,names(id.list))]] <- help.ids
			gene.list[[match(kegg.map,names(gene.list))]] <- help.genes
		}
		help.list <- list()
		for(reaction in reaction.tag){
      
			reaction.id <- xmlGetAttr(xml$doc$children[["pathway"]][reaction]$reaction,"name")
			reaction.id <- unlist(strsplit(reaction.id," "))
			reaction.id <- gsub("^\\w+:","",reaction.id)

			# 2012-05; R.M. Piro added:

			#need to remove or convert special characters of regular expressions
			reaction.id <- gsub("-|\\)|\\(|\\[|\\]|:|\\*|\\?","_",reaction.id)
			reaction.id <- gsub("\\+","plus",reaction.id)

			# 2012-05; end R.M. Piro added


			reaction.id <- paste(kegg.map,reaction.id,sep=":") 
          
			reac.children <- xmlChildren(xml$doc$children[["pathway"]][reaction]$reaction)
      
			compounds <- NULL
			if(length(reac.children)>0){
				for(i in seq(along=reac.children)){
					comp <- xmlGetAttr(reac.children[[i]], "name")
					comp <- gsub("\\w+:","",comp)
					comp <- unlist(strsplit(comp," "))
	
					compounds <- c(compounds,comp)
				}
				for(help.reaction in reaction.id){
					if(is.na(match(help.reaction,names(help.list)))){
						help.list[[help.reaction]] <- compounds
					} else {
						help.list[[match(help.reaction,names(help.list))]] <- c(help.list[[match(help.reaction,names(help.list))]],compounds)
					}
				}
			}
		}
		if(length(help.list)>0){
			if(is.na(match(kegg.map,names(compound.list)))){          
				compound.list[[kegg.map]] <- help.list
			} else{
				compound.list[[match(kegg.map,names(compound.list))]] <- help.list
			}
		}
    
		help.list <- list()
		for(relation in relation.tag){
			entry1.id <- xmlGetAttr(xml$doc$children[["pathway"]][[relation]], "entry1")
			entry2.id <- xmlGetAttr(xml$doc$children[["pathway"]][[relation]], "entry2")
			type <- xmlGetAttr(xml$doc$children[["pathway"]][[relation]], "type")
      
			if(!is.null(help.ids.list[[match(entry1.id,names(help.ids.list))]]) && !is.null(help.ids.list[[match(entry2.id,names(help.ids.list))]])){
				entry1 <- unlist(strsplit(help.ids.list[[entry1.id]]," "))
				entry2 <- unlist(strsplit(help.ids.list[[entry2.id]]," "))
      	
				for(e in entry1){
					if(is.na(match(e,names(help.list)))){
						help.list[[e]] <- entry2
					} else{
						help.list[[match(e,names(help.list))]] <- unique(c(help.list[[match(e,names(help.list))]],entry2))
					}
				}
				for(e in entry2){
					if(is.na(match(e,names(help.list)))){
						help.list[[e]] <- entry1
					} else{
						help.list[[match(e,names(help.list))]] <- unique(c(help.list[[match(e,names(help.list))]],entry1))
					}
				}
			}    
		}
		if(is.na(match(kegg.map,names(relation.list)))){          
			relation.list[[kegg.map]] <- help.list
		} else{
			relation.list[[match(kegg.map,names(relation.list))]] <- help.list
		}
	}
	
	all.list[["call"]] <- call("pw.KEGG",url=url)
	all.list[["version"]] <- Sys.Date()
	all.list[["url"]] <- url
	all.list[["ids"]] <- id.list
	all.list[["genes"]] <- gene.list
	all.list[["reactions"]] <- reaction.list
	all.list[["compounds"]] <- compound.list
	all.list[["relations"]] <- relation.list
	class(all.list) <- "PathWave"
	
	return(all.list) 
}

