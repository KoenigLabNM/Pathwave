`pw.optGrid` <-
function(path,adjMatrix,pattern="out$",verbose=TRUE){

	require(gtools)

	path <- sub("/$","",path)
	path <- paste(path,"/",sep="")

	files <- dir(path=path,pattern=pattern,full.names=TRUE)
	files <- mixedsort(files)

	if(is.null(files)){
		stop(paste("No files found in path",path,"with pattern",pattern,"!",sep="\t"))
	} else {
		optimalGridHSA <- list()
		act.map <- ""
		for(file in files){
			if(verbose){
				cat(paste("Processing:",file,sep="\t"),sep="\n")
			}
			map <- strsplit(file,"\\/")[[1]]
			map <- map[length(map)]
	
			mapOrgID <- strsplit(map,"\\.")[[1]][1]
			mapNewID <- gsub("\\.matrix|\\.out","",map)

			# 2012-05; R.M.Piro added:

			# need to remove or convert special characters of regular expressions
			mapOrgID <- gsub("-|\\)|\\(|\\[|\\]|:|\\*|\\?","_",mapOrgID)
			mapOrgID <- gsub("\\+","plus",mapOrgID)
			mapNewID <- gsub("-|\\)|\\(|\\[|\\]|:|\\*|\\?","_",mapNewID)
			mapNewID <- gsub("\\+","plus",mapNewID)

			# 2012-05; end R.M.Piro added

	
			reactions <- rownames(adjMatrix$data[[mapOrgID]]$M)
			#reactions <- rownames(adjMatrix[[mapOrgID]]$M)

# R.M. PIRO: changed to accomodate new grid file format

			#content <- grep("^\\d+ \\d+",readLines(file),value=TRUE)

			content <- grep("^ *\\d+ \\d+",readLines(file),value=TRUE)
			content <- gsub("^ *", "", content)
			content <- gsub(" *$", "", content)
	
# R.M. PIRO: end changed

			M <- matrix(as.numeric(unlist(strsplit(content," ")))+1,nrow=length(content),byrow=TRUE)
			gridSize <- max(M[,-1])

			#build grid
			x.grid <- matrix(0,nrow=gridSize,ncol=gridSize)
			for(i in 1:nrow(M)){
				#x.grid[M[i,2],M[i,3]] <- paste(mapNewID,reactions[M[i,1]],sep=":")
				x.grid[M[i,2],M[i,3]] <- reactions[M[i,1]]
			}
		
			if(mapOrgID != act.map){
				act.map <- mapOrgID
				optimalGridHSA[[mapOrgID]] <- list(M1=x.grid)
			} else{
				comp.no <- gsub(paste(mapOrgID,"|\\.|component",sep=""),"",mapNewID)
				optimalGridHSA[[match(mapOrgID,names(optimalGridHSA))]][[paste("M",comp.no,sep="")]] <- x.grid
			}
		}
		aname <- deparse(substitute(adjMatrix))
		fcall <- call("pw.optGrid",adjMatrix=aname,pattern=pattern,verbose=verbose)
		res <- list(call=fcall,version=adjMatrix$version,url=adjMatrix$url,data=optimalGridHSA)
		class(res)="PathWave"
		return(res)
	}
}

