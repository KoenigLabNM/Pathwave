'pathWave.resultSummary'=
function (x, digits=2)
{
	cat("\n")
	cat(strwrap(x$call[1], prefix = "\t"), sep = "\n")
	cat("\n")
	if(length(grep("pathWave",x$call))>0){
		cat(strwrap(paste("Pathways:",x$oM$pathways,"pathways with",x$oM$reactions,"reactions",sep=" "),prefix="\t"),sep="\n")
		cat(strwrap(paste("Source url:",x$oM$url,sep="\t"),prefix="\t"),sep="\n")
		cat(strwrap(paste("Version of",x$oM$version,sep="\t"),prefix="\t"),sep="\n")
		cat("\n")
		cat(strwrap(paste("Expression data: ",x$data$x$row,"reactions",sep=" "),prefix="\t"),sep="\n")
		cat(strwrap(paste("Samples: ",x$data$x$col,sep="\t"),prefix="\t"),sep="\n")
		cat(strwrap(paste("Classes: ",paste(x$data$y,collapse=","),sep="\t"),prefix="\t"),sep="\n")
		cat("\n")
		cat(strwrap(paste("Overlap between expression and pathway reactions:",x$data$x$overlap,sep="\t"),prefix="\t"),sep="\n")
		cat("\n")
		cat(strwrap(paste("Permutations: ", x$nperm,sep="\t"),prefix="\t"),sep="\n")
		if (!is.null(x$p.value)) {
			fp=format.pval(x$p.value, digits = digits)
			np=names(x$p.value)
	    }
		cat("\n")
		a=x$p.value
		cat(strwrap(paste("Number of features generated:", length(x$feat.p.value),sep="\t"),prefix="\t"),sep="\n")
		cat(strwrap(paste("Number of pathways with p.value <= 0.01:", length(a[a<=0.01]),"and p.value <= 0.05:",length(a[a<=0.01]),sep="\t"),prefix="\t"),sep="\n")
		cat("\n")
		cat(strwrap("Significance of regulation patterns (first 5):",prefix="\t"),sep="\n")
		cat("\n")
		cat(strwrap(paste("pathway","p.value(uncorrected)",sep="\t"),prefix="\t\t"),sep="\n")
		for(i in 1:(min(length(fp),5))){
			cat(strwrap(paste(np[i],fp[i],sep="\t"),prefix="\t\t"),sep="\n")
		}
	    cat("\n")
	} 
	if(length(grep("pw.result",x$call))>0){
		cat(strwrap(paste("P-value cutoff p <=",x$pvalCutoff,sep="\t"),prefix="\t"),sep="\n")
		cat(strwrap(paste("Filtering was used:",x$filter,sep="\t"),prefix="\t"),sep="\n")
		if(x$filter){
			cat(strwrap(paste("Size of filter:",x$filter.size,sep="\t"),prefix="\t"),sep="\n")
		}
		if (!is.null(x$multtest)) {
			cat(strwrap(paste("Multiple testing correction: ", x$multtest,sep="\t"),prefix="\t"),sep="\n")
		} else {
			cat(strwrap(paste("Multiple testing correction: ", "none",sep="\t"),prefix="\t"),sep="\n")
		}
		cat(strwrap(paste("Number of pathways with significant pattern:",length(x$p.value),sep="\t"),prefix="\t"),sep="\n")
	} 
	if(length(grep("pw.KEGG",x$call))>0){
		cat(strwrap(paste("XML-files read from url:",x$url,sep="\t"),prefix="\t"),sep="\n")
		cat(strwrap(paste("Version from",x$version,sep="\t"),prefix="\t"),sep="\n")
		cat("\n")
		cat(strwrap(paste("Data processed for",length(x$genes),"pathways.",sep="\t"),prefix="\t"),sep="\n")

	}
	if(length(grep("pw.adjM",x$call))>0){
		help=unlist(lapply(x$data,function(e){nrow(e$M)}))
		cat(strwrap(paste("Source url:",x$url,sep="\t"),prefix="\t"),sep="\n")
		cat(strwrap(paste("Version from",x$version,sep="\t"),prefix="\t"),sep="\n")
		cat("\n")
		cat(strwrap(paste("Adjacency matrices built for",length(x$data),"pathways.",sep="\t"),prefix="\t"),sep="\n")
		cat(strwrap(paste("Matrix sizes ranging from", min(help),"to",max(help),".",sep="\t"),prefix="\t"),sep="\n")
	} 
	if(length(grep("pw.optGrid",x$call))>0){
		help=unlist(lapply(x$data,function(e){nrow(e$M)}))
		cat(strwrap(paste("Source url:",x$url,sep="\t"),prefix="\t"),sep="\n")
		cat(strwrap(paste("Version from",x$version,sep="\t"),prefix="\t"),sep="\n")
		cat("\n")
		cat(strwrap(paste("Optimal Grids built for",length(x$data),"pathways.",sep="\t"),prefix="\t"),sep="\n")
		cat(strwrap(paste("Grid sizes ranging from", min(help),"to",max(help),".",sep="\t"),prefix="\t"),sep="\n")
	}
    invisible(x)
}

