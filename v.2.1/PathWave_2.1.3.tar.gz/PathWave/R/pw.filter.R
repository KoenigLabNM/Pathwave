`pw.filter` <-
function(reg,genes,cutoff){

	FILTER_NOT_PASSED=-111

	if(is.null(genes)){
		if(sum(abs(reg))>=cutoff){
			return(reg)
		} else {
			return(FILTER_NOT_PASSED)
		}
	} else {
		if(sum(abs(reg))>=cutoff){
			rl <- length(genes)
			gene.matrix <- NULL
			sig.reac <- names(reg)[reg!=0]
			for(j in sig.reac){
				hg <- c(sort(genes[names(genes)==j]),rep("dummy",rl-length(genes[names(genes)==j])))
				gene.matrix <- rbind(gene.matrix,hg)
			}
			gene.matrix <- unique(gene.matrix,MARGIN=1)
			if(length(rownames(gene.matrix))>=cutoff){
				return(reg)
			} else {
				return(FILTER_NOT_PASSED)
			}
		} else {
			return(FILTER_NOT_PASSED)
		}
	}
}

