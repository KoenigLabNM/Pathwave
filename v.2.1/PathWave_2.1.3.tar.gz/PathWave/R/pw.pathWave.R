`pw.pathWave` <-
function(x,y,optimalM,nperm=1000,verbose=TRUE){
	require(evd)
	require(multtest)
	require(genefilter)

	if(!is.matrix(x)){
		stop("Variable x should be a matrix containing the expression values! Rows: reactions, Columns: samples!")
	}
	if(!is.factor(y) || length(y) != ncol(x) || length(levels(y))!= 2){
		stop(paste("Variable y should be a class factor with two classes and length(y) corresponding to column size of x! Having: class(y)=",class(y),"; length(y)=",length(y),"; length(levels(y))=",length(levels(y)),"; ncol(x)=",ncol(x),sep=""))
	}
	  
	#p.values and regulation for single reactions	
	help <- rowttests(x,y)
	p.value.x <- help$p.value
	reg.x <- sign(help$dm)
	
	names(p.value.x) <- names(reg.x) <- rownames(x)
	
	#feature matrix and feature name->reactions mapping
	M.feature.result <- pw.genFeatures(x,optimalM$data,verbose)
	M.feature.org <- M.feature.result$feat
	M.feature.org <- M.feature.org[order(rownames(M.feature.org)),]

	feature.pval <- as.vector(rowttests(M.feature.org,y)$p.value)
	names(feature.pval) <- rownames(M.feature.org)
	M.feature <- as.vector(abs(log10(feature.pval)))
	names(M.feature) <- rownames(M.feature.org)

	map.names <- sapply(names(M.feature),function(e){unlist(strsplit(e,"\\:"))[1]})

	coord <- which(!duplicated(map.names))
	coord <- cbind(coord,c((coord-1)[-1],nrow(M.feature.org)),seq(length(coord)))

	M.feature <- sapply(seq(nrow(coord)),function(e,c,h){max(h[c[e,1]:c[e,2]])},coord,M.feature)
	names(M.feature) <- unique(map.names)

	s.y <- apply(matrix(rep(y,nperm),nrow=nperm,byrow=TRUE),1,sample)
	M.feature.perm <- sapply(seq(ncol(s.y)),function(e,h,s){if(verbose && e%%100==0){cat(paste("PathWave:",e,"permutations done.",sep="\t"),sep="\n")}; return(as.vector(abs(log10(rowttests(h,as.factor(s[,e]))$p.value))))},M.feature.org,s.y)
	res.perm <- t(apply(M.feature.perm,2,function(x){sapply(seq(nrow(coord)),function(e,c,h){max(h[c[e,1]:c[e,2]])},coord,x)}))
	colnames(res.perm) <- unique(map.names)

	est.gumbel <- apply(res.perm,2,function(e){fgev(e,shape=0,std.err=FALSE,warn.inf=FALSE)})
	pval <- sapply(seq(length(M.feature)),function(e,h,o){1-pgumbel(o[e],loc=h[[e]]$estimate[1],scale=h[[e]]$estimate[2],lower.tail=TRUE)},est.gumbel,M.feature)
	pval[is.na(pval)] <- 1

	pval <- sort(pval)
	feature.pval <- sort(feature.pval)
	
	xname <- deparse(substitute(x))
	yname <- deparse(substitute(y))
	oname <- deparse(substitute(optimalM))
	oM.reac <- unlist(optimalM$data)
	oM.reac <- unique(oM.reac[oM.reac!="0"])
	overlap <- length(na.omit(match(oM.reac,rownames(x))))
	fcall <- call("pw.pathWave",x=xname,y=yname,optimalM=oname,nperm=nperm,verbose=verbose)
	res <- list(call=fcall,p.value=pval,feat.p.value=feature.pval,feat.reaction_list=M.feature.result$feat_reaction_list,r.reg=reg.x,r.p.value=p.value.x,r.reg.direction=levels(y)[1],nperm=nperm,oM=list(version=optimalM$version,url=optimalM$url,pathways=length(optimalM$data),reactions=length(oM.reac),data=optimalM$data),data=list(x=list(row=nrow(x),col=ncol(x),overlap=overlap),y=levels(y)))
	class(res) <- "PathWave"

	return(res)
}

