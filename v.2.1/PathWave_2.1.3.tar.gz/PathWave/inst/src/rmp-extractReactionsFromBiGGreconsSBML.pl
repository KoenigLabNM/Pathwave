#!/usr/bin/perl -w

##############################################################################
# copyright 2011 by Rosario M. Piro (r.piro@dkfz.de)
#
# ---------------------------------------------------------------------------
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
##############################################################################

use strict;

use Getopt::Std;
use File::Basename;
use XML::TreeBuilder;

# command buffering of STDOUT
$| = 1;


my $prgname = "rmp-extractReactionsFromBiGGreconsSBML.pl";

my $organismTag4XML = "hsa";

my $infile = "";
my $excludeMetabolitesFile = "";

my $pathXMLoutPrefix = "";
my $writeXML = 0;
my $pwNumCount = 1;   # for fake pathway numbers
my $elemIdCount = 1;  # for fake KGML element IDs
my %writtenCompounds2ElementID = ();
my %writtenGenes2ElementID = ();
my %writtenReactions2ElementID = ();


my $simplifyGeneAssociation = 0;
my $verboseOutput = 0;


# -------------------
# getting options ...
# -------------------

my %opts;
$opts{h} = "";
$opts{f} = "";
$opts{s} = "";
$opts{E} = "";
$opts{P} = "";
$opts{O} = "";
$opts{v} = "";

getopts('hf:sE:P:O:v', \%opts);


if ( $opts{h} eq "1" ) {
    &printUsageInfo();
}

if ( $opts{f} ne "" ) {
    $infile = $opts{f};
}

if ( $opts{E} ne "" ) {
    $excludeMetabolitesFile = $opts{E};
}

if ( $opts{P} ne "" ) {
    $pathXMLoutPrefix = $opts{P};
    $writeXML = 1;
    $simplifyGeneAssociation = 1;
}

if ( $opts{O} ne "" ) {
    $organismTag4XML = $opts{O};
}

if ( $opts{s} eq "1" ) {
    $simplifyGeneAssociation = 1;
}

if ( $opts{v} eq "1" ) {
    $verboseOutput = 1;
}


# check file
if ($infile eq "") {
    print STDERR "Error: mandatory parameter missing (-h for help)!\n";
    exit(1);
}

if (! -e "$infile" || ! -r "$infile") {
    print STDERR "Error: cannot access file $infile!\n";
    exit(2);
}

#if ($writeXML) {
#    if (! -w "${pathXMLoutPrefix}test.xml") {
#	print STDERR "Error: cannot write pathway XML files with prefix $pathXMLoutPrefix!\n";
#	exit(3);
#    }
#}


# variables needed
my %subsyst2RctList = ();

my %rctNames = ();
my %rctSubsystems = ();
my %rctConfidence = ();
my %rctReversible = ();
my %rctGeneAssoc = ();
my %rctGeneAssocSimplified = ();
my %rct2GeneList = ();
#my %gene2RctList = ();

my %reactants2reactions = ();
my %products2reactions = ();
my %reactions2reactants = ();
my %reactions2products = ();

my %metabolitesToExclude = ();


# first try to see if we need to exclude some metabolites:
if ($excludeMetabolitesFile ne "") {
    unless(open(METABFILE, "< $excludeMetabolitesFile")) {
	print STDERR "Error: cannot open file $excludeMetabolitesFile for reading!\n";
	exit(3);
    }

    my $line = "";
    while($line = <METABFILE>) {
	chomp($line);
	next if ($line =~ /^\#/); # ignore comments
	$line =~ s/^[[:space:]]*//; # remove initial spaces
	$line =~ s/[[:space:]]*$//; # remove trailing spaces
	$metabolitesToExclude{$line} = 1;

	if ($verboseOutput) {
	    print "# species/metabolite to be excluded: $line\n";
	}
    }

    close(METABFILE);
}


# start parsing the XML file

my $xmltree = XML::TreeBuilder->new( );
$xmltree->parse_file($infile);

if($@) {
    print STDERR "\nError while parsing XML file $infile:\n$@\n";
    exit(3);
}

my $sbml = $xmltree->find_by_tag_name("sbml");
my $model = $sbml->find_by_tag_name("model");


# first check what species/compounds we find throughout the model and initialize the mappings from species to reactions:

my $listOfSpecies = $model->find_by_tag_name("listOfSpecies");
foreach my $species ($listOfSpecies->find_by_tag_name("species")) {
    my $sid = $species->attr_get_i("id");

    # initialize this species as reactant and product:
    @{$reactants2reactions{$sid}} = ();
    @{$products2reactions{$sid}} = ();

    if($verboseOutput) {
	print "# found species: $sid\n";
    }
}



# now find the reactions themselves:
my $reactionCount = 0;

my $listOfReactions = $model->find_by_tag_name("listOfReactions");
foreach my $reaction ($listOfReactions->find_by_tag_name("reaction")) {

    $reactionCount++;
    my $rid = $reaction->attr_get_i("id");
    $rctNames{$rid} = "";
    $rctReversible{$rid} = "";
    $rctSubsystems{$rid} = "";
    $rctConfidence{$rid} = "";
    $rctGeneAssoc{$rid} = "";
    $rctGeneAssocSimplified{$rid} = "";

    if ($verboseOutput) {
	print "# processing reaction no. $reactionCount: $rid\n";
    }

    $rctNames{$rid} = $reaction->attr_get_i("name");
    $rctReversible{$rid} = $reaction->attr_get_i("reversible");
    if (!exists($rctReversible{$rid}) || !defined($rctReversible{$rid})) {
        $rctReversible{$rid} = "true"; # assume reversibility if it was not specified; in some files only "false" is specified!
    }

    if ($verboseOutput) {
	print "#   name = \"$rctNames{$rid}\"\n#   reversible = $rctReversible{$rid}\n";
    }

    #my $notes = $reaction->find_by_tag_name("notes");
    #my @html_p_notes = $notes->find_by_tag_name("html:p");
    #print $html_p_notes[0]->as_XML;
    #print $html_p_notes[0]->as_text;
    foreach my $html_p (( ($reaction->find_by_tag_name("notes"))->find_by_tag_name("html:p"), ($reaction->find_by_tag_name("notes"))->find_by_tag_name("p") ) ) {
	if ($verboseOutput) {
	    print "#   checking note: ".$html_p->as_text."\n";
	}
	if ($html_p->as_text =~ /^SUBSYSTEM: *([^ ].*)$/i) {
	    $rctSubsystems{$rid} = $1;

	    # map also the subsystem to a list of reactions
	    if (exists($subsyst2RctList{$1})) {
		$subsyst2RctList{$1} .= "|";
	    }
	    else {
		$subsyst2RctList{$1} = "";
	    }
	    $subsyst2RctList{$1} .= $rid;

	    if ($verboseOutput) {
		print "#   -> subsystem = \"$rctSubsystems{$rid}\"\n";
		print "#      \[current list of reactions for this subsystem: $subsyst2RctList{$1}\]\n";
	    }
	}
	elsif ($html_p->as_text =~ /^Confidence[ _]Level: *([^ ].*)$/i) {
	    $rctConfidence{$rid} = $1;

	    if ($verboseOutput) {
		print "#   -> confidence level = $rctConfidence{$rid}\n";
	    }
	}
	elsif ($html_p->as_text =~ /^GENE[ _]ASSOCIATION: *([^ ].*)$/i) {
	    $rctGeneAssoc{$rid} = $1;

	    if ($verboseOutput) {
		print "#   -> gene association = \"$rctGeneAssoc{$rid}\"\n";
	    }

	    # simplify this?
	    if ($simplifyGeneAssociation) {
		$rctGeneAssocSimplified{$rid} = &simplifyGeneAssociation($rctGeneAssoc{$rid}, $rid);

		if ($verboseOutput) {
		    print "#   -> simplified gene association = \"$rctGeneAssocSimplified{$rid}\"\n";
		}
	    }
	}
    }

    # which reactants serve as input?
    @{$reactions2reactants{$rid}} = ();
    my $lReact = $reaction->find_by_tag_name("listOfReactants");
    if (defined($lReact)) {
	foreach my $speciesRef ($lReact->find_by_tag_name("speciesReference")) {
	    my $sid = $speciesRef->attr_get_i("species");
	    my $stoichiometry = $speciesRef->attr_get_i("stoichiometry");
	    if (!defined($stoichiometry)) {
		$stoichiometry = 1; # assume 1 if not specified for this reactant!
	    }

	    if (!exists($metabolitesToExclude{$sid})) {
		# do this only if we need not exclude the metabolite/species!

		push(@{$reactants2reactions{$sid}}, "${rid}");  
		push(@{$reactions2reactants{$rid}}, "${sid}[$stoichiometry]"); # this species serves (N times) as a reactant for $rid

		if ($verboseOutput) {
		    print "#   found reactant = ${sid}; stoichiometry: $stoichiometry\n";
		}
	    }
	    else {
		if ($verboseOutput) {
		    print "#   excluding reactant = ${sid}; stoichiometry: $stoichiometry\n";
		}
	    }
	}
    } # if defined $lReact

    # which species are produced?
    @{$reactions2products{$rid}} = ();
    my $lProd = $reaction->find_by_tag_name("listOfProducts");
    if (defined($lProd)) {
	foreach my $speciesRef ($lProd->find_by_tag_name("speciesReference")) {
	    my $sid = $speciesRef->attr_get_i("species");
	    my $stoichiometry = $speciesRef->attr_get_i("stoichiometry");
	    if (!defined($stoichiometry)) {
		$stoichiometry = 1; # assume 1 if not specified for this reactant!
	    }


	    if (!exists($metabolitesToExclude{$sid})) {
		# do this only if we need not exclude the metabolite/species!

		push(@{$products2reactions{$sid}}, "${rid}");
		push(@{$reactions2products{$rid}}, "${sid}[$stoichiometry]"); # this species is produced (N times) by $rid

		if ($verboseOutput) {
		    print "#   found product = ${sid}; stoichiometry: $stoichiometry\n";
		}
	    }
	    else {
		if ($verboseOutput) {
		    print "#   excluding product = ${sid}; stoichiometry: $stoichiometry\n";
		}
	    }
	}

    } # if defined $lProd ...

} # foreach my $reaction ...


# print header
print "reaction_id\treaction_name\tsubsystem\tconfidence_level\treversible\tgene_association";

if ($simplifyGeneAssociation) {
    print "\tgene_association_simplified";
}

print "\treactants(from_reaction[stoichiometry])\tproducts(to_reaction[stoichiometry])";

print "\n";


if ($writeXML) {
    foreach my $subsyst (keys(%subsyst2RctList)) {
	next if ($subsyst eq "");

	&writeXMLpathway($subsyst);
    }
}

foreach my $rid (keys(%rctNames)) {
    &printReaction($rid);
}


if ($verboseOutput) {
    print "# done processing $reactionCount reactions.\n";
}

exit(0);

#############################################################################
#                                   FUNCTIONS:
#############################################################################


# ---------------------------------------------------------------------------
#
# Print usage information (help).
# arguments: none
#
# --------------------------------------------------------------------------
sub printUsageInfo() {
    print "Author: Rosario M. Piro (r.piro\@dkfz.de)\n\n";
    print "Usage:\n";
    print "$prgname [OPTIONS]\n";
    print "\nWhere OPTIONS are:\n";
    print "-h                Display this help message and exit.\n";
    print "-f <infile>       The BiGG SGML file.\n";
    print "-s                Simplify gene associations for the reactions.\n";
    print "-E <metab_file>   Optional file containing a list (one per line) of metabolite\n";
    print "                  IDs to be excluded from the reconstruction of the reactions.\n";
    print "                  This may be used to exclude metabolites/reaction products\n";
    print "                  that do not provide any meaningful information for links\n";
    print "                  between reactions (e.g. H2O).\n";
    print "-P <prefix>       Prefix for producing optional KEGG-like XML pathway files.\n";
    print "                  If specified, each subsystem of the SGML model will be\n";
    print "                  interpreted as a pathway and converted into a KEGG-like\n";
    print "                  pathway file in XML format. Full compatibility with KGML\n";
    print "                  is not guaranteed. Each subsystem will be saved in a\n";
    print "                  seperate XML file named \"<prefix><subsystem_name>.xml\".\n";
    print "                  (Spaces in subssytem names are replaced by underscores.)\n";
    print "                  NOTE: This will cause -s to be automatically activated.\n";
    print "-O <tag>          Tag to use as abbreviation of the organism when writing\n";
    print "                  KEGG-like XML pathway files. Default: \"$organismTag4XML\"\n";
    print "-v                Verbose (add comments for debugging)\n\n";
    print "Mandatory parameter: -f must be specified.\n\n";
    exit(0);

} # printUsageInfo() ...



sub writeXMLpathway() {

    my $subsyst = $_[0];
    my $subsyst4FName = $subsyst;
    $subsyst4FName =~ s/ /_/g;
    $subsyst4FName =~ s/\//---/g;

    my $xmlFName = $pathXMLoutPrefix.$subsyst4FName.".xml";

    my $pwNumber = sprintf("%.5d", $pwNumCount++);

    if ($verboseOutput) {
	print "# writing subsystem '$subsyst' as '$xmlFName'.\n";
    }

    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
    $year += 1900;
    my @months = qw( Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec );

    unless(open(XMLFILE, "> $xmlFName")) {
	print STDERR "Error: cannot open file for writing: $xmlFName\n";
	exit(44);
    }

    # KGML/XML header
    if ($verboseOutput) {
	print "#  -> writing header ...\n";
    }

    print XMLFILE "<?xml version=\"1.0\"?>\n";
    print XMLFILE "<!DOCTYPE pathway SYSTEM \"http://www.genome.jp/kegg/xml/KGML_v0.7.1_.dtd\">\n";
    print XMLFILE "<!-- Creation date: $months[$mon] $mday, $year $hour:$min:$sec; created by $prgname -->\n";
    print XMLFILE "<pathway name=\"path:$subsyst4FName\" org=\"$organismTag4XML\" number=\"$pwNumber\"\n";
    print XMLFILE "         title=\"$subsyst\"\n";
    print XMLFILE "         image=\"\"\n";
    print XMLFILE "         link=\"\">\n";

    # compounds = metabolites/species

    my %compoundsInThisXML = ();

    my @thisRctList = split(/\|/, $subsyst2RctList{$subsyst});

 
    my $x_dummy = 1000;
    my $y_dummy = 100;

    foreach my $rct (@thisRctList) {

	if ($verboseOutput) {
	    print "#  -> writing compound elements for reaction $rct\n";
	}

	my @thisCmpList = ();
	push(@thisCmpList, @{$reactions2reactants{$rct}});
	push(@thisCmpList, @{$reactions2products{$rct}});

	foreach my $cid (@thisCmpList) {

	    my $cidNoStoich = $cid;
	    $cidNoStoich =~ s/\[[0-9]+\]//g; # remove stoichiometry

	    if ($verboseOutput) {
		print "#     compound: $cidNoStoich ... ";
	    }

	    if (!exists($compoundsInThisXML{$cidNoStoich})) {
		# we don't have this compound yet in this file, need to write it
		if ($verboseOutput) {
		    print "first occurence (need to write)";
		}

		if (!exists($writtenCompounds2ElementID{$cidNoStoich})) {
		    # in no file before, give new unique ID
		    my $newElemId = $elemIdCount++;
		    $writtenCompounds2ElementID{$cidNoStoich} = $newElemId;

		    if ($verboseOutput) {
			print "; new element ID: $writtenCompounds2ElementID{$cidNoStoich}";
		    }
		}
		else {
		    if ($verboseOutput) {
			print "; previously associated element ID: $writtenCompounds2ElementID{$cidNoStoich}";
		    }
		}
		$compoundsInThisXML{$cidNoStoich} = $writtenCompounds2ElementID{$cidNoStoich};

		print XMLFILE "    <entry id=\"$compoundsInThisXML{$cidNoStoich}\" name=\"cpd:$cidNoStoich\" type=\"compound\"\n";
		print XMLFILE "        link=\"\">\n";
		print XMLFILE "        <graphics name=\"$cidNoStoich\" fgcolor=\"#E0E0E0\" bgcolor=\"#E0E0E0\"\n";
		print XMLFILE "             type=\"circle\" x=\"$x_dummy\" y=\"$y_dummy\" width=\"14\" height=\"14\"/>\n";
		$y_dummy += 100;
		print XMLFILE "    </entry>\n";
	    }
	    else {
		if ($verboseOutput) {
		    print "already written in this XML file; ingoring!";
		}
	    }

	    if ($verboseOutput) {
		print "\n";
	    }
	}
    }


    # genes

    $x_dummy = 100;
    $y_dummy = 100;

    my %gene2ThisXMLRctList = ();

    # get list of genes and reactions _of this subsystem_ they are involved in
    if ($verboseOutput) {
	print "#  -> checking for genes associated to the subsystem ...\n";
    }
    foreach my $rct (@thisRctList) {
	if ($verboseOutput) {
	    print "#     reaction: $rct";
	}

	foreach my $gene (keys(%{$rct2GeneList{$rct}})) {
	    ${$gene2ThisXMLRctList{$gene}}{$rct} = 1;

	    if ($verboseOutput) {
		my @r4g = keys(%{$gene2ThisXMLRctList{$gene}});
		print "; gene $gene (now reactions for this gene: @r4g)";
	    }
	}

	if ($verboseOutput) {
	    print "\n";
	}
    }

    foreach my $gene (keys(%gene2ThisXMLRctList)) {

	if ($verboseOutput) {
	    print "#  -> writing gene: $gene";
	}

	if (!exists($writtenGenes2ElementID{$gene})) {
	    # in no file before, give new unique ID
	    my $newElemId = $elemIdCount++;
	    $writtenGenes2ElementID{$gene} = $newElemId;

	    if ($verboseOutput) {
		print "; new element ID: $writtenGenes2ElementID{$gene}";
	    }
	}
	else {
	    if ($verboseOutput) {
		print "; previously associated element ID: $writtenGenes2ElementID{$gene}";
	    }
	}

	if ($verboseOutput) {
	    print "\n";
	}

	my $rctString = "";
	foreach my $rct (keys(%{$gene2ThisXMLRctList{$gene}})) {
	    if ($rctString ne "") {
		$rctString .= " ";
	    }
	    $rct =~ s/ /_/g; # make sure there are no spaces, because they are
	                     # considered as separators for reaction IDs
	    $rctString .= "rn:$rct";
	}

	if ($verboseOutput) {
	    print "#     reactions for this gene: '$rctString'\n";
	}

	print XMLFILE "    <entry id=\"$writtenGenes2ElementID{$gene}\" name=\"$organismTag4XML:$gene\" type=\"gene\" reaction=\"$rctString\"\n";
	print XMLFILE "        link=\"\">\n";
	print XMLFILE "        <graphics name=\"$gene\" fgcolor=\"#99CCFF\" bgcolor=\"#FFFFFF\"\n";
	print XMLFILE "             type=\"line\" coords=\"$x_dummy,$y_dummy,".($x_dummy+100).",$y_dummy\"/>\n";
	$y_dummy += 100;
	print XMLFILE "    </entry>\n";
    }

    # reactions

    foreach my $rct (@thisRctList) {

	if ($verboseOutput) {
	    print "#  -> writing reaction: $rct";
	}

	my $rctNoSpaces = $rct;
	$rctNoSpaces =~ s/ /_/g; # make sure there are no spaces, because they
	                         # are considered as separators for reaction IDs

	if (!exists($writtenReactions2ElementID{$rct})) {
	    # in no file before, give new unique ID
	    my $newElemId = $elemIdCount++;
	    $writtenReactions2ElementID{$rct} = $newElemId;

	    if ($verboseOutput) {
		print "; new element ID: $writtenReactions2ElementID{$rct}";
	    }
	}
	else {
	    if ($verboseOutput) {
		print "; previously associated element ID: $writtenReactions2ElementID{$rct}";
	    }
	}

	my $revString = "reversible";
	if ($rctReversible{$rct} ne "true") {
	    $revString = "non-reversible";
	}
	if ($verboseOutput) {
	    print "; type=$revString";
	}


	print XMLFILE "    <reaction id=\"$writtenReactions2ElementID{$rct}\" name=\"rn:$rctNoSpaces\" type=\"$revString\">\n";

	foreach my $substr (@{$reactions2reactants{$rct}}) {
	    my $substrNoStoich = $substr;
	    $substrNoStoich =~ s/\[[0-9]+\]//g; # remove stoichiometry

	    my $id = $writtenCompounds2ElementID{$substrNoStoich};

	    print XMLFILE "        <substrate id=\"$id\" name=\"cpd:$substrNoStoich\"/>\n";

	    if ($verboseOutput) {
		print "; substrate: $substrNoStoich($id)";
	    }
	}

	foreach my $product (@{$reactions2products{$rct}}) {
	    my $productNoStoich = $product;
	    $productNoStoich =~ s/\[[0-9]+\]//g; # remove stoichiometry

	    my $id = $writtenCompounds2ElementID{$productNoStoich};

	    print XMLFILE "        <product id=\"$id\" name=\"cpd:$productNoStoich\"/>\n";
	    if ($verboseOutput) {
		print "; product: $productNoStoich($id)";
	    }
	}

	print XMLFILE "    </reaction>\n";

	if ($verboseOutput) {
	    print "\n";
	}
    }

    print XMLFILE "</pathway>\n";

    close(XMLFILE);

    return;
}





sub printReaction() {

    my $rid = $_[0];

    print "$rid\t$rctNames{$rid}\t$rctSubsystems{$rid}\t$rctConfidence{$rid}\t$rctReversible{$rid}\t$rctGeneAssoc{$rid}\t";

    if ($simplifyGeneAssociation) {
	print "$rctGeneAssocSimplified{$rid}\t";
    }

    my $reactantString = "";
    foreach my $sid (@{$reactions2reactants{$rid}}) {
	if ($reactantString ne "") {
	    $reactantString .= ";";
	}
	$reactantString .= $sid."(";

	# from which "input" reactions is this reactant a product?
	my $first = 1;
	$sid =~ s/\[[0-9]+\]//; # remove stoichiometry info
	foreach my $r_in (@{$products2reactions{$sid}}) {
	    if (!$first) {
		$reactantString .= ",";
	    }
	    $reactantString .= $r_in;
	    $first = 0;
	}

	$reactantString .= ")";
    }

    print "$reactantString\t";


    my $productString = "";
    foreach my $sid (@{$reactions2products{$rid}}) {
	if ($productString ne "") {
	    $productString .= ";";
	}
	$productString .= $sid."(";

	# from which "input" reactions is this product a reactant?
	my $first = 1;
	$sid =~ s/\[[0-9]+\]//; # remove stoichiometry info
	foreach my $r_in (@{$reactants2reactions{$sid}}) {
	    if (!$first) {
		$productString .= ",";
	    }
	    $productString .= $r_in;
	    $first = 0;
	}

	$productString .= ")";
    }

    print "$productString\n";

    return;
}



sub simplifyGeneAssociation() {

    my $tmpGA = $_[0];
    my $rid = $_[1];

    # forget about isoforms, use only gene IDs
    $tmpGA =~ s/\.[0-9]//g;

    my @orGeneSets = split(/\) or \(/, $tmpGA);
    my $ii;
    for ($ii = 0; $ii < scalar(@orGeneSets); $ii++) {

	if ($ii != 0) {
	    # if not the first element,
            # then we must have removed a ( during the split
	    $orGeneSets[$ii] = "(".$orGeneSets[$ii];
	}

	if ($ii != scalar(@orGeneSets)-1) {
	    # if not the last element,
            # then we must have removed a ) during the split
	    $orGeneSets[$ii] = $orGeneSets[$ii].")";

	}

    }

    # after having removed info on isoforms, make sure to use
    # each gene combination only once
    my $simplifiedGA = "";
    for ($ii = 0; $ii < scalar(@orGeneSets); $ii++) {

	if ($verboseOutput) {
	    print "#          having alternative (OR) gene set: $orGeneSets[$ii]; protein complexes: ";
	}

	# check for repetitions within protein complexes in the set:

	# descend in complexes: (...)
	my $thisGeneSet = $orGeneSets[$ii];
	my $tmpNewSet = "";

	my $complexStartPos = 0;
	my $complexEndPos = 0;
	while( ($complexStartPos = index($thisGeneSet, "(",
					     $complexEndPos) )
	       >= 0) {

	    # save first part up to start of protein complex
	    $tmpNewSet .= substr($thisGeneSet, $complexEndPos,
				 $complexStartPos-$complexEndPos+1);
	    # search for end of protein complexes;
	    $complexEndPos = index($thisGeneSet, ")", $complexStartPos);

	    # get alternative protein complexes
	    my @orProtComplexes = split(/ or /, substr($thisGeneSet, $complexStartPos+1, $complexEndPos-$complexStartPos-1));

	    # each alternative complex only once:
	    my $tmpComplexes = "";
	    my $kk;
	    for ($kk = 0; $kk < scalar(@orProtComplexes); $kk++) {

		if ($verboseOutput) {
		    print "$orProtComplexes[$kk]";
		}

		# maybe we have to sort this?
		# we sort all complexes in order to recognize duplicates!
		my @complexMembers = split (/ and /, $orProtComplexes[$kk]);
		my @membersSorted = sort(@complexMembers);
		my $sortedProtComplex = "";
		my $tt;
		for ($tt = 0; $tt < scalar(@membersSorted); $tt++) {
		    if ($tt != 0) {
			$sortedProtComplex .= " and ";
		    }
		    $sortedProtComplex .= $membersSorted[$tt];

		    # keep track of which genes form this reaction (for XML)
		    ${$rct2GeneList{$rid}}{$membersSorted[$tt]} = 1;
		    #${$gene2RctList{$membersSorted[$tt]}}{$rid} = 1;

		}
		if ($sortedProtComplex ne $orProtComplexes[$kk]) {
		    $orProtComplexes[$kk] = $sortedProtComplex;

		    if ($verboseOutput) {
			print " -> $orProtComplexes[$kk] (sorted!)";
		    }
		}

		my $complexUsed = 0;
		my $mm;
		for ($mm = 0; $mm < $kk; $mm++) {
		    if ($orProtComplexes[$kk] eq $orProtComplexes[$mm]) {
			$complexUsed = 1; # already had this!
		    }
		}

		if (!$complexUsed) {
		    if ($tmpComplexes ne "") {
			$tmpComplexes .= " or ";
		    }
		    $tmpComplexes .= $orProtComplexes[$kk]
		}
		else {
		    if ($verboseOutput) {
			print " (duplicate)";
		    }
		}

		if ($verboseOutput) {
		    print "; ";
		}

	    }
	    $tmpNewSet .= $tmpComplexes;

	}

	$tmpNewSet .= ")";


	# we have sorted the components within the single complexes,
	# now sort the entire gene set

	###print "\n;;; before sorting: $tmpNewSet\n";

	my @complexVect = split(/\) and \(/, $tmpNewSet);
	my $aa;
	for ($aa = 0; $aa < scalar(@complexVect); $aa++) {
	    $complexVect[$aa] =~ s/[\)\(]//g;
	}
	@complexVect = sort(@complexVect);

	###print ";;; sorted vect: @complexVect\n";

	# reconstruct the sorted gene set
	my $tmpNewSet2 = "";
	for ($aa = 0; $aa < scalar(@complexVect); $aa++) {

	    if ($aa != 0) {
		if ($tmpNewSet2 !~ /\)$/) {
		    $tmpNewSet2 .= ")";
		}
		$tmpNewSet2 .= " and ";
	    }

	    if ($complexVect[$aa] !~ /^\(/) {
		    $tmpNewSet2 .= "(";
	    }

	    $tmpNewSet2 .= $complexVect[$aa];
	}
	if ($tmpNewSet2 !~ /\)$/) {
	    $tmpNewSet2 .= ")";
	}

        ###print ";;; after reconstruction: $tmpNewSet2\n";

	# save the version with sorted gene set (and sorted protein complexes);
	# required to identify duplicate gene sets
 	$orGeneSets[$ii] = $tmpNewSet2;


	if ($verboseOutput) {
	    if ($tmpNewSet2 ne $tmpNewSet) {
		print " [sorting protein complexes within the gene set: $tmpNewSet2] ";
	    }
	}


	my $used = 0;
	my $jj;
	for ($jj = 0; $jj < $ii; $jj++) {
	    if ($orGeneSets[$ii] eq $orGeneSets[$jj]) {
		$used = 1; # already had this!
	    }
	}

	if (!$used) {

	    if ($simplifiedGA ne "") {
		$simplifiedGA .= " or ";
	    }
	    $simplifiedGA .= $orGeneSets[$ii];

	    if ($verboseOutput) {
		print "\n";
	    }
	}
	else {
	    if ($verboseOutput) {
		print " ... ignoring duplicate gene set!\n";
	    }
	}
    }

    return $simplifiedGA;

}




