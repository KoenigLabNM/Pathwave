`pwKEGGxml` <-
function(url=NULL){
	require(RCurl)
	require(XML)
  
	all.list=list()
	id.list=list()
	gene.list=list()
	reaction.list=list()
	compound.list=list()
  
	url.error=FALSE
  
	url=sub("/$","",url)
	url=paste(url,"/",sep="")
    
	if(length(grep("^ftp",url))){
		fileNames=getURL(url, .opts=list(customrequest=paste("NLST","*.xml",sep=" ")))
		fileNames=unlist(strsplit(fileNames,"\\\n"))
		fileNames=unlist(strsplit(fileNames,"\\\r"))
	} else {
		if(length(grep("^http",url))){
			helpFiles=getURL(url)
			#search for links and extract link targets
			helpFiles=grep("\\.xml",unlist(strsplit(helpFiles,"</a>")),value=TRUE)
			help=gregexpr("<a href=.*\\.xml\">",helpFiles)
			fileNames=NULL
			for(i in 1:length(help)){
				fileNames=c(fileNames,gsub("<a href=|\"|>","",substr(helpFiles[i],help[[i]][1],attributes(help[[i]])$match.length[1]+help[[i]][1]-1)))
			}
			fileNames=unique(fileNames)
		} else {
			fileNames=dir(url)
		}
	}   
  
	fileNames=grep("xml$",fileNames,value=TRUE)
  
	if(length(fileNames)==0){
		stop(paste("There are no xml files in",url,"!",sep=" ")) 
	}
  
	for(files in fileNames){
		help.ids=NULL
		help.ids.reactions=NULL  
		help.genes.reactions=NULL
		help.genes=NULL
    
		kegg.map=sub(".xml$","",files)
    
		xml=xmlTreeParse(paste(url,files,sep=""),isURL=TRUE,fullNamespaceInfo=TRUE,asTree=TRUE)
		var.names=names(xmlChildren(xml$doc$children[["pathway"]]))
  
		entry.tag=grep("entry",var.names)
		reaction.tag=grep("reaction",var.names)
  
		#get genes and reactions
		for(entry in entry.tag){
  
			type=xmlGetAttr(xml$doc$children[["pathway"]][[entry]], "type")
    
			if(type=="gene"){
				ids=xmlGetAttr(xml$doc$children[["pathway"]][[entry]], "id")
				genes=xmlGetAttr(xml$doc$children[["pathway"]][[entry]], "name")
				reactions=xmlGetAttr(xml$doc$children[["pathway"]][[entry]], "reaction")
    
				if(!(is.null(reactions))){
					genes=gsub("\\w+:","",genes)
					genes=unlist(strsplit(genes," "))
      
					reactions=gsub("\\w+:","",reactions)
					reactions=unlist(strsplit(reactions," "))
					reactions=paste(kegg.map,reactions,sep=":")
	  
					reaction.list[[kegg.map]]=unique(c(reaction.list[[kegg.map]],reactions))
	  
					for(reac in reactions){
						#gene.list[[reac]]=unique(c(gene.list[[reac]],genes))
						help.ids=c(help.ids,ids)
						help.ids.reactions=c(help.ids.reactions,reac)
						help.genes=c(help.genes,genes)
						help.genes.reactions=c(help.genes.reactions,rep(reac,length(genes)))
					}	
				}
			}
		}
		names(help.ids)=help.ids.reactions
		names(help.genes)=help.genes.reactions
    
		id.list[[kegg.map]]=help.ids
		gene.list[[kegg.map]]=help.genes
    
		help.list=list()
		for(reaction in reaction.tag){
			reaction.id=xmlGetAttr(xml$doc$children[["pathway"]][reaction]$reaction,"name")
			reaction.id=gsub("\\w+:","",reaction.id)
			reaction.id=unlist(strsplit(reaction.id," "))
			reaction.id=paste(kegg.map,reaction.id,sep=":") 
          
			reac.children=xmlChildren(xml$doc$children[["pathway"]][reaction]$reaction)
      
			compounds=NULL
			for(i in 1:length(reac.children)){
				comp=xmlGetAttr(reac.children[[i]], "name")
				comp=gsub("\\w+:","",comp)
				comp=unlist(strsplit(comp," "))
	
				compounds=c(compounds,comp)
			}
			help.list[[reaction.id]]=compounds
		}
		if(length(help.list)>0){
			compound.list[[kegg.map]]=help.list
		}
	}
  
	all.list[["ids"]]=id.list
	all.list[["genes"]]=gene.list
	all.list[["reactions"]]=reaction.list
	all.list[["compounds"]]=compound.list
  
	return(all.list) 
}

