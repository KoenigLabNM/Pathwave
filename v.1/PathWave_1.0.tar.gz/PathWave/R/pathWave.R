`pathWave` <-
function(x,y,optimalM,mTest=TRUE,mTestMethod="Bonferroni",pvalCutoff=0.01,diffReac=5,genes=NULL, nperm=10000,verbose=TRUE){
	require(evd)
	require(multtest)
	require(waveslim)
	require(genefilter)

	if(!is.matrix(x)){
		stop("Variable x should be a matrix containing the expression values! Rows: reactions, Columns: samples!")
	}
	if(!is.factor(y) || length(y) != ncol(x) || length(levels(y))!=2){
		stop("Variable y should be a class factor with two classes and length(y) corresponding to column size of x!")
	}
	  
	if(!is.null(genes) ){
	 	if(!is.list(genes)){
			stop("Variable genes should be a list as returned by PathWave:pwKEGGxml$genes !")
		}
  	}
	#p.values and regulation for single reactions	
	help=rowttests(x,y)
	p.values.x=help$p.value
	regulation.x=sign(help$statistic)
	regulation.x[p.values.x>pvalCutoff]=0
	
	names(p.values.x)=names(regulation.x)=rownames(x)
	
	#feature matrix
	M.res=pwBuildFeatureMatrix(x,y,optimalM)	
	M.feature.org=M.res$features
	M.feature.org=M.feature.org[order(rownames(M.feature.org)),]
	
	#M.feature=as.matrix(apply(M.feature.org,1,function(entry,a){wilcox.test(entry[a==levels(a)[1]],entry[a==levels(a)[2]])$p.value},y))	
	feature.pval.org=as.vector(rowttests(M.feature.org,y)$p.value)	
	M.feature=as.vector(abs(log10(feature.pval.org)))
	names(M.feature)=rownames(M.feature.org)

	map.names=sapply(names(M.feature),function(entry){unlist(strsplit(entry,"\\."))[1]})
	coord=which(!duplicated(map.names))
	coord=cbind(coord,c((coord-1)[-1],nrow(M.feature.org)),1:length(coord))
	
	A=matrix(0,nrow=nrow(M.feature.org),ncol=nrow(coord)) 
	for(i in 1:nrow(coord)){
		 A[coord[i,1]:coord[i,2],coord[i,3]]=1
	}
		
	M.feature=as.matrix(M.feature*A)
	M.feature=M.feature[max.col(t(M.feature)),1:ncol(M.feature)]
	if(is.matrix(M.feature)){
		M.feature=diag(M.feature)
	}
	names(M.feature)=unique(map.names)
	
	res.perm=matrix(0,nrow=nperm,ncol=ncol(A))
	for(i in 1:nperm){
		if(verbose){ 
			if(i%%100==0){
				print(paste("PathWave:",i,"permutations done.",sep=" ")) 
			} 
		}
		
		M.feature.perm=as.vector(abs(log10(rowttests(M.feature.org,sample(y))$p.value)))
		M.feature.perm=as.matrix(M.feature.perm*A)
		M.feature.perm=M.feature.perm[max.col(t(M.feature.perm)),1:ncol(M.feature.perm)]
		if(is.matrix(M.feature.perm)){
			M.feature.perm=diag(M.feature.perm)
		}		
		res.perm[i,]=M.feature.perm
	}
	colnames(res.perm)=unique(map.names)

	pval=NULL
	for(maps in names(optimalM)){
		help.org=M.feature[match(maps,names(M.feature))]
		help.perm=res.perm[,match(maps,colnames(res.perm))]

		if(length(as.vector(na.omit(help.perm)))>0){

			est.gumbel=fgev(help.perm,shape=0,std.err=FALSE,warn.inf=FALSE)		
			help.pval=1-pgumbel(help.org,loc=est.gumbel$estimate[1],scale=est.gumbel$estimate[2],lower.tail=TRUE)

			pval=c(pval,help.pval)
		} else{
			pval=c(pval,1)
		}		
	}
	pval.org=pval
	names(pval.org)=names(optimalM)

	if(mTest){
		mTest.proc = c("Bonferroni", "Holm", "Hochberg", "SidakSS", "SidakSD", "BH", "BY")
		proc=mTest.proc[match(mTestMethod,mTest.proc)]
		if(is.na(proc)){
			print("Multitesting correction was set to 'Bonferroni'")
			proc="Bonferroni"
		}
		c.pval=mt.rawp2adjp(pval,proc)
		pval.adj=c.pval$adjp[order(c.pval$index),]
		pval=pval.adj[,2]
		
		c.feature.pval=mt.rawp2adjp(feature.pval.org,proc)
		feature.pval.adj=c.feature.pval$adjp[order(c.feature.pval$index),]
		feature.pval.org=feature.pval.adj[,2]
	}

	names(pval)=names(optimalM)
	names(feature.pval.org)=rownames(M.feature.org)

	pval=sort(pval)
	feature.pval.org=sort(feature.pval.org)
	
	pval=pval[pval<pvalCutoff]
	feature.pval=feature.pval.org[feature.pval.org<pvalCutoff]
	
	#get significant parts of KEGG maps
	kegg.maps.matrices=M.res$M
	kegg.maps.features=list()	
	kegg.maps.results=list()	
	for(p in 1:length(pval)){

		map.features=feature.pval[grep(names(pval)[p],names(feature.pval))]
		if(length(map.features)==0){			
			map.features=feature.pval.org[grep(names(pval)[p],names(feature.pval.org))]
			map.features=map.features[match(map.features[1],map.features)]
			feature.pval=c(feature.pval,map.features)
		}
		for(i in 1:length(map.features)){
			#get coordinates - from feature names
			help=unlist(strsplit(names(map.features)[i],split="_"))
			x=as.numeric(help[3])
			y=as.numeric(help[4])
			z=as.numeric(unlist(strsplit(help[2],split=""))[length(unlist(strsplit(help[2],split="")))])

			M.org=matrix(kegg.maps.matrices[[match(help[1],names(kegg.maps.matrices))]],nrow=sqrt(length(kegg.maps.matrices[[match(help[1],names(kegg.maps.matrices))]])),ncol=sqrt(length(kegg.maps.matrices[[match(help[1],names(kegg.maps.matrices))]])))
			kegg.maps.features[[names(map.features)[i]]]=M.org[(2^z*x-(2^z-1)):(2^z*x),(2^z*y-(2^z-1)):(2^z*y)]
    
			#build vector of reactions found by wavelet transform
			value=unique(as.vector(kegg.maps.features[[names(map.features)[i]]]))
			value=value[is.na(match(value,"0"))]
    
			
			help[1]=unlist(strsplit(help[1],split="\\."))[1]
			
			#build list kegg.maps.results  
			if(is.na(match(help[1],names(kegg.maps.results)))){
				kegg.maps.results[[help[1]]]=value
			} else{    
				kegg.maps.results[[match(help[1],names(kegg.maps.results))]]=unique(c(kegg.maps.results[[match(help[1],names(kegg.maps.results))]],value))
			}
		}
	}
	
	
	kegg.maps.results.final=list()
	for(i in 1:length(names(kegg.maps.results))){  
		reactionsName=kegg.maps.results[[match(names(kegg.maps.results)[i],names(kegg.maps.results))]]
		reactionsPValues=p.values.x[match(reactionsName,names(p.values.x))]
		reactionsRegulation=regulation.x[match(reactionsName,names(regulation.x))]  
		
		score.type=feature.pval[grep(names(kegg.maps.results)[i],names(feature.pval))]
		score.type=names(score.type)[grep(score.type[1],score.type)]
		score.type=min(as.numeric(unique(gsub("\\D+","",unlist(lapply(strsplit(score.type,"_"),function(entry){entry[2]}))))))
		
		help.list=list(p.value=pval[match(names(kegg.maps.results)[i],names(pval))], score=score.type, reactions=reactionsName, reaction.p.value=reactionsPValues, reaction.regulation=reactionsRegulation, feature.p.value=feature.pval[grep(names(kegg.maps.results)[i],names(feature.pval))], feature=kegg.maps.features[grep(names(kegg.maps.results)[i],names(kegg.maps.features))])
		kegg.maps.results.final[[names(kegg.maps.results)[i]]]=help.list
	}
	
	if(!is.null(genes)){
		kegg.maps.results.final=filterResults(kegg.maps.results.final,genes,diffReac)		
	}
	
	return(kegg.maps.results.final)
}

