`pwAdjMatrices` <-
function(reactionList,compoundList,printMatrices=FALSE,matrixType="adjacency"){

	require(e1071)
 
	if(is.null(reactionList) || is.null(compoundList)){
		stop("reactionList and compoundList have to be defined")
	} else {
		kegg.maps.names=names(reactionList)
  
		#store build matrices to trace calculated features
		kegg.maps.matrices=list()
  
		#loop over all pathways
		for(map in kegg.maps.names){
     
			reactions=reactionList[[map]]
         
			kegg.maps.ID=map
			#kegg.maps.ID=sub("[Aa-Zz]+","",kegg.maps.ID)
       
			compList=compoundList[[kegg.maps.ID]]
        
			if(length(reactions)>1){
     
				#build list reaction.connect: reaction -> reactions the reaction is connectedt to
				#BUILD_START
				reaction.connect=list()

				for(i in 1:length(reactions)){
					reaction1=compList[[reactions[i]]]
					if(length(reaction1)>=0){
						reaction.value=NULL
						for(j in 1:length(reactions)){
							if(i!=j){
								reaction2=compList[[reactions[j]]]
								if(length(reaction2)>=0){
									if(length(reaction1[!is.na(match(reaction1,reaction2))])>0){
										#reaction1=reaction1[-match((reaction1[!is.na(match(reaction1,reaction2))])[1],reaction1)]
										reaction.value=c(reaction.value,reactions[j])
									}
								}  
								else {
									stop("reaction has no compounds")
								}      
							}
						}
						reaction.connect[[reactions[i]]]=reaction.value
					}
				}
				#BUILD_END
	
				#build adjacency matrix
				M=matrix(0,nrow=length(reactions),ncol=length(reactions))
				rownames(M)=colnames(M)=reactions
	
				for(i in names(reaction.connect)){
					M[match(i,colnames(M)),match(reaction.connect[[i]],colnames(M))]=1
					M[match(reaction.connect[[i]],colnames(M)),match(i,colnames(M))]=1
				}
	
				diag(M)=0	
	
				if(max(M) > 0){	  
					M.org=M
	  
					#build distance matrix
					M[M==0]=Inf
	
					dist.matrix=allShortestPaths(M)$length
					dist.max=max(na.omit(as.vector(dist.matrix)))  
					dist.matrix[is.na(dist.matrix)]=Inf
	  
					if((dist.max^2) < length(unique(rownames(M)))){
						dist.max = (round(sqrt(length(unique(rownames(M)))),digits=0)+1)
					}
					diag(dist.matrix)=0
	
					if(printMatrices){
						if(matrixType=="distance"){
							cat(paste(dim(M)[1],"\n",sep=""),file=paste(map,"inv","dist","matrix",sep="."))
							cat(paste(dist.max,"\n",sep=""),file=paste(map,"inv","dist","matrix",sep="."),append=TRUE)
							write.table(dist.matrix,file=paste(map,"inv","dist","matrix",sep="."),col.names=FALSE,row.names=FALSE,append=TRUE)
						} else {
							cat(paste(dim(M)[1],"\n",sep=""),file=paste(map,"matrix",sep="."))
							cat(paste(dist.max,"\n",sep=""),file=paste(map,"matrix",sep="."),append=TRUE)
							write.table(M.org,file=paste(map,"matrix",sep="."),col.names=FALSE,row.names=FALSE,append=TRUE)
						}
					}	
					kegg.maps.matrices[[map]]=list(nNodes=dim(M)[1],iMax=dist.max,M=M.org,dist=dist.matrix)
				}
			}
		}
		attr(kegg.maps.matrices,"class")="PathWaveAdjMatrices"
    
		return(kegg.maps.matrices)
	}
}

