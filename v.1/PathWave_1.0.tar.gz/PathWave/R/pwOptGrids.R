`pwOptGrids` <-
function(path,adjMatrix,pattern="\\.lp\\.log$"){
    
	path=sub("/$","",path)
	path=paste(path,"/",sep="")
            
	fileNames=dir(path,pattern=pattern)

	result=list()    
	if(is.null(fileNames)){
		stop(paste("No files found in path",path,"that show pattern",pattern,"!",sep=" "))
	} else{
		for(file in fileNames){
			res=NULL
	 
			map=unlist(strsplit(file,"\\."))[1]
			reactions=rownames(adjMatrix[[map]]$M)
			if(is.null(reactions)){
				stop(paste("No reactions found in adjMatrix for KEGG pathway",map,". Variable adjMatrix should be as returned by PathWave:pwAdjMatrix!",sep=" "))
			} else{
      
				fileContent=readLines(paste(path,file,sep=""),warn=FALSE)  	
				grid.x=grep("^x_\\d*_\\d*_\\d*",fileContent,value=TRUE)
				for(i in 1:length(grid.x)){
					res=rbind(res,c(unlist(strsplit(grid.x[i]," "))[c(1,length(unlist(strsplit(grid.x[i]," "))))]))
				}
				res=res[as.numeric(res[,2])==1,]
				res=res[1:length(reactions),1]
	
				M=matrix(0,nrow=length(reactions),ncol=length(reactions))
  	
				maxCoord=0
				for(i in res){
					coord=unlist(strsplit(i,"_"))
					coord=coord[-1]
					coord=as.numeric(coord) 
  
					M[coord[2]+1,coord[3]+1]=reactions[coord[1]+1]
					maxCoord=max(c(maxCoord,coord[2],coord[3]))
				}
				maxCoord=maxCoord+2

				if(maxCoord < dim(M)[1] && maxCoord < dim(M)[2]){
					M=M[-(maxCoord:dim(M)[1]),-(maxCoord:dim(M)[2])]
				}
				result[[map]]=list(M=M)
			}
		}
		return(result)
	}
}

