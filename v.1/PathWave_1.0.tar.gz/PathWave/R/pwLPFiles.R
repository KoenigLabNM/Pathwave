`pwLPFiles` <-
function(adjMatrix,strategy="automatic",
							addTriangleInequalities=TRUE,
							addCliqueConstraints=TRUE,
							addSymmetryBreakingConstraints=TRUE,
							addStarInequalities=TRUE,
							add5CycleConstraints=TRUE,
							useDummyNodes=TRUE,
							addNeighbourStarConstraints=FALSE){ 
  
	#check variables
	if(!is.list(adjMatrix)){
		stop("adjMatrix should be a list as returned by PathWave:pwAdjMatrix!")
	} 	       
	       
	poss.strategies=c("automatic","manually","largesystem","basicsystem")
	strategy=pmatch(strategy,poss.strategies, 99) - 1

	if(strategy>10){ 
		stop(paste("Wrong optimisation strategy chosen! Possible choices are",poss.strategies,"!",sep=" "))
	}
  
	for(map in names(adjMatrix)){
  
		fileName=paste(map,"matrix","lp",sep=".")
    
		nNodes=adjMatrix[[map]]$nNodes
		iMax=adjMatrix[[map]]$iMax
		x=adjMatrix[[map]]$M
        
		if(is.null(nNodes)){
			stop("adjMatrix should contain a variable nNodes as returned by PathWave:pwAdjMatrix!")
		}
  
		if(is.null(iMax)){
			stop("adjMatrix should contain a variable iMax as returned by PathWave:pwAdjMatrix!")
		}
    
		if(!is.matrix(x)){ 
			stop("adjMatrix should contain a matrix M as returned by PathWave:pwAdjMatrix!") 
		}
    
		#include only maps that have connected components
		if(sum(x)>0){
    
			ret<- .C("buildLPFiles", as.double(t(x)),
											as.integer(nrow(x)),
											as.integer(ncol(x)),
											as.integer(nNodes),
											as.integer(iMax),
											as.integer(strategy),
											as.integer(addTriangleInequalities),
											as.integer(addCliqueConstraints),
											as.integer(addSymmetryBreakingConstraints),
											as.integer(addStarInequalities),
											as.integer(add5CycleConstraints),
											as.integer(useDummyNodes),
											as.integer(addNeighbourStarConstraints),
											as.character(fileName),
											PACKAGE = "PathWave")$ret
		}
	}
}


