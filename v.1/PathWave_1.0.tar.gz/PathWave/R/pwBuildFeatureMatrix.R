`pwBuildFeatureMatrix` <-
function(x.org,y,optimalM){
  
	require(waveslim)   
  
	if(!is.matrix(x.org)){
		stop("Variable x should be a matrix containing the expression values! Rows: reactions, Columns: samples!")
	}
	if(!is.factor(y) || length(y) != ncol(x.org) || length(levels(y))!=2){
		stop("Variable y should be a class factor with two classes and length(y) corresponding to column size of x!")
	}
	
	#feature matrix
	feature.matrix.total=NULL
	feature.names.total=NULL
  
	kegg.maps=names(optimalM)
	kegg.maps.matrices=list()
	
	#loop over all KEGG maps
	for(map in kegg.maps){
    	  
		M=optimalM[[map]]$M
      
		if(is.matrix(M) && ncol(M)==nrow(M)){
        	  	
			x=x.org[grep(paste(map,":",sep=""),rownames(x.org)),]
	
			if(is.vector(x)){
				x=matrix(x,ncol=ncol(x.org))
			}
				
			#set reactions to "0" for which no expression data is available
			help=as.vector(M)
			help[is.na(match(help,rownames(x)))]="0"
			M=matrix(help,nrow=nrow(M),ncol=ncol(M))

			if(ncol(M)%%2==0){
				M.frame.col=as.matrix(M[,-c(1,ncol(M))])
				M.frame.row=as.matrix(M[-c(1,nrow(M)),])
				M.frame.total=as.matrix(M[-c(1,nrow(M)),-c(1,ncol(M))])
      
			} else{
				M.frame.row=as.matrix(M[-1,])
				M.frame.col=as.matrix(M[,-1])
				M.frame.total=as.matrix(M[-1,-1])
				M[nrow(M),]=0
				M[,ncol(M)]=0
			}           
            
			#scale adjacency matrix to 2^n (n: natural number) - start
			if(is.null(ncol(M)) || ncol(M)<=1){
				colSize=2
			} else {
				colSize=2^(ceiling(log(ncol(M),base=2)))
			}
			if(is.null(nrow(M)) || nrow(M)<=1){
				rowSize=2
			} else {
				rowSize=2^(ceiling(log(nrow(M),base=2)))
			}
  
			if(colSize>rowSize){
				rowSize=colSize
			} else{
				colSize=rowSize
			}
			if(ncol(M)!=colSize || nrow(M)!=rowSize){
				M=rbind(M,matrix(0,nrow=colSize-nrow(M),ncol=ncol(M)))      
				M=cbind(M,matrix(0,nrow=colSize,ncol=colSize-ncol(M)))
			}
	
			M.frame.row=rbind(M.frame.row,matrix(0,nrow=colSize-nrow(M.frame.row),ncol=ncol(M.frame.row)))      
			M.frame.row=cbind(M.frame.row,matrix(0,nrow=colSize,ncol=colSize-ncol(M.frame.row)))
			
			M.frame.col=rbind(M.frame.col,matrix(0,nrow=colSize-nrow(M.frame.col),ncol=ncol(M.frame.col)))      
			M.frame.col=cbind(M.frame.col,matrix(0,nrow=colSize,ncol=colSize-ncol(M.frame.col)))
			
			M.frame.total=rbind(M.frame.total,matrix(0,nrow=colSize-nrow(M.frame.total),ncol=ncol(M.frame.total)))      
			M.frame.total=cbind(M.frame.total,matrix(0,nrow=colSize,ncol=colSize-ncol(M.frame.total)))
			#scale adjacency matrix to 2^n (n: natural number) - end
						
			M.org=M
			M.frame.row.org=M.frame.row 
			M.frame.col.org=M.frame.col    
			M.frame.total.org=M.frame.total      

			#list of matrices to recalculate results -> nodes involved
			kegg.maps.matrices[[paste(map,"org",sep=".")]]=as.vector(M)
			kegg.maps.matrices[[paste(map,"frame.row",sep=".")]]=as.vector(M.frame.row)
			kegg.maps.matrices[[paste(map,"frame.col",sep=".")]]=as.vector(M.frame.col)
			kegg.maps.matrices[[paste(map,"frame.total",sep=".")]]=as.vector(M.frame.total)
	
			feature.matrix=NULL
			feature.names=NULL

			size=sum(4*(4^(0:(log2(nrow(M))-1))))+sum(4*(4^(0:(log2(nrow(M.frame.row))-1))))+sum(4*(4^(0:(log2(nrow(M.frame.col))-1))))+sum(4*(4^(0:(log2(nrow(M.frame.total))-1))))
			
			feature.matrix=matrix(0,ncol=ncol(x),nrow=size)
			feature.names=rep("NA",size)	
			for(i in 1:ncol(x)){
				feature.count=1
				
				M=M.org  
				M.frame.row=M.frame.row.org
				M.frame.col=M.frame.col.org
				M.frame.total=M.frame.total.org
	 
				M[M!="0"]=x[match(M[M!="0"],rownames(x)),i]	
				M.frame.row[M.frame.row!="0"]=x[match(M.frame.row[M.frame.row!="0"],rownames(x)),i]
				M.frame.col[M.frame.col!="0"]=x[match(M.frame.col[M.frame.col!="0"],rownames(x)),i]
				M.frame.total[M.frame.total!="0"]=x[match(M.frame.total[M.frame.total!="0"],rownames(x)),i]
				#M[grep("^[A-Z][0-9]*",M)]=x[match(M[grep("^[A-Z][0-9]",M)],rownames(x)),i]
      					

				#transform matrix values to numeric values
				M=matrix(as.numeric(M),nrow=nrow(M),ncol=ncol(M))
				M.frame.row=matrix(as.numeric(M.frame.row),nrow=nrow(M.frame.row),ncol=ncol(M.frame.row))
				M.frame.col=matrix(as.numeric(M.frame.col),nrow=nrow(M.frame.col),ncol=ncol(M.frame.col))
				M.frame.total=matrix(as.numeric(M.frame.total),nrow=nrow(M.frame.total),ncol=ncol(M.frame.total))

				#calculate modified haar wavelet transform - start
				if(log2(ncol(M))-1 > 0){	
					for(j in 1:(log2(ncol(M))-1)){
						if(j > 0){
							M.dwt=dwt.2d(M,"haar",J=j)
							M.dwt.row=dwt.2d(M.frame.row,"haar",J=j)
							M.dwt.col=dwt.2d(M.frame.col,"haar",J=j)
							M.dwt.total=dwt.2d(M.frame.total,"haar",J=j)
						
							ll=as.vector(M.dwt[[length(M.dwt)]]) 
							ll.row=as.vector(M.dwt.row[[length(M.dwt.row)]])
							ll.col=as.vector(M.dwt.col[[length(M.dwt.col)]])
							ll.total=as.vector(M.dwt.total[[length(M.dwt.total)]])
		
							ll.length=length(ll)+length(ll.row)+length(ll.col)+length(ll.total)
							feature.matrix[feature.count:(feature.count+ll.length-1),i]=c(ll,ll.row,ll.col,ll.total)


							if(i == 1){
								ll.name=paste(paste(paste(paste(map,"org",sep="."),"_LL",j,sep=""),rep(1:sqrt(length(ll)),sqrt(length(ll))),sep="_"),rep(1:sqrt(length(ll)),each=sqrt(length(ll))),sep="_")
								ll.name.row=paste(paste(paste(paste(map,"frame.row",sep="."),"_LL",j,sep=""),rep(1:sqrt(length(ll)),sqrt(length(ll))),sep="_"),rep(1:sqrt(length(ll)),each=sqrt(length(ll))),sep="_")
								ll.name.col=paste(paste(paste(paste(map,"frame.col",sep="."),"_LL",j,sep=""),rep(1:sqrt(length(ll)),sqrt(length(ll))),sep="_"),rep(1:sqrt(length(ll)),each=sqrt(length(ll))),sep="_")
								ll.name.total=paste(paste(paste(paste(map,"frame.total",sep="."),"_LL",j,sep=""),rep(1:sqrt(length(ll)),sqrt(length(ll))),sep="_"),rep(1:sqrt(length(ll)),each=sqrt(length(ll))),sep="_")              
								
								feature.names[feature.count:(feature.count+ll.length-1)]=c(ll.name,ll.name.row,ll.name.col,ll.name.total)
							}
							feature.count=feature.count+ll.length
						}
					}
				}
		  
				M.dwt=dwt.2d(M,"haar",J=log2(ncol(M)))
				M.dwt.row=dwt.2d(M.frame.row,"haar",J=log2(ncol(M.frame.row)))
				M.dwt.col=dwt.2d(M.frame.col,"haar",J=log2(ncol(M.frame.col)))
				M.dwt.total=dwt.2d(M.frame.total,"haar",J=log2(ncol(M.frame.total)))
				
				ll=unlist(lapply(M.dwt,as.vector))
				ll.row=unlist(lapply(M.dwt.row,as.vector))
				ll.col=unlist(lapply(M.dwt.col,as.vector))
				ll.total=unlist(lapply(M.dwt.total,as.vector))

				ll.length=length(ll)+length(ll.row)+length(ll.col)+length(ll.total)
				feature.matrix[feature.count:(feature.count+ll.length-1),i]=c(ll,ll.row,ll.col,ll.total)
				

				#build feature names only in the first iteration
				if(i == 1){
					ll.name=unlist(lapply(names(M.dwt),generateFeatureNames,M.dwt,paste(map,"org",sep=".")))
					ll.name.row=unlist(lapply(names(M.dwt.row),generateFeatureNames,M.dwt.row,paste(map,"frame.row",sep=".")))
					ll.name.col=unlist(lapply(names(M.dwt.col),generateFeatureNames,M.dwt.col,paste(map,"frame.col",sep=".")))
					ll.name.total=unlist(lapply(names(M.dwt.total),generateFeatureNames,M.dwt.total,paste(map,"frame.total",sep=".")))

					feature.names[feature.count:(feature.count+ll.length-1)]=c(ll.name,ll.name.row,ll.name.col,ll.name.total)
				}
				feature.count=feature.count+ll.length
			}

			#delete features with range equal zero - start	
			zeroes.vector=apply(feature.matrix,1,sd)
			zeroes.vector=sapply(zeroes.vector,all.equal,0)

			toDel=1:length(zeroes.vector)
			toDel=toDel[zeroes.vector==TRUE]
      	  
			if(length(toDel)>0){	
				feature.matrix=feature.matrix[-toDel,]
				feature.names=feature.names[-toDel]
			}
			#delete features with range equal zero - end

			#build complete feature matrix
			feature.matrix.total=rbind(feature.matrix.total,feature.matrix)
			feature.names.total=c(feature.names.total,feature.names)
		}
	}
	colnames(feature.matrix.total)=colnames(x)
	rownames(feature.matrix.total)=feature.names.total
 
	res=list(features=feature.matrix.total,M=kegg.maps.matrices)
	
	return(res)
}

