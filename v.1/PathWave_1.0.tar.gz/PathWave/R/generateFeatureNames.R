`generateFeatureNames` <-
function(entry,M.dwt.entry,pwName){
	ll.dim=dim(M.dwt.entry[[entry]])[1]
	paste(paste(pwName,entry,rep(1:ll.dim,ll.dim),sep="_"),rep(1:ll.dim,each=ll.dim),sep="_")
}

