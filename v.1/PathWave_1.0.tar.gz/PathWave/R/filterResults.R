`filterResults` <-
function(entry,gene.list,cutoff){

	result=list()
  
	rowLength=max(as.numeric(summary(gene.list)[,1]))
    
	for(i in names(entry)){
		gene.matrix=NULL
  
		help.reg=entry[[i]]$reaction.regulation
		help.reac=entry[[i]]$reactions

		if(sum(abs(help.reg))>cutoff){
			sig.reac=help.reac[help.reg!=0]
      
			help.genes=NULL
			for(j in sig.reac){
				map=sub("\\.M\\d*","",i) 
				map=sub("\\.component\\d*","",map)
				help.gene.list=gene.list[[map]]
				help.genes=c(help.genes,help.gene.list[names(help.gene.list)==j])
				help=c(help.gene.list[names(help.gene.list)==j],rep("dummy",rowLength-length(help.gene.list[names(help.gene.list)==j])))
				gene.matrix=rbind(gene.matrix,help)
			}
			rownames(gene.matrix)=sig.reac
			help.genes=unique(help.genes)
      
			gene.matrix=unique(gene.matrix,MARGIN=1)
     
			if(length(rownames(gene.matrix))>=cutoff){
				result[[i]] = entry[[i]]  
			}
		}
	}
	return(result)
}

