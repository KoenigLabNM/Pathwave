
// Code fuer CPLEX
//  fuer ungewichteten Fall
// 14.8.2008
// Stefan Wiesberg

#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <string>
#include <list>
//#include <sstream>
//#include <stdio>
//#include <math>
//#include <stdlib>
#include <R.h> 
using namespace std;






int rhsClique[9] = {0,1,4,8,16,25,38,54,72};
int rhsQuasiClique[9] = {0,0,2,6,13,22,35,50,68};

int nNodes;
int nEdges = 0;
float edgeDensity;
int iMax;

string intToString(const int& port) {
   stringstream strStream;
   strStream << port;
    
   return strStream.str();
}

bool isInList(int element, list<int>& list1){
  list<int>::iterator iter;
  for(iter = (list1).begin(); iter != (list1).end(); ++iter){
	if(*iter == element){return true;}
  }
  return false;
}

bool areListsEqual(list<int>& list1, list<int>& list2){
  if(list1.size() != list2.size()) return false;
  bool result;
  list<int>::iterator iter1 ,iter2;
  for(iter1 = (list1).begin(); iter1 != (list1).end(); ++iter1){
    result = false;
    for(iter2 = (list1).begin(); iter2 != (list1).end(); ++iter2){
	if(*iter1 == *iter2) {result = true; break;}
    }
  if(result == false) return false;
  }
  return true;
}

string gen_symPairConstraint(int i, int j){
  string line="";

  for(int k=1;k<iMax;k++){
    for(int l=0;l<iMax;l++){	
	line += "-" + intToString(k) + "x_" + intToString(i) + "_" + intToString(k) + "_" + intToString(l);
	line += " +" + intToString(k) + "x_" + intToString(j) + "_" + intToString(k) + "_" + intToString(l) + " ";
    }
  }
  line += ">= 0\n";
  
  for(int k=0;k<iMax;k++){
    for(int l=0;l<iMax;l++){
	int coeff = (iMax+1)*k;    
	if(k!=0){line += "-" + intToString(coeff) + "x_" + intToString(i) + "_" + intToString(k) + "_" + intToString(l);
             line += " +" + intToString(coeff) + "x_" + intToString(j) + "_" + intToString(k) + "_" + intToString(l) + " ";}
	if(l!=0){line += "-" + intToString(l) + "x_" + intToString(i) + "_" + intToString(k) + "_" + intToString(l);
             line += " +" + intToString(l) + "x_" + intToString(j) + "_" + intToString(k) + "_" + intToString(l) + " ";}
    }
  }
  line += ">= 0";
  
  return line;
}

string gen_symForbidRotation(int i){
  int help;
  
  string line="";
  
  if(iMax % 2 == 0) help = iMax/2 -1;
  else help = (int) iMax/2; 

  for(int j=0;j<=help;j++){
    for(int k=0; k<=j; k++){
	line += "+x_" + intToString(i) + "_" + intToString(j) + "_" + intToString(k) + " ";	
    }
  }
  line +="=1";
  
  return line;
}


extern "C" {

void buildLPFiles(double *x, int *xr, int *xc, int *nN, int *iM, int *strat, int *aTI, int *aCC, int *aSBC, int *aSI, int *a5CC, int *uDM, int *aNSC, char **fileName){

// ------------------------------------------------------------
// ------------------ PARAMETERS SECTION ----------------------
// ------------------------------------------------------------

enum Strategy {automatic, manually, largesystem, basicsystem};

// CHOOSE STRATEGY
// Choose the strategy for the creation of the integral linear
// program. There are four possibilities:
// (1) automatic: The default setting. The generator will auto-
//	matically strike a balance between running time and 
//	performance, depending on the input matrix.
// (2) manually: The user can choose (below) the type of 
//	additional inequalities to be generated. The basic
//	system will be generated in any case.
// (3) largesystem: As much inequalities as possible are tried
// 	to be found. This may yield results of good quality
//	for systems of small or medium size.
// (4) basicsystem: Only the most basic system is generated.
//	Use this option for large adjacency matrices where no
//	feasible solution was found using a larger number of
//	inequalities.

Strategy strategy = (Strategy)*strat;

  bool addTriangleInequalities = (bool)*aTI;
  bool addCliqueConstraints = (bool)*aCC;
  bool addSymmetryBreakingConstraints = (bool)*aSBC;
  bool addStarInequalities = (bool)*aSI;
  bool add5CycleConstraints = (bool)*a5CC;
  bool useDummyNodes = (bool)*uDM;
  bool addNeighbourStarConstraints = (bool)*aNSC;
  
  
// ------------------------------------------------------------
// --------------END: PARAMETERS SECTION ----------------------
// ------------------------------------------------------------

ofstream myfile;
myfile.open (*fileName);  
if (!myfile) {
  cout << "ERROR: Can't open output file !" << *fileName << endl;
  exit(1);
}
// ---------------------------------------------
// ---------------------------------------------
// -------------- Build Matrix -----------------
// ---------------------------------------------
// ---------------------------------------------
  int i,j,v,v1,v2,v3;
  int row = *xr;
  int col = *xc; 

  string helpLine;
  
  nNodes=*nN;
  iMax=*iM;

   
  iMax = 1;
  do {
      iMax++;
  } while(iMax*iMax < nNodes);

  iMax ++;

  int nDummies = 0;
  if(useDummyNodes){nDummies = iMax * iMax - nNodes;}

  int nNeighbours[nNodes+nDummies];
  for(int i=0; i<nNodes+nDummies; i++) nNeighbours[i] = 0;	
  list<int> neighbourList[nNodes+nDummies];

  double adjMatrix[nNodes+nDummies][nNodes+nDummies];
  for(v1=0; v1<nNodes; v1++) {
      for(v2=0; v2<nNodes; v2++) {
	  adjMatrix[v1][v2]=x[v1*col+v2];
	  if (adjMatrix[v1][v2] < 0.5) adjMatrix[v1][v2] = 0.0;
	  else{
		if(v1 < v2){
		  nNeighbours[v1]++; nNeighbours[v2]++;
		  neighbourList[v1].push_back(v2);
		  neighbourList[v2].push_back(v1);
		  nEdges++;
		}
	  }
      }
  }
 for(v1=0; v1<nNodes+nDummies; v1++){
   for(v2=nNodes; v2<nNodes+nDummies; v2++){
	adjMatrix[v1][v2] = 0.0;
   }
 }
 for(v1=nNodes; v1<nNodes+nDummies; v1++){
   for(v2=0; v2<nNodes; v2++){
	adjMatrix[v1][v2] = 0.0;
   }
 }

  edgeDensity = (float)nEdges / ((float)nNodes*((float)nNodes-1)/2);



// ---------------------------------------------
// ---------------------------------------------
// ---------- Objective function ---------------
// ---------------------------------------------
// ---------------------------------------------
  myfile << "Minimize" <<endl;

  for(v1=0; v1<nNodes-1; v1++) {
      for(v2=v1+1; v2<nNodes; v2++) {
	    if(adjMatrix[v1][v2] > 0.001){
           myfile << "+" << adjMatrix[v1][v2] << "d_" << v1 << "_" << v2 << " ";
        }
      } 
  }
  myfile <<endl << "Subject To" <<endl;

// ---------------------------------------------
// ---------------------------------------------
// ------------ Basic inequalities -------------
// ---------------------------------------------
// ---------------------------------------------

// (1) One grid point for every node:
  for(v=0; v<nNodes+nDummies; v++) {
      for(i=0; i<iMax; i++) {
	  for(j=0; j<iMax; j++) {
	      myfile << "+ x_" << v << "_" << i << "_" << j << " ";
	  }
      }
      myfile << "= 1" << endl;
  }

// (2) At most 1 node on every grid point:
  for(i=0; i<iMax; i++) {
      for(j=0; j<iMax; j++) {
	  for(v=0; v<nNodes+nDummies; v++) {
	      myfile << "+ x_" << v << "_" << i << "_" << j << " ";
	  }
	  if(useDummyNodes) {myfile << "= 1" << endl;}
	  else{myfile << "<= 1" << endl;}
      }
  }
  

// (3a) Manhattan metric
  for(v1=0; v1<nNodes-1; v1++) {
      for(v2=v1+1; v2<nNodes; v2++) {
	  myfile <<  "+ d_" << v1 << "_" << v2 << " ";
	  for(i=0; i<iMax; i++) {
	      for(j=0; j<iMax; j++) {
		  myfile << "+ " << i << "x_" << v1 << "_" << i << "_" << j << " ";
		  myfile << "- " << i << "x_" << v2 << "_" << i << "_" << j << " ";
		  myfile << "+ " << j << "x_" << v1 << "_" << i << "_" << j << " ";
		  myfile << "- " << j << "x_" << v2 << "_" << i << "_" << j << " ";
	      }
	  }
	  myfile << ">= 0" << endl;
      }
  }

// (3b) Manhattan metric	  
  for(v1=0; v1<nNodes-1; v1++) {
      for(v2=v1+1; v2<nNodes; v2++) {
	  myfile <<  "+ d_" << v1 << "_" << v2 << " ";
	  for(i=0; i<iMax; i++) {
	      for(j=0; j<iMax; j++) {
		  myfile << "+ " << i << "x_" << v1 << "_" << i << "_" << j << " ";
		  myfile << "- " << i << "x_" << v2 << "_" << i << "_" << j << " ";
		  myfile << "- " << j << "x_" << v1 << "_" << i << "_" << j << " ";
		  myfile << "+ " << j << "x_" << v2 << "_" << i << "_" << j << " ";
	      }
	  }
	  myfile << ">= 0" << endl;
      }
  }
	  
// (3c) Manhattan metric
  for(v1=0; v1<nNodes-1; v1++) {
      for(v2=v1+1; v2<nNodes; v2++) {
	  myfile <<  "+ d_" << v1 << "_" << v2 << " ";
	  for(i=0; i<iMax; i++) {
	      for(j=0; j<iMax; j++) {
		  myfile << "- " << i << "x_" << v1 << "_" << i << "_" << j << " ";
		  myfile << "+ " << i << "x_" << v2 << "_" << i << "_" << j << " ";
		  myfile << "- " << j << "x_" << v1 << "_" << i << "_" << j << " ";
		  myfile << "+ " << j << "x_" << v2 << "_" << i << "_" << j << " ";
	      }
	  }
	  myfile << ">= 0" << endl;
      }
  }
	
// (3d) Manhattan metric  
  for(v1=0; v1<nNodes-1; v1++) {
      for(v2=v1+1; v2<nNodes; v2++) {
	  myfile <<  "+ d_" << v1 << "_" << v2 << " ";
	  for(i=0; i<iMax; i++) {
	      for(j=0; j<iMax; j++) {
		  myfile << "- " << i << "x_" << v1 << "_" << i << "_" << j << " ";
		  myfile << "+ " << i << "x_" << v2 << "_" << i << "_" << j << " ";
		  myfile << "+ " << j << "x_" << v1 << "_" << i << "_" << j << " ";
		  myfile << "- " << j << "x_" << v2 << "_" << i << "_" << j << " ";
	      }
	  }
	  myfile << ">= 0" << endl;
      }
  }

// ---------------------------------------------
// ---------------------------------------------
// ---- Symmetry breaking inequalities ---------
// ---------------------------------------------
// ---------------------------------------------
if( ((strategy == manually) && addSymmetryBreakingConstraints)
    || (strategy == largesystem) 
    || (strategy == automatic) ){
// a) Forbid Translation
if(nNodes < ((iMax-1)*(iMax-1)) ){  // if translation theoretically possible
    for(int j=0; j < iMax; j++){
	for(int i=0; i < nNodes-1; i++){
	    myfile << "+x_" << i << "_" << j << "_0 ";
	}
    }
    myfile << ">= 1" <<endl;
    for(int j=0; j < iMax; j++){
	for(int i=0; i < nNodes-1; i++){
	    myfile << "+x_" << i << "_0_" << j << " ";
	}
    }
    myfile << ">= 1" <<endl;
}

// b) Symmetrical vertex pairs in graph
for(int i=0;i<nNodes;i++){
	neighbourList[i].sort();
}

list<int> symPairPartners[nNodes+nDummies];

for(int i=0;i<nNodes+nDummies;i++){
  for(int j=i+1; j<nNodes+nDummies;j++){
    if(nNeighbours[i] == nNeighbours[j]){
	list<int> list1 = neighbourList[i];
	list<int> list2 = neighbourList[j];
	list1.remove(j);
	list2.remove(i);
	int list1Size = list1.size();
	bool listsEqual = true;
	for(int k=0; k<list1Size; k++){
	  if(list1.front() != list2.front()) {
		listsEqual = false;
		break;
	  }
	  else{
		list1.pop_front();
		list2.pop_front();
	  }
	}
	if(listsEqual){ 
		symPairPartners[i].push_back(j);
		symPairPartners[j].push_back(i);
	}
	
    }
  }
}

  // Eliminate sym pairs implied by other sym pairs
list<int>::iterator iter,iter2;
for(int i=0;i<nNodes+nDummies;i++){
 for(iter=symPairPartners[i].begin(); iter != symPairPartners[i].end(); ++iter){ 
   for(iter2=symPairPartners[*iter].begin(); 
                                iter2 != symPairPartners[*iter].end(); ++iter2){ 	
	if(*iter2 > *iter){
		symPairPartners[i].remove(*iter2);
		symPairPartners[*iter2].remove(i);
	}
   }
 }
}
  // Generate constraints for remaining sym pairs
for(int i=0;i<nNodes+nDummies;i++){
 for(iter=symPairPartners[i].begin(); iter != symPairPartners[i].end(); ++iter){ 
	if(i < *iter){ 
	  helpLine=gen_symPairConstraint(i, *iter);
	  myfile << helpLine <<endl;
	}	
 }
}

// c) Forbid rotation
for(int i=0;i<nNodes;i++){
  if(symPairPartners[i].empty()){
	helpLine=gen_symForbidRotation(i);	
	myfile << helpLine << endl;
	
	break;
  }
}

} // END: Symmetry breaking inequalities


// ---------------------------------------------
// ---------------------------------------------
// -----------  Star Inequalities --------------
// ---------------------------------------------
// ---------------------------------------------
if(   ((strategy == manually) && addStarInequalities)
   || (strategy == largesystem)
   || (strategy == automatic)){

  int rhsStar[nNodes];
  int neighbours;
  for(v1=0; v1<nNodes; v1++) {
      v=0;
      for(v2=0; v2<nNodes; v2++) { 
	  if(adjMatrix[v1][v2] > 0.001) v++;
      }
      neighbours = 1;
      rhsStar[v1] = 0;
      while(v > 4*neighbours) {
	  v -= 4*neighbours;
	  rhsStar[v1] += 4*neighbours*neighbours;
	  neighbours++;
      }
      rhsStar[v1] += v*neighbours;
  }

  for(v1=0; v1<nNodes; v1++) {
    if(nNeighbours[v1] > 4){
      for(v2=0; v2<v1; v2++) {
	   if(adjMatrix[v1][v2] > 0.001) myfile << "+ d_" << v2 << "_" << v1 << " ";
      }
      for(v2=v1+1; v2<nNodes; v2++) {
        if(adjMatrix[v1][v2] > 0.001) myfile << "+ d_" << v1 << "_" << v2 << " ";
      }
      myfile << " >= " << rhsStar[v1] << endl;
    }
  }
}

// ---------------------------------------------
// ---------------------------------------------
// ---------  Triangle Inequalities ------------
// ---------------------------------------------
// ---------------------------------------------
if( (  (strategy == manually) && addTriangleInequalities )
    || (strategy == largesystem)
    || (strategy == basicsystem) 
    || (strategy == automatic)){
 for(v1=0; v1<nNodes-2; v1++) {
   for(v2=v1+1; v2<nNodes-1; v2++) {
     for(v3=v2+1; v3<nNodes; v3++) {
       if(adjMatrix[v1][v2] + adjMatrix[v1][v3] + adjMatrix[v2][v3] >= 1.0) {
		  myfile << "+ d_" << v1 << "_" << v2 << " + d_" << v2 << "_" << v3;
          myfile << " - d_" << v1 << "_" << v3 << " >= 0" << endl; 
		  myfile << "+ d_" << v1 << "_" << v2 << " - d_" << v2 << "_" << v3;
          myfile << " + d_" << v1 << "_" << v3 << " >= 0" << endl; 
		  myfile << "- d_" << v1 << "_" << v2 << " + d_" << v2 << "_" << v3;
          myfile << " + d_" << v1 << "_" << v3 << " >= 0" << endl; 
		  //myfile << "+ d_" << v1 << "_" << v2 << " + d_" << v2 << "_" << v3;
          //myfile << " + d_" << v1 << "_" << v3 << " >= 4" << endl; 
	      }
	   } 
    }
  }
}


// ---------------------------------------------
// ---------------------------------------------
// ------------ Clique Constraints -------------
// ---------------------------------------------
// ---------------------------------------------

int nCliquesFound = 0;
if( (   (strategy == manually) && addCliqueConstraints )
     || (strategy == largesystem) 
     || (strategy == automatic) ) {

int maxCliqueSize = 9;
list<int> allCliques[maxCliqueSize-2+1]; // +1 

list<int> trianglePartners[nNodes][nNodes];

int cliqueCounter[maxCliqueSize+1];  // +1 
for(int i=0;i<maxCliqueSize;i++){cliqueCounter[i]=0;}

for(int i=0;i<nNodes-2;i++){
  for(int j=i+1; j<nNodes-1;j++){
    if(adjMatrix[i][j] > 0.9){
      for(int k= j+1;k<nNodes;k++){
	if(adjMatrix[i][k] > 0.9 && adjMatrix[j][k] > 0.9){
	 cliqueCounter[0]++;
	 trianglePartners[i][j].push_back(k);
	 allCliques[0].push_back(i);
	 allCliques[0].push_back(j);
	 allCliques[0].push_back(k);
	 myfile << "d_" << i << "_" << j << " + d_" << i << "_" << k;
     myfile << " + d_" << j << "_" << k << " >= 4" <<endl;
//	 trianglePartners[i][k].push_back(j);
//	 trianglePartners[j][k].push_back(i);
	}
      }
    }
  }
}

if(cliqueCounter[0] == 0){
//	myfile << "No cliques found!" << endl;
}
else{
    nCliquesFound += cliqueCounter[0];
}

//int k=3;

if(cliqueCounter[0] > 3){

list<int> currentClique;
list<int>::iterator iter, iter2;
//list<int> clique4Partners[cliqueCounter[0]];
for(int i=0;i<nNodes;i++){
  for(int j=i+1; j<nNodes;j++){
     if(trianglePartners[i][j].size() > 1){
	int listSize = trianglePartners[i][j].size();
	for(int k=0; k < listSize; k++){	
	  int first = trianglePartners[i][j].front();
	  for(iter=trianglePartners[i][j].begin(); 
                                  iter != trianglePartners[i][j].end(); ++iter){ 
		if(adjMatrix[first][*iter] > 0.9){
			cliqueCounter[1]++;
			currentClique.clear();
			currentClique.push_back(i);
			currentClique.push_back(j);
			currentClique.push_back(first);
			currentClique.push_back(*iter);
			currentClique.sort();
			int currentCliqueArray4[4];
			int countTill3 = 0;
			for(iter2=currentClique.begin(); 
                                         iter2 != currentClique.end(); ++iter2){ 
			  currentCliqueArray4[countTill3] = (*iter2);
			  countTill3++;
			  allCliques[1].push_back(*iter2);
			}
			for(int h1=0; h1<3; h1++){
			  for(int h2=h1+1; h2<4;h2++){
			    myfile << "+d_" << currentCliqueArray4[h1] << "_";
                myfile << currentCliqueArray4[h2] << " ";
			  }
			}
			myfile << ">= 8" << endl;
		}
	  }
	  trianglePartners[i][j].pop_front();
        }
    }
  }
}

//if(cliqueCounter[1] != 0){
//   myfile << cliqueCounter[1] << " 4-cliques found" << endl;
//}
nCliquesFound += cliqueCounter[1];
if(cliqueCounter[1] > 4){

 int cliqueKArray[maxCliqueSize-3][cliqueCounter[1] * maxCliqueSize +1]; // +1 
 int currentCliqueArray[maxCliqueSize+1][maxCliqueSize+1];   // +1

for(int k=5; k<maxCliqueSize+1;k++){   // +1 

  allCliques[k-5].clear();

 int i=0;
 for(iter=allCliques[k-4].begin(); iter != allCliques[k-4].end(); ++iter){ 
	if(i < cliqueCounter[1]*maxCliqueSize){
             cliqueKArray[k-5][i] = (*iter);
	     i++;
        }
	else{ break; }
 }
 for(int i1=0; i1<(k-1)* cliqueCounter[k-4] - k-1; i1=i1+(k-1)){
  for(int i2=i1+k-1; i2<(k-1)* cliqueCounter[k-4]; i2=i2+(k-1)){
  //compare the cliques:
    bool isIdentical = true;
    for(int j=0; j<k-2; j++){
	if(cliqueKArray[k-5][i1+j] != cliqueKArray[k-5][i2+j]){
		isIdentical = false;
		break;
	}
    }
    if(isIdentical){
	if(   (cliqueKArray[k-5][i1+k-2] != cliqueKArray[k-5][i2+k-2]) 
       && adjMatrix[cliqueKArray[k-5][i1+k-2]][cliqueKArray[k-5][i2+k-2]] >0.9){
	  cliqueCounter[k-3]++;
	  currentClique.clear();
	  //myfile << "Clique found: ";
	  for(int i3=0; i3<k-1; i3++){
	    currentClique.push_back(cliqueKArray[k-5][i1+i3]);
	// myfile << cliqueKArray[k-5][i1]+i3 << " ";
	  }
	  currentClique.push_back(cliqueKArray[k-5][i2+k-2]);
	// myfile << cliqueKArray[k-5][i2+k-2] << " ";
	  currentClique.sort();
	  int counter = 0;
	  for(iter2=currentClique.begin(); iter2 != currentClique.end(); ++iter2){ 
	    currentCliqueArray[k-5][counter] = (*iter2);	
	    counter++;
	    (allCliques[k-3]).push_back(*iter2);
	  }

	  for(int h1=0; h1<k-1; h1++){
	    for(int h2=h1+1; h2<k;h2++){
	      myfile << "+d_" << currentCliqueArray[k-5][h1] << "_";
          myfile << currentCliqueArray[k-5][h2] << " ";
	    }
	  }
	  myfile << ">= " << rhsClique[k-1] << endl;
	// myfile << endl;

	}
    }

  }
 }


if(cliqueCounter[k-3] != 0){
    nCliquesFound += cliqueCounter[k-3];
  //myfile << cliqueCounter[k-3] << " " << k << "-cliques found" << endl;
  if(k == maxCliqueSize){ break; }

// Quasi cliques
 if(cliqueCounter[k-3] < k) {
   if(cliqueCounter[k-3] == 0){ break; }
   else{
     k++;
     i=0;
     for(iter=allCliques[k-3].begin(); iter != allCliques[k-3].end(); ++iter){ 
	if( i < cliqueCounter[1]*maxCliqueSize ){
	    cliqueKArray[k-5][i] = (*iter);
	    i++;
	}
        else{ break; }
     }
   }
    for(int i=0; i<cliqueCounter[k-3]; i++){ //cliques
      for(int node=0; node<nNodes; node++){ // other nodes
	int edgeCounter = 0;
	bool isNodeInClique = false;
        for(int j=i*k; j<i+k; j++){ // clique nodes
	  if(node == cliqueKArray[k-5][j]) isNodeInClique = true;
	  if(adjMatrix[cliqueKArray[k-5][j]][node] == 1) edgeCounter++;
        }
	if(!isNodeInClique && edgeCounter == k-1){
//	  myfile << "Quasi-Clique!" << endl;
	  int counter = 0;
          for(int j=i; j<i+k; j++){
	    if(cliqueKArray[k-5][j] < node){
	    allCliques[k-3].push_back(cliqueKArray[k-5][j]);
	    currentCliqueArray[k-5][counter] = cliqueKArray[k-5][j];
	    counter++;
//	myfile << cliqueKArray[k-5][j] << " ";
	    }
	    else{break;}
	  }
	  allCliques[k-3].push_back(node);
	  currentCliqueArray[k-5][counter] = node;
	  counter++;

//	myfile << "n" << node << " ";
          for(int j=i; j<i+k; j++){
	    if(cliqueKArray[k-5][j] > node){
	    allCliques[k-3].push_back(cliqueKArray[k-5][j]);
	    currentCliqueArray[k-5][counter] = cliqueKArray[k-5][j];
	    counter++;
//	myfile << cliqueKArray[k-5][j] << " ";
	    }
	  }
   // Print quasi clique
	  for(int h1=0; h1<k; h1++){
	    for(int h2=h1+1; h2<k+1;h2++){
		if(  currentCliqueArray[k-5][h1] < currentCliqueArray[k-5][h2] 
          && adjMatrix[currentCliqueArray[k-5][h1]][currentCliqueArray[k-5][h2]]
              > 0.9){
		  myfile << "+d_" << currentCliqueArray[k-5][h1] << "_";
          myfile << currentCliqueArray[k-5][h2] << " ";
		}
		if(currentCliqueArray[k-5][h1] > currentCliqueArray[k-5][h2] 
         && adjMatrix[currentCliqueArray[k-5][h2]][currentCliqueArray[k-5][h1]] 
             > 0.9){
		  myfile << "+d_" << currentCliqueArray[k-5][h2] << "_";
          myfile << currentCliqueArray[k-5][h1] << " ";
		}
	    }
	  }
	  myfile << ">= " << rhsQuasiClique[k] << endl;	


	}
    }
  }

    break;
  }
}
}
}
}
}



// ---------------------------------------------
// ---------------------------------------------
// ----------- 5-Cycle Constraints -------------
// ---------------------------------------------
// ---------------------------------------------


if( (   (strategy == manually) && add5CycleConstraints ) 
     || (strategy == largesystem) 
     || (strategy == automatic) ){

list<int> current5cycle;
int n5cycles = 0;
int all5Cycles[nNodes* nNodes][5];

//myfile << "5cycle: " << endl;
list<int>::iterator iter1,iter2, iter3, iter4, iter5;
for(int u1 = 0; u1 <nNodes; u1++){
 if(!neighbourList[u1].empty()){
  iter1 = neighbourList[u1].begin();
  for(int u2 = 0; u2 < nNeighbours[u1]-1; u2++){
   if(*iter1 > u1){
     iter2 = neighbourList[u1].begin();
     for(int i=0; i<u2+1; i++){iter2++;}
       for(int u3 = u2+1; u3 < nNeighbours[u1];u3++){
	  if(*iter2 > u1){
	    iter3 = neighbourList[*iter1].begin();
	      for(int u4=0; u4<nNeighbours[*iter1]; u4++){
	        iter4 = neighbourList[*iter2].begin();
	        for(int u5=0; u5<nNeighbours[*iter2];u5++){

		  if(    *iter3 != u1 
             && *iter3 != *iter2 
             && *iter4 != u1 
             && *iter4 != *iter1 
             && *iter4 > *iter3 
             && adjMatrix[*iter4][*iter3] > 0.9){
			current5cycle.clear();
			current5cycle.push_back(u1);
			current5cycle.push_back(*iter1);
			current5cycle.push_back(*iter2);
			current5cycle.push_back(*iter3);
			current5cycle.push_back(*iter4);
			current5cycle.sort();
			bool identical = false;
			for(int i=0; i<n5cycles; i++){
			  identical = false;
			  int j=0;
 			  for(iter5=current5cycle.begin(); 
                                         iter5 != current5cycle.end(); ++iter5){ 
			     if(*iter5 == all5Cycles[i][j]) {identical = true; j++;}	
			     else{identical = false; break;}
			  }
			if(identical){break;}
			}
			if(!identical){
			    int i=0;
 			    for(iter5=current5cycle.begin(); 
                                         iter5 != current5cycle.end(); ++iter5){ 	
				 all5Cycles[n5cycles][i] = *iter5;
				 //myfile << *iter5 << " ";
				 i++;
			    }
			n5cycles++;
			//myfile << endl;
			if(u1 < *iter1) myfile << "+d_" <<u1 << "_" << *iter1 << " ";
			else myfile << "+d_" <<*iter1 << "_" << u1 << " ";
			if(u1 < *iter2) myfile << "+d_" <<u1 << "_" << *iter2 << " ";
			else myfile << "+d_" <<*iter2 << "_" << u1 << " ";
			if(*iter3 < *iter1) myfile << "+d_" <<*iter3 << "_" << *iter1 << " ";
			else myfile << "+d_" <<*iter1 << "_" << *iter3 << " ";
			if(*iter2 < *iter4) myfile << "+d_" <<*iter2 << "_" << *iter4 << " ";
			else myfile << "+d_" <<*iter4 << "_" << *iter2 << " ";
			if(*iter3 < *iter4) myfile << "+d_" <<*iter3 << "_" << *iter4 << " ";
			else myfile << "+d_" <<*iter4 << "_" << *iter3 << " ";
			myfile << ">= 6" <<endl;
			}

		  }
		  iter4++;
	        }
	       iter3++;
	      }
	   }
	iter2++;
	  //neighbourList

       }
      }
   iter1++;
  }
}
}
}


// ---------------------------------------------
// ---------------------------------------------
// ---------- NeighbourStar Constraints --------
// ---------------------------------------------
// ---------------------------------------------


if(  ( (strategy == manually) && addNeighbourStarConstraints )
    || (strategy == largesystem) 
    || ( (strategy == automatic) 
            && (nNodes < 50) 
            && (nCliquesFound < nNodes) 
            && (edgeDensity < 0.2) ) ) {

int maxNOfConstraints = 10*nNodes;
list<int> neighbourStarArray[maxNOfConstraints];
int solCounter = 0;

int neighbourArray[nNodes][nNodes];
for(int center=0; center<nNodes; center++){
    list<int>::iterator neighStarIter;
    int i=0;
    for(neighStarIter = neighbourList[center].begin(); 
                 neighStarIter != neighbourList[center].end(); ++neighStarIter){
	neighbourArray[center][i] = *neighStarIter;
	i++;
    }
  }

for(int center=0; center<nNodes; center++){
  if(    (nNeighbours[center] >= 4) 
      && (     (strategy != automatic) 
           || (    (strategy == automatic) 
                && (nNeighbours[center] <= 6) ) 
         ) 
    ){

//myfile << "Center: " << center << endl;

    int mostNeighbours[4] = {-1, -1, -1, -1};
    int mostNeighboursVal[4] = {0,0,0,0};

 for(int n1=0; n1<nNeighbours[center]; n1++){
 for(int n2=0; n2<nNeighbours[center]; n2++){
 for(int n3=0; n3<nNeighbours[center]; n3++){
 for(int n4=0; n4<nNeighbours[center]; n4++){
 if(center != n1 && center != n2 && center != n3 && center != n4 &&
    n1 != n2 && n1 != n3 && n1 != n4 && 
    n2 != n3 && n2 != n4 && n3 != n4){
  bool solutionFound = false;

// myfile << "center n1 n2 " << center << " "<< n1 << " "<< n2 << endl;
mostNeighbours[0] = n1;
mostNeighbours[1] = n2;
mostNeighbours[2] = n3;
mostNeighbours[3] = n4;
mostNeighboursVal[0] = nNeighbours[n1];
mostNeighboursVal[1] = nNeighbours[n2];
mostNeighboursVal[2] = nNeighbours[n3];
mostNeighboursVal[3] = nNeighbours[n4];

    list<int> finalNodes;

    finalNodes.push_back(center);
    finalNodes.push_back(mostNeighbours[0]);
    finalNodes.push_back(mostNeighbours[1]);
    finalNodes.push_back(mostNeighbours[2]);
    finalNodes.push_back(mostNeighbours[3]);

    if(mostNeighboursVal[0] >= 4) {
    int candidatesFor1[nNeighbours[n1]];
    int cand1counter = 0;
    for(int i=0; i<nNeighbours[n1]; i++){
	if(!isInList(neighbourArray[n1][i], finalNodes) ){
	  candidatesFor1[cand1counter] = neighbourArray[n1][i];
	  cand1counter++;
	}
     }
    if(cand1counter >= 4){

    for(int c11 = 0; c11 < cand1counter-3; c11++){
    for(int c12 = c11+1; c12 < cand1counter-2; c12++){
    for(int c13 = c12+1; c13 < cand1counter-1; c13++){
    for(int c14 = c13+1; c14 < cand1counter; c14++){

    solutionFound = false;
	finalNodes.push_back(candidatesFor1[c11]); 
	finalNodes.push_back(candidatesFor1[c12]); 
	finalNodes.push_back(candidatesFor1[c13]); 
	finalNodes.push_back(candidatesFor1[c14]); 

    for(int i=0; i <nNeighbours[mostNeighbours[1]]; i++){
	if(   !isInList(neighbourArray[mostNeighbours[1]][i], finalNodes) 
       && finalNodes.size() < 11){
		finalNodes.push_back(neighbourArray[mostNeighbours[1]][i]); 
        }
    }
    if(finalNodes.size() == 11){
	for(int i=0; i <nNeighbours[mostNeighbours[2]]; i++){
	  if(  !isInList(neighbourArray[mostNeighbours[2]][i], finalNodes) 
         && finalNodes.size() < 14){
		     finalNodes.push_back(neighbourArray[mostNeighbours[2]][i]); 
          }
    	}
     if(finalNodes.size() == 13){
	    for(int i=0; i <nNeighbours[mostNeighbours[3]]; i++){
		if(   !isInList(neighbourArray[mostNeighbours[3]][i], finalNodes) 
           && finalNodes.size() < 15){
		          finalNodes.push_back(neighbourArray[mostNeighbours[3]][i]); 
        	}
        }
	    if(finalNodes.size() == 16){
             solutionFound = true;    // !!!!!!!!!!!!!!!!
             finalNodes.push_front(3);
             finalNodes.push_front(3);
             finalNodes.push_front(4);
             finalNodes.push_front(4);
        }
     }
	
}


//add solution to solution's array
if(solutionFound){
if(solCounter < maxNOfConstraints){
neighbourStarArray[solCounter] = finalNodes;
solCounter++;}
//myfile << "solCounter: " << solCounter << endl;
}
finalNodes.clear();


}
}

//

} 
}

}
}

} //if main
} //for main
} //for main
} //for main
} //for main

}
}
// Delete multiple solutions
bool isSolutionUnique[solCounter];
for(int i=0; i<solCounter; i++) isSolutionUnique[i] = true;
for(int i=0; i<solCounter-1; i++){
  for(int j=i+1; j<solCounter; j++){
	if(isSolutionUnique[i] && isSolutionUnique[j]){
	  if(areListsEqual(neighbourStarArray[i],neighbourStarArray[j])){
		isSolutionUnique[j] = false;
	  }
	}
  }
}

// Print inequalities
int nDifferentNeighbourStars = 0;
for(int i=0; i<solCounter; i++){
  if(isSolutionUnique[i]){
	int currentSol[22];
	for(int j=0; j<22; j++){currentSol[j] = -1;}
	list<int>::iterator iter;
	int k=0;
	for(iter = neighbourStarArray[i].begin(); 
                iter != neighbourStarArray[i].end(); ++iter){
		currentSol[k] = *iter;
//		myfile << *iter << " ";
		k++;
	}
//	myfile << endl;
		
    myfile << "+d_" << currentSol[4] << "_" << currentSol[5];
    myfile << " +d_" << currentSol[4] << "_" << currentSol[6];
    myfile << " +d_"<< currentSol[4] << "_" << currentSol[7];
    myfile << " +d_"<< currentSol[4] << "_" << currentSol[8] << " ";
	for(int k1 = 0; k1<currentSol[0]-1; k1++){
	  if(currentSol[5] < currentSol[9+k1]) {
           myfile << "+d_" << currentSol[5] << "_" << currentSol[9+k1] << " ";
      }
	  else {myfile << "+d_" << currentSol[9+k1] << "_" << currentSol[5] << " ";}
	}
	for(int k2 = 0; k2<currentSol[1]-1; k2++){
	   if(currentSol[6] < currentSol[8+currentSol[0]+k2]){
            myfile << "+d_" << currentSol[6] << "_";
            myfile << currentSol[8+currentSol[0]+k2] << " ";
       }
	   else{
            myfile << "+d_" << currentSol[8+currentSol[0]+k2] << "_";
            myfile << currentSol[6] << " ";
       }
	}
	for(int k3 = 0; k3<currentSol[2]-1; k3++){
	    if(currentSol[7] < currentSol[7+currentSol[0]+currentSol[1]+k3]) {
            myfile << "+d_" << currentSol[7] << "_";
            myfile << currentSol[7+currentSol[0]+currentSol[1]+k3] << " ";
        }
	    else{
            myfile << "+d_" << currentSol[7+currentSol[0]+currentSol[1]+k3];
            myfile << "_" << currentSol[7] << " ";
        }
	}
	for(int k4 = 0; k4<currentSol[3]-1; k4++){
       if(  currentSol[8] 
            < currentSol[6+currentSol[0]+currentSol[1]+currentSol[2]+k4]) {
          myfile << "+d_" << currentSol[8] << "_";
          myfile << currentSol[6+currentSol[0]+currentSol[1]+currentSol[2]+k4];
          myfile << " ";
       }
       else{
          myfile << "+d_";
          myfile << currentSol[6+currentSol[0]+currentSol[1]+currentSol[2]+k4];
          myfile << "_" << currentSol[8] << " ";
       }
	}
	// right-hand side
	int rhs = currentSol[0] + currentSol[1] + currentSol[2] + currentSol[3] + 1;
	if(currentSol[2] == 4 && currentSol[3] == 3) rhs++;
	if(currentSol[2] == 4 && currentSol[3] == 4) rhs++;
	myfile << ">= " << rhs << endl;
	nDifferentNeighbourStars++;
  }
}


// myfile << "nDifferentNeighbourStars: " << nDifferentNeighbourStars << endl;
} // END neighbour star constraints


// ---------------------------------------------
// ---------------------------------------------
// ----- Simple Bounds and Integrality ---------
// ---------------------------------------------
// ---------------------------------------------

myfile << "Bounds" <<endl;
  for(v1=0; v1<nNodes-1; v1++) {
      for(v2=v1+1; v2<nNodes; v2++) {
	  myfile << "1 <= d_" << v1 << "_" << v2 <<endl;
	  myfile << "d_" << v1 << "_" << v2 << " <= " << 2*iMax-2<< "" << endl; 
      } 
  }

myfile << "Integers" << endl;
  for(v1=0; v1<nNodes-1; v1++) {
      for(v2=v1+1; v2<nNodes; v2++) {
	  myfile << "d_" << v1 << "_" << v2 << endl; 
      } 
  }

myfile << "Binaries" <<endl;
  for(v=0; v<nNodes; v++) {
      for(i=0; i<iMax; i++) {
	  for(j=0; j<iMax; j++) {
	      myfile << "x_" << v << "_" << i << "_" << j <<endl;
	  }
      }
  }

myfile << "End" << endl;

myfile.close();


}

}
