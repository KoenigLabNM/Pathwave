### Name: pwLPFiles
### Title: PathWave input file generator for LP solver
### Aliases: pwLPFiles
### Keywords: manip graphs optimize

### ** Examples

#build a simple adjacency matrix
library(e1071)
#define number of nodes and generate random adjacency matrix
nNodes=5
M=dist.matrix=matrix(sample(c(0,1),nNodes^2,replace=TRUE),nrow=nNodes,ncol=nNodes)
rownames(M)=colnames(M)=paste("R",1:nNodes,sep="")

#distances
dist.matrix[dist.matrix==0]=Inf
dist.matrix=allShortestPaths(dist.matrix)$length 

#avoid infinity and NAs in this test case
dist.matrix[is.na(dist.matrix)]=0
dist.matrix[dist.matrix==Inf]=0

#set iMax
iMax=max(dist.matrix)

#build test list
test.list=list()
test.list[["testGraph"]]=list(nNodes=nNodes, iMax=iMax, M=M)

#a file "testGraph.lp" should be printed
pwLPFiles(test.list)



