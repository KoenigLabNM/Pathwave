### Name: pathWave
### Title: PathWave analysis tool
### Aliases: pathWave
### Keywords: manip graphs optimize

### ** Examples

#build test optimal matrices:
test.opM=list()
test.opM[["test1"]]=list(M=matrix(sample(c(paste("test1:R",1:6,sep=""),rep("0",19))),nrow=5))
test.opM[["test2"]]=list(M=matrix(sample(c(paste("test2:R",7:11,sep=""),rep("0",11))),nrow=4))

#generate test class factor for two classes
test.y=as.factor(c(rep("test.1",20),rep("test.2",20)))

#generate test expression matrix with two classes
test.x1=matrix(rnorm(11*length(test.y)),ncol=length(test.y),dimnames=list(paste("test1:R",1:11,sep=""),paste("sample",1:length(test.y),sep="")))
test.x2=matrix(rnorm(11*length(test.y)),ncol=length(test.y),dimnames=list(paste("test2:R",1:11,sep=""),paste("sample",1:length(test.y),sep="")))

#all reactions of the second class are up-regulated in the first pathway
test.x1[,test.y==levels(test.y)[2]]=test.x1[,test.y==levels(test.y)[2]] + 2

test.x=rbind(test.x1,test.x2)

#build gene list
test.gene=list()
test1.genes=as.character(1:6)
test2.genes=as.character(1:5)
names(test1.genes)=paste("test1:R",1:6,sep="")
names(test2.genes)=paste("test2:R",7:11,sep="")
test.gene[["genes"]]=list(test1=test1.genes,test2=test2.genes)

#start pathwave
test.result=pathWave(test.x,test.y,optimalM=test.opM,pvalCutoff=0.05,genes=test.gene$genes,diffReac=1)



