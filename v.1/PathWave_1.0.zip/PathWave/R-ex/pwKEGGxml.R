### Name: pwKEGGxml
### Title: PathWave parser for KEGG XML files
### Aliases: pwKEGGxml
### Keywords: manip graphs optimize

### ** Examples

kegg.ftp="ftp://ftp.genome.jp/pub/kegg/xml/organisms/hsa/"
keggXml=pwKEGGxml(kegg.ftp)



