### Name: pwOptGrids
### Title: PathWave result file parser for LP solver
### Aliases: pwOptGrids
### Keywords: manip graphs optimize

### ** Examples

library(e1071)
#define number of nodes and generate random adjacency matrix
nNodes=5
M=dist.matrix=matrix(sample(c(0,1),nNodes^2,replace=TRUE),nrow=nNodes,ncol=nNodes)
rownames(M)=colnames(M)=paste("R",1:nNodes,sep="")

#distances
dist.matrix[dist.matrix==0]=Inf
dist.matrix=allShortestPaths(dist.matrix)$length 

#avoid infinity and NAs in this test case
dist.matrix[is.na(dist.matrix)]=0
dist.matrix[dist.matrix==Inf]=0

#set iMax
iMax=max(dist.matrix)

#build test list
test.list=list()
test.list[["testGraph"]]=list(nNodes=nNodes, iMax=iMax, M=M)

#Assuming testGraph should have been arranged on a 4x4 grid
size=4

#write dummy solution file, CAUTION: the numbering will start with 0!
cat(paste("start dummy file","\n",sep=""),file="testGraph.lp.log")

#print dummy distance information - not necessary
for(i in paste("d",rep(0:(nNodes-1),each=nNodes),rep(0:(nNodes-1),times=nNodes),sep="_")){
  cat(paste(i,as.integer(runif(1)*nNodes),sep="   "),file="testGraph.lp.log",append=TRUE,fill=TRUE)
}

#print ordering information for x
val=abs(rnorm(nNodes*size^2))
x.names=as.matrix(expand.grid(paste("x",0:(nNodes-1),sep="_"), 0:(size-1),0:(size-1)))
names(val)=paste(x.names[,1],x.names[,2],x.names[,3],sep="_")

#set the real nodes to value 1 -> every node should be chosen once and should only occupy one grid element alone!
val[diag(sapply(X=1:nNodes,seq,to=nNodes*size^2,by=nNodes)[sample(1:((nNodes*size^2)/nNodes),size=5),])]=1

for(i in 1:length(val)){
  cat(paste(names(val)[i],val[i],sep="   "),file="testGraph.lp.log",append=TRUE,fill=TRUE)         
}

#use pwOptGrids
testOptGrids=pwOptGrids(path=getwd(),adjMatrix=test.list,pattern=".lp.log$")



