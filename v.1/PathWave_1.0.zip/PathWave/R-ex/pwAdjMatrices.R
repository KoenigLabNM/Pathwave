### Name: pwAdjMatrices
### Title: PathWave adjacency matrices builder
### Aliases: pwAdjMatrices
### Keywords: manip graphs optimize

### ** Examples

#read in actual KEGG xml files
kegg.ftp="ftp://ftp.genome.jp/pub/kegg/xml/organisms/hsa/"
keggXml=pwKEGGxml(kegg.ftp)

#build adjacency matrices
adjacencyMatrices=pwAdjMatrices(reactionList=keggXml$reactions,compoundList=keggXml$compounds,printMatrices=FALSE)



